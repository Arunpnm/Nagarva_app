// Export pages
export '/login_page/login_page_widget.dart' show LoginPageWidget;
export '/login_page/pin_login_page_widget.dart' show PinLoginPageWidget;
export '/login_page/org_binding_page_widget.dart' show OrgBindingPageWidget;
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/orders_page/orders_page_widget.dart' show OrdersPageWidget;
export '/leads_page/leads_page_widget.dart' show LeadsPageWidget;
export '/operations_page/operations_page_widget.dart' show OperationsPageWidget;
export '/payments_page/payments_page_widget.dart' show PaymentsPageWidget;
export '/expense_page/expense_page_widget.dart' show ExpensePageWidget;
export '/salary_page/salary_page_widget.dart' show SalaryPageWidget;
export '/fleet_page/fleet_page_widget.dart' show FleetPageWidget;
export '/quotation_page/survey_quote_page_widget.dart'
    show SurveyQuotePageWidget;
export '/accounts_page/accounts_page_widget.dart' show AccountsPageWidget;
export '/p_l_report_page/p_l_report_page_widget.dart' show PLReportPageWidget;
export '/settings_page/recycle_bin_page.dart' show RecycleBinPage;
export '/settings_page/help_about_page.dart' show HelpAboutPage;
export '/settings_page/survey_pricing_page.dart' show SurveyPricingPage;
export '/settings_page/branches_page.dart' show BranchesPage;
export '/settings_page/settings_page_widget.dart' show SettingsPageWidget;
export '/calendar_page/calendar_page_widget.dart' show CalendarPageWidget;
export '/materials_page/materials_page_widget.dart' show MaterialsPageWidget;
export '/warehouses_page/warehouses_page_widget.dart' show WarehousesPageWidget;
export '/reviews_page/reviews_page_widget.dart' show ReviewsPageWidget;
export '/wa_inbox_page/wa_inbox_page_widget.dart' show WaInboxPageWidget;
export '/survey_quote_hub_page/survey_quote_hub_page_widget.dart'
    show SurveyQuoteHubPageWidget;
export '/rate_cards_page/rate_cards_page_widget.dart' show RateCardsPageWidget;
export '/rate_cards_page/rate_card_detail_page_widget.dart'
    show RateCardDetailPageWidget;
export '/lr_register_page/lr_register_page_widget.dart'
    show LrRegisterPageWidget;
export '/operations_standalone_page/operations_standalone_page_widget.dart'
    show OperationsStandalonePageWidget;
export '/vendors_page/vendors_page_widget.dart' show VendorsPageWidget;
export '/vendors_page/vendor_detail_page_widget.dart'
    show VendorDetailPageWidget;
export '/customers_page/customers_page_widget.dart' show CustomersPageWidget;
export '/customers_page/customer_detail_page_widget.dart'
    show CustomerDetailPageWidget;
export '/insurance_claims_page/insurance_claims_page_widget.dart'
    show InsuranceClaimsPageWidget;
export '/trips_page/trips_page_widget.dart' show TripsPageWidget;
export '/trips_page/trip_detail_page_widget.dart' show TripDetailPageWidget;
export '/tasks_page/tasks_page_widget.dart' show TasksPageWidget;
export '/reports_page/reports_page_widget.dart' show ReportsPageWidget;
export '/users_page/users_page_widget.dart' show UsersPageWidget;
export '/order_journey_page/order_journey_page_widget.dart'
    show OrderJourneyPageWidget, JourneyEntryCard;
export '/record_payment_page/record_payment_page_widget.dart'
    show RecordPaymentPageWidget;
export '/quick_expense_page/quick_expense_page_widget.dart'
    show QuickExpensePageWidget;
export '/new_order_page/new_order_page_widget.dart' show NewOrderPageWidget;
export '/order_detail_page/order_detail_page_widget.dart'
    show OrderDetailPageWidget;
export '/new_lead_page/new_lead_page_widget.dart' show NewLeadPageWidget;
export '/lead_detail_page/lead_detail_page_widget.dart'
    show LeadDetailPageWidget;
export '/quick_entry_page/quick_entry_page_widget.dart'
    show QuickEntryPageWidget;
export '/signup_page/signup_page_widget.dart' show SignupPageWidget;
export '/vendor_signup_page/vendor_signup_page_widget.dart'
    show VendorSignupPageWidget;
export '/set_new_password_page/set_new_password_page_widget.dart'
    show SetNewPasswordPageWidget;
export '/set_owner_pin_page/set_owner_pin_page_widget.dart'
    show SetOwnerPinPageWidget;
export '/org_setup_page/org_setup_page_widget.dart' show OrgSetupPageWidget;
export '/plan_page/plan_page_widget.dart' show PlanPageWidget;
export '/supervisor_job_page/supervisor_job_page_widget.dart'
    show SupervisorJobPageWidget;
export '/supervisor_jobs_page/supervisor_jobs_page_widget.dart'
    show SupervisorJobsListPageWidget;
export '/supervisor_entry_page/supervisor_entry_page_widget.dart'
    show SupervisorEntryPageWidget;
export '/supervisor_team_page/supervisor_team_page_widget.dart'
    show SupervisorTeamPageWidget;
export '/supervisor_earnings_page/supervisor_earnings_page_widget.dart'
    show SupervisorEarningsPageWidget;
export '/supervisor_attendance_page/supervisor_attendance_page_widget.dart'
    show SupervisorAttendancePageWidget;
export '/sign_page/sign_page_widget.dart' show SignPageWidget;
export '/track_page/track_page_widget.dart' show TrackPageWidget;
export '/super_admin_page/super_admin_page_widget.dart'
    show SuperAdminPageWidget;
export '/crew_sheet_page/crew_sheet_page_widget.dart' show CrewSheetPageWidget;

// Design-parity modules (21 Oct 2026).
export '/modules/sales_modules.dart';
export '/modules/money_modules.dart';
export '/modules/transport_modules.dart';
export '/modules/ops_people_modules.dart';
export '/modules/setup_modules.dart';
export '/modules/more_modules.dart';
export '/whatsapp/whatsapp_page.dart';
export '/settings_page/modules_page.dart';
export '/settings_page/dashboard_widgets_page.dart';
export '/settings_page/quote_design_page.dart';
export '/driver_app_page/driver_app_page_widget.dart';
export '/field_attendance_page/field_attendance_page_widget.dart';
export '/marketplace_page/marketplace_jobs_page.dart';
export '/super_admin_page/admin_login_page.dart';
