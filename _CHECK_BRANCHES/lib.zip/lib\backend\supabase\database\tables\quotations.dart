import '../database.dart';

class QuotationsTable extends SupabaseTable<QuotationsRow> {
  @override
  String get tableName => 'quotations';

  @override
  QuotationsRow createRow(Map<String, dynamic> data) => QuotationsRow(data);
}

class QuotationsRow extends SupabaseDataRow {
  QuotationsRow(super.data);

  @override
  SupabaseTable get table => QuotationsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  // Added Phase 1 multi-tenancy pass — see supabase/phase1_add_org_id.sql.
  String? get orgId => getField<String>('org_id');
  set orgId(String? value) => setField<String>('org_id', value);

  String? get leadId => getField<String>('lead_id');
  set leadId(String? value) => setField<String>('lead_id', value);

  String? get customer => getField<String>('customer');
  set customer(String? value) => setField<String>('customer', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get fromAddress => getField<String>('from_address');
  set fromAddress(String? value) => setField<String>('from_address', value);

  String? get toAddress => getField<String>('to_address');
  set toAddress(String? value) => setField<String>('to_address', value);

  int? get fromFloor => getField<int>('from_floor');
  set fromFloor(int? value) => setField<int>('from_floor', value);

  int? get toFloor => getField<int>('to_floor');
  set toFloor(int? value) => setField<int>('to_floor', value);

  dynamic get items => getField<dynamic>('items');
  set items(dynamic value) => setField<dynamic>('items', value);

  dynamic get charges => getField<dynamic>('charges');
  set charges(dynamic value) => setField<dynamic>('charges', value);

  // Item 12C (20260817_item12c_package_columns.sql). `suggested_vehicle`
  // and `total_cft` pre-existed the migration but had no getters here —
  // the same Dart-class-lags-live-schema gap this codebase has hit
  // repeatedly (see trips/rate_cards/tasks, 17 Aug 2026). `total_cft` is
  // read as num, not int: the migration widens it to numeric because the
  // survey builder can produce a fractional total.
  String? get suggestedPackage => getField<String>('suggested_package');
  set suggestedPackage(String? value) =>
      setField<String>('suggested_package', value);

  String? get suggestedVehicle => getField<String>('suggested_vehicle');
  set suggestedVehicle(String? value) =>
      setField<String>('suggested_vehicle', value);

  int? get suggestedCrew => getField<int>('suggested_crew');
  set suggestedCrew(int? value) => setField<int>('suggested_crew', value);

  String? get chosenPackage => getField<String>('chosen_package');
  set chosenPackage(String? value) =>
      setField<String>('chosen_package', value);

  String? get chosenVehicle => getField<String>('chosen_vehicle');
  set chosenVehicle(String? value) =>
      setField<String>('chosen_vehicle', value);

  int? get chosenCrew => getField<int>('chosen_crew');
  set chosenCrew(int? value) => setField<int>('chosen_crew', value);

  double? get totalCft => getField<double>('total_cft');
  set totalCft(double? value) => setField<double>('total_cft', value);

  double? get subtotal => getField<double>('subtotal');
  set subtotal(double? value) => setField<double>('subtotal', value);

  double? get gstPct => getField<double>('gst_pct');
  set gstPct(double? value) => setField<double>('gst_pct', value);

  double? get gstAmount => getField<double>('gst_amount');
  set gstAmount(double? value) => setField<double>('gst_amount', value);

  double? get total => getField<double>('total');
  set total(double? value) => setField<double>('total', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  // Added by supabase/20260725_survey_quote_flow.sql (item 8, CORE V1) —
  // customer-facing share link + e-sign acceptance tracking.
  String? get token => getField<String>('token');
  set token(String? value) => setField<String>('token', value);

  String? get surveyId => getField<String>('survey_id');
  set surveyId(String? value) => setField<String>('survey_id', value);

  DateTime? get acceptedAt => getField<DateTime>('accepted_at');
  set acceptedAt(DateTime? value) => setField<DateTime>('accepted_at', value);

  String? get acceptedByName => getField<String>('accepted_by_name');
  set acceptedByName(String? value) =>
      setField<String>('accepted_by_name', value);

  /// Quote version — the live pointer into `quote_versions`.
  ///
  /// CORRECTED 11 Sept 2026. This comment read "the column does NOT
  /// exist yet ... so this returns null today" and was wrong on both
  /// counts: the column is `integer` and every live row carries `1`
  /// (counted, all 7 quotations). The claim had stood long enough to be
  /// worth naming — a stale "does not exist" is what sends the next
  /// session to build something twice.
  ///
  /// `revise_quote()` is the only writer. It advances this to the
  /// version number of the row it just wrote into `quote_versions`, so
  /// the two can be read together: `version` is where the quote is now,
  /// `quote_versions` is how it got there.
  ///
  /// A quote that has never been revised sits at 1 with NO version rows
  /// at all — history is written lazily, so an empty history means
  /// "never revised", not "history lost". See the lazy version-1
  /// backfill in supabase/20260911_revise_quote_rpc.sql.
  int? get version => getField<int>('version');

  // Added by nagarva_migration_009_documents (Session 3) — consignment
  // characteristics and survey-derived answers printed on the quotation.
  DateTime? get packingDate => getField<DateTime>('packing_date');
  set packingDate(DateTime? value) =>
      setField<DateTime>('packing_date', value);

  DateTime? get deliveryDate => getField<DateTime>('delivery_date');
  set deliveryDate(DateTime? value) =>
      setField<DateTime>('delivery_date', value);

  DateTime? get movingDate => getField<DateTime>('moving_date');
  set movingDate(DateTime? value) => setField<DateTime>('moving_date', value);

  String? get loadType => getField<String>('load_type');
  set loadType(String? value) => setField<String>('load_type', value);

  String? get vehicleType => getField<String>('vehicle_type');
  set vehicleType(String? value) => setField<String>('vehicle_type', value);

  String? get transportMode => getField<String>('transport_mode');
  set transportMode(String? value) =>
      setField<String>('transport_mode', value);

  bool? get fromHasLift => getField<bool>('from_has_lift');
  set fromHasLift(bool? value) => setField<bool>('from_has_lift', value);

  bool? get toHasLift => getField<bool>('to_has_lift');
  set toHasLift(bool? value) => setField<bool>('to_has_lift', value);

  /// "@{fov_pct}% On Declaration Value Of Goods ({declared_value}/-)"
  double? get declaredValue => getField<double>('declared_value');
  set declaredValue(double? value) =>
      setField<double>('declared_value', value);

  double? get fovPct => getField<double>('fov_pct');
  set fovPct(double? value) => setField<double>('fov_pct', value);

  double? get fovAmount => getField<double>('fov_amount');
  set fovAmount(double? value) => setField<double>('fov_amount', value);

  bool? get easyAccess => getField<bool>('easy_access');
  set easyAccess(bool? value) => setField<bool>('easy_access', value);

  bool? get accessRestrictions => getField<bool>('access_restrictions');
  set accessRestrictions(bool? value) =>
      setField<bool>('access_restrictions', value);

  String? get accessNotes => getField<String>('access_notes');
  set accessNotes(String? value) => setField<String>('access_notes', value);
}
