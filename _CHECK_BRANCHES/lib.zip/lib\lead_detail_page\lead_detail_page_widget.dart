import '/components/ng_widgets.dart';
import '/order_journey_page/order_journey_page_widget.dart';
import '/backend/whatsapp_cloud.dart';
import '/backend/order_journey.dart';
import '/app_session.dart';
import '/config/app_config.dart';
import '/permissions.dart';
import '/backend/customer_lookup.dart';
import '/backend/gst_state_codes.dart';
import '/backend/lead_status.dart';
import '/components/detail_row.dart';
import '/components/lead_status_strip.dart';
import '/backend/reminders_service.dart';
import '/backend/signature_service.dart';
import '/backend/soft_delete.dart';
import '/components/delete_action.dart';
import '/backend/lead_stage_evidence.dart';
import '/components/reminders_section.dart';
import '/backend/tracking_service.dart';
import '/components/share_link_sheet.dart';
import '/components/survey_response_section.dart';
import '/backend/pricing_defaults.dart';
import '/backend/quote_design.dart';
import '/components/pdf_branding.dart';
import '/components/survey_pdf.dart';
import '/components/quote_pdf.dart';
import '/backend/supabase/supabase.dart';
import '/backend/supabase/org_scope.dart';
import '/backend/issued_documents.dart';
import '/flutter_flow/ng_tokens.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/l10n/gen/app_localizations.dart';
import '/backend/detail_navigation.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';
import 'lead_detail_page_model.dart';
import '/backend/vendor_identity.dart';
import '/backend/order_id_allocator.dart';
export 'lead_detail_page_model.dart';

/// Read-only view of a single lead with convert-to-order action.
class LeadDetailPageWidget extends StatefulWidget {
  const LeadDetailPageWidget({
    super.key,
    this.leadId,
    this.leadCustomer,
    this.leadPhone,
    this.leadEmail,
    this.leadFromCity,
    this.leadToCity,
    this.leadApproxDate,
    this.leadService,
    this.leadSource,
    this.leadStatus,
    this.leadBranch,
    this.leadNotes,
    this.surveyQuoteOnly = false,
    this.onChanged,
  });

  /// Builds the widget for one lead from its row, as the Leads list does.
  factory LeadDetailPageWidget.fromLead(LeadsRow l,
          {Key? key, bool surveyQuoteOnly = false, VoidCallback? onChanged}) =>
      LeadDetailPageWidget(
        key: key,
        leadId: l.id,
        leadCustomer: l.customer,
        leadPhone: l.phone,
        leadEmail: l.email,
        leadFromCity: l.fromCity,
        leadToCity: l.toCity,
        leadApproxDate: l.approxDate,
        leadService: l.service,
        leadSource: l.source,
        leadStatus: l.status,
        leadBranch: l.branch,
        leadNotes: l.notes,
        surveyQuoteOnly: surveyQuoteOnly,
        onChanged: onChanged,
      );

  final String? leadId;
  final String? leadCustomer;
  final String? leadPhone;
  final String? leadEmail;
  final String? leadFromCity;
  final String? leadToCity;
  final String? leadApproxDate;
  final String? leadService;
  final String? leadSource;
  final String? leadStatus;
  final String? leadBranch;
  final String? leadNotes;

  /// The order journey's Survey and Quote stages embed this page with
  /// [surveyQuoteOnly]: just the Survey & Quote card, no scaffold, so the
  /// survey request, quote, revisions, signature and convert-to-order run
  /// on the one copy of that logic. [onChanged] fires after it reloads
  /// following a change, and in place of opening Order Details once an
  /// order is created.
  final bool surveyQuoteOnly;
  final VoidCallback? onChanged;

  static String routeName = 'LeadDetailPage';
  static String routePath = '/lead-detail';

  @override
  State<LeadDetailPageWidget> createState() => _LeadDetailPageWidgetState();
}

class _LeadDetailPageWidgetState extends State<LeadDetailPageWidget>
    with RefreshOnPopMixin<LeadDetailPageWidget> {
  late LeadDetailPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  bool _converting = false;

  // Refresh-after-write fix (parity brief Part 1): re-run when a pushed
  // route (Request Survey / Create Quote share-link dialogs, or Edit Lead)
  // is popped back to this page, so the Survey & Quote section reflects
  // newly-created rows without needing a full back-and-forth to LeadsPage.
  @override
  void onPageRefresh() {
    _loadLinked();
    _loadJourney();
    // Item 10.7: reminders added/completed in a pushed route or sheet must
    // show immediately too.
    _remindersKey.currentState?.reload();
  }

  // ---- Item 8 (CORE V1): Survey -> Quotation -> Order flow ---------------
  // See supabase/20260725_survey_quote_flow.sql for the scope assumption.
  // Deliberately scoped to this one file rather than also modifying
  // quotation_page_widget.dart (a large, separate standalone quote-
  // creation form that still works fine on its own for ad-hoc quotes not
  // tied to a lead) — this is a simpler, self-contained lead-linked path:
  // request a survey, get a quote back with a single total (not a full
  // line-item builder), share it, convert once accepted.
  SurveysRow? _survey;
  QuotationsRow? _quotation;

  // ---- Part 1: quote revision history -----------------------------------
  // Every quote on this lead, newest-first, as loaded. `_quotation` is one
  // OF these, chosen by _pickBestQuote — which is a silent selection, and
  // silence is the problem: before this list existed the page showed one
  // quote and never admitted the others were there. A manager revising
  // "the quote" with a second one present had no way to know.
  //
  // Live count on 11 Sept 2026: 7 quotations, one per lead, none doubled.
  // So this is prevention, not a fix for something happening today.
  List<QuotationsRow> _quotesOnLead = const [];

  /// Revision history for `_quotation`, newest version first.
  ///
  /// EMPTY MEANS NEVER REVISED, not "history missing" — `revise_quote()`
  /// writes version 1 lazily at the first revision, so an unrevised quote
  /// legitimately has no rows at all. Rendered as "no revisions yet",
  /// never as an error.
  List<QuoteVersionsRow> _quoteVersions = const [];
  bool _loadingVersions = false;
  bool _revisingQuote = false;

  /// Evidence for the pipeline's ORDER stage: a live order against any of
  /// this lead's quotes. Read rather than inferred, for the same reason
  /// the survey and quote stages are — see [LeadStageEvidence].
  bool _hasOrder = false;
  // Session 4, A1/A2: the constructor's leadXxx params are a nav-time
  // snapshot and don't carry every column the field table/auto-creation
  // note need (from_floor/to_floor/package_type/packing_type/notes aren't
  // nav params at all) — this is the live row, re-read alongside
  // surveys/quotations below. Every A1/A2 read prefers `_lead?.x` and
  // falls back to the matching `widget.x` so the page still renders
  // something sensible if this fetch fails.
  LeadsRow? _lead;
  bool _loadingLinked = true;
  bool _requestingSurvey = false;
  bool _convertingQuote = false;

  // ---- Item 5: lead status pipeline ------------------------------------
  // Seeded from the nav param so the strip renders instantly, then
  // refreshed from the DB in _loadLinked (the param is a snapshot from
  // whenever LeadsPage last loaded and can be stale).
  String? _status;
  bool _savingStatus = false;

  // ---- Item 3: signature on the quote ----------------------------------
  SignatureRequest? _quoteSignature;
  bool _sendingQuoteSignature = false;

  // ---- Part 8 addendum item 2: Survey/Quote PDF export ------------------
  bool _downloadingSurveyPdf = false;
  bool _downloadingQuotePdf = false;

  // ---- Item 10: reminders ----------------------------------------------
  final _remindersKey = GlobalKey<RemindersSectionState>();

  /// Drives the journey strip and the Activity list (follow-up logs).
  JourneyData? _journey;

  Future<void> _loadJourney() async {
    final id = widget.leadId;
    if (id == null || id.isEmpty) return;
    try {
      final d = await JourneyLoader.load(leadId: id);
      if (mounted) setState(() => _journey = d);
    } catch (_) {
      // The strip falls back to its plain title.
    }
  }
  bool _deleting = false;

  String get _canonicalStatus => canonicalLeadStatus(_status);

  /// Writes [target] to the lead, never downgrading (item 5.2: "Never
  /// auto-downgrade"). Pass [force] for an explicit manual chip tap, which
  /// is allowed to move the lead backwards or to `lost`.
  Future<void> _setLeadStatus(String target, {bool force = false}) async {
    if (widget.leadId == null) return;
    final next =
        force ? canonicalLeadStatus(target) : advanceLeadStatus(_status, target);
    if (next == _canonicalStatus) return;
    final previous = _status;
    setState(() {
      _status = next;
      _savingStatus = true;
    });
    try {
      await LeadsTable().update(
        data: {'status': next},
        matchingRows: (q) => OrgScope.write(q).eq('id', widget.leadId!),
      );
    } catch (e) {
      // Roll the optimistic update back so the strip can't show a stage
      // the database never accepted.
      if (mounted) {
        setState(() => _status = previous);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not update status: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _savingStatus = false);
    }
  }

  /// "Convert to Order" used to just navigate to a blank NewOrderPage,
  /// discarding all the lead's data and never marking the lead as
  /// converted (so it could never show up as a win in PLReportPage's lead
  /// source conversion rate, which checks leads.status == 'confirmed').
  /// Fixed to actually create the order from the lead's fields and flip
  /// the lead's status. Amount isn't known from a lead, so the order is
  /// created with amount 0 / status 'booked' — the office still needs to
  /// fill in the real quote via Edit Order once that flow exists (see
  /// CLAUDE.md's OrderDetailPage/NewOrderPage edit-mode gap).
  /// Generates a human-readable order id like NGV-1007. orders.id is TEXT
  /// (not uuid) and has NOT-NULL / no default, so the insert crashes with
  /// 23502 unless we supply one. Counter lives in the settings table, per-
  /// org, with the same PK convention as _nextInvoiceNo on OrderDetailPage.

  /// The one place an order is created from a lead.
  ///
  /// Live-test fix brief #2, item 2: there used to be two near-identical
  /// copies of this insert — `_convertToOrder` (plain "Convert to Order"
  /// button) and `_convertQuoteToOrder` (the Survey & Quote section's
  /// button). Only the second one was ever taught about quotes, and even
  /// it only copied the *total*: it never set `quotation_id`, so
  /// `QuotationBreakdownSection` on Order Details (which resolves the
  /// order's linked quotation to render item lines, charges and GST)
  /// always found null and rendered nothing. That is the reported
  /// "detailed quote data not carried into the order".
  ///
  /// Both buttons now funnel through here, so a future change can't teach
  /// one path about quotes and silently miss the other.
  ///
  /// No schema change was needed: `orders` already has `quotation_id`,
  /// `from_address`, `to_address`, `from_floor`, `to_floor`, and the item
  /// lines / charge lines / GST split live on the linked `quotations` row
  /// (jsonb `items` + `charges`, plus `gst_pct`/`gst_amount`) rather than
  /// being duplicated onto the order.
  Future<void> _createOrderFromLead({
    required QuotationsRow? quote,
    required String successMessage,
    required String errorPrefix,
    // Session 4, A5: the Confirm Order sheet lets the office edit these
    // before creating the order (pre-filled from the lead, but the lead
    // may be stale or missing fields the office knows at booking time).
    // Every override defaults to the same widget.*/quote fallback this
    // method already used, so the existing quote-based conversion paths
    // (_convertToOrder / _convertQuoteToOrder) are unaffected.
    String? overrideCustomer,
    String? overridePhone,
    String? overrideFromCity,
    String? overrideToCity,
    DateTime? overrideMoveDate,
    double? overrideAmount,
    String? overrideService,
  }) async {
    if (widget.leadId == null) return;
    try {
      DateTime moveDate = overrideMoveDate ??
          (() {
            try {
              return DateTime.parse(widget.leadApproxDate ?? '');
            } catch (_) {
              return DateTime.now();
            }
          })();

      final customerName =
          overrideCustomer ?? quote?.customer ?? widget.leadCustomer ?? '';
      final phone = overridePhone ?? quote?.phone ?? widget.leadPhone;

      // A5: "Call findOrCreateCustomer so orders.customer_id is set at
      // creation — same helper Quick Payment uses. Do not leave it null."
      // This insert never set customer_id before — every order created
      // from a lead has had a null customer_id until now.
      String? customerId;
      final orgId = OrgScope.currentOrgId;
      if (orgId != null) {
        try {
          customerId = await CustomerLookup.findOrCreate(
            orgId: orgId,
            name: customerName,
            phone: phone,
          );
        } catch (_) {
          // A missing/malformed phone already makes findOrCreate return
          // null by design (see its own doc comment) — any other failure
          // here must not block order creation, just leave customer_id
          // unset same as before this fix.
        }
      }

      final newOrderId = await OrderIdAllocator.next();
      final order = await OrdersTable().insert({
        ...OrgScope.stamp(),
        'id': newOrderId,
        'lead_id': widget.leadId,
        if (customerId != null) 'customer_id': customerId,
        // Link back to the quote so Order Details can render its item
        // lines, and so the invoice can later be generated from the same
        // lines rather than a bare total.
        if (quote != null) 'quotation_id': quote.id,
        'customer': customerName,
        'phone': phone,
        'from_city': overrideFromCity ?? widget.leadFromCity,
        'to_city': overrideToCity ?? widget.leadToCity,
        // Survey/quote captures the full street address and floor; a lead
        // only ever has the city. Prefer the richer values when present.
        if (quote?.fromAddress != null) 'from_address': quote!.fromAddress,
        if (quote?.toAddress != null) 'to_address': quote!.toAddress,
        if (quote?.fromFloor != null) 'from_floor': quote!.fromFloor,
        if (quote?.toFloor != null) 'to_floor': quote!.toFloor,
        'move_date': supaSerialize<DateTime>(moveDate),
        'amount': overrideAmount ?? quote?.total ?? 0.0,
        'service': overrideService ?? widget.leadService,
        'branch': widget.leadBranch,
        'notes': widget.leadNotes,
        'status': 'booked',
        'payment_status': 'pending',
        'tracking_status': 'Booked',
      });

      // Item 2: freeze the quote figures onto the order.
      if (quote != null) {
        await _writeQuoteSnapshot(newOrderId, quote);
      }

      // Item 6: seed the customer-facing tracking timeline at its first
      // stage, so a freshly-converted order already has a "Confirmed"
      // entry with a real timestamp rather than an empty timeline.
      await TrackingService.logStatus(
        orderId: newOrderId,
        status: 'booked',
        note: 'Order confirmed',
      );
      WhatsAppCloud.orderBooked(order);

      // LEAK_AUDIT.md write-gap fix: matched only on id before.
      await LeadsTable().update(
        data: {'status': kLeadStatusConfirmed},
        matchingRows: (q) => OrgScope.write(q).eq('id', widget.leadId!),
      );

      // A5: "link lead.order_id" — SCHEMA GAP, flagged rather than
      // patched: no `leads.order_id` column exists in any migration
      // (grepped 001-010). Best-effort, same pattern as
      // _writeQuoteSnapshot below — never blocks the conversion, which
      // has already committed by this point. Migration handed over
      // separately for Arun to run; the write starts working with no
      // code change once it has.
      try {
        await LeadsTable().update(
          data: {'order_id': newOrderId},
          matchingRows: (q) => OrgScope.write(q).eq('id', widget.leadId!),
        );
      } catch (_) {}

      // Advance the quote out of 'draft' now that it has become a real
      // order. (Arun, 3 Sept 2026.)
      //
      // Without this a won quote stayed `status: 'draft'` with
      // `accepted_at` null FOREVER — verified on APC-COIMBATORE-1001,
      // whose quote still read 'draft' while the order existed and was
      // already in a warehouse. Every quote a vendor ever won would sit
      // in their list looking like an unfinished draft, so the list
      // cannot be used to see what is still outstanding, which is the
      // one thing a quote list is for.
      //
      // The columns were already there and simply never written:
      // `accepted_at` and `accepted_by_name` exist on `quotations`.
      // Recorded against the person who confirmed it, not the customer —
      // this is the vendor accepting on the customer's behalf at the
      // counter, which is what the Confirm Order button means. A
      // customer-side acceptance (via the signature flow) is a different
      // event and sets these itself.
      //
      // Best-effort like the two writes above: the order is already
      // committed by this point, and failing the conversion over a
      // status flag would be worse than a stale one.
      if (quote != null) {
        try {
          await QuotationsTable().update(
            data: {
              'status': 'accepted',
              'accepted_at': supaSerialize<DateTime>(DateTime.now()),
              'accepted_by_name':
                  AppSession.instance.currentStaffName ?? 'Owner',
            },
            matchingRows: (q) => OrgScope.write(q).eq('id', quote.id),
          );
        } catch (_) {}
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(successMessage)),
      );
      // Inside the journey the order appears in the next stages instead.
      if (widget.surveyQuoteOnly) {
        await _loadLinked();
        widget.onChanged?.call();
        return;
      }
      openOrderJourney(context, order);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$errorPrefix: $e')),
      );
    }
  }

  /// Item 2: freezes the quote's figures onto the order at conversion.
  ///
  /// Written as a SEPARATE update rather than folded into the order
  /// insert, deliberately: the snapshot columns arrive in
  /// supabase/20260729_order_quote_snapshot.sql, and if that hasn't been
  /// run yet an insert naming unknown columns would 400 and take the
  /// whole conversion with it. Isolated and swallowed, a missing column
  /// costs the snapshot only — the order, the lead status flip and the
  /// tracking entry all still land. Snapshots start populating by
  /// themselves once the migration runs, with no code change.
  ///
  /// `orders.quotation_id` remains the live link; this is the historic
  /// record of what the order was confirmed on, for when a quote is later
  /// revised (operational flow 1.2) or signed (item 3).
  Future<void> _writeQuoteSnapshot(String orderId, QuotationsRow quote) async {
    try {
      final charges = (quote.charges is Map)
          ? Map<String, dynamic>.from(quote.charges as Map)
          : <String, dynamic>{};

      // Resolve the GST mode NOW. The quote stores '_gstType' = 'auto'
      // when the surveyor let it derive from the from/to cities — but
      // that derivation re-runs against whatever the addresses say
      // later. Freezing 'auto' would re-introduce exactly the drift this
      // snapshot exists to prevent, so resolve it to inter/intra here.
      final rawMode = charges['_gstType'];
      final resolvedMode = (rawMode == 'inter' || rawMode == 'intra')
          ? rawMode as String
          : (isInterState(
                  quote.fromAddress ?? widget.leadFromCity,
                  quote.toAddress ?? widget.leadToCity)
              ? 'inter'
              : 'intra');

      num? asNum(dynamic v) => v is num ? v : num.tryParse('$v');

      await OrdersTable().update(
        data: {
          'quote_items': quote.items,
          'quote_charges': quote.charges,
          'quote_subtotal': quote.subtotal,
          'quote_gst_pct': quote.gstPct,
          'quote_gst_amount': quote.gstAmount,
          'quote_total': quote.total,
          'quote_gst_mode': resolvedMode,
          'quote_packing_type': charges['_suggestedPackage'],
          'quote_total_cft': asNum(charges['_totalCft']),
          // Item 12C: carry the frozen suggestion AND the surveyor's
          // choice onto the order, so a dispatched job holds its own copy
          // rather than joining back to a quotation that may since have
          // been superseded — and so a later slab edit in Settings can
          // never rewrite what this job was actually quoted with.
          // Falls back to the jsonb key for quotes created before the
          // 12C columns existed (those have no vehicle/crew at all).
          'suggested_package': quote.suggestedPackage,
          'suggested_vehicle': quote.suggestedVehicle,
          'suggested_crew': quote.suggestedCrew,
          'chosen_package':
              quote.chosenPackage ?? charges['_suggestedPackage'],
          'chosen_vehicle': quote.chosenVehicle,
          'chosen_crew': quote.chosenCrew,
          // Versioning IS built as of 11 Sept 2026 — this comment used to
          // say "no quotations.version column", which was never true.
          // The column exists and carries a real number, so an order
          // converted from a revised quote now freezes the version it was
          // actually confirmed on rather than always claiming v1. The
          // `?? 1` stays for rows written before the column was populated.
          'quote_version': quote.version ?? 1,
          'quote_snapshot_at': DateTime.now().toUtc().toIso8601String(),
        },
        matchingRows: (q) => OrgScope.write(q).eq('id', orderId),
      );
    } catch (_) {
      // See doc comment — never fail the conversion over the snapshot.
    }
  }

  /// Opens the detailed quote builder seeded from this survey's
  /// submitted selections, so the vendor doesn't re-key what the customer
  /// already entered on the public page.
  void _openQuoteBuilder(SurveysRow survey) {
    context.pushNamed(
      SurveyQuotePageWidget.routeName,
      queryParameters: {
        'surveyId': serializeParam(survey.id, ParamType.String),
        'leadId': serializeParam(widget.leadId, ParamType.String),
        'leadCustomer': serializeParam(
            survey.customerName ?? widget.leadCustomer, ParamType.String),
        'leadPhone': serializeParam(
            survey.customerPhone ?? widget.leadPhone, ParamType.String),
        'leadFromCity': serializeParam(
            survey.fromAddress ?? widget.leadFromCity, ParamType.String),
        'leadToCity': serializeParam(
            survey.toAddress ?? widget.leadToCity, ParamType.String),
      }.withoutNulls,
    );
  }

  /// Session 4, A5 — "Confirm Order (Skip Survey)": must succeed from any
  /// status, with no survey and no quote present. Replaces the old plain
  /// "Convert to Order" button, which created the order silently at
  /// amount 0 with no review step. Opens the minimal order sheet
  /// pre-filled from the lead (and the best available quote, if one
  /// exists — its presence is never required).
  Future<void> _confirmOrder() async {
    if (widget.leadId == null) return;
    setState(() => _converting = true);
    try {
      // Picks up a quote if the lead has one, same re-query as before (a
      // quote built moments ago in another route may not have landed in
      // `_quotation` yet) — purely to pre-fill the sheet's amount field
      // and to link quotation_id; the sheet must still work with none.
      var quote = _quotation;
      try {
        final rows = await QuotationsTable().queryRows(
          queryFn: (q) => OrgScope
              .read(q)
              .eq('lead_id', widget.leadId!)
              .order('created_at', ascending: false),
        );
        quote = _pickBestQuote(rows) ?? quote;
      } catch (_) {}

      if (!mounted) return;
      final lead = _lead;
      final result = await showDialog<_ConfirmOrderResult>(
        context: context,
        builder: (_) => _ConfirmOrderSheet(
          initialCustomer:
              lead?.customer ?? widget.leadCustomer ?? '',
          initialPhone: lead?.phone ?? widget.leadPhone ?? '',
          initialFromCity: lead?.fromCity ?? widget.leadFromCity ?? '',
          initialToCity: lead?.toCity ?? widget.leadToCity ?? '',
          initialService: lead?.service ?? widget.leadService ?? '',
          initialAmount: quote?.total ?? 0,
          initialMoveDate: () {
            try {
              return DateTime.parse(
                  lead?.approxDate ?? widget.leadApproxDate ?? '');
            } catch (_) {
              return DateTime.now();
            }
          }(),
        ),
      );
      if (result == null) return;

      await _createOrderFromLead(
        quote: quote,
        successMessage: quote == null
            ? 'Order confirmed'
            : 'Order confirmed (quote attached)',
        errorPrefix: 'Could not confirm order',
        overrideCustomer: result.customer,
        overridePhone: result.phone,
        overrideFromCity: result.fromCity,
        overrideToCity: result.toCity,
        overrideMoveDate: result.moveDate,
        overrideAmount: result.amount,
        overrideService: result.service,
      );
    } finally {
      if (mounted) setState(() => _converting = false);
    }
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LeadDetailPageModel());
    _status = widget.leadStatus;
    _loadLinked();
    _loadJourney();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  /// Set after the first load, so [LeadDetailPageWidget.onChanged] fires
  /// on reloads only, not on opening.
  bool _linkedLoadedOnce = false;

  Future<void> _loadLinked() async {
    if (widget.leadId == null) {
      setState(() => _loadingLinked = false);
      return;
    }
    try {
      // Live-test fix brief #2 item 2: both of these used to take
      // `rows.first` off an UNORDERED query, so with more than one survey
      // or quote on a lead the page showed (and Convert to Order used) an
      // arbitrary row — in practice often the older, simpler one. That is
      // the main reason a freshly-built detailed quote appeared to be
      // "lost" on conversion. Now explicitly newest-first.
      final surveys = await SurveysTable().queryRows(
        queryFn: (q) => OrgScope
            .read(q)
            .eq('lead_id', widget.leadId!)
            .order('created_at', ascending: false),
      );
      final quotations = await QuotationsTable().queryRows(
        queryFn: (q) => OrgScope
            .read(q)
            .eq('lead_id', widget.leadId!)
            .order('created_at', ascending: false),
      );
      // The nav param is a snapshot from whenever LeadsPage last loaded —
      // re-read so the progress strip reflects reality (e.g. the customer
      // submitted the survey since this page was opened).
      final leads = await LeadsTable().queryRows(
        queryFn: (q) => OrgScope.read(q).eq('id', widget.leadId!),
      );

      if (!mounted) return;
      // Evidence for the ORDER stage. `orders.quotation_id` is the live
      // link from a converted quote, so an order exists for this lead
      // when one references any of its quotes. A cancelled or deleted
      // order is not evidence the job happened.
      var hasOrder = false;
      final quoteIds =
          quotations.map((q) => q.id).whereType<String>().toList();
      if (quoteIds.isNotEmpty) {
        try {
          final orders = await OrdersTable().queryRows(
            queryFn: (q) => OrgScope.read(q).inFilter('quotation_id', quoteIds),
          );
          hasOrder = orders.any((o) => (o.status ?? '') != 'cancelled');
        } catch (_) {
          // Supplemental. A failure understates progress rather than
          // inventing it — the safe direction, per LeadStageEvidence.
        }
      }

      setState(() {
        _survey = surveys.isNotEmpty ? surveys.first : null;
        _quotesOnLead = quotations;
        _hasOrder = hasOrder;
        _quotation = _pickBestQuote(quotations);
        if (leads.isNotEmpty) {
          _lead = leads.first;
          _status = leads.first.status;
        }
        _loadingLinked = false;
      });

      // Item 3: refresh-after-write for the signature chip. The customer
      // signs on their own phone, so this reconcile-on-load is the only
      // way the chip ever flips from Awaiting to Signed.
      final quote = _quotation;
      if (quote != null) {
        try {
          final sig = await SignatureService.find(
            documentType: 'quote',
            documentId: quote.id,
          );
          if (mounted) setState(() => _quoteSignature = sig);
        } catch (_) {
          // Supplemental — never blank the page over this.
        }

        // Part 1: revision history. Same shape and same place as the
        // signature reconcile above — guarded on a quote existing,
        // best-effort, and never allowed to blank the page.
        await _loadQuoteVersions(quote.id);
      }

      // Item 5.2 auto-transitions, reconciled on every load rather than
      // only at the moment of the action: a customer submitting the survey
      // happens on their phone, so there is no in-app event to hook. This
      // catches up whenever the page is opened or refreshed. advanceOnly
      // semantics mean a lead already further along is never pulled back.
      await _reconcileStatusFromProgress();
      if (_linkedLoadedOnce) widget.onChanged?.call();
      _linkedLoadedOnce = true;
    } catch (_) {
      if (mounted) setState(() => _loadingLinked = false);
    }
  }

  /// Loads the revision history for [quoteId], newest version first.
  ///
  /// Read-only: `quote_versions` has exactly one writer, `revise_quote()`,
  /// and it is in Postgres. Nothing here ever inserts.
  ///
  /// A failure clears nothing and shows nothing — the history is
  /// supplemental to a page whose primary job is the lead. Losing it must
  /// not cost the manager the customer's phone number.
  Future<void> _loadQuoteVersions(String? quoteId) async {
    if (quoteId == null) return;
    if (mounted) setState(() => _loadingVersions = true);
    try {
      final rows = await QuoteVersionsTable().queryRows(
        queryFn: (q) => OrgScope
            .read(q)
            .eq('quote_id', quoteId)
            .order('version', ascending: false),
      );
      if (mounted) {
        setState(() {
          _quoteVersions = rows;
          _loadingVersions = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingVersions = false);
    }
  }

  /// Opens the detailed builder on an EXISTING quote and, if it saved a
  /// revision, re-reads the row and its history.
  ///
  /// Deliberately does not call `revise_quote()` itself. The builder owns
  /// the snapshot — it is the only thing that knows the complete priced
  /// state — and the RPC takes the whole snapshot or nothing. A second
  /// caller assembling a partial one here is exactly the shape the RPC
  /// was written to make impossible.
  ///
  /// After a successful revision the whole row is re-read rather than
  /// hand-patched: the RPC writes `version` and, on an unaccepted quote,
  /// `status`, and a trigger may touch more. Listing the fields we think
  /// changed is a bet that loses quietly.
  Future<void> _reviseQuote(QuotationsRow quotation) async {
    setState(() => _revisingQuote = true);
    try {
      final saved = await context.pushNamed<bool>(
        SurveyQuotePageWidget.routeName,
        queryParameters: {
          'quotationId': serializeParam(quotation.id, ParamType.String),
          'leadId': serializeParam(widget.leadId, ParamType.String),
        }.withoutNulls,
      );
      if (saved == true) await _loadLinked();
    } finally {
      if (mounted) setState(() => _revisingQuote = false);
    }
  }

  /// Shows the stored customer signature.
  ///
  /// Reads the bytes already held on the loaded request — no fetch, so it
  /// cannot fail halfway and leave a dialog with a spinner in it. The
  /// caller only offers this when [SignatureRequest.signatureBytes]
  /// decodes, so there is no empty state to design.
  void _showSignature(SignatureRequest sig) {
    final bytes = sig.signatureBytes;
    if (bytes == null) return;
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Signed by ${sig.customerName ?? 'customer'}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (sig.signedAt != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  DateFormat('d MMM yyyy, h:mm a')
                      .format(sig.signedAt!.toLocal()),
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                border: Border.all(
                    color: NgPalette.of(context).w08),
                borderRadius: BorderRadius.circular(8),
                // The pad captures dark ink on white. Painting a white
                // ground here keeps it legible in dark mode instead of
                // black-on-black.
                color: Colors.white,
              ),
              child: Image.memory(bytes, fit: BoxFit.contain),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  /// Switches which quote the page is showing, when a lead carries more
  /// than one. Re-reads that quote's history — the panel must never show
  /// one quote's header over another quote's versions.
  Future<void> _selectQuote(QuotationsRow quote) async {
    setState(() {
      _quotation = quote;
      _quoteVersions = const [];
      _quoteSignature = null;
    });
    await _loadQuoteVersions(quote.id);
    try {
      final sig = await SignatureService.find(
        documentType: 'quote',
        documentId: quote.id,
      );
      if (mounted) setState(() => _quoteSignature = sig);
    } catch (_) {}
  }

  /// Derives the stage implied by the survey/quote rows and advances the
  /// lead to it if it is further along than where the lead currently sits.
  Future<void> _reconcileStatusFromProgress() async {
    final survey = _survey;
    final quote = _quotation;
    String? implied;
    if (survey != null) {
      implied = kLeadStatusFollowUp;
      if (survey.submittedAt != null) implied = kLeadStatusSurveyDone;
    }
    if (quote != null) implied = kLeadStatusQuoted;
    if (implied == null) return;
    if (advanceLeadStatus(_status, implied) == _canonicalStatus) return;
    await _setLeadStatus(implied);
  }

  /// "Detailed quote takes precedence over simple quote if both exist"
  /// (fix brief #2, item 2). [rows] must already be newest-first.
  ///
  /// A detailed quote (SurveyQuotePageWidget) writes a non-empty `items`
  /// list; the simple one-total quote created from this page's own "Create
  /// Quote" dialog writes `items: []`. So: newest quote that actually has
  /// line items, else just the newest quote of any kind.
  static QuotationsRow? _pickBestQuote(List<QuotationsRow> rows) {
    if (rows.isEmpty) return null;
    for (final r in rows) {
      if (r.items is List && (r.items as List).isNotEmpty) return r;
    }
    return rows.first;
  }

  // Was '${Uri.base.origin}$path?token=$token' — threw "Bad state: Origin is
  // only applicable schemes http and https: file:///" on a real APK, where
  // Uri.base is file:/// rather than the page URL it is on web. See
  // kPublicBaseUrl's doc comment in lib/config/app_config.dart.
  String _shareLink(String path, String token) => buildTokenLink(path, token);

  /// Survey link out to the customer. Was a copy-only dialog; now the
  /// shared sheet — WhatsApp on this phone, or straight from the vendor's
  /// own WhatsApp number once the survey-link template is approved.
  void _showLinkDialog(String title, String link) {
    final name = widget.leadCustomer;
    ShareLinkSheet.show(
      context,
      title: title,
      subtitle: 'The customer lists what they are moving. It takes about '
          'five minutes and needs no login.',
      link: link,
      phone: widget.leadPhone,
      message: 'Hello${(name ?? '').isEmpty ? '' : ' $name'}, this is '
          '${VendorIdentity.forSentence}. Please list the items you are '
          'moving here:',
      cloud: WaCloudSend('survey_link',
          params: {'customer_name': name ?? '', 'survey_link': link},
          entityType: 'lead',
          entityId: widget.leadId),
    );
  }

  Future<void> _requestSurvey() async {
    if (widget.leadId == null) return;
    setState(() => _requestingSurvey = true);
    try {
      // Carry the ROUTE and the DATE onto the survey, not just the name.
      //
      // Found in the 6 Sept 2026 live run: the customer page rendered
      // "Pickup -> Drop" with no date, because this insert wrote only
      // name and phone. `public_get_survey` returns from_address,
      // to_address and move_date, and the page renders all three - so
      // three fields the vendor had already captured were dropped on the
      // way out, and the customer was shown placeholder labels instead
      // of their own move.
      //
      // The lead's ADDRESS fields are frequently blank at this stage (the
      // New Lead form captures cities, and the full address arrives with
      // the survey), so the city is the fallback rather than the other
      // way round: a city is what the vendor actually has when the link
      // is sent.
      String? orBlank(String? v) =>
          (v == null || v.trim().isEmpty) ? null : v.trim();
      final from = orBlank(_lead?.fromAddress) ?? orBlank(widget.leadFromCity);
      final to = orBlank(_lead?.toAddress) ?? orBlank(widget.leadToCity);
      final row = await SurveysTable().insert({
        ...OrgScope.stamp(),
        'lead_id': widget.leadId,
        'customer_name': widget.leadCustomer,
        'customer_phone': widget.leadPhone,
        if (from != null) 'from_address': from,
        if (to != null) 'to_address': to,
        if (orBlank(widget.leadApproxDate) != null)
          'move_date': widget.leadApproxDate,
      });
      setState(() => _survey = row);
      // Item 5.2: sending a survey moves the lead to at least follow_up.
      await _setLeadStatus(kLeadStatusFollowUp);
      // Item 10.4: chase the survey if the customer doesn't fill it in.
      await RemindersService.autoCreate(
        entityType: kEntityLead,
        entityId: widget.leadId!,
        title: 'Survey follow-up: ${widget.leadCustomer ?? 'customer'}',
        days: kDefaultSurveyFollowUpDays,
      );
      _remindersKey.currentState?.reload();
      if (!mounted) return;
      _showLinkDialog('Survey link — share with the customer',
          _shareLink('/survey', row.token));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not create survey link: $e')),
      );
    } finally {
      if (mounted) setState(() => _requestingSurvey = false);
    }
  }

  /// Item 5.3 / Session 4 A3: `lost` requires a confirm dialog + optional
  /// reason. The reason now goes into `quote_outcomes` (migration 004 —
  /// outcome/reason_code/reason_note/competitor_name/competitor_price),
  /// not appended to the lead's notes as free text — that table exists
  /// specifically for this ("won/lost outcome with competitor
  /// intelligence") and was never written to from anywhere in the app.
  /// No generated Dart class exists for it (same as lr_register/receipts
  /// before their own Session 3 classes) — raw client insert, same
  /// established pattern.
  Future<void> _confirmMarkLost() async {
    final result = await showDialog<_LostReasonResult>(
      context: context,
      builder: (_) => const _LostReasonDialog(),
    );
    if (result == null) return;

    await _setLeadStatus(kLeadStatusLost, force: true);
    if (!mounted || _canonicalStatus != kLeadStatusLost) return;

    // Only written once the status change itself has landed — same
    // "don't record intent that never happened" rule the old notes-append
    // version followed.
    try {
      final orgId = OrgScope.currentOrgId;
      await SupaFlow.client.from('quote_outcomes').insert({
        'org_id': orgId,
        'quote_id': _quotation?.id,
        'lead_id': widget.leadId,
        'outcome': 'lost',
        if (result.reasonCode != null) 'reason_code': result.reasonCode,
        if (result.reasonNote != null) 'reason_note': result.reasonNote,
        if (result.competitorName != null)
          'competitor_name': result.competitorName,
        if (result.competitorPrice != null)
          'competitor_price': result.competitorPrice,
        if (_quotation?.total != null) 'our_price': _quotation!.total,
        'recorded_by': AppSession.instance.currentStaffName ?? 'Owner',
      });
    } catch (_) {
      // The status change is the important part and already landed;
      // failing to record the outcome shouldn't surface as an error.
    }
  }

  Future<void> _convertQuoteToOrder() async {
    if (widget.leadId == null || _quotation == null) return;
    setState(() => _convertingQuote = true);
    try {
      await _createOrderFromLead(
        quote: _quotation,
        successMessage: 'Quote converted to order',
        errorPrefix: 'Could not convert quote',
      );
    } finally {
      if (mounted) setState(() => _convertingQuote = false);
    }
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  // ---- Session 4, A3: freely-tappable status chips -----------------------
  // Colours: the brief's own hex set was retired with the redesign (Oct
  // 2026); chips now use leadStatusColor(key, context) like the strip
  // below, so they follow the theme and read in Light.
  static const _chipLabels = <String, String>{
    kLeadStatusNew: 'New Lead',
    kLeadStatusFollowUp: 'Follow Up',
    kLeadStatusSurveyDone: 'Survey Done',
    kLeadStatusQuoted: 'Quoted',
    kLeadStatusConfirmed: 'Confirmed',
    kLeadStatusLost: 'Lost',
  };
  static const _chipOrder = [
    kLeadStatusNew,
    kLeadStatusFollowUp,
    kLeadStatusSurveyDone,
    kLeadStatusQuoted,
    kLeadStatusConfirmed,
    kLeadStatusLost,
  ];

  Widget _statusChipsRow(BuildContext context) {
    final canEdit = StaffPermissions.canActive('leads', 'edit');
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final key in _chipOrder)
          _statusChip(context, key, canEdit: canEdit && !_savingStatus),
      ],
    );
  }

  Widget _statusChip(BuildContext context, String key, {required bool canEdit}) {
    final current = key == _canonicalStatus;
    final color = leadStatusColor(key, context);
    final tappable = canEdit && !current;
    return InkWell(
      onTap: !tappable
          ? null
          : () {
              // Immediate write, no dialog — except Lost, which confirms
              // and captures an optional reason (A3). Backward movement
              // is allowed (force: true bypasses advanceLeadStatus's
              // never-downgrade rule, same as the old pipeline strip's
              // manual taps already did).
              if (key == kLeadStatusLost) {
                _confirmMarkLost();
              } else {
                _setLeadStatus(key, force: true);
              }
            },
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 34,
        padding: const EdgeInsets.symmetric(horizontal: 13),
        decoration: BoxDecoration(
          color: current ? color : NgPalette.of(context).s1,
          borderRadius: BorderRadius.circular(999),
          border: current
              ? null
              : Border.all(color: NgPalette.of(context).w1),
        ),
        child: Center(
          widthFactor: 1,
          child: Text(
            _chipLabels[key]!,
            style: NgFonts.geist(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: current ? Colors.white : NgPalette.of(context).soft,
            ),
          ),
        ),
      ),
    );
  }

  // ---- Session 4, A4: quick contact row -----------------------------------
  bool get _hasUsablePhone =>
      (widget.leadPhone ?? '').replaceAll(RegExp(r'\D'), '').length >= 10;

  Future<String> _leadOpeningMessage() async {
    final customer = widget.leadCustomer ?? 'there';
    final org = VendorIdentity.forSentence;
    // Tenant-editable template (app_settings, category 'whatsapp') with a
    // sensible default when unset — same fallback-default pattern as
    // DocumentBoilerplate (Session 3), never a hardcoded-only string.
    String template =
        'Hello {customer}, this is {org}. Thank you for your interest in '
        'our packing & moving services. How can we help you today?';
    try {
      final rows = await AppSettingsTable().queryRows(
        queryFn: (q) => OrgScope.read(q)
            .eq('category', 'whatsapp')
            .eq('key', 'lead_opening_template'),
      );
      if (rows.isNotEmpty && rows.first.value != null) {
        final v = rows.first.value.toString().trim();
        if (v.isNotEmpty) template = v;
      }
    } catch (_) {}
    return template.replaceAll('{customer}', customer).replaceAll('{org}', org);
  }

  Future<void> _openWhatsApp() async {
    if (!_hasUsablePhone) return;
    final message = await _leadOpeningMessage();
    final uri =
        Uri.parse(buildWhatsAppLink(phone: widget.leadPhone, message: message));
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open WhatsApp.')));
    }
  }

  Future<void> _callLead() async {
    if (!_hasUsablePhone) return;
    final uri = Uri(scheme: 'tel', path: widget.leadPhone);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Could not start call.')));
    }
  }

  Widget _quickContactRow(BuildContext context) {
    final c = NgPalette.of(context);
    final l = AppLocalizations.of(context);
    return Row(
      children: [
        Expanded(
          child: NgQuickAction(
            label: l.ngCall,
            icon: Icons.call_outlined,
            iconColor: c.green,
            onTap: _hasUsablePhone ? _callLead : null,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: NgQuickAction(
            label: l.ngWhatsApp,
            icon: Icons.chat_outlined,
            iconColor: c.green,
            onTap: _hasUsablePhone ? _openWhatsApp : null,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: NgQuickAction(
            label: l.ngQuote,
            icon: Icons.request_quote_outlined,
            iconColor: c.acc,
            onTap: widget.leadId == null
                ? null
                : () => context.pushNamed(
                      SurveyQuotePageWidget.routeName,
                      queryParameters: {
                        'leadId':
                            serializeParam(widget.leadId, ParamType.String),
                        'leadCustomer': serializeParam(
                            _lead?.customer ?? widget.leadCustomer,
                            ParamType.String),
                        'leadPhone': serializeParam(
                            _lead?.phone ?? widget.leadPhone,
                            ParamType.String),
                        'leadFromCity': serializeParam(
                            _lead?.fromCity ?? widget.leadFromCity,
                            ParamType.String),
                        'leadToCity': serializeParam(
                            _lead?.toCity ?? widget.leadToCity,
                            ParamType.String),
                      }.withoutNulls,
                    ),
          ),
        ),
      ],
    );
  }

  /// Handoff header: initial avatar, name, the phone in mono (tappable,
  /// A4) and the status pill.
  Widget _leadHeader(BuildContext context) {
    final c = NgPalette.of(context);
    final name = _lead?.customer ?? widget.leadCustomer ?? 'Lead';
    final phone = _lead?.phone ?? widget.leadPhone;
    final tone = leadStatusTone(_status);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          NgAvatar(name, status: tone, size: 56),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: NgFonts.geist(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.3,
                        color: c.text)),
                if ((phone ?? '').isNotEmpty)
                  InkWell(
                    onTap: _hasUsablePhone ? _callLead : null,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(phone!,
                          style: NgFonts.mono(fontSize: 14.5, color: c.mute)),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          NgPill(leadStatusLabel(_status), status: tone),
        ],
      ),
    );
  }

  /// Follow-up logs, newest first, ending with when the lead came in.
  Widget _leadActivity(BuildContext context) {
    final c = NgPalette.of(context);
    final logs = [...?_journey?.followUps]
      ..sort((a, b) => (b.loggedAt ?? DateTime(0))
          .compareTo(a.loggedAt ?? DateTime(0)));
    final created = _lead?.createdAt;
    final items = <(IconData, NgStatus, String, String?, DateTime?)>[
      for (final f in logs)
        (
          f.channel == 'whatsapp' ? Icons.chat_outlined : Icons.call_outlined,
          NgStatus.green,
          [
            f.channel == 'whatsapp' ? 'WhatsApp' : 'Called customer',
            if ((f.outcome ?? '').isNotEmpty)
              f.outcome!.replaceAll('_', ' '),
          ].join(' · '),
          f.notes,
          f.loggedAt,
        ),
      if (created != null)
        (
          Icons.add_circle_outline_rounded,
          NgStatus.blue,
          [
            'Lead created',
            if ((_lead?.source ?? '').isNotEmpty) 'Source: ${_lead!.source}',
          ].join(' · '),
          null,
          created,
        ),
    ];
    if (items.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
          child: Text(AppLocalizations.of(context).odActivity,
              style: NgFonts.geist(
                  fontSize: 18, fontWeight: FontWeight.w600, color: c.text)),
        ),
        for (var i = 0; i < items.length; i++)
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  width: 36,
                  child: Column(children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                          color: c.status(items[i].$2).bg,
                          shape: BoxShape.circle),
                      child: Icon(items[i].$1,
                          size: 16, color: c.status(items[i].$2).fg),
                    ),
                    if (i < items.length - 1)
                      Expanded(child: Container(width: 2, color: c.w07)),
                  ]),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 16, top: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(items[i].$3,
                            style: NgFonts.geist(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w500,
                                color: c.text)),
                        if ((items[i].$4 ?? '').trim().isNotEmpty)
                          Text(items[i].$4!.trim(),
                              style: NgFonts.geist(
                                  fontSize: 13.5, color: c.soft)),
                        if (items[i].$5 != null)
                          Text(
                              DateFormat('d MMM, h:mm a')
                                  .format(items[i].$5!.toLocal()),
                              style: NgFonts.geist(
                                  fontSize: 12.5, color: c.mute)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  // ---- Session 4, A1/A2: detail field table + auto-creation note --------
  Widget _leadDetailTable(BuildContext context) {
    final lead = _lead;
    final fromFloor = lead?.fromFloor;
    final toFloor = lead?.toFloor;
    return DetailCard(
      title: AppLocalizations.of(context).odMoveDetails,
      children: [
        DetailRow(
          label: 'Route',
          value: [
            lead?.fromCity ?? widget.leadFromCity,
            lead?.toCity ?? widget.leadToCity,
          ].whereType<String>().where((s) => s.isNotEmpty).join(' → '),
        ),
        DetailRow(label: 'From', value: lead?.fromAddress ?? widget.leadFromCity),
        DetailRow(label: 'To', value: lead?.toAddress ?? widget.leadToCity),
        DetailRow(
          label: 'Floor',
          value: (fromFloor == null && toFloor == null)
              ? null
              : '${fromFloor ?? '—'}F → ${toFloor ?? '—'}F',
        ),
        DetailRow(label: 'Date', value: lead?.approxDate ?? widget.leadApproxDate),
        DetailRow(label: 'Service', value: lead?.service ?? widget.leadService),
        DetailRow(label: 'Package', value: lead?.packageType),
        DetailRow(label: 'Packing', value: lead?.packingType),
        DetailRow(label: 'Source', value: lead?.source ?? widget.leadSource),
        DetailRow(label: 'Branch', value: lead?.branch ?? widget.leadBranch),
      ],
    );
  }

  /// Nothing when null — no empty container, no placeholder (A2).
  Widget? _autoCreationNote(BuildContext context) {
    final note = (_lead?.notes ?? widget.leadNotes ?? '').trim();
    if (note.isEmpty) return null;
    final ng = NgPalette.of(context);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: ng.s1,
        borderRadius: BorderRadius.circular(8),
        border: Border(left: BorderSide(color: ng.acc, width: 3)),
      ),
      child: Text(
        note,
        style: NgFonts.geist(
          fontSize: 12.5,
          fontStyle: FontStyle.italic,
          height: 1.4,
          color: ng.mute,
        ),
      ),
    );
  }

  Widget _surveyQuoteSection(BuildContext context) {
    final ng = NgPalette.of(context);
    final survey = _survey;
    final quotation = _quotation;
    return NgCard(
      radius: 20,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('Survey & Quote',
                    style: NgFonts.geist(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: ng.text)),
              ),
              // Part 8 addendum item 2: two separate documents, not one
              // combined (Rev B, Q2) - the survey PDF exists before pricing
              // does, so the quote button stays disabled until a quote
              // does. Downloads survey_pdf.dart/quote_pdf.dart output via
              // Printing.sharePdf, same share/download path invoice_pdf.dart
              // already uses.
              IconButton(
                tooltip: 'Download Survey PDF',
                iconSize: 19,
                visualDensity: VisualDensity.compact,
                icon: _downloadingSurveyPdf
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.description_outlined),
                onPressed: (survey == null ||
                        survey.status == 'pending' ||
                        _downloadingSurveyPdf)
                    ? null
                    : _downloadSurveyPdf,
              ),
              // Part 8 Rev B item 4: Summary (single total per line, as
              // before item 4 existed) vs Detailed (qty/rate/basis
              // breakdown + Inclusions/Exclusions) — a menu instead of a
              // single tap since there are now two documents to choose
              // from, not because the download itself changed.
              PopupMenuButton<bool>(
                tooltip: 'Download Quote PDF',
                enabled: quotation != null && !_downloadingQuotePdf,
                icon: _downloadingQuotePdf
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.picture_as_pdf_outlined, size: 19),
                onSelected: (detailed) => _downloadQuotePdf(detailed: detailed),
                itemBuilder: (context) => const [
                  PopupMenuItem(value: false, child: Text('Summary PDF')),
                  PopupMenuItem(value: true, child: Text('Detailed PDF')),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Step 1: survey
          if (!kSurveyLinkHosted)
            _linkUnavailableNote(context, 'Survey',
                'Fill the survey in yourself from Survey & Quote.')
          else if (survey == null)
            OutlinedButton.icon(
              onPressed: _requestingSurvey ? null : _requestSurvey,
              icon: const Icon(Icons.fact_check_outlined, size: 18),
              label: Text(_requestingSurvey
                  ? 'Creating link…'
                  : 'Request Survey (send customer a link)'),
            )
          else if (survey.status == 'pending')
            OutlinedButton.icon(
              onPressed: () => _showLinkDialog(
                  'Survey link', _shareLink('/survey', survey.token)),
              icon: const Icon(Icons.hourglass_top, size: 18),
              label: const Text('Survey sent — awaiting customer response'),
            )
          else
            // Was a bare "Survey response received" line — the items the
            // customer had gone to the trouble of listing were invisible
            // in the app, so the whole survey link delivered nothing to
            // the vendor. Now the full submission, grouped by category,
            // with the total CFT and the package it implies.
            SurveyResponseSection(
              survey: survey,
              onBuildQuote: () => _openQuoteBuilder(survey),
            ),
          const SizedBox(height: 10),
          // Step 2: quote (needs a survey submitted first, or can be
          // skipped straight from the lead — vendor's call).
          if (quotation == null)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                // Parity brief Part 3: the itemized CFT survey +
                // charges/GST builder. Was one of two options here — the
                // "Create Quote" quick subtotal-only dialog was removed
                // (12 Aug 2026) as a strict subset of this: no line items,
                // no CFT breakdown, and quote_pdf.dart already renders the
                // items-empty case for the rows it already produced, so
                // nothing existing was orphaned.
                OutlinedButton.icon(
                  onPressed: () => context.pushNamed(
                    SurveyQuotePageWidget.routeName,
                    queryParameters: {
                      'leadId': serializeParam(widget.leadId, ParamType.String),
                      'leadCustomer':
                          serializeParam(widget.leadCustomer, ParamType.String),
                      'leadPhone':
                          serializeParam(widget.leadPhone, ParamType.String),
                      'leadFromCity':
                          serializeParam(widget.leadFromCity, ParamType.String),
                      'leadToCity':
                          serializeParam(widget.leadToCity, ParamType.String),
                    },
                  ),
                  icon: const Icon(Icons.list_alt, size: 18),
                  label: const Text('Build Detailed Quote'),
                ),
              ],
            )
          else if (quotation.status == 'accepted')
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.check_circle, size: 18, color: ng.green),
                    const SizedBox(width: 6),
                    Expanded(
                        child: Text(
                            'Quote accepted by ${quotation.acceptedByName ?? 'customer'}')),
                  ],
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: _convertingQuote ? null : _convertQuoteToOrder,
                  icon: const Icon(Icons.assignment_turned_in, size: 18),
                  label: Text(_convertingQuote
                      ? 'Converting…'
                      : 'Convert Quote to Order'),
                ),
              ],
            )
          // Was an OutlinedButton opening the `/quote` link. Removed
          // 11 Sept 2026 — it told TWO lies at once.
          //
          // 1. The link is dead. `/quote` has never been served by
          //    anything; verified live the same day, it returns the
          //    "This link isn't available right now" holding page. The
          //    hub's equivalent button has been gated behind
          //    kQuoteLinkHosted since 19 Aug; THIS one was missed, so a
          //    vendor could still hand a customer a link that fails in
          //    front of them.
          // 2. "Quote sent" was never a fact. Nothing writes
          //    quotations.status = 'sent' — the branch only knows the
          //    quote is NOT accepted. Draft, sent, revised and lost all
          //    land here, and it asserted the one state it could not
          //    establish.
          //
          // Now a plain status row: the information is real, the dead
          // action is gone. When a genuine send path exists (see the
          // 11 Sept trace — the honest candidate is the quote PDF share,
          // and it would mean ISSUED, not seen) this becomes a button
          // again and 'sent' gets its writer.
          else
            Row(
              children: [
                Icon(Icons.hourglass_top, size: 18, color: ng.mute),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    quotation.status == 'lost'
                        ? 'Quote marked lost'
                        : 'Quote not yet accepted',
                    style: TextStyle(color: ng.mute),
                  ),
                ),
              ],
            ),
          // Part 1: which quote this is, its revision history, and the
          // Revise action — collocated with the status row deliberately.
          // A revision is a RESPONSE to a customer, and the manager is on
          // the lead when that callback happens: the follow-up log is on
          // this page, and so is the negotiation context. Putting Revise
          // in the Survey & Quote hub would mean leaving the conversation
          // to make a decision that is entirely about the conversation.
          //
          // Guarded rather than `quotation!`: this sits AFTER the
          // if/else chain above, so null promotion does not reach here —
          // a lead with no quote at all renders nothing.
          if (quotation != null) _quoteRevisionPanel(context, quotation),
          // Item 3: e-signature on the quote, alongside the plain view
          // link above. Separate action because accepting a quote and
          // signing it are different things — the customer can read the
          // quote without committing.
          const SizedBox(height: 8),
          if (_quoteSignature?.isSigned ?? false)
            Row(
              children: [
                Icon(Icons.verified, size: 17, color: ng.blue),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Signed by ${_quoteSignature!.customerName ?? 'customer'}'
                    '${_quoteSignature!.signedAt == null ? '' : ' on ${DateFormat('d MMM yyyy').format(_quoteSignature!.signedAt!.toLocal())}'}',
                    style: NgFonts.geist(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: ng.text),
                  ),
                ),
                // Offered ONLY when the stored signature actually decodes.
                // A "View" that opens an empty box is worse than no View:
                // it turns a complete record into one the vendor believes
                // is broken. Same rule as never shipping a contact
                // affordance that goes nowhere.
                if (_quoteSignature!.signatureBytes != null)
                  TextButton(
                    onPressed: () => _showSignature(_quoteSignature!),
                    child: const Text('View'),
                  ),
              ],
            )
          else
            if (!kSignLinkHosted)
              _linkUnavailableNote(context, 'Signature',
                  'Capture the signature in person instead — Order '
                  'Details, Documents, Capture Signature.')
            else
            OutlinedButton.icon(
              onPressed: _sendingQuoteSignature
                  ? null
                  : () => _sendQuoteForSignature(quotation!),
              icon: const Icon(Icons.draw, size: 18),
              label: Text(_sendingQuoteSignature
                  ? 'Preparing…'
                  : _quoteSignature == null
                      ? 'Send for Signature'
                      : 'Awaiting signature — resend link'),
            ),
        ],
      ),
    );
  }

  /// Item 3: creates (or reuses) the quote's signature request and opens
  /// the WhatsApp-first share sheet.
  Future<void> _sendQuoteForSignature(QuotationsRow quotation) async {
    setState(() => _sendingQuoteSignature = true);
    try {
      final sig = await SignatureService.getOrCreate(
        documentType: 'quote',
        documentId: quotation.id,
        customerName: quotation.customer ?? widget.leadCustomer,
      );
      if (!mounted) return;
      setState(() => _quoteSignature = sig);
      final org = VendorIdentity.forSentence;
      await ShareLinkSheet.show(
        context,
        title: 'Send quote for signature',
        subtitle: 'The customer reviews the quotation and signs on their '
            'phone. No login needed.',
        link: sig.link,
        phone: widget.leadPhone,
        message: 'Hello${widget.leadCustomer == null ? '' : ' ${widget.leadCustomer}'}, '
            'please review and accept your quotation from $org:',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not create signature link: $e')),
      );
    } finally {
      if (mounted) setState(() => _sendingQuoteSignature = false);
    }
  }

  /// Loads the vendor's business profile + logo the same way
  /// order_detail_page_widget.dart does for the invoice, so the survey and
  /// quote PDFs carry the same branding rather than a second, possibly
  /// drifting copy of this lookup.
  Future<(Map<String, dynamic>, Uint8List?)> _loadProfileAndLogo() async {
    Map<String, dynamic> profile = const {};
    try {
      final rows = await SettingsTable().queryRows(
        queryFn: (q) => OrgScope.read(q).eq('key', 'business_profile'),
      );
      profile = rows.isEmpty ? {} : (rows.first.valueJson ?? {});
    } catch (_) {}
    final logoBytes =
        await PdfBranding.fetchBytes(AppSession.instance.currentOrgLogoUrl);
    return (profile, logoBytes);
  }

  /// A short human-readable reference for PDF filenames/headers. Leads
  /// have no dedicated short code (just a uuid `id`), so this truncates it
  /// the same way orders' own text ids read as a short reference.
  String get _leadRef =>
      (widget.leadId ?? '').length >= 8
          ? widget.leadId!.substring(0, 8).toUpperCase()
          : (widget.leadId ?? 'LEAD');

  Future<void> _downloadSurveyPdf() async {
    final survey = _survey;
    if (survey == null || _downloadingSurveyPdf) return;
    setState(() => _downloadingSurveyPdf = true);
    try {
      final (profile, logoBytes) = await _loadProfileAndLogo();
      final config = await PricingConfig.loadForCurrentOrg();
      final lines = parseSurveyRooms(survey.rooms);
      final bytes = await SurveyPdf.generate(
        leadRef: _leadRef,
        customerName: survey.customerName ?? widget.leadCustomer ?? 'Customer',
        customerPhone: survey.customerPhone ?? widget.leadPhone,
        moveDate: survey.moveDate,
        fromAddress: survey.fromAddress,
        toAddress: survey.toAddress,
        fromCity: widget.leadFromCity,
        toCity: widget.leadToCity,
        lines: lines,
        orgName: VendorIdentity.forDocument,
        profile: profile,
        logoBytes: logoBytes,
        cftRanges: config.cftRanges,
        packages: config.packages,
      );
      await Printing.sharePdf(
        bytes: bytes,
        filename: SurveyPdf.filename(_leadRef, DateTime.now()),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not generate survey PDF: $e')),
      );
    } finally {
      if (mounted) setState(() => _downloadingSurveyPdf = false);
    }
  }

  Future<void> _downloadQuotePdf({bool detailed = false}) async {
    final quotation = _quotation;
    if (quotation == null || _downloadingQuotePdf) return;
    setState(() => _downloadingQuotePdf = true);
    try {
      final (profile, logoBytes) = await _loadProfileAndLogo();
      final charges = quotation.charges is Map
          ? Map<String, dynamic>.from(quotation.charges as Map)
          : <String, dynamic>{};
      final gstType = charges['_gstType'] as String?;
      final interstate = gstType == 'inter'
          ? true
          : gstType == 'intra'
              ? false
              : isInterState(
                  quotation.fromAddress ?? widget.leadFromCity ?? '',
                  quotation.toAddress ?? widget.leadToCity ?? '',
                );
      // Re-read rather than trusting the cached _quoteSignature, same
      // reasoning as the invoice's signature fetch: a signature captured
      // moments ago on the customer's own phone must show up here without
      // needing the page reopened.
      SignatureRequest? sig = _quoteSignature;
      try {
        sig = await SignatureService.find(
              documentType: 'quote',
              documentId: quotation.id,
            ) ??
            sig;
      } catch (_) {}

      // Dual-source branding (Session 3, task #41) + document boilerplate.
      String? signatureUrl;
      try {
        final rows = await SettingsTable().queryRows(
          queryFn: (q) => OrgScope.read(q).eq('key', 'signature_url'),
        );
        if (rows.isNotEmpty) signatureUrl = rows.first.value;
      } catch (_) {}
      OrganizationsRow? orgRow;
      try {
        final orgId = OrgScope.currentOrgId;
        if (orgId != null) {
          final rows = await OrganizationsTable()
              .queryRows(queryFn: (q) => q.eq('id', orgId));
          if (rows.isNotEmpty) orgRow = rows.first;
        }
      } catch (_) {}
      final org = OrgProfile.resolve(orgRow,
          businessProfile: profile, legacyESignUrl: signatureUrl);

      DocumentBoilerplate boilerplate = const DocumentBoilerplate();
      try {
        final docRows = await AppSettingsTable().queryRows(
          queryFn: (q) => OrgScope.read(q).eq('category', 'documents'),
        );
        boilerplate = DocumentBoilerplate.resolve(docRows);
      } catch (_) {}

      String? amountInWords;
      try {
        amountInWords = await SupaFlow.client.rpc('amount_in_words',
            params: {'amt': quotation.total ?? 0}) as String?;
      } catch (_) {}

      // Moving Items table (field spec §3, page 2) — the survey linked to
      // this lead, same rooms data _downloadSurveyPdf already renders.
      final surveyLines =
          _survey != null ? parseSurveyRooms(_survey!.rooms) : <SurveyLine>[];

      final design = await QuoteDesign.load();
      final bytes = await QuotePdf.generate(
        design: design,
        leadRef: _leadRef,
        org: org,
        boilerplate: boilerplate,
        customerName: quotation.customer ?? widget.leadCustomer ?? 'Customer',
        customerPhone: quotation.phone ?? widget.leadPhone,
        // No email column exists anywhere in the survey/quotation/lead
        // schema today — omitted rather than guessed; the PDF already
        // renders cleanly without it (see the isNotEmpty guard on this
        // field in QuotePdf.generate).
        fromAddress: quotation.fromAddress,
        toAddress: quotation.toAddress,
        fromCity: widget.leadFromCity,
        toCity: widget.leadToCity,
        charges: charges,
        subtotal: quotation.subtotal ?? 0,
        gstPct: quotation.gstPct ?? kGstDefaultPct.toDouble(),
        gstAmount: quotation.gstAmount ?? 0,
        total: quotation.total ?? 0,
        interstate: interstate,
        logoBytes: logoBytes,
        customerSignatureBytes:
            (sig?.isSigned ?? false) ? sig!.signatureBytes : null,
        customerSignedByName: (sig?.isSigned ?? false) ? sig!.customerName : null,
        customerSignedAt: (sig?.isSigned ?? false) ? sig!.signedAt : null,
        detailed: detailed,
        loadType: quotation.loadType,
        vehicleType: quotation.vehicleType,
        transportMode: quotation.transportMode,
        packingDate: quotation.packingDate,
        deliveryDate: quotation.deliveryDate,
        movingDate: quotation.movingDate,
        fromFloor: quotation.fromFloor,
        fromHasLift: quotation.fromHasLift,
        toFloor: quotation.toFloor,
        toHasLift: quotation.toHasLift,
        declaredValue: quotation.declaredValue,
        fovPct: quotation.fovPct,
        fovAmount: quotation.fovAmount,
        easyAccess: quotation.easyAccess,
        accessRestrictions: quotation.accessRestrictions,
        accessNotes: quotation.accessNotes,
        surveyLines: surveyLines,
        amountInWords: amountInWords,
      );
      final quoteFile = QuotePdf.filename(_leadRef, DateTime.now())
          .replaceAll(RegExp(r'[\\/:*?"<>|]'), '-');

      // Keep the customer's copy. Arun, 7 Sept 2026: "also add quote".
      // Stored against the QUOTATION, since no order exists yet — it
      // reaches the customer's tracking link through the order's
      // quotation_id once the lead converts.
      //
      // Best-effort, like every other document: a storage failure must
      // never stop a quote going out.
      if ((quotation.id ?? '').isNotEmpty) {
        await IssuedDocuments.storeForQuotation(
          quotationId: quotation.id!,
          fileName: quoteFile,
          bytes: bytes,
        );
      }

      await Printing.sharePdf(bytes: bytes, filename: quoteFile);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not generate quote PDF: $e')),
      );
    } finally {
      if (mounted) setState(() => _downloadingQuotePdf = false);
    }
  }

  /// Explains why a customer-link button is missing, instead of leaving a
/// hole where a feature used to be.
///
/// Added 3 Sept 2026. `kSurveyLinkHosted` and `kSignLinkHosted` had been
/// declared since 19 Aug and NEVER REFERENCED - 0 uses - so the flags
/// documented an intention nobody enforced, and the buttons handed out
/// links to a dead page regardless of what the flags said. Verified the
/// same day by fetching all four paths: every one returns "Link
/// unavailable".
///
/// Hidden rather than disabled, matching the quote/track buttons, but
/// with this note so it does not read as a missing feature.
  /// Identity line, the other-quotes switcher, Revise, and the version
  /// list — one block, because they are one question: *which quote is
  /// this, what has it been through, and do I change it again?*
  Widget _quoteRevisionPanel(BuildContext context, QuotationsRow quotation) {
    final ng = NgPalette.of(context);
    final money = NumberFormat.currency(
        locale: 'en_IN', symbol: '₹', decimalDigits: 0);
    final created = quotation.createdAt;
    final others = _quotesOnLead.where((q) => q.id != quotation.id).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 10),
        Divider(height: 1, color: ng.w08),
        const SizedBox(height: 8),

        // WHICH QUOTE. Named, not implied. `_pickBestQuote` chooses
        // silently among however many a lead carries, and a manager about
        // to revise has to know which row they are about to change.
        Row(
          children: [
            Icon(Icons.receipt_long, size: 16, color: ng.mute),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                'v${quotation.version ?? 1} · ${money.format(quotation.total ?? 0)}'
                '${created == null ? '' : ' · ${DateFormat('d MMM yyyy').format(created.toLocal())}'}',
                style: NgFonts.geist(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    color: ng.text),
              ),
            ),
          ],
        ),

        // MORE THAN ONE QUOTE ON THIS LEAD. Read-only, no schema change —
        // it states the fact and offers the switch. Today every lead
        // carries exactly one (counted 11 Sept 2026), so this is
        // prevention: nothing stops a second quote being created, and
        // before this the page would simply have shown one of them with
        // no hint the other existed.
        if (others.isNotEmpty) ...[
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.layers_outlined, size: 15, color: ng.amber),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  '${_quotesOnLead.length} quotes on this lead — showing the '
                  'most detailed one.',
                  style: NgFonts.geist(
                      fontSize: 11.5, color: ng.mute),
                ),
              ),
              PopupMenuButton<QuotationsRow>(
                tooltip: 'Switch quote',
                onSelected: _selectQuote,
                itemBuilder: (context) => [
                  for (final q in others)
                    PopupMenuItem(
                      value: q,
                      child: Text(
                        'v${q.version ?? 1} · ${money.format(q.total ?? 0)}'
                        '${q.createdAt == null ? '' : ' · ${DateFormat('d MMM').format(q.createdAt!.toLocal())}'}',
                      ),
                    ),
                ],
                child: Text('Switch',
                    style: NgFonts.geist(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: ng.acc)),
              ),
            ],
          ),
        ],

        // THE HISTORY. An empty list is "no revisions yet", never an
        // error — history is written lazily, so a quote that has never
        // been revised legitimately has no rows.
        if (_loadingVersions) ...[
          const SizedBox(height: 8),
          const SizedBox(
              height: 14,
              width: 14,
              child: CircularProgressIndicator(strokeWidth: 2)),
        ] else if (_quoteVersions.isNotEmpty) ...[
          const SizedBox(height: 8),
          for (final v in _quoteVersions)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 2),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                      color: ng.w08,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text('v${v.version ?? 1}',
                        style: NgFonts.geist(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            color: ng.text)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          // change_summary already carries the reason
                          // after ' -- ', because the RPC appends it
                          // there. One field, so the what and the why
                          // cannot be shown apart.
                          v.changeSummary ?? 'Revised',
                          style: NgFonts.geist(
                              fontSize: 12, color: ng.text),
                        ),
                        Text(
                          [
                            money.format(v.totalAmount ?? 0),
                            if (v.createdAt != null)
                              DateFormat('d MMM yyyy, h:mm a')
                                  .format(v.createdAt!.toLocal()),
                          ].join(' · '),
                          style: NgFonts.geist(
                              fontSize: 11, color: ng.mute),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],

        // REVISE. Offered whatever the status — a quote can be
        // renegotiated before acceptance and on job day, and the RPC is
        // what decides whether a reason is mandatory, not this button.
        // Never gated on status here: two places deciding one rule is
        // how they come to disagree.
        const SizedBox(height: 6),
        // VIEW sits beside REVISE because a quote that exists has two
        // things a vendor wants on a customer call: to read what was
        // sent, and to change it. View opens the document the customer
        // actually received, not an editor — reading a quote through the
        // revise form is how an accidental revision happens.
        Row(
          children: [
            OutlinedButton.icon(
              onPressed:
                  _downloadingQuotePdf ? null : () => _downloadQuotePdf(),
              icon: _downloadingQuotePdf
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.visibility_outlined, size: 18),
              label: Text(_downloadingQuotePdf ? 'Opening…' : 'View'),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed:
                    _revisingQuote ? null : () => _reviseQuote(quotation),
                icon: const Icon(Icons.edit_note, size: 18),
                label: Text(_revisingQuote ? 'Opening…' : 'Revise Quote'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _linkUnavailableNote(BuildContext context, String what, String instead) {
    final ng = NgPalette.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: ng.amber.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.link_off, size: 15, color: ng.amber),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '$what links are switched off — the customer page is not '
              'live right now, so a link would open a dead page. $instead',
              style: NgFonts.geist(
                  fontSize: 11.5, color: ng.text),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.surveyQuoteOnly) {
      return _loadingLinked
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            )
          : _surveyQuoteSection(context);
    }
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: NgPalette.of(context).bg,
        appBar: NgSimpleBar(
          title: AppLocalizations.of(context).leadDetails,
          actions: [
            if (StaffPermissions.canActive('leads', 'edit') &&
                widget.leadId != null)
              NgHeaderButtonBox(
                icon: Icons.edit_outlined,
                tooltip: AppLocalizations.of(context).editLead,
                onTap: () => context.pushNamed(
                  NewLeadPageWidget.routeName,
                  queryParameters: {
                    'leadId':
                        serializeParam(widget.leadId, ParamType.String),
                  }.withoutNulls,
                ),
              ),
          ],
        ),
        body: SafeArea(
          top: true,
          child: Container(
            decoration: BoxDecoration(
              color: NgPalette.of(context).bg,
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Claude Design handoff "LEAD DETAIL": journey strip,
                    // avatar header with the status pill, Call / WhatsApp
                    // / Quote, then the segmented pipeline.
                    if (widget.leadId != null)
                      JourneyEntryCard(
                          leadId: widget.leadId, data: _journey),
                    _leadHeader(context),
                    _quickContactRow(context),
                    // Item 5.4 pipeline strip, now the handoff's segmented
                    // bars. Each stage reads its OWN record (12 Sept 2026
                    // fix: reaching `quoted` used to tick SURVEY on leads
                    // that were never surveyed).
                    LeadStatusStrip(
                      compact: true,
                      status: _status,
                      evidence: LeadStageEvidence(
                        surveySubmitted: _survey?.submittedAt != null,
                        hasQuote: _quotation != null,
                        hasOrder: _hasOrder,
                      ),
                      busy: _savingStatus,
                      onStageTap: (stage) => _setLeadStatus(stage, force: true),
                    ),
                    // Session 4, A3: the one interactive control for lead
                    // status — the strip above mirrors it, read-only.
                    _statusChipsRow(context),
                    // Session 4, A1: one detail table, every row rendered
                    // even when empty (— for null) — replaces the old
                    // Contact/Move Details split, which didn't cover
                    // Floor/Package/Packing at all and hid Email instead
                    // of showing its dash.
                    _leadDetailTable(context),
                    // Session 4, A2: nothing rendered when there's no note
                    // — no empty container, no placeholder.
                    if (_autoCreationNote(context) != null)
                      _autoCreationNote(context)!,
                    // Item 10: REMINDERS, above Survey & Quote as specified.
                    if (widget.leadId != null)
                      RemindersSection(
                        key: _remindersKey,
                        entityType: kEntityLead,
                        entityId: widget.leadId!,
                        customerName: widget.leadCustomer,
                        customerPhone: widget.leadPhone,
                      ),
                    if (!_loadingLinked) _surveyQuoteSection(context),
                    _leadActivity(context),
                    NgPrimaryButton(
                      onPressed: _converting ? null : _confirmOrder,
                      label: _converting ? 'Confirming…' : 'Confirm Order',
                      icon: Icons.assignment_turned_in_outlined,
                    ),
                    // Item 11: destructive, at the bottom, deliberately
                    // separated from the primary actions above.
                    if (widget.leadId != null)
                      DeleteAction.button(
                        context: context,
                        busy: _deleting,
                        label: 'Delete Lead',
                        onPressed: _deleteLead,
                      ),
                  ].divide(const SizedBox(height: 12.0)),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Item 11: soft-delete this lead. Blocked once converted — the order
  /// still references it, and "Lost" is the honest state for a lead that
  /// didn't work out.
  Future<void> _deleteLead() async {
    setState(() => _deleting = true);
    try {
      final deleted = await DeleteAction.run(
        context,
        table: 'leads',
        id: widget.leadId!,
        entityLabel: 'lead',
        check: () => SoftDeleteService.canDeleteLead(widget.leadId!),
        onAlternative: (alt) {
          if (alt == 'mark_lost') _confirmMarkLost();
        },
      );
      if (deleted && mounted) {
        // Straight back to the list — staying on a detail page for a row
        // that no longer exists would just show stale data.
        context.pop();
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }
}

/// Session 4, A3: what the Lost-reason dialog hands back to the page.
class _LostReasonResult {
  const _LostReasonResult({
    this.reasonCode,
    this.reasonNote,
    this.competitorName,
    this.competitorPrice,
  });
  final String? reasonCode;
  final String? reasonNote;
  final String? competitorName;
  final double? competitorPrice;
}

/// `quote_outcomes.reason_code`'s permitted values, and the ONLY place
/// they are offered to a user.
///
/// **Provenance corrected 11 Sept 2026.** This comment used to say the
/// list came from "migration 004's own column comment — not invented
/// here". `col_description` on that column returned NULL: the comment
/// had never existed, so the claim was never true. The column now
/// carries a real comment, written by
/// `20260911_status_vocabulary.sql`, and this map must match it.
///
/// **Trimmed from eight to six**, both free — `quote_outcomes` has 0
/// rows, so nothing needed migrating:
///  * `trust` — a customer will not say "I did not trust you", so the
///    code would be guessed on their behalf, and a guessed reason in a
///    reasons report is worse than a blank one.
///  * `unreachable` — that is a LEAD state and already exists as
///    `leads.status`. Keeping it here too is the duplication this
///    codebase keeps removing.
///
/// `reason_note` carries the detail that does not fit a code.
/// A CHECK constraint pins this list in the database; adding a seventh
/// value here without adding it there will fail at insert.
const _kLostReasonCodes = <String, String>{
  'price': 'Price',
  'competitor': 'Went with a competitor',
  'timing': 'Timing',
  'service_scope': 'Service scope',
  'customer_cancelled': 'Customer cancelled the move',
  'other': 'Other',
};

class _LostReasonDialog extends StatefulWidget {
  const _LostReasonDialog();
  @override
  State<_LostReasonDialog> createState() => _LostReasonDialogState();
}

class _LostReasonDialogState extends State<_LostReasonDialog> {
  String? _reasonCode;
  final _noteCtrl = TextEditingController();
  final _competitorNameCtrl = TextEditingController();
  final _competitorPriceCtrl = TextEditingController();

  @override
  void dispose() {
    _noteCtrl.dispose();
    _competitorNameCtrl.dispose();
    _competitorPriceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCompetitor = _reasonCode == 'competitor';
    return AlertDialog(
      title: const Text('Mark lead as lost?'),
      content: SizedBox(
        width: 380,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'The lead stays in the list under "Lost" and can be reopened '
                'later.',
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _reasonCode,
                decoration: const InputDecoration(labelText: 'Reason (optional)'),
                items: [
                  for (final e in _kLostReasonCodes.entries)
                    DropdownMenuItem(value: e.key, child: Text(e.value)),
                ],
                onChanged: (v) => setState(() => _reasonCode = v),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _noteCtrl,
                decoration: const InputDecoration(
                  labelText: 'Note (optional)',
                  hintText: 'e.g. went with a cheaper vendor',
                ),
                maxLines: 2,
              ),
              if (isCompetitor) ...[
                const SizedBox(height: 8),
                TextField(
                  controller: _competitorNameCtrl,
                  decoration:
                      const InputDecoration(labelText: 'Competitor name'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _competitorPriceCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Competitor price (₹)'),
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(_LostReasonResult(
            reasonCode: _reasonCode,
            reasonNote:
                _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
            competitorName: isCompetitor && _competitorNameCtrl.text.trim().isNotEmpty
                ? _competitorNameCtrl.text.trim()
                : null,
            competitorPrice: isCompetitor
                ? double.tryParse(_competitorPriceCtrl.text.trim())
                : null,
          )),
          
          child: const Text('Mark lost'),
        ),
      ],
    );
  }
}

/// Session 4, A5: what the Confirm Order sheet hands back to the page.
class _ConfirmOrderResult {
  const _ConfirmOrderResult({
    required this.customer,
    required this.phone,
    required this.fromCity,
    required this.toCity,
    required this.moveDate,
    required this.amount,
    required this.service,
  });
  final String customer;
  final String? phone;
  final String? fromCity;
  final String? toCity;
  final DateTime moveDate;
  final double amount;
  final String? service;
}

/// The "minimal order sheet" A5 asks for — review/edit the handful of
/// fields an order actually needs before it's created, pre-filled from
/// the lead (and the best available quote's amount, if any). Deliberately
/// not a full NewOrderPage-style form: this exists specifically for the
/// "skip survey, confirm now" path, where speed matters more than
/// capturing every order field up front — the rest can be filled in via
/// Edit Order afterward, same as the plain lead-to-order conversion this
/// replaces already assumed.
class _ConfirmOrderSheet extends StatefulWidget {
  const _ConfirmOrderSheet({
    required this.initialCustomer,
    required this.initialPhone,
    required this.initialFromCity,
    required this.initialToCity,
    required this.initialService,
    required this.initialAmount,
    required this.initialMoveDate,
  });

  final String initialCustomer;
  final String initialPhone;
  final String initialFromCity;
  final String initialToCity;
  final String initialService;
  final double initialAmount;
  final DateTime initialMoveDate;

  @override
  State<_ConfirmOrderSheet> createState() => _ConfirmOrderSheetState();
}

class _ConfirmOrderSheetState extends State<_ConfirmOrderSheet> {
  late final _customerCtrl = TextEditingController(text: widget.initialCustomer);
  late final _phoneCtrl = TextEditingController(text: widget.initialPhone);
  late final _fromCtrl = TextEditingController(text: widget.initialFromCity);
  late final _toCtrl = TextEditingController(text: widget.initialToCity);
  late final _serviceCtrl = TextEditingController(text: widget.initialService);
  late final _amountCtrl =
      TextEditingController(text: widget.initialAmount == 0 ? '' : widget.initialAmount.toStringAsFixed(0));
  late DateTime _moveDate = widget.initialMoveDate;

  @override
  void dispose() {
    _customerCtrl.dispose();
    _phoneCtrl.dispose();
    _fromCtrl.dispose();
    _toCtrl.dispose();
    _serviceCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _moveDate,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 730)),
    );
    if (picked != null) setState(() => _moveDate = picked);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Confirm Order'),
      content: SizedBox(
        width: 380,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _customerCtrl,
                decoration: const InputDecoration(labelText: 'Customer'),
                autofocus: true,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _phoneCtrl,
                decoration: const InputDecoration(labelText: 'Phone'),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _fromCtrl,
                      decoration: const InputDecoration(labelText: 'From'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _toCtrl,
                      decoration: const InputDecoration(labelText: 'To'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              InkWell(
                onTap: _pickDate,
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'Move Date'),
                  child: Text(DateFormat('d MMM yyyy').format(_moveDate)),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _serviceCtrl,
                decoration: const InputDecoration(labelText: 'Service'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                    labelText: 'Amount (₹)',
                    hintText: '0 if not yet quoted — edit later'),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () {
            if (_customerCtrl.text.trim().isEmpty) return;
            Navigator.of(context).pop(_ConfirmOrderResult(
              customer: _customerCtrl.text.trim(),
              phone: _phoneCtrl.text.trim().isEmpty
                  ? null
                  : _phoneCtrl.text.trim(),
              fromCity:
                  _fromCtrl.text.trim().isEmpty ? null : _fromCtrl.text.trim(),
              toCity: _toCtrl.text.trim().isEmpty ? null : _toCtrl.text.trim(),
              moveDate: _moveDate,
              amount: double.tryParse(_amountCtrl.text.trim()) ?? 0,
              service: _serviceCtrl.text.trim().isEmpty
                  ? null
                  : _serviceCtrl.text.trim(),
            ));
          },
          child: const Text('Confirm Order'),
        ),
      ],
    );
  }
}
