// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get arunPackersAndCouriers => 'Arun Packers And Couriers';

  @override
  String get movingYouTowardsYourFuture =>
      'आपको आपके भविष्य की ओर ले जा रहे हैं';

  @override
  String get nameOrPhone => 'नाम या फ़ोन';

  @override
  String get enterYourNameOrPhone => 'अपना नाम या फ़ोन दर्ज करें';

  @override
  String get pin => 'PIN';

  @override
  String get n4DigitPin => '4 अंकों का PIN';

  @override
  String get login => 'लॉगिन';

  @override
  String get securedEncrypted => 'सुरक्षित और एन्क्रिप्टेड';

  @override
  String get dashboard => 'डैशबोर्ड';

  @override
  String get thisMonth => 'इस महीने';

  @override
  String get revenue => 'कमाई';

  @override
  String get labour => 'मज़दूर';

  @override
  String get expenses => 'खर्च';

  @override
  String get porter => 'पोर्टर';

  @override
  String get netProfit => 'शुद्ध मुनाफ़ा';

  @override
  String get activeLeads => 'सक्रिय लीड';

  @override
  String get ordersMonth => 'ऑर्डर/महीना';

  @override
  String get outstanding => 'बकाया';

  @override
  String get reminders => 'रिमाइंडर';

  @override
  String get monthlyTarget => 'मासिक लक्ष्य';

  @override
  String get edit => 'बदलें';

  @override
  String get targetThisMonth => 'इस महीने का लक्ष्य';

  @override
  String get eG200000 => 'e.g. 200000';

  @override
  String get save => 'सेव करें';

  @override
  String get upcomingOrders => 'आने वाले ऑर्डर';

  @override
  String get calendar => 'कैलेंडर ->';

  @override
  String get hotLeads => 'हॉट लीड';

  @override
  String get viewAll => 'सभी देखें ->';

  @override
  String get branchPerformance => 'शाखा प्रदर्शन';

  @override
  String get orders => 'ऑर्डर';

  @override
  String get leads => 'लीड';

  @override
  String get operations => 'ऑपरेशंस';

  @override
  String get payments => 'भुगतान';

  @override
  String get homePageExpenses => 'खर्च';

  @override
  String get salary => 'वेतन';

  @override
  String get settings => 'सेटिंग';

  @override
  String get logout => 'लॉगआउट';

  @override
  String get all => 'सभी';

  @override
  String get pending => 'बाकी';

  @override
  String get completed => 'पूरी';

  @override
  String get cancelled => 'रद्द';

  @override
  String get confirmed => 'पक्का';

  @override
  String get transit => 'ट्रांज़िट';

  @override
  String get done => 'पूरा';

  @override
  String get ord001 => 'ORD-001';

  @override
  String get rajeshKumar => 'Rajesh Kumar';

  @override
  String get chennaiBangalore => 'Chennai → Bangalore';

  @override
  String get n12500 => '₹12,500';

  @override
  String get ord002 => 'ORD-002';

  @override
  String get priyaSharma => 'Priya Sharma';

  @override
  String get mumbaiPune => 'Mumbai → Pune';

  @override
  String get n8000 => '₹8,000';

  @override
  String get ord003 => 'ORD-003';

  @override
  String get inTransit => 'रास्ते में';

  @override
  String get anandVerma => 'Anand Verma';

  @override
  String get delhiNoida => 'Delhi → Noida';

  @override
  String get n5500 => '₹5,500';

  @override
  String get ord004 => 'ORD-004';

  @override
  String get sunitaDevi => 'Sunita Devi';

  @override
  String get hyderabadChennai => 'Hyderabad → Chennai';

  @override
  String get n9200 => '₹9,200';

  @override
  String get leadsCrm => 'लीड / CRM';

  @override
  String get n8 => '8';

  @override
  String get statusNew => 'नया';

  @override
  String get n5 => '5';

  @override
  String get contacted => 'संपर्क हुआ';

  @override
  String get n3 => '3';

  @override
  String get qualified => 'योग्य';

  @override
  String get n2 => '2';

  @override
  String get won => 'जीते';

  @override
  String get lost => 'खोई';

  @override
  String get raviMenon => 'Ravi Menon';

  @override
  String get n919840012345 => '+91 98400 12345';

  @override
  String get chennaiTn => 'Chennai, TN';

  @override
  String get newLead => 'नई लीड';

  @override
  String get deepaNair => 'Deepa Nair';

  @override
  String get n919447067890 => '+91 94470 67890';

  @override
  String get coimbatoreTn => 'Coimbatore, TN';

  @override
  String get karthikS => 'Karthik S.';

  @override
  String get n919940054321 => '+91 99400 54321';

  @override
  String get maduraiTn => 'Madurai, TN';

  @override
  String get meenaRaj => 'Meena Raj';

  @override
  String get n919380011223 => '+91 93800 11223';

  @override
  String get trichyTn => 'Trichy, TN';

  @override
  String get todaySJobs => 'आज के काम';

  @override
  String get n3Active => '3 सक्रिय';

  @override
  String get tn01Ab1234 => 'TN-01-AB-1234';

  @override
  String get loading => 'लोडिंग';

  @override
  String get sureshDriver => 'Suresh (Driver)';

  @override
  String get chennaiVellore => 'Chennai → Vellore';

  @override
  String get tn02Cd5678 => 'TN-02-CD-5678';

  @override
  String get muruganDriver => 'Murugan (Driver)';

  @override
  String get salemErode => 'Salem → Erode';

  @override
  String get tn03Ef9012 => 'TN-03-EF-9012';

  @override
  String get unloading => 'अनलोडिंग';

  @override
  String get baluDriver => 'Balu (Driver)';

  @override
  String get coimbatoreOoty => 'Coimbatore → Ooty';

  @override
  String get upcoming => 'आने वाले';

  @override
  String get tn04Gh3456 => 'TN-04-GH-3456';

  @override
  String get scheduled => 'निर्धारित';

  @override
  String get senthilDriver => 'Senthil (Driver)';

  @override
  String get maduraiTirunelveli => 'Madurai → Tirunelveli';

  @override
  String get vehicleTripLog => 'वाहन ट्रिप लॉग';

  @override
  String get logNewTrip => 'नई ट्रिप दर्ज करें';

  @override
  String get paymentsPageOutstanding => 'बकाया';

  @override
  String get n42800 => '₹42,800';

  @override
  String get receivedMonth => 'प्राप्त (महीना)';

  @override
  String get n124000 => '₹1,24,000';

  @override
  String get pendingPaymentsLive => 'बकाया भुगतान (लाइव)';

  @override
  String get pendingInvoices => 'बकाया इनवॉइस';

  @override
  String get inv045 => 'INV-045';

  @override
  String get due15May => 'देय: 15 मई';

  @override
  String get inv046 => 'INV-046';

  @override
  String get due18May => 'देय: 18 मई';

  @override
  String get inv047 => 'INV-047';

  @override
  String get overdue => 'समय से अधिक बकाया';

  @override
  String get inv048 => 'INV-048';

  @override
  String get due22May => 'देय: 22 मई';

  @override
  String get n16800 => '₹16,800';

  @override
  String get may2025Total => 'मई 2025 कुल';

  @override
  String get n68450 => '₹68,450';

  @override
  String get n12VsLastMonth => '↑ पिछले महीने से 12%';

  @override
  String get liveExpenses => 'लाइव खर्च';

  @override
  String get byCategory => 'श्रेणी के हिसाब से';

  @override
  String get fuel => 'ईंधन';

  @override
  String get n41 => '41%';

  @override
  String get n28000 => '₹28,000';

  @override
  String get tollsPermits => 'टोल और परमिट';

  @override
  String get n18 => '18%';

  @override
  String get maintenance => 'मरम्मत में';

  @override
  String get n26 => '26%';

  @override
  String get n18000 => '₹18,000';

  @override
  String get expensePageLabour => 'मज़दूर';

  @override
  String get n15 => '15%';

  @override
  String get n9950 => '₹9,950';

  @override
  String get addExpense => 'खर्च जोड़ें';

  @override
  String get may2025 => 'मई 2025';

  @override
  String get totalPayroll => 'कुल वेतन';

  @override
  String get n182000 => '₹1,82,000';

  @override
  String get liveStaffData => 'लाइव स्टाफ़ डेटा';

  @override
  String get todaySAttendance => 'आज की उपस्थिति';

  @override
  String get label => '·';

  @override
  String get pendingAdvances => 'बकाया एडवांस';

  @override
  String get bal => 'शेष:';

  @override
  String get staff => 'स्टाफ';

  @override
  String get sureshKumar => 'Suresh Kumar';

  @override
  String get driver => 'ड्राइवर';

  @override
  String get n22000 => '₹22,000';

  @override
  String get paid => 'दिया';

  @override
  String get muruganP => 'Murugan P.';

  @override
  String get n20000 => '₹20,000';

  @override
  String get baluS => 'Balu S.';

  @override
  String get helper => 'हेल्पर';

  @override
  String get n14000 => '₹14,000';

  @override
  String get senthilR => 'Senthil R.';

  @override
  String get n21000 => '₹21,000';

  @override
  String get kalaM => 'Kala M.';

  @override
  String get officeStaff => 'ऑफ़िस स्टाफ़';

  @override
  String get fleet => 'गाड़ियां';

  @override
  String get n4 => '4';

  @override
  String get active => 'चालू';

  @override
  String get idle => 'खाली';

  @override
  String get n1 => '1';

  @override
  String get service => 'सेवा';

  @override
  String get liveFleet => 'लाइव फ़्लीट';

  @override
  String get miniTruck407 => 'मिनी ट्रक (407)';

  @override
  String get suresh => 'Suresh';

  @override
  String get n124560Km => '1,24,560 km';

  @override
  String get largeTruckTata => 'बड़ा ट्रक (टाटा)';

  @override
  String get murugan => 'Murugan';

  @override
  String get n98340Km => '98,340 km';

  @override
  String get inService => 'सर्विस में';

  @override
  String get balu => 'Balu';

  @override
  String get n212000Km => '2,12,000 km';

  @override
  String get largeTruckEicher => 'बड़ा ट्रक (आयशर)';

  @override
  String get senthil => 'Senthil';

  @override
  String get n67890Km => '67,890 km';

  @override
  String get newQuotation => 'नया कोटेशन';

  @override
  String get customerDetails => 'ग्राहक विवरण';

  @override
  String get customerName => 'ग्राहक का नाम';

  @override
  String get enterFullName => 'पूरा नाम दर्ज करें';

  @override
  String get phoneNumber => 'फ़ोन नंबर';

  @override
  String get n91XxxxxXxxxx => '+91 XXXXX XXXXX';

  @override
  String get moveDetails => 'शिफ़्टिंग विवरण';

  @override
  String get fromAddress => 'कहाँ से (पता)';

  @override
  String get pickupLocation => 'पिकअप स्थान';

  @override
  String get toAddress => 'कहाँ तक (पता)';

  @override
  String get dropLocation => 'ड्रॉप स्थान';

  @override
  String get moveDate => 'शिफ्टिंग तारीख';

  @override
  String get ddMmYyyy => 'DD/MM/YYYY';

  @override
  String get floorAccess => 'मंज़िल / पहुँच';

  @override
  String get eG2ndFloorLiftAvailable => 'जैसे, दूसरी मंज़िल, लिफ़्ट उपलब्ध';

  @override
  String get estimate => 'अनुमान';

  @override
  String get quotedAmount => 'कोट की गई राशि (₹)';

  @override
  String get n000 => '0.00';

  @override
  String get notes => 'नोट्स';

  @override
  String get additionalDetails => 'अतिरिक्त विवरण';

  @override
  String get generateQuotation => 'कोटेशन बनाएँ';

  @override
  String get accounts => 'खाते';

  @override
  String get sbiCurrentAC => 'SBI — चालू खाता';

  @override
  String get xxxx4521 => 'XXXX 4521';

  @override
  String get n284500 => '₹2,84,500';

  @override
  String get hdfcSavingsAC => 'HDFC — बचत खाता';

  @override
  String get xxxx7832 => 'XXXX 7832';

  @override
  String get n112300 => '₹1,12,300';

  @override
  String get cashOnHand => 'हाथ में नकद';

  @override
  String get totalBalance => 'कुल शेष';

  @override
  String get n414800 => '₹4,14,800';

  @override
  String get recentTransactions => 'हाल के लेन-देन';

  @override
  String get receivedOrd001 => 'प्राप्त — ORD-001';

  @override
  String get accountsPageN12500 => '+₹12,500';

  @override
  String get may5 => '5 मई';

  @override
  String get fuelTn01Ab1234 => 'ईंधन — TN-01-AB-1234';

  @override
  String get petrolBunk => 'पेट्रोल पंप';

  @override
  String get n3200 => '-₹3,200';

  @override
  String get receivedOrd002 => 'प्राप्त — ORD-002';

  @override
  String get accountsPageN8000 => '+₹8,000';

  @override
  String get may4 => '4 मई';

  @override
  String get tollChennaiNh => 'टोल — चेन्नई NH';

  @override
  String get nhai => 'NHAI';

  @override
  String get n480 => '-₹480';

  @override
  String get pLReport => 'लाभ-हानि रिपोर्ट';

  @override
  String get periodMay2025 => 'अवधि: मई 2025';

  @override
  String get n192000 => '₹1,92,000';

  @override
  String get pLReportPageRevenue => 'कमाई';

  @override
  String get n123550 => '₹1,23,550';

  @override
  String get pLReportPageNetProfit => 'शुद्ध मुनाफ़ा';

  @override
  String get n643 => '64.3%';

  @override
  String get margin => 'मार्जिन';

  @override
  String get topExpenses => 'सबसे बड़े खर्च';

  @override
  String get arunPackersStaff => 'Arun Packers Staff';

  @override
  String get adminArunpackersIn => 'admin@arunpackers.in';

  @override
  String get company => 'कंपनी';

  @override
  String get businessName => 'व्यवसाय का नाम';

  @override
  String get settingsPageArunPackersAndCouriers => 'Arun Packers and Couriers';

  @override
  String get phone => 'फ़ोन';

  @override
  String get n9144XxxxXxxx => '+91 44 XXXX XXXX';

  @override
  String get gstNumber => 'GST नंबर';

  @override
  String get xxxxxxxxxxxx => 'XXXXXXXXXXXX';

  @override
  String get app => 'ऐप';

  @override
  String get notifications => 'सूचनाएं';

  @override
  String get enabled => 'चालू';

  @override
  String get darkMode => 'डार्क मोड';

  @override
  String get on => 'चालू';

  @override
  String get language => 'भाषा';

  @override
  String get english => 'अंग्रेज़ी';

  @override
  String get data => 'डेटा';

  @override
  String get exportData => 'डेटा निर्यात करें';

  @override
  String get csvPdf => 'CSV / PDF';

  @override
  String get backup => 'बैकअप';

  @override
  String get autoDaily => 'स्वतः (रोज़)';

  @override
  String get appTheme => 'ऐप थीम';

  @override
  String get chooseYourPreferredColourScheme => 'अपनी पसंद की रंग योजना चुनें।';

  @override
  String get dark => 'डार्क';

  @override
  String get midnight => 'मिडनाइट';

  @override
  String get light => 'लाइट';

  @override
  String get calendarPageCalendar => 'कैलेंडर';

  @override
  String get mon => 'सोम';

  @override
  String get tue => 'मंगल';

  @override
  String get wed => 'बुध';

  @override
  String get thu => 'गुरु';

  @override
  String get fri => 'शुक्र';

  @override
  String get sat => 'शनि';

  @override
  String get sun => 'रवि';

  @override
  String get n6 => '6';

  @override
  String get n7 => '7';

  @override
  String get n9 => '9';

  @override
  String get n10 => '10';

  @override
  String get n11 => '11';

  @override
  String get n12 => '12';

  @override
  String get n13 => '13';

  @override
  String get n14 => '14';

  @override
  String get calendarPageN15 => '15';

  @override
  String get n17 => '17';

  @override
  String get calendarPageN18 => '18';

  @override
  String get n20 => '20';

  @override
  String get n21 => '21';

  @override
  String get n22 => '22';

  @override
  String get n23 => '23';

  @override
  String get n24 => '24';

  @override
  String get n25 => '25';

  @override
  String get calendarPageN26 => '26';

  @override
  String get n27 => '27';

  @override
  String get n28 => '28';

  @override
  String get n29 => '29';

  @override
  String get n30 => '30';

  @override
  String get n31 => '31';

  @override
  String get remindersFollowUps => 'रिमाइंडर और फ़ॉलो-अप';

  @override
  String get followUpRaviMenon => 'फ़ॉलो-अप: Ravi Menon';

  @override
  String get callRegardingBangaloreMoveQuote =>
      'बेंगलुरु शिफ़्टिंग कोट के बारे में कॉल';

  @override
  String get may7 => '7 मई';

  @override
  String get collectionOrd047 => 'वसूली: ORD-047';

  @override
  String get overduePaymentFromAnandVerma => 'Anand Verma से बकाया भुगतान';

  @override
  String get may8 => '8 मई';

  @override
  String get jobTn01Ab1234 => 'काम: TN-01-AB-1234';

  @override
  String get chennaiVelloreScheduledDelivery =>
      'चेन्नई → वेल्लोर निर्धारित डिलीवरी';

  @override
  String get may9 => '9 मई';

  @override
  String get reviewMayExpenses => 'समीक्षा: मई के खर्च';

  @override
  String get monthlyExpenseReviewWithTeam => 'टीम के साथ मासिक खर्च समीक्षा';

  @override
  String get may12 => '12 मई';

  @override
  String get activeRemindersLive => 'सक्रिय रिमाइंडर (लाइव)';

  @override
  String get addReminder => 'रिमाइंडर जोड़ें';

  @override
  String get materials => 'सामान';

  @override
  String get totalSkus => 'कुल SKU';

  @override
  String get lowStock => 'कम स्टॉक';

  @override
  String get inventory => 'इन्वेंटरी';

  @override
  String get cardboardBoxSmall => 'कार्डबोर्ड बॉक्स — छोटा';

  @override
  String get reorder20 => '20 से कम पर दोबारा मँगाएँ';

  @override
  String get n42Pcs => '42 pcs';

  @override
  String get cardboardBoxMedium => 'कार्डबोर्ड बॉक्स — मध्यम';

  @override
  String get n28Pcs => '28 pcs';

  @override
  String get cardboardBoxLarge => 'कार्डबोर्ड बॉक्स — बड़ा';

  @override
  String get reorder15 => '15 से कम पर दोबारा मँगाएँ';

  @override
  String get n11Pcs => '11 pcs';

  @override
  String get bubbleWrapRoll50m => 'बबल रैप रोल (50 मी)';

  @override
  String get reorder5 => '5 से कम पर दोबारा मँगाएँ';

  @override
  String get n4Rolls => '4 rolls';

  @override
  String get stretchWrapRoll => 'स्ट्रेच रैप रोल';

  @override
  String get ok => 'ठीक';

  @override
  String get n18Rolls => '18 rolls';

  @override
  String get packingTapeBrown => 'पैकिंग टेप (भूरा)';

  @override
  String get reorder10 => '10 से कम पर दोबारा मँगाएँ';

  @override
  String get n7Pcs => '7 pcs';

  @override
  String get furnitureCoverLarge => 'फ़र्नीचर कवर (बड़ा)';

  @override
  String get n24Pcs => '24 pcs';

  @override
  String get rope50m => 'रस्सी (50 मी)';

  @override
  String get n8Rolls => '8 rolls';

  @override
  String get cornerGuards => 'कॉर्नर गार्ड';

  @override
  String get n60Pcs => '60 pcs';

  @override
  String get addRestockItem => 'आइटम जोड़ें / स्टॉक भरें';

  @override
  String get reports => 'रिपोर्ट';

  @override
  String get generateReports => 'रिपोर्ट बनाएँ';

  @override
  String get monthlySummary => 'मासिक सारांश';

  @override
  String get revenueExpensesProfitOverview => 'आय, खर्च और मुनाफ़े का सार';

  @override
  String get customerReport => 'ग्राहक रिपोर्ट';

  @override
  String get topCustomersByRevenue => 'आय के अनुसार शीर्ष ग्राहक';

  @override
  String get driverPerformance => 'ड्राइवर प्रदर्शन';

  @override
  String get jobsCompletedPerDriver => 'प्रति ड्राइवर पूरे किए गए काम';

  @override
  String get expenseBreakdown => 'खर्च का ब्योरा';

  @override
  String get categoryWiseExpenseAnalysis => 'श्रेणी अनुसार खर्च विश्लेषण';

  @override
  String get revenueTrend => 'आय का रुझान';

  @override
  String get monthOnMonthRevenueChart => 'महीने-दर-महीने आय चार्ट';

  @override
  String get outstandingReport => 'बकाया रिपोर्ट';

  @override
  String get pendingPaymentsAgeing => 'बकाया भुगतान और उनकी अवधि';

  @override
  String get vehicleUtilisation => 'वाहन उपयोग';

  @override
  String get fleetUsageAndIdleTimeAnalysis =>
      'फ़्लीट उपयोग और खाली समय का विश्लेषण';

  @override
  String get exportOptions => 'निर्यात विकल्प';

  @override
  String get exportPdf => 'PDF निर्यात करें';

  @override
  String get exportCsv => 'CSV निर्यात करें';

  @override
  String get users => 'उपयोगकर्ता';

  @override
  String get addNewUser => 'नया उपयोगकर्ता जोड़ें';

  @override
  String get admin => 'एडमिन';

  @override
  String get activeUsers => 'सक्रिय उपयोगकर्ता';

  @override
  String get arunKumar => 'Arun Kumar';

  @override
  String get n919840000001 => '+91 98400 00001';

  @override
  String get today => 'आज';

  @override
  String get sureshM => 'Suresh M.';

  @override
  String get n919840000002 => '+91 98400 00002';

  @override
  String get n919840000003 => '+91 98400 00003';

  @override
  String get yesterday => 'कल';

  @override
  String get kalaR => 'Kala R.';

  @override
  String get n919840000004 => '+91 98400 00004';

  @override
  String get n919840000005 => '+91 98400 00005';

  @override
  String get n2DaysAgo => '2 दिन पहले';

  @override
  String get inactiveUsers => 'निष्क्रिय उपयोगकर्ता';

  @override
  String get n919840000006 => '+91 98400 00006';

  @override
  String get inactive => 'बंद';

  @override
  String get n5DaysAgo => '5 दिन पहले';

  @override
  String get recordPayment => 'भुगतान दर्ज करें';

  @override
  String get selectOrder => 'ऑर्डर चुनें';

  @override
  String get loadingPendingOrders => 'बकाया ऑर्डर लोड हो रहे हैं...';

  @override
  String get select => 'चुनें';

  @override
  String get paymentEntry => 'भुगतान दर्ज करें';

  @override
  String get customer => 'ग्राहक:';

  @override
  String get totalAmount => 'कुल राशि:';

  @override
  String get alreadyPaid => 'पहले से भुगतान:';

  @override
  String get amountReceived => 'प्राप्त राशि (₹)';

  @override
  String get selectStatus => 'स्थिति चुनें';

  @override
  String get paymentStatus => 'भुगतान स्थिति';

  @override
  String get partial => 'आंशिक';

  @override
  String get recordPaymentPagePaid => 'दिया';

  @override
  String get savePayment => 'भुगतान सेव करें';

  @override
  String get quickExpense => 'त्वरित खर्च';

  @override
  String get expenseDetails => 'खर्च विवरण';

  @override
  String get amount => 'राशि (₹)';

  @override
  String get selectCategory => 'श्रेणी चुनें';

  @override
  String get category => 'श्रेणी';

  @override
  String get vehicleMaintenance => 'गाड़ी की मरम्मत';

  @override
  String get office => 'ऑफिस';

  @override
  String get material => 'सामान';

  @override
  String get other => 'अन्य';

  @override
  String get date => 'तारीख';

  @override
  String get yyyyMmDd => 'YYYY-MM-DD';

  @override
  String get linkedOrderIdOptional => 'जुड़ा ऑर्डर ID (वैकल्पिक)';

  @override
  String get leaveBlankIfNotLinked => 'जुड़ा न हो तो खाली छोड़ें';

  @override
  String get description => 'विवरण';

  @override
  String get briefDescription => 'संक्षिप्त विवरण';

  @override
  String get saveExpense => 'खर्च सेव करें';

  @override
  String get newOrder => 'नया ऑर्डर';

  @override
  String get newOrderPageCustomer => 'ग्राहक';

  @override
  String get newOrderPageCustomerName => 'ग्राहक का नाम *';

  @override
  String get fullName => 'पूरा नाम';

  @override
  String get newOrderPagePhone => 'फ़ोन *';

  @override
  String get fromCity => 'कहाँ से (शहर) *';

  @override
  String get originCity => 'प्रारंभ शहर';

  @override
  String get toCity => 'कहाँ तक (शहर) *';

  @override
  String get destinationCity => 'गंतव्य शहर';

  @override
  String get pickupAddress => 'पिकअप पता';

  @override
  String get dropAddress => 'ड्रॉप पता';

  @override
  String get fromFloor => 'कहाँ से (मंज़िल)';

  @override
  String get eG2ndFloor => 'जैसे, दूसरी मंज़िल';

  @override
  String get toFloor => 'कहाँ तक (मंज़िल)';

  @override
  String get eGGroundFloor => 'जैसे, भूतल';

  @override
  String get newOrderPageMoveDate => 'शिफ़्टिंग की तारीख *';

  @override
  String get tapToPickDate => 'तारीख चुनने के लिए टैप करें';

  @override
  String get pickDate => 'तारीख चुनें';

  @override
  String get pricingClassification => 'कीमत और वर्गीकरण';

  @override
  String get newOrderPageAmount => 'राशि (₹) *';

  @override
  String get selectService => 'सेवा चुनें';

  @override
  String get newOrderPageService => 'सेवा *';

  @override
  String get houseShifting => 'घर शिफ्टिंग';

  @override
  String get officeShifting => 'ऑफिस शिफ्टिंग';

  @override
  String get vehicleTransport => 'गाड़ी ट्रांसपोर्ट';

  @override
  String get storage => 'स्टोरेज';

  @override
  String get packingOnly => 'सिर्फ़ पैकिंग';

  @override
  String get longDistance => 'लंबी दूरी';

  @override
  String get selectBranch => 'शाखा चुनें';

  @override
  String get branch => 'शाखा *';

  @override
  String get chennai => 'Chennai';

  @override
  String get bengaluru => 'Bengaluru';

  @override
  String get coimbatore => 'Coimbatore';

  @override
  String get selectType => 'प्रकार चुनें';

  @override
  String get orderType => 'ऑर्डर प्रकार *';

  @override
  String get direct => 'सीधा';

  @override
  String get newOrderPagePorter => 'पोर्टर';

  @override
  String get porterCommission => 'पोर्टर कमीशन %';

  @override
  String get saveOrder => 'ऑर्डर सहेजें';

  @override
  String get orderDetails => 'ऑर्डर विवरण';

  @override
  String get orderDetailPageBranch => 'शाखा';

  @override
  String get type => 'प्रकार';

  @override
  String get from => 'से';

  @override
  String get to => 'तक';

  @override
  String get addressFrom => 'पता (कहाँ से)';

  @override
  String get addressTo => 'पता (कहाँ तक)';

  @override
  String get floorFrom => 'मंज़िल (कहाँ से)';

  @override
  String get floorTo => 'मंज़िल (कहाँ तक)';

  @override
  String get payment => 'भुगतान';

  @override
  String get orderDetailPageAmount => 'राशि';

  @override
  String get advancePaid => 'एडवांस भुगतान';

  @override
  String get trackingStatus => 'ट्रैकिंग स्थिति';

  @override
  String get editOrder => 'ऑर्डर बदलें';

  @override
  String get contact => 'संपर्क';

  @override
  String get email => 'ईमेल';

  @override
  String get emailExampleCom => 'email@example.com';

  @override
  String get newLeadPageFromCity => 'कहाँ से (शहर)';

  @override
  String get newLeadPageToCity => 'कहाँ तक (शहर)';

  @override
  String get approxDate => 'अनुमानित तारीख *';

  @override
  String get classification => 'वर्गीकरण';

  @override
  String get status => 'स्थिति *';

  @override
  String get newLeadPageNew => 'नया';

  @override
  String get newLeadPageContacted => 'संपर्क हुआ';

  @override
  String get surveyDone => 'सर्वे हो गया';

  @override
  String get quoted => 'कोट भेजा';

  @override
  String get converted => 'बुक हुए';

  @override
  String get newLeadPageLost => 'खोई';

  @override
  String get howDidTheyHearAboutUs => 'उन्हें हमारे बारे में कैसे पता चला?';

  @override
  String get source => 'स्रोत *';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get phoneCall => 'फ़ोन कॉल';

  @override
  String get website => 'वेबसाइट';

  @override
  String get referral => 'रेफ़रल';

  @override
  String get walkIn => 'वॉक-इन';

  @override
  String get google => 'Google';

  @override
  String get justdial => 'JustDial';

  @override
  String get anyRelevantNotes => 'कोई ज़रूरी नोट';

  @override
  String get saveLead => 'लीड सहेजें';

  @override
  String get leadDetails => 'लीड विवरण';

  @override
  String get leadDetailPageSource => 'स्रोत';

  @override
  String get leadDetailPageApproxDate => 'अनुमानित तारीख';

  @override
  String get convertToOrder => 'ऑर्डर में बदलें';

  @override
  String get editLead => 'लीड बदलें';

  @override
  String get quickEntry => 'त्वरित एंट्री';

  @override
  String get whatWouldYouLikeToDo => 'आप क्या करना चाहेंगे?';

  @override
  String get newInquiry => 'नई पूछताछ';

  @override
  String get confirmBooking => 'बुकिंग पक्की करें';

  @override
  String get cashCollectedByPorter => 'पोर्टर द्वारा लिया गया नकद (₹)';

  @override
  String get leaveBlankIfNoneCollectedYet => 'अभी कुछ न लिया हो तो खाली छोड़ें';

  @override
  String get jrTitle => 'ऑर्डर यात्रा';

  @override
  String get jrStageLead => 'लीड';

  @override
  String get jrStageFollowUp => 'फॉलो-अप';

  @override
  String get jrStageSurvey => 'सर्वे';

  @override
  String get jrStageQuote => 'कोट और पुष्टि';

  @override
  String get jrStageSupervisor => 'सुपरवाइज़र';

  @override
  String get jrStageMoveDay => 'शिफ्टिंग का दिन';

  @override
  String get jrStageInvoice => 'इनवॉइस';

  @override
  String get jrStagePayment => 'भुगतान और समस्याएं';

  @override
  String get jrStageClosed => 'बंद';

  @override
  String get jrStateDone => 'पूरा';

  @override
  String get jrStateSkipped => 'छोड़ा';

  @override
  String get jrStateCurrent => 'अभी';

  @override
  String get jrStatePending => 'बाद में';

  @override
  String get jrDirectOrder => 'छोड़ा · सीधा ऑर्डर';

  @override
  String get jrMoveDate => 'शिफ्टिंग तारीख';

  @override
  String get jrRoute => 'रूट';

  @override
  String get jrOrderValue => 'ऑर्डर मूल्य';

  @override
  String get jrNotSet => 'तय नहीं';

  @override
  String get jrDocuments => 'दस्तावेज़';

  @override
  String get jrDocQuote => 'कोटेशन';

  @override
  String get jrDocInvoice => 'टैक्स इनवॉइस';

  @override
  String get jrDocReceipts => 'मनी रसीदें';

  @override
  String get jrDocLr => 'लॉरी रसीद';

  @override
  String get jrDocReady => 'तैयार · देखने के लिए दबाएं';

  @override
  String jrDocAfter(String stage) {
    return '$stage के बाद';
  }

  @override
  String jrCreated(String date) {
    return 'बनाया $date';
  }

  @override
  String jrSource(String source) {
    return 'स्रोत: $source';
  }

  @override
  String jrService(String service) {
    return 'सेवा: $service';
  }

  @override
  String get jrNoCalls => 'अभी कोई कॉल दर्ज नहीं';

  @override
  String jrCallsLogged(String count) {
    return '$count कॉल दर्ज';
  }

  @override
  String get jrOutcomeQ => 'कॉल कैसी रही?';

  @override
  String get jrOutNoAnswer => 'संपर्क नहीं हुआ';

  @override
  String get jrOutCallback => 'बाद में कॉल';

  @override
  String get jrOutInterested => 'रुचि है';

  @override
  String get jrOutNotInterested => 'रुचि नहीं';

  @override
  String get jrCallNotes => 'कॉल के नोट';

  @override
  String get jrNextFollowUp => 'अगला फ़ॉलो-अप';

  @override
  String get jrToday => 'आज';

  @override
  String get jrTomorrow => 'कल';

  @override
  String get jrIn2Days => '2 दिन में';

  @override
  String get jrNextWeek => 'अगले हफ्ते';

  @override
  String get jrPickDate => 'तारीख चुनें';

  @override
  String get jrNoNext => 'कोई नहीं';

  @override
  String get jrLogCall => 'कॉल दर्ज करें';

  @override
  String get jrCallLogged => 'कॉल दर्ज हो गई';

  @override
  String get jrPickOutcome => 'चुनें कि कॉल कैसी रही';

  @override
  String get jrSurveyWaiting => 'सर्वे लिंक भेजा · ग्राहक का इंतज़ार';

  @override
  String get jrSurveyDone => 'ग्राहक ने सर्वे भेज दिया';

  @override
  String get jrNoSurvey => 'अभी कोई सर्वे नहीं';

  @override
  String get jrOpenSurveyQuote => 'सर्वे और कोट खोलें';

  @override
  String get jrNoQuote => 'अभी कोई कोट नहीं';

  @override
  String jrQuoteLine(String amount) {
    return 'कोट $amount';
  }

  @override
  String jrOrderConfirmed(String id) {
    return 'ऑर्डर $id पक्का';
  }

  @override
  String get jrLeadLost => 'लीड खो गई';

  @override
  String get jrNoSupervisor => 'अभी कोई सुपरवाइज़र नहीं';

  @override
  String jrSupervisorIs(String name) {
    return 'सुपरवाइज़र: $name';
  }

  @override
  String jrCrew(String count) {
    return 'काम पर टीम: $count';
  }

  @override
  String get jrAssignInOrder => 'सुपरवाइज़र सौंपें';

  @override
  String get jrNotStarted => 'शुरू नहीं हुआ';

  @override
  String jrMoveStarted(String time) {
    return 'शुरू हुआ $time';
  }

  @override
  String jrMoveFinished(String time) {
    return 'पूरा हुआ $time';
  }

  @override
  String get jrOpenFieldJob => 'फ़ील्ड जॉब खोलें';

  @override
  String get jrNoInvoice => 'इनवॉइस नहीं बना';

  @override
  String jrInvoiceNo(String no) {
    return 'इनवॉइस $no';
  }

  @override
  String get jrSigned => 'ग्राहक ने हस्ताक्षर किए';

  @override
  String get jrNotSigned => 'ग्राहक का साइन नहीं';

  @override
  String get jrOpenOrder => 'ऑर्डर खोलें';

  @override
  String get jrTotal => 'कुल';

  @override
  String get jrPaid => 'दिया';

  @override
  String get jrBalance => 'बाकी';

  @override
  String get jrRecordPayment => 'भुगतान दर्ज करें';

  @override
  String get jrTickets => 'टिकट';

  @override
  String get jrNoTickets => 'कोई टिकट नहीं';

  @override
  String get jrTicketHint => 'जैसे, AC फ़िटिंग बाकी';

  @override
  String get jrRaiseTicket => 'टिकट बनाएं';

  @override
  String get jrResolve => 'सुलझाएं';

  @override
  String get jrTicketRaised => 'टिकट दर्ज हुआ';

  @override
  String get jrTicketResolved => 'टिकट हल हुआ';

  @override
  String get jrBlockTicket => 'एक टिकट अभी खुला है';

  @override
  String jrBlockBalance(String amount) {
    return '$amount की शेष राशि बकाया है';
  }

  @override
  String get jrCloseOrder => 'ऑर्डर बंद करें';

  @override
  String jrClosedOn(String date) {
    return 'बंद $date';
  }

  @override
  String get jrNotClosed => 'खुला';

  @override
  String jrPaymentLine(String amount, String mode) {
    return '$amount · $mode';
  }

  @override
  String get jrCouldNotLoad => 'यह यात्रा लोड नहीं हो सकी';

  @override
  String get jrRetry => 'फिर कोशिश करें';

  @override
  String jrCouldNotSave(String error) {
    return 'सहेजा नहीं जा सका: $error';
  }

  @override
  String get ngNavHome => 'होम';

  @override
  String get ngNavLeads => 'लीड';

  @override
  String get ngNavOrders => 'ऑर्डर';

  @override
  String get ngNavOps => 'ऑप्स';

  @override
  String get ngNavPay => 'भुगतान';

  @override
  String get ngNavMore => 'और';

  @override
  String get ngMenuDashboard => 'डैशबोर्ड';

  @override
  String get ngMenuLeads => 'लीड / CRM';

  @override
  String get ngMenuInbox => 'इनबॉक्स';

  @override
  String get ngMenuSurveyQuote => 'सर्वे और कोट';

  @override
  String get ngMenuCalendar => 'कैलेंडर';

  @override
  String get ngMenuOrders => 'ऑर्डर';

  @override
  String get ngMenuOperations => 'ऑपरेशंस';

  @override
  String get ngMenuReviews => 'रिव्यू';

  @override
  String get ngMenuPayments => 'भुगतान';

  @override
  String get ngMenuExpenses => 'खर्च';

  @override
  String get ngMenuStaff => 'स्टाफ़';

  @override
  String get ngMenuTeamAttendance => 'टीम उपस्थिति';

  @override
  String get ngMenuFleet => 'वाहन';

  @override
  String get ngMenuMaterials => 'सामग्री';

  @override
  String get ngMenuWarehouses => 'गोदाम';

  @override
  String get ngMenuRateCards => 'रेट कार्ड';

  @override
  String get ngMenuLrRegister => 'LR रजिस्टर';

  @override
  String get ngMenuOpsLog => 'ऑप्स लॉग';

  @override
  String get ngMenuVendors => 'वेंडर';

  @override
  String get ngMenuCustomers => 'ग्राहक';

  @override
  String get ngMenuInsurance => 'बीमा';

  @override
  String get ngMenuTrips => 'ट्रिप';

  @override
  String get ngMenuTasks => 'काम';

  @override
  String get ngMenuAccounts => 'खाते';

  @override
  String get ngMenuPnl => 'लाभ-हानि';

  @override
  String get ngMenuReports => 'रिपोर्ट';

  @override
  String get ngMenuSalary => 'वेतन';

  @override
  String get ngMenuSettings => 'सेटिंग्स';

  @override
  String get ngMenuPlatformAdmin => 'प्लेटफ़ॉर्म एडमिन';

  @override
  String get ngMenuMyJobs => 'मेरे काम';

  @override
  String get ngMenuMyTeam => 'मेरी टीम';

  @override
  String get ngMenuMyEarnings => 'मेरी कमाई';

  @override
  String get ngMenuMyAttendance => 'मेरी उपस्थिति';

  @override
  String get ngGroupSales => 'बिक्री';

  @override
  String get ngGroupOperations => 'ऑपरेशंस';

  @override
  String get ngGroupMoney => 'पैसा';

  @override
  String get ngGroupPeople => 'लोग';

  @override
  String get ngGroupAssets => 'संपत्ति';

  @override
  String get ngGroupPartners => 'पार्टनर';

  @override
  String get ngGroupSetup => 'सेटअप';

  @override
  String get ngGroupField => 'फ़ील्ड';

  @override
  String get ngGroupOther => 'अन्य';

  @override
  String get ngQuickEntry => 'त्वरित एंट्री';

  @override
  String get ngSearchModules => 'मॉड्यूल खोजें';

  @override
  String get ngNoModuleMatches => 'कोई मॉड्यूल नहीं मिला';

  @override
  String get ngHelp => 'मदद';

  @override
  String ngOrgsSwitch(String count) {
    return '$count संगठन · बदलने के लिए टैप करें';
  }

  @override
  String get ngRoleOwner => 'मालिक';

  @override
  String get ngRoleStaff => 'स्टाफ़';

  @override
  String get ngTodayMoves => 'शिफ़्टिंग';

  @override
  String get ngTodayFollowUps => 'फ़ॉलो-अप';

  @override
  String get ngToCollect => 'वसूलना है';

  @override
  String get ngOpenLeads => 'खुली लीड';

  @override
  String get ngNoMovesYet => 'अभी कोई शिफ़्टिंग तय नहीं';

  @override
  String get ngCreateFirstOrder => 'अपना पहला ऑर्डर बनाएँ';

  @override
  String get ngNoLeadsYet => 'अभी कोई लीड नहीं';

  @override
  String get ngAddLead => 'लीड जोड़ें';

  @override
  String get ngAllLeads => 'सभी लीड';

  @override
  String get ngConversion => 'कन्वर्ज़न';

  @override
  String get ngOpen => 'खुली';

  @override
  String get ngOther => 'अन्य';

  @override
  String get ngSurveyResponse => 'सर्वे का जवाब मिला';

  @override
  String get ngFollowUpOverdue => 'फ़ॉलो-अप में देरी';

  @override
  String get ngCall => 'कॉल';

  @override
  String get ngWhatsApp => 'WhatsApp';

  @override
  String get ngSurvey => 'सर्वे';

  @override
  String get ngNewLead => 'नई लीड';

  @override
  String get ngNameOrPhone => 'नाम या फ़ोन';

  @override
  String get ngNoLeadsMatch => 'कोई लीड नहीं मिली';

  @override
  String get ngLeadsEmptyHint => 'नई लीड से पूछताछ जोड़ें, वह यहाँ दिखेगी।';

  @override
  String get ngSurveyLinkCreated => 'सर्वे लिंक बन गया';

  @override
  String get ngCopyClose => 'कॉपी करें और बंद करें';

  @override
  String get ngClose => 'बंद करें';

  @override
  String get ngTabAll => 'सभी';

  @override
  String get ngTabPending => 'चालू';

  @override
  String get ngTabCompleted => 'पूरे';

  @override
  String get ngTabCancelled => 'रद्द';

  @override
  String get ngToday => 'आज';

  @override
  String get ngTomorrow => 'कल';

  @override
  String get ngYesterday => 'बीता कल';

  @override
  String get ngNoMoveDate => 'शिफ़्टिंग की तारीख नहीं';

  @override
  String get ngPaid => 'भुगतान हुआ';

  @override
  String get ngPartPaid => 'आंशिक भुगतान';

  @override
  String get ngDue => 'बकाया';

  @override
  String get ngUnpaid => 'अदत्त';

  @override
  String get ngNewOrder => 'नया ऑर्डर';

  @override
  String get ngNoOrdersHere => 'यहाँ कोई ऑर्डर नहीं';

  @override
  String get ngRemind => 'याद दिलाएँ';

  @override
  String get ngRecord => 'दर्ज करें';

  @override
  String get ngOverdue => 'देरी से';

  @override
  String get ngUpcoming => 'आने वाले';

  @override
  String get ngNothingToCollect => 'वसूलने को कुछ नहीं';

  @override
  String get ngLinkedDevice => 'जुड़ा हुआ डिवाइस';

  @override
  String get ngEnterPin => 'अपना 4 अंकों का PIN डालें';

  @override
  String get ngVerifying => 'जाँच हो रही है…';

  @override
  String get ngUseEmail => 'इसके बजाय ईमेल से लॉगिन करें';

  @override
  String get ngSwitchDevice => 'आपका संगठन नहीं? डिवाइस बदलें';

  @override
  String get ngSecuredBy => 'Nagarva द्वारा सुरक्षित';

  @override
  String get suCreate => 'अपना बिज़नेस खाता बनाएं';

  @override
  String suStep(String n) {
    return 'चरण $n / 4';
  }

  @override
  String get suS1 => 'मोबाइल';

  @override
  String get suS2 => 'बिज़नेस';

  @override
  String get suS3 => 'दस्तावेज़';

  @override
  String get suS4 => 'जाँच';

  @override
  String get suPhS => 'मालिक का नंबर डालें। इसी से लॉग इन होगा।';

  @override
  String get suPh => 'मोबाइल नंबर';

  @override
  String get suSend => 'OTP भेजें';

  @override
  String get suPhBad => '10 अंकों का मोबाइल नंबर डालें';

  @override
  String get suOtpT => 'OTP डालें';

  @override
  String suOtpS(String p) {
    return '+91 $p पर भेजा गया';
  }

  @override
  String get suEnter => '6 अंकों का कोड लिखें';

  @override
  String get suVerify => 'पुष्टि करें';

  @override
  String get suOtpBad => '6 अंकों का OTP डालें';

  @override
  String get suResend => 'OTP दोबारा भेजें';

  @override
  String get suResent => 'OTP दोबारा भेजा गया';

  @override
  String get suChange => 'नंबर बदलें';

  @override
  String get suBzT => 'आपके बिज़नेस के बारे में';

  @override
  String get suBzS => 'यह आपके कोटेशन और बिल पर दिखेगा। बाद में बदल सकते हैं।';

  @override
  String get suName => 'बिज़नेस का नाम';

  @override
  String get suNameP => 'जैसे अरुण पैकर्स एंड मूवर्स';

  @override
  String get suOwner => 'मालिक का नाम';

  @override
  String get suEmail => 'ईमेल (वैकल्पिक)';

  @override
  String get suEmailP => 'बिल और पासवर्ड रीसेट के लिए';

  @override
  String get suCity => 'शहर';

  @override
  String get suType => 'आप क्या काम करते हैं?';

  @override
  String get suTPm => 'पैकर्स एंड मूवर्स';

  @override
  String get suTPmS => 'घर और ऑफ़िस शिफ्टिंग';

  @override
  String get suTTr => 'ट्रांसपोर्ट';

  @override
  String get suTTrS => 'ट्रक, ट्रिप और LR';

  @override
  String get suTBo => 'दोनों';

  @override
  String get suTBoS => 'शिफ्टिंग और ट्रांसपोर्ट';

  @override
  String get suGst => 'GSTIN (वैकल्पिक)';

  @override
  String get suGstP => '15 अक्षरों का GST नंबर';

  @override
  String get suRef => 'रेफ़रल कोड (वैकल्पिक)';

  @override
  String get suNeedBz => 'बिज़नेस का नाम, मालिक का नाम और शहर भरें';

  @override
  String get suGstBad => 'GSTIN 15 अक्षरों का होना चाहिए';

  @override
  String get suEmailBad => 'ईमेल पता जाँचें';

  @override
  String get suDcT => 'अपना बिज़नेस सत्यापित करें';

  @override
  String get suDcS =>
      'फ़ोटो या PDF। खाता चालू होने से पहले हमारी टीम इन्हें जाँचती है।';

  @override
  String get suPan => 'PAN कार्ड';

  @override
  String get suPanS => 'मालिक या बिज़नेस का PAN';

  @override
  String get suGstC => 'GST प्रमाणपत्र';

  @override
  String get suGstCS => 'ज़रूरी, क्योंकि आपने GSTIN डाला है';

  @override
  String get suShop => 'ऑफ़िस या गोदाम की फ़ोटो';

  @override
  String get suShopS => 'इससे जल्दी सत्यापन होता है';

  @override
  String get suUpload => 'अपलोड';

  @override
  String get suReq => 'ज़रूरी';

  @override
  String get suOpt => 'वैकल्पिक';

  @override
  String get suNeedPan => 'अपना PAN कार्ड अपलोड करें';

  @override
  String get suNeedGstC => 'GST प्रमाणपत्र अपलोड करें या GSTIN हटाएं';

  @override
  String get suPriv =>
      'दस्तावेज़ सिर्फ़ बिज़नेस सत्यापन के लिए हैं। ये आपके स्टाफ़ या ग्राहकों को नहीं दिखते।';

  @override
  String get suRvT => 'जाँचें और भेजें';

  @override
  String get suEdit => 'बदलें';

  @override
  String get suNext => 'आगे क्या होगा';

  @override
  String get suN1 =>
      'हमारी टीम आपकी जानकारी जाँचेगी, आमतौर पर 1 कार्यदिवस में।';

  @override
  String get suN3 => 'आप फ़्री प्लान से शुरू करेंगे। कभी भी अपग्रेड करें।';

  @override
  String get suNeedAgree => 'आगे बढ़ने के लिए शर्तें स्वीकार करें';

  @override
  String get suSubmit => 'मंज़ूरी के लिए भेजें';

  @override
  String get suContinue => 'आगे बढ़ें';

  @override
  String get suMob => 'मोबाइल';

  @override
  String get suBt => 'बिज़नेस का प्रकार';

  @override
  String get suNone => 'नहीं जोड़ा';

  @override
  String get suPendT => 'आवेदन की जाँच चल रही है';

  @override
  String suAppId(String id) {
    return 'आवेदन $id';
  }

  @override
  String get suTl1 => 'भेजा गया';

  @override
  String get suTl2 => 'दस्तावेज़ जाँच';

  @override
  String get suTl3 => 'खाता तैयार';

  @override
  String get suOkT => 'आपका खाता तैयार है';

  @override
  String suOkS(String b) {
    return '$b मंज़ूर हो गया। आप फ़्री प्लान पर हैं।';
  }

  @override
  String get suStart => 'Nagarva शुरू करें';

  @override
  String get suNoT => 'बदलाव ज़रूरी';

  @override
  String get suNoS =>
      'हमारी टीम अभी आवेदन मंज़ूर नहीं कर सकी। नीचे दी गई चीज़ ठीक करके दोबारा भेजें।';

  @override
  String get suFix => 'ठीक करके दोबारा भेजें';

  @override
  String get suWa => 'WhatsApp पर बात करें';

  @override
  String get suToLogin => 'लॉग इन पर वापस';

  @override
  String get suHave => 'पहले से खाता है?';

  @override
  String get suLogin => 'लॉग इन';

  @override
  String get suBnP => 'आवेदन की जाँच चल रही है';

  @override
  String get suBnOk => 'खाता मंज़ूर';

  @override
  String get suBnNo => 'आवेदन में बदलाव ज़रूरी';

  @override
  String get suView => 'देखें';

  @override
  String get suSent => 'आवेदन भेजा गया';

  @override
  String get lgTerms => 'उपयोग की शर्तें';

  @override
  String get lgPriv => 'गोपनीयता नीति';

  @override
  String suTrT(String n) {
    return '$n दिन के लिए Pro मुफ़्त आज़माएं';
  }

  @override
  String suTrUsers(String n) {
    return '$n उपयोगकर्ता तक';
  }

  @override
  String get suTrOrdersAll => 'हर महीने असीमित ऑर्डर';

  @override
  String suTrOrders(String n) {
    return 'हर महीने $n ऑर्डर';
  }

  @override
  String get suTrReports => 'रिपोर्ट और लाभ-हानि';

  @override
  String get suTrBranches => 'कई शाखाएं';

  @override
  String suTrNote(String n) {
    return 'कार्ड की ज़रूरत नहीं। $n दिन बाद आप अपने-आप फ़्री प्लान पर आ जाएंगे। आपका डेटा सुरक्षित रहेगा।';
  }

  @override
  String suTrBtn(String n) {
    return '$n दिन का Pro ट्रायल शुरू करें';
  }

  @override
  String get suStayFree => 'फ़्री पर ही रहें';

  @override
  String suTrOn(String n) {
    return 'Pro ट्रायल शुरू · $n दिन';
  }

  @override
  String get suFreeOn => 'आप फ़्री प्लान पर हैं';

  @override
  String plTrBan(String n) {
    return 'Pro ट्रायल $n दिन में खत्म होगा। फिर आप फ़्री प्लान पर आ जाएंगे। आपका डेटा सुरक्षित रहेगा।';
  }

  @override
  String get plTrEnded =>
      'आपका Pro ट्रायल खत्म हो गया है। आप फ़्री प्लान पर हैं और आपका सारा डेटा सुरक्षित है।';

  @override
  String plTrEnds(String d, String n) {
    return 'Pro ट्रायल $d को खत्म · $n दिन बाकी';
  }

  @override
  String get suN2b =>
      'अपनी स्थिति देखने के लिए कभी भी इसी मोबाइल नंबर से लॉग इन करें।';

  @override
  String suPendS2(String p) {
    return 'हम आमतौर पर 1 कार्यदिवस में जवाब देते हैं। नतीजा देखने के लिए +91 $p से लॉग इन करें।';
  }

  @override
  String get suOtpUnavailable =>
      'मोबाइल से साइन-अप अभी चालू नहीं है। कृपया Nagarva सहायता से संपर्क करें।';

  @override
  String get suSendFailed =>
      'OTP नहीं भेजा जा सका। नंबर जांचें और फिर कोशिश करें।';

  @override
  String get suOtpFailed => 'यह कोड काम नहीं किया। जांचें और फिर कोशिश करें।';

  @override
  String get suUploadFailed => 'अपलोड नहीं हुआ। फिर कोशिश करें।';

  @override
  String get suMobileLogin => 'मोबाइल नंबर से लॉग इन करें';

  @override
  String get suRefresh => 'स्थिति देखें';

  @override
  String suResendIn(String n) {
    return '$n सेकंड में दोबारा भेजें';
  }

  @override
  String get suAgreeLead => 'मैं इनसे सहमत हूँ:';

  @override
  String get ngGreetMorning => 'सुप्रभात';

  @override
  String get ngGreetAfternoon => 'शुभ दोपहर';

  @override
  String get ngGreetEvening => 'शुभ संध्या';

  @override
  String ngPlanName(String plan) {
    return '$plan प्लान';
  }

  @override
  String get ngPlanActive => 'सक्रिय';

  @override
  String get ngPlanTrial => 'ट्रायल';

  @override
  String get ngPlanEndingSoon => 'जल्द खत्म';

  @override
  String get ngPlanEnded => 'समाप्त';

  @override
  String ngPlanTrialEnds(String date, int days) {
    return 'ट्रायल $date को खत्म · $days दिन बाकी';
  }

  @override
  String ngPlanReadOnlyIn(int days) {
    return 'ट्रायल खत्म · $days दिन में केवल देखना';
  }

  @override
  String get ngPlanReadOnly => 'ट्रायल खत्म · केवल देखना';

  @override
  String get ngPlanNoExpiry => 'कोई समाप्ति तिथि नहीं';

  @override
  String get ngPlanSee => 'प्लान';

  @override
  String get ngPaymentsDue => 'बकाया भुगतान';

  @override
  String ngPaymentsDueSub(int n) {
    return '$n ऑर्डर का पूरा भुगतान नहीं';
  }

  @override
  String get ngOverdueFollowUps => 'छूटे फॉलो-अप';

  @override
  String get ngOverdueFollowUpsSub => 'पहले इन्हें कॉल करें';

  @override
  String get ngTodaysPlan => 'आज की योजना';

  @override
  String get ngNothingToday => 'आज के लिए कुछ तय नहीं';

  @override
  String get ngComingUp => 'आगामी';

  @override
  String ngAgendaMove(String name) {
    return 'शिफ्टिंग · $name';
  }

  @override
  String get ngAllDay => 'पूरा दिन';

  @override
  String get ngPeriodThisMonth => 'इस महीने';

  @override
  String get ngPeriodLastMonth => 'पिछला महीना';

  @override
  String get ngPeriod3m => 'पिछले 3 महीने';

  @override
  String get ngPeriodFy => 'इस वित्त वर्ष';

  @override
  String get ngPeriodAll => 'अब तक';

  @override
  String get ngPickPeriod => 'इस अवधि के आंकड़े';

  @override
  String get ngProfitTarget => 'लाभ लक्ष्य';

  @override
  String get ngSetTarget => 'मासिक लाभ लक्ष्य तय करें';

  @override
  String get ngSetTargetSub =>
      'जिस राशि तक पहुँचना है, उसे तय करने के लिए टैप करें';

  @override
  String get ngProfit => 'लाभ';

  @override
  String ngProfitAfter(String labour, String expenses) {
    return 'मज़दूरी $labour और खर्च $expenses के बाद';
  }

  @override
  String get ngAddExpense => 'खर्च जोड़ें';

  @override
  String get ngSeeAll => 'सभी देखें';

  @override
  String get ngHotLeads => 'हॉट लीड';

  @override
  String get ngBranches => 'शाखाएँ';

  @override
  String ngOrdersN(int n) {
    return '$n ऑर्डर';
  }

  @override
  String get ngTargetDone => 'लक्ष्य पूरा';

  @override
  String get ngNoProfitYet => 'इस अवधि में अभी लाभ नहीं';

  @override
  String get ngEditTarget => 'मासिक लाभ लक्ष्य';

  @override
  String get ngQuote => 'कोटेशन';

  @override
  String get ngTabDone => 'पूरे';

  @override
  String get ngReceived => 'प्राप्त';

  @override
  String ngDaysLate(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n दिन देर',
      one: '1 दिन देर',
    );
    return '$_temp0';
  }

  @override
  String get ngNoPaymentsYet => 'अभी कोई भुगतान दर्ज नहीं';

  @override
  String get ngOpsTitle => 'ऑपरेशन्स';

  @override
  String get ngOpsNewTrip => 'नई ट्रिप';

  @override
  String get ngOpsCrewsOut => 'काम पर टीम';

  @override
  String get ngOpsVehiclesFree => 'खाली वाहन';

  @override
  String get ngOpsAttention => 'ध्यान दें';

  @override
  String ngOpsNoCrew(String name) {
    return 'टीम नहीं · $name';
  }

  @override
  String get ngOpsAssign => 'असाइन करें';

  @override
  String get ngOpsAssignCrew => 'टीम असाइन करें';

  @override
  String ngOpsInsuranceExpires(int n) {
    return 'बीमा $n दिन में खत्म';
  }

  @override
  String get ngOpsInsuranceExpired => 'बीमा खत्म';

  @override
  String ngOpsLowStock(String name) {
    return '$name कम है';
  }

  @override
  String ngOpsStockLeft(String qty) {
    return '$qty बचा';
  }

  @override
  String get ngOpsReorder => 'फिर मंगाएँ';

  @override
  String get ngOpsView => 'देखें';

  @override
  String get ngOpsAwaiting => 'मंज़ूरी बाकी';

  @override
  String get ngOpsJobs => 'काम';

  @override
  String get ngOpsNoJobs => 'इस दिन कोई शिफ्टिंग नहीं';

  @override
  String get ngOpsFleet => 'फ्लीट';

  @override
  String ngOpsFleetSummary(int free, int total) {
    return '$total में $free खाली';
  }

  @override
  String get ngOpsInService => 'सर्विस में';

  @override
  String get ngOpsOnJob => 'काम पर';

  @override
  String get ngOpsFree => 'खाली';

  @override
  String ngExpCount(int n) {
    return '$n खर्च';
  }

  @override
  String ngExpVsLast(int pct) {
    return 'पिछले महीने से $pct%';
  }

  @override
  String get ngExpThisWeek => 'इस हफ्ते';

  @override
  String get ngExpOrderOnly => 'केवल ऑर्डर से जुड़े';

  @override
  String get ngExpNone => 'इस अवधि में कोई खर्च नहीं';

  @override
  String get ngExpUncategorised => 'बिना श्रेणी';

  @override
  String get ngExpDelete => 'खर्च हटाएँ';

  @override
  String get ngExpByCategory => 'श्रेणी अनुसार';

  @override
  String get ngExpNoCat => 'अभी बाँटने को कुछ नहीं';

  @override
  String get ngExpNoCatSub => 'खर्च दर्ज करते ही श्रेणियाँ यहाँ दिखेंगी।';

  @override
  String get ngFleetNew => 'नया वाहन';

  @override
  String get ngFleetActive => 'सक्रिय';

  @override
  String get ngFleetMaintenance => 'मरम्मत';

  @override
  String get ngFleetInactive => 'निष्क्रिय';

  @override
  String get ngFleetNone =>
      'अभी कोई वाहन नहीं। कागज़ और ट्रिप देखने के लिए एक जोड़ें।';

  @override
  String get ngFleetDelete => 'वाहन हटाएँ';

  @override
  String get ngFleetInsurance => 'बीमा';

  @override
  String get ngFleetPermit => 'परमिट';

  @override
  String ngFleetExpires(String doc, int n) {
    return '$doc $n दिन में खत्म';
  }

  @override
  String ngFleetExpired(String doc, int n) {
    return '$doc $n दिन पहले खत्म';
  }

  @override
  String get ngMatNew => 'नया सामान';

  @override
  String get ngMatSearch => 'सामान खोजें';

  @override
  String get ngMatReorderSoon => 'जल्द मंगाएँ';

  @override
  String get ngMatReturnable => 'वापसी योग्य';

  @override
  String ngMatMin(String n) {
    return 'न्यूनतम $n';
  }

  @override
  String get ngMatDelete => 'सामान हटाएँ';

  @override
  String get ngMatNone => 'अभी यहाँ कोई सामान नहीं';

  @override
  String get ngTripPlanned => 'योजना में';

  @override
  String get ngTripOngoing => 'चालू';

  @override
  String get ngTripNone => 'अभी कोई ट्रिप नहीं';

  @override
  String get ngTripNoNumber => '(ट्रिप नंबर नहीं)';

  @override
  String get ngTripHired => 'किराये का';

  @override
  String get ngTripOwn => 'अपना';

  @override
  String get ngTripDelete => 'ट्रिप हटाएँ';

  @override
  String ngCustCount(int n) {
    return '$n ग्राहक';
  }

  @override
  String get ngCustNew => 'नया';

  @override
  String get ngCustSearch => 'नाम, फ़ोन या कंपनी खोजें';

  @override
  String get ngCustNone => 'कोई ग्राहक नहीं मिला';

  @override
  String ngCustDue(String amount) {
    return '$amount बकाया';
  }

  @override
  String get ngStaffTitle => 'स्टाफ़';

  @override
  String ngStaffSummary(int n, int monthly, int other) {
    return '$n लोग · $monthly मासिक · $other दैनिक / अस्थायी';
  }

  @override
  String get ngStaffAdd => 'स्टाफ़ जोड़ें';

  @override
  String get ngStaffMonthly => 'तय मासिक';

  @override
  String get ngStaffDaily => 'दैनिक';

  @override
  String get ngStaffTemporary => 'अस्थायी';

  @override
  String ngStaffJoined(String date) {
    return 'जुड़े $date';
  }

  @override
  String get ngStaffAllRoles => 'सभी भूमिकाएँ';

  @override
  String get ngStaffNone => 'अभी कोई स्टाफ़ नहीं';

  @override
  String get ngStaffInactive => 'निष्क्रिय';

  @override
  String get ngSalTitle => 'वेतन';

  @override
  String get ngSalToPay => 'देना है';

  @override
  String get ngSalAdvances => 'एडवांस';

  @override
  String get ngSalPaid => 'दिया गया वेतन';

  @override
  String get ngSalBalance => 'बाकी';

  @override
  String ngSalJobs(int n) {
    return '$n काम';
  }

  @override
  String ngSalAdvance(String amount) {
    return 'एडवांस $amount';
  }

  @override
  String get ngSalNote =>
      'कमाई इस महीने हर काम में दर्ज टीम से आती है। भुगतान या एडवांस देने के लिए व्यक्ति खोलें।';

  @override
  String get ngSetApp => 'ऐप';

  @override
  String get ngSetLanguage => 'भाषा';

  @override
  String get ngSetTheme => 'थीम';

  @override
  String get ngSetThemeLight => 'लाइट';

  @override
  String get ngSetThemeDark => 'डार्क';

  @override
  String get ngSetThemeMidnight => 'मिडनाइट';

  @override
  String get ngSetNotifications => 'सूचनाएँ';

  @override
  String get ngSetNotificationsSub => 'ऐप खुला होने पर अलर्ट दिखाएँ';

  @override
  String get ngSetBusiness => 'व्यवसाय';

  @override
  String get ngSetBizDetails => 'व्यवसाय विवरण';

  @override
  String get ngSetBizDetailsSub =>
      'नाम, टैगलाइन, GST, पता, लोगो, हस्ताक्षर, शर्तें, नंबरिंग';

  @override
  String get ngSetCft => 'CFT और पैकेज';

  @override
  String get ngSetCftSub => 'सामान का आयतन, घर का आकार, स्टोरेज दरें';

  @override
  String get ngSetSecurity => 'सुरक्षा';

  @override
  String get ngSetLogin => 'लॉगिन और सुरक्षा';

  @override
  String get ngSetLoginSub => 'आपका ऐप PIN';

  @override
  String get ngSetAccount => 'खाता और सहायता';

  @override
  String get ngSetPlan => 'प्लान और बिलिंग';

  @override
  String get ngSetPlanSub => 'आपका प्लान और सीमाएँ';

  @override
  String get ngSetRecycle => 'हटाए गए आइटम';

  @override
  String get ngSetRecycleSub => 'गलती से हटाया गया वापस लाएँ';

  @override
  String get ngSetHelp => 'सहायता';

  @override
  String get ngSetHelpSub => 'सहायता संपर्क, गोपनीयता नीति और शर्तें';

  @override
  String get ngSetPorter => 'Porter इंटीग्रेशन';

  @override
  String get ngSetPorterSub =>
      'डैशबोर्ड पर Porter कमीशन दिखाएँ। केवल तभी चालू करें जब आपका व्यवसाय Porter इस्तेमाल करता हो।';

  @override
  String odStageOf(int n, int total, String name) {
    return 'चरण $n / $total · $name';
  }

  @override
  String get odJourneyDone => 'सभी चरण पूरे';

  @override
  String get odMaps => 'मैप्स';

  @override
  String get odProgress => 'प्रगति';

  @override
  String get odInProgress => 'जारी है';

  @override
  String odMarkAs(String stage) {
    return '$stage मार्क करें';
  }

  @override
  String get odDeliveredHint =>
      'डिलीवरी तब दर्ज होती है जब टीम ग्राहक के कोड से काम पूरा करती है।';

  @override
  String get odOpenFieldJob => 'फील्ड जॉब खोलें';

  @override
  String get odCrewVehicle => 'टीम और वाहन';

  @override
  String get odNoCrew => 'अभी कोई टीम नहीं';

  @override
  String get odNoVehicle => 'कोई वाहन नहीं';

  @override
  String odSupervisorCrew(String name, int count) {
    return 'सुपरवाइज़र · $name · $count लोग';
  }

  @override
  String odCrewCount(int count) {
    return '$count लोग';
  }

  @override
  String get odPayment => 'भुगतान';

  @override
  String get odTotal => 'कुल';

  @override
  String get odPaid => 'भुगतान हुआ';

  @override
  String get odBalance => 'बकाया';

  @override
  String get odPartPaid => 'आंशिक भुगतान';

  @override
  String get odFullyPaid => 'पूरा भुगतान';

  @override
  String get odUnpaid => 'बकाया';

  @override
  String get odRemind => 'याद दिलाएँ';

  @override
  String get odRecordPayment => 'भुगतान दर्ज करें';

  @override
  String get odActivity => 'गतिविधि';

  @override
  String odAllN(int count) {
    return 'सभी $count';
  }

  @override
  String get odStageChanged => 'चरण बदला';

  @override
  String odPaymentReceived(String amount) {
    return 'भुगतान मिला · $amount';
  }

  @override
  String get odNoActivity => 'इस ऑर्डर पर अभी कुछ दर्ज नहीं है।';

  @override
  String get odMoveDetails => 'शिफ्टिंग विवरण';

  @override
  String get odCancelled => 'रद्द';

  @override
  String get odMore => 'और विकल्प';

  @override
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor) {
    return 'Hi $customer, a balance of $amount is due for your move ($orderId). Thank you, $vendor';
  }

  @override
  String get odStConfirmed => 'पुष्ट';

  @override
  String get odStPacking => 'पैकिंग';

  @override
  String get odStInTransit => 'रास्ते में';

  @override
  String get odStArrived => 'पहुँच गया';

  @override
  String get odStDelivered => 'डिलीवर';

  @override
  String get odStCompleted => 'पूरा';

  @override
  String get nlPhone => 'फ़ोन';

  @override
  String get nlName => 'नाम';

  @override
  String get nlRoute => 'रूट';

  @override
  String get nlMovingFrom => 'कहाँ से';

  @override
  String get nlMovingTo => 'कहाँ तक';

  @override
  String get nlService => 'सेवा';

  @override
  String get nlWhen => 'कब';

  @override
  String get nlToday => 'आज';

  @override
  String get nlTomorrow => 'कल';

  @override
  String get nlPickDate => 'तारीख चुनें';

  @override
  String get nlSource => 'स्रोत';

  @override
  String get nlBranch => 'शाखा';

  @override
  String get nlNextStep => 'अगला कदम';

  @override
  String get nlStepFollow => 'फॉलो-अप';

  @override
  String get nlStepFollowSub => 'बाद में फिर कॉल करें';

  @override
  String get nlStepSurvey => 'सर्वे';

  @override
  String get nlStepSurveySub => 'विज़िट, लिंक या कॉल पर';

  @override
  String get nlStepQuote => 'सर्वे छोड़ें · कोटेशन';

  @override
  String get nlStepQuoteSub => 'इसी कॉल पर कीमत';

  @override
  String get nlStepConfirm => 'ऑर्डर पक्का करें';

  @override
  String get nlStepConfirmSub => 'ग्राहक अभी मान गए';

  @override
  String get nlMore => 'और जानकारी';

  @override
  String get nlEmail => 'ईमेल (वैकल्पिक)';

  @override
  String get nlNotes => 'नोट्स';

  @override
  String get nlNameRequired => 'ग्राहक का नाम लिखें।';

  @override
  String get nlNoBranches => 'लीड सेव करने से पहले सेटिंग्स में शाखा जोड़ें।';

  @override
  String get nlUpdateLead => 'लीड अपडेट करें';

  @override
  String get noPickup => 'पिकअप';

  @override
  String get noDrop => 'ड्रॉप';

  @override
  String get noPricing => 'कीमत और स्रोत';

  @override
  String get ngSetFy => 'वित्त वर्ष और नंबरिंग';

  @override
  String get ngSetFySub => 'अगले साल के बिल नंबर शुरू करें';

  @override
  String get ngSetWa => 'WhatsApp';

  @override
  String get ngSetWaSub => 'अपने नंबर से मैसेज भेजें';

  @override
  String get ngSetAutoWa => 'ऑटो WhatsApp';

  @override
  String get ngSetAutoWaSub => 'हर चरण पर ग्राहक को भेजे जाने वाले मैसेज';

  @override
  String get mdTitle => 'मॉड्यूल';

  @override
  String get mdSettingsSub => 'पैकर्स और मूवर्स, ट्रांसपोर्ट या दोनों';

  @override
  String get mdType => 'आपका व्यवसाय';

  @override
  String get mdAdv => 'एडवांस';

  @override
  String mdCount(int count, int total) {
    return '$total में से $count मॉड्यूल चालू';
  }

  @override
  String mdGroupOn(int count, int total) {
    return '$total में से $count चालू';
  }

  @override
  String get mdNote =>
      'बंद मॉड्यूल मेन्यू से हट जाते हैं। आपका डेटा सेव रहता है और मॉड्यूल फिर चालू करने पर वापस आता है।';

  @override
  String get mdReset => 'इस व्यवसाय के लिए सुझाए गए पर वापस';

  @override
  String mdResetDone(String type) {
    return '$type के लिए मॉड्यूल रीसेट';
  }

  @override
  String mdTypeSet(String type) {
    return '$type चुना · मेन्यू अपडेट';
  }

  @override
  String get mdOwnerOnly => 'सिर्फ मालिक मॉड्यूल बदल सकते हैं';

  @override
  String get mdSaveFailed => 'सेव नहीं हुआ। कनेक्शन देखकर फिर कोशिश करें।';

  @override
  String get btPm => 'पैकर्स और मूवर्स';

  @override
  String get btPmS => 'घर, ऑफ़िस और गाड़ी शिफ्टिंग';

  @override
  String get btTr => 'ट्रांसपोर्ट / लॉजिस्टिक्स';

  @override
  String get btTrS => 'ट्रक, ट्रिप, भाड़ा और ड्राइवर';

  @override
  String get btBoth => 'दोनों';

  @override
  String get btBothS => 'शिफ्टिंग और ट्रांसपोर्ट, सब चालू';

  @override
  String get btTitle => 'आपका व्यवसाय क्या करता है?';

  @override
  String get btSub =>
      'हम सिर्फ ज़रूरी मॉड्यूल दिखाएंगे। इसे कभी भी सेटिंग्स › मॉड्यूल में बदल सकते हैं।';

  @override
  String get btLater => 'बाद में सेटिंग्स › मॉड्यूल में बदल सकते हैं';

  @override
  String get dwTitle => 'विजेट';

  @override
  String get dwSub => 'मालिक के डैशबोर्ड पर क्या दिखे';

  @override
  String get dwNote =>
      'मालिक के डैशबोर्ड पर इसी क्रम में दिखते हैं। तीर से ऊपर करें, स्विच से छिपाएं।';

  @override
  String dwShown(int n) {
    return 'दिख रहा · स्थान $n';
  }

  @override
  String get dwHidden => 'छिपा';

  @override
  String get dwUp => 'ऊपर';

  @override
  String get dwToday => 'आज के आंकड़े';

  @override
  String get dwFleet => 'गाड़ियों की स्थिति';

  @override
  String dwFleetSub(int a, int s) {
    return '$a चालू · $s सर्विस में';
  }

  @override
  String get dwAttendance => 'स्टाफ हाज़िरी';

  @override
  String get dwAttendanceSub => 'आज चेक-इन';

  @override
  String get dwSaveFailed => 'सेव नहीं हुआ। कनेक्शन जांचें और फिर कोशिश करें।';

  @override
  String get jrShareInvoice => 'बिल भेजें';

  @override
  String get jrSendForSignature => 'साइन के लिए भेजें';

  @override
  String get lsTitle => 'लॉगिन और सुरक्षा';

  @override
  String get lsMy => 'आपका लॉगिन';

  @override
  String get lsMyEmail => 'लॉगिन ईमेल';

  @override
  String get lsChangePw => 'पासवर्ड बदलें';

  @override
  String get lsCurPw => 'मौजूदा पासवर्ड';

  @override
  String get lsNewPw => 'नया पासवर्ड';

  @override
  String get lsConfPw => 'नया पासवर्ड दोबारा';

  @override
  String get lsPwSub => 'कम से कम 8 अक्षर';

  @override
  String get lsPwShort => 'पासवर्ड कम से कम 8 अक्षर का हो';

  @override
  String get lsPwMismatch => 'पासवर्ड मेल नहीं खाते';

  @override
  String get lsPwCurReq => 'मौजूदा पासवर्ड डालें';

  @override
  String get lsPwDone => 'पासवर्ड बदला';

  @override
  String get lsUpdatePw => 'पासवर्ड अपडेट करें';

  @override
  String get lsForgot =>
      'पासवर्ड भूल गए? लॉगिन स्क्रीन पर \"पासवर्ड भूल गए?\" दबाएं। हम रीसेट लिंक ईमेल करेंगे।';

  @override
  String get lsStaffPins => 'स्टाफ PIN';

  @override
  String get lsStaffPinsSub =>
      'स्टाफ और सुपरवाइज़र PIN से लॉगिन करते हैं। भूल जाएं तो नया PIN सेट करें। बार-बार गलत PIN डालने पर PIN लॉक हो जाता है, आपके रीसेट करने तक।';

  @override
  String get lsResetPin => 'PIN रीसेट';

  @override
  String get lsPinSet => 'PIN सेट';

  @override
  String lsLocked(int n) {
    return 'लॉक · $n बार गलत';
  }

  @override
  String get lsNewPin => 'नया PIN';

  @override
  String get lsConfPin => 'PIN दोबारा';

  @override
  String get lsPinBad => 'PIN 4 अंक का हो';

  @override
  String get lsPinMismatch => 'PIN मेल नहीं खाते';

  @override
  String lsPinSetFor(String name) {
    return 'नया PIN सेट हुआ: $name';
  }

  @override
  String get lsTellStaff =>
      'स्टाफ को नया PIN खुद या फ़ोन पर बताएं। यह दोबारा नहीं दिखेगा।';

  @override
  String get lsSetPin => 'नया PIN सेट करें';

  @override
  String get lsSignOutAll => 'बाकी सभी डिवाइस से साइन आउट';

  @override
  String get lsAllOut => 'बाकी सभी डिवाइस साइन आउट हुए';

  @override
  String get lsNoPin => 'अभी PIN नहीं';

  @override
  String get lsOwnerOnly => 'स्टाफ PIN सिर्फ मालिक रीसेट कर सकते हैं।';

  @override
  String get qdTitle => 'कोटेशन डिज़ाइन';

  @override
  String get qdSub => 'ग्राहक को आपका कोटेशन PDF कैसा दिखेगा।';

  @override
  String get qdTheme => 'थीम';

  @override
  String get qdColor => 'ब्रांड रंग';

  @override
  String get qdLogo => 'लोगो';

  @override
  String get qdLogoAdd => 'लोगो अपलोड करें';

  @override
  String get qdLogoHint => 'PNG या JPG, चौकोर सबसे अच्छा';

  @override
  String get qdSave => 'डिज़ाइन सेव करें';

  @override
  String get qdPreview => 'सैंपल PDF देखें';

  @override
  String get qdSaved => 'कोटेशन डिज़ाइन सेव हुआ';

  @override
  String get qdTheme1A => 'क्लासिक';

  @override
  String get qdTheme1B => 'बोल्ड बैंड';

  @override
  String get qdTheme1C => 'साइडबार';

  @override
  String get qdTheme1D => 'मिनिमल';

  @override
  String get qdTheme1E => 'कॉर्पोरेट';

  @override
  String get qdTheme1F => 'लेटरहेड';

  @override
  String get qdThemeDesc1A => 'सेरिफ़, रेखाएं';

  @override
  String get qdThemeDesc1B => 'रंगीन हेडर, गोल पैनल';

  @override
  String get qdThemeDesc1C => 'बाईं ओर विवरण';

  @override
  String get qdThemeDesc1D => 'ब्लैक एंड व्हाइट, कहीं भी प्रिंट';

  @override
  String get qdThemeDesc1E => 'बॉक्स फ़ॉर्म, ऑफ़िस शिफ्टिंग के लिए';

  @override
  String get qdThemeDesc1F => 'केंद्रित, दोहरी रेखा';

  @override
  String get drvTitle => 'ड्राइवर ऐप';

  @override
  String get drvNone => 'आज कोई ट्रिप नहीं';

  @override
  String get drvPlanned => 'तय';

  @override
  String get drvOngoing => 'ट्रिप पर';

  @override
  String get drvStart => 'ट्रिप शुरू';

  @override
  String get drvEnd => 'ट्रिप खत्म';

  @override
  String get drvDone => 'ट्रिप पूरी';

  @override
  String get drvFuel => 'ईंधन';

  @override
  String get drvFuelT => 'ईंधन जोड़ें';

  @override
  String get drvToll => 'टोल';

  @override
  String get drvTollT => 'टोल जोड़ें';

  @override
  String get drvLitres => 'लीटर';

  @override
  String get drvPlaza => 'प्लाज़ा';

  @override
  String get drvAdd => 'एंट्री जोड़ें';

  @override
  String get drvNeedStart => 'शुरू का ओडोमीटर डालें';

  @override
  String get drvNeedEnd => 'अंत का ओडोमीटर शुरू से ज़्यादा हो';

  @override
  String get drvNeedAmount => 'राशि डालें';

  @override
  String get drvTripKm => 'ट्रिप किमी';

  @override
  String get drvTripSpend => 'ट्रिप खर्च';

  @override
  String get drvToday => 'आज की एंट्री';

  @override
  String get drvOdoStart => 'शुरू का ओडोमीटर';

  @override
  String get drvOdoEnd => 'अंत का ओडोमीटर';

  @override
  String get mktTitle => 'Nagarva काम';

  @override
  String get mktSub => 'Nagarva पर ग्राहकों की बुक की गई शिफ्टिंग';

  @override
  String get mktTier => 'आपका टियर';

  @override
  String get mktWallet => 'वॉलेट';

  @override
  String mktMinL(String m) {
    return 'काम पाने के लिए न्यूनतम $m';
  }

  @override
  String get mktLowS => 'न्यूनतम से कम';

  @override
  String get mktTJobs => 'काम';

  @override
  String get mktTWallet => 'वॉलेट';

  @override
  String get mktTTier => 'टियर';

  @override
  String get mktAv => 'काम के लिए उपलब्ध';

  @override
  String mktAvOn(String c) {
    return '$c के जॉब अलर्ट मिल रहे हैं';
  }

  @override
  String get mktAvOff => 'बंद। नए जॉब अलर्ट नहीं। आपके स्कोर पर असर नहीं।';

  @override
  String get mktCities => 'पिकअप शहर';

  @override
  String get mktCitiesN =>
      'इन शहरों से शुरू होने वाली बुकिंग के अलर्ट मिलेंगे। मुख्य शहर हटाया नहीं जा सकता।';

  @override
  String get mktEdit => 'बदलें';

  @override
  String get mktDone2 => 'हो गया';

  @override
  String get mktCancel => 'रद्द';

  @override
  String get mktHome => 'मुख्य';

  @override
  String get mktRtAsk => 'गाड़ी दूसरे शहर में है?';

  @override
  String get mktRtAdd => 'जोड़ें';

  @override
  String get mktRtEnd => 'खत्म';

  @override
  String get mktRtFrom => 'गाड़ी अभी यहां है';

  @override
  String get mktRtDate => 'निकलने की तारीख';

  @override
  String mktRtOn(String f, String t) {
    return 'रिटर्न ट्रिप · $f → $t';
  }

  @override
  String get mktRtEnded => 'रिटर्न ट्रिप खत्म';

  @override
  String get mktFNew => 'नए';

  @override
  String get mktFAcc => 'स्वीकार किए';

  @override
  String get mktFDone => 'पूरे';

  @override
  String get mktENew => 'अभी कोई नया काम नहीं। आने पर सूचना मिलेगी।';

  @override
  String get mktEAcc => 'कोई स्वीकार किया काम नहीं।';

  @override
  String get mktEDone => 'अभी कोई पूरा काम नहीं।';

  @override
  String get mktEOff =>
      'आप उपलब्ध नहीं हैं। नई बुकिंग देखने के लिए उपलब्ध चालू करें।';

  @override
  String mktLow(String a, String m) {
    return 'वॉलेट $m से कम है। नए काम देखने के लिए $a टॉप-अप करें।';
  }

  @override
  String get mktVal => 'काम का मूल्य (GST सहित)';

  @override
  String mktCom(String p) {
    return 'Nagarva कमीशन $p%';
  }

  @override
  String get mktEarn => 'आपकी कमाई';

  @override
  String get mktAdv => 'Nagarva को दिया एडवांस';

  @override
  String get mktBal => 'डिलीवरी OTP के बाद लें';

  @override
  String get mktMasked => 'स्वीकार करने पर ग्राहक का नाम और फ़ोन दिखेगा';

  @override
  String get mktPass => 'छोड़ें';

  @override
  String get mktAccept => 'काम स्वीकार करें';

  @override
  String mktAccepted(String id) {
    return '$id आपका है। ग्राहक विवरण खुल गया।';
  }

  @override
  String get mktPassed => 'काम छोड़ा';

  @override
  String get mktTaken => 'दूसरे वेंडर ने लिया';

  @override
  String get mktGoldOnly => 'सिर्फ गोल्ड';

  @override
  String get mktRl => 'रिटर्न लोड';

  @override
  String get mktS0 => 'स्वीकार';

  @override
  String get mktS1 => 'रास्ते में';

  @override
  String get mktS2 => 'पहुंचे';

  @override
  String get mktS3 => 'लोडिंग';

  @override
  String get mktS4 => 'सफ़र में';

  @override
  String get mktS5 => 'डिलीवर';

  @override
  String mktNext(String s) {
    return '$s करें';
  }

  @override
  String mktPhotos(int n) {
    return 'लोडिंग फ़ोटो $n/3';
  }

  @override
  String get mktNeedPh => 'पहले 3 लोडिंग फ़ोटो जोड़ें';

  @override
  String get mktAddPh => 'फ़ोटो जोड़ें';

  @override
  String get mktFinish => 'OTP जांचें और पूरा करें';

  @override
  String get mktOtpBad => 'गलत OTP। ग्राहक से जांचें।';

  @override
  String mktDone(String a, String c) {
    return 'पूरा। $c कमीशन कटा, $a एडवांस जमा।';
  }

  @override
  String mktRate(String r) {
    return 'ग्राहक रेटिंग $r';
  }

  @override
  String get mktNoRate => 'ग्राहक रेटिंग बाकी';

  @override
  String get mktTopup => 'टॉप-अप';

  @override
  String get mktWBal => 'वॉलेट बैलेंस';

  @override
  String get mktWOk => 'चालू · नए काम मिलेंगे';

  @override
  String get mktWWithdraw => 'निकालें';

  @override
  String mktWNote(String p) {
    return 'ग्राहक एडवांस Nagarva को देते हैं। काम पूरा होने पर एडवांस यहां जमा होता है और $p% कमीशन कटता है। काम पाने के लिए न्यूनतम बैलेंस रखें।';
  }

  @override
  String mktWtAdv(String id) {
    return 'एडवांस · $id';
  }

  @override
  String mktWtCom(String id) {
    return 'कमीशन · $id';
  }

  @override
  String get mktWtTop => 'UPI टॉप-अप';

  @override
  String get mktWtWd => 'बैंक में निकासी';

  @override
  String get mktTierF => 'आपका स्कोर कैसे बनता है';

  @override
  String get mktTierBands => 'गोल्ड 80+ · सिल्वर 60–79 · ब्रॉन्ज़ <60';

  @override
  String get mktTierGold => 'गोल्ड';

  @override
  String get mktTierSilver => 'सिल्वर';

  @override
  String get mktTierBronze => 'ब्रॉन्ज़';

  @override
  String mktTierScore(String s) {
    return 'स्कोर $s / 100';
  }

  @override
  String get mktOtpAsk => 'ग्राहक से 4 अंकों का डिलीवरी कोड पूछें।';

  @override
  String get mktReqSent =>
      'अनुरोध भेजा गया। Nagarva भुगतान की पुष्टि करने पर यह जुड़ेगा।';

  @override
  String get mktPending => 'लंबित';

  @override
  String get mktHomeCity => 'होम शहर';

  @override
  String get mktExtraCities => 'अन्य शहर, कॉमा से अलग';

  @override
  String get mktNotJoined => 'Nagarva जॉब पाने के लिए अपना होम शहर सेट करें।';

  @override
  String get mktFactorNote =>
      'Nagarva आपका स्कोर इन्हीं से, इन्हीं वज़न से निकालता है।';

  @override
  String get mktFRating => 'ग्राहक रेटिंग';

  @override
  String get mktFOnTime => 'समय पर पहुँचना';

  @override
  String get mktFDamage => 'नुकसान के दावे';

  @override
  String get mktFAccept => 'स्वीकृति दर';

  @override
  String get mktFPhotos => 'फ़ोटो अनुपालन';

  @override
  String get mktFCancel => 'वेंडर रद्दीकरण';

  @override
  String get mktFJobs => 'पूरे किए जॉब';

  @override
  String get mktAvOnT => 'जॉब अलर्ट फिर मिलेंगे';

  @override
  String get mktAvOffT => 'जॉब अलर्ट रुके';
}
