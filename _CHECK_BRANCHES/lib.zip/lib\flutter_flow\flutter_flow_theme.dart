// ignore_for_file: overridden_fields, annotate_overrides

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'ng_tokens.dart';

const kThemeModeKey = '__theme_mode__';
// Parity brief Part 2b: a third "Midnight" option alongside Light/Dark.
// Midnight is still ThemeMode.dark under the hood (same brightness, same
// MaterialApp.themeMode) — this flag just picks MidnightModeTheme over
// DarkModeTheme for the actual colors once brightness is already dark.
const kMidnightKey = '__theme_midnight__';

// ---------------------------------------------------------------------------
// Brand palette — the ONE definition (fix brief #2, item 9.3: "brand
// navy/gold/teal should live only in the ThemeData definitions").
//
// The gold was previously written out as a raw `Color(0xFFE3B23C)` in
// twelve separate places across LoginPage and SignupPage, plus again in
// lead_status.dart — so a rebrand meant finding all thirteen.
//
// These exist for the two legitimate cases where a colour must NOT follow
// the active theme:
//   * LoginPage / SignupPage run pre-auth, before any org or theme is
//     resolved, and are deliberately fixed platform branding.
//   * Semantic stage colours that happen to reuse a brand hue.
// Everywhere else inside the app, read from FlutterFlowTheme.of(context)
// instead of reaching for these.
// ---------------------------------------------------------------------------
// Redesign (Oct 2026): the accent is the handoff's orange — the gold,
// teal and navy triad of 27 Jul is retired. Renamed from kBrandGold so
// the name stops describing a colour it no longer is.
const Color kBrandAccent = Color(0xFFF68C36);

/// WhatsApp's own brand green. Not part of the Nagarva palette and
/// deliberately never themed — a WhatsApp button that isn't WhatsApp green
/// stops being recognisable. Named so it reads as intentional rather than
/// as a stray hex someone forgot to theme.
const Color kWhatsAppGreen = Color(0xFF25D366);

SharedPreferences? _prefs;

abstract class FlutterFlowTheme {
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();

  static ThemeMode get themeMode {
    final darkMode = _prefs?.getBool(kThemeModeKey);
    // CORRECTIONS.md B7: light until the user picks Dark or Midnight in
    // Settings. Was ThemeMode.system, which opened dark on any phone set
    // to dark mode. A choice already saved on the device is kept.
    return darkMode == null
        ? ThemeMode.light
        : darkMode
            ? ThemeMode.dark
            : ThemeMode.light;
  }

  static void saveThemeMode(ThemeMode mode) => mode == ThemeMode.system
      ? _prefs?.remove(kThemeModeKey)
      : _prefs?.setBool(kThemeModeKey, mode == ThemeMode.dark);

  static bool get isMidnight => _prefs?.getBool(kMidnightKey) ?? false;

  static void saveMidnight(bool value) => value
      ? _prefs?.setBool(kMidnightKey, true)
      : _prefs?.remove(kMidnightKey);

  static FlutterFlowTheme of(BuildContext context) {
    if (Theme.of(context).brightness == Brightness.dark) {
      return isMidnight ? MidnightModeTheme() : DarkModeTheme();
    }
    return LightModeTheme();
  }

  /// Which of 'light' / 'dark' / 'midnight' is actually in effect right
  /// now — resolves ThemeMode.system via the current platform brightness
  /// rather than assuming an explicit choice was made.
  static String effectiveVariant(BuildContext context) {
    if (Theme.of(context).brightness != Brightness.dark) return 'light';
    return isMidnight ? 'midnight' : 'dark';
  }

  /// Builds a real Material [ThemeData] from this palette.
  ///
  /// Live-test fix brief #2, item 9 ("theme not applied: left sidebar +
  /// search button"). The reported cause was hardcoded colours in those
  /// widgets; the actual cause was the reverse. `main.dart` passed
  ///
  ///     theme:     ThemeData(brightness: Brightness.light,  useMaterial3: false)
  ///     darkTheme: ThemeData(brightness: Brightness.dark,   useMaterial3: false)
  ///
  /// i.e. bare Material defaults carrying none of the brand palette. The
  /// Drawer, its ListTiles and SearchDelegate's search field specify no
  /// colours of their own (correctly!), so they resolved against those
  /// stock defaults instead of FlutterFlowTheme — which is why the rest of
  /// the app re-themed and they did not.
  ///
  /// Midnight made it worse: it rides `ThemeMode.dark`, so `Theme.of()`
  /// handed back the *identical* ThemeData for Dark and Midnight and no
  /// Material-themed widget could tell them apart. Passing the midnight
  /// palette through here is what actually separates them.
  ThemeData toThemeData() {
    final brightness =
        this is LightModeTheme ? Brightness.light : Brightness.dark;
    // Redesign: text on the orange accent is near-black in the dark
    // variants (handoff: "text on an accent button is always #0A0C10").
    // Light keeps the luminance rule — its primary is the darker
    // text-orange, which needs white.
    final onPrimary = brightness == Brightness.dark
        ? NgPalette.onAcc
        : primary.computeLuminance() > 0.5
            ? Colors.black
            : Colors.white;
    final c = this is MidnightModeTheme
        ? NgPalette.midnight
        : this is LightModeTheme
            ? NgPalette.light
            : NgPalette.dark;
    return ThemeData(
      brightness: brightness,
      useMaterial3: false,
      fontFamily: NgFonts.family,
      scaffoldBackgroundColor: primaryBackground,
      canvasColor: primaryBackground,
      cardColor: secondaryBackground,
      dividerColor: alternate,
      primaryColor: primary,
      colorScheme: ColorScheme(
        brightness: brightness,
        primary: primary,
        onPrimary: onPrimary,
        secondary: secondary,
        onSecondary: onPrimary,
        tertiary: tertiary,
        onTertiary: onPrimary,
        error: error,
        onError: Colors.white,
        surface: secondaryBackground,
        onSurface: primaryText,
      ),
      // ---- Redesign component themes (Claude Design handoff, Oct 2026).
      // Most module pages are built from stock Material widgets — Card,
      // FilledButton, AlertDialog, TextField, ChoiceChip — so theming them
      // here restyles every screen at once without touching page code:
      // s1 cards with a hairline and no shadow, 14px-radius accent
      // buttons with near-black labels, inset fields with 12px corners,
      // sheet-coloured dialogs and sheets. Values come from NgPalette.
      drawerTheme: DrawerThemeData(
        backgroundColor: c.sheet,
        scrimColor: Colors.black.withValues(alpha: 0.6),
      ),
      iconTheme: IconThemeData(color: c.soft),
      // Left-aligned 20px title on the page colour, as the handoff's
      // screen headers are; no elevation or M3 tint when content scrolls.
      appBarTheme: AppBarTheme(
        backgroundColor: c.bg,
        foregroundColor: c.text,
        iconTheme: IconThemeData(color: c.soft),
        actionsIconTheme: IconThemeData(color: c.soft),
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        titleTextStyle: NgFonts.geist(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          letterSpacing: -0.3,
          color: c.text,
        ),
      ),
      cardTheme: CardThemeData(
        color: c.s1,
        elevation: 0,
        shadowColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(NgRadius.card),
          side: BorderSide(color: c.w06),
        ),
      ),
      dividerTheme: DividerThemeData(color: c.w06, thickness: 1, space: 1),
      listTileTheme: ListTileThemeData(
        iconColor: c.soft,
        textColor: c.text,
        titleTextStyle: NgFonts.geist(
            fontSize: 14.5, fontWeight: FontWeight.w500, color: c.text),
        subtitleTextStyle: NgFonts.geist(fontSize: 12.5, color: c.mute),
        leadingAndTrailingTextStyle: NgFonts.geist(
            fontSize: 13.5, fontWeight: FontWeight.w600, color: c.text),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(NgRadius.button)),
      ),
      expansionTileTheme: ExpansionTileThemeData(
        iconColor: c.mute,
        collapsedIconColor: c.mute,
        textColor: c.text,
        collapsedTextColor: c.text,
        tilePadding: const EdgeInsets.symmetric(horizontal: 16),
        shape: const Border(),
        collapsedShape: const Border(),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: c.accBtn,
        foregroundColor: NgPalette.onAcc,
        elevation: 0,
        focusElevation: 0,
        hoverElevation: 0,
        highlightElevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(NgRadius.tile)),
      ),
      filledButtonTheme: FilledButtonThemeData(style: _filledStyle(c)),
      elevatedButtonTheme: ElevatedButtonThemeData(style: _filledStyle(c)),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: c.text,
          minimumSize: const Size(0, 44),
          side: BorderSide(color: c.w15),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(NgRadius.button)),
          textStyle: NgFonts.geist(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: c.acc,
          textStyle: NgFonts.geist(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: c.sheet,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: c.w08),
        ),
        titleTextStyle: NgFonts.geist(
            fontSize: 18, fontWeight: FontWeight.w600, color: c.text),
        contentTextStyle:
            NgFonts.geist(fontSize: 14, height: 1.4, color: c.soft),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: c.sheet,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(NgRadius.sheet)),
        ),
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: c.sheet,
        elevation: 2,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: c.w08),
        ),
        textStyle: NgFonts.geist(fontSize: 14, color: c.text),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: c.s1,
        selectedColor: c.inv,
        disabledColor: c.s2,
        side: BorderSide(color: c.w06),
        shape: const StadiumBorder(),
        labelStyle: NgFonts.geist(
            fontSize: 13, fontWeight: FontWeight.w600, color: c.soft),
        secondaryLabelStyle: NgFonts.geist(
            fontSize: 13, fontWeight: FontWeight.w600, color: c.invText),
        checkmarkColor: c.invText,
        padding: const EdgeInsets.symmetric(horizontal: 6),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: c.text,
        unselectedLabelColor: c.mute,
        indicatorColor: c.accBtn,
        dividerColor: c.w06,
        labelStyle: NgFonts.geist(fontSize: 14, fontWeight: FontWeight.w600),
        unselectedLabelStyle:
            NgFonts.geist(fontSize: 14, fontWeight: FontWeight.w500),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.all(Colors.white),
        trackColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.selected) ? c.accBtn : c.w15),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.selected) ? c.accBtn : Colors.transparent),
        checkColor: WidgetStateProperty.all(NgPalette.onAcc),
        side: BorderSide(color: c.hairline(0.25), width: 1.5),
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? c.accBtn : c.mute),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: c.accBtn,
        linearTrackColor: c.w07,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: c.inv,
        contentTextStyle: NgFonts.geist(fontSize: 14, color: c.invText),
        actionTextColor: c.isLight ? c.accBtn : c.acc,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(NgRadius.button)),
      ),
      // Fields: inset surface, 12px corners, w1 hairline, accent when
      // focused. Pages that pass their own borders keep them.
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: c.inset,
        hintStyle: NgFonts.geist(fontSize: 14, color: c.faint),
        labelStyle: NgFonts.geist(fontSize: 14, color: c.mute),
        floatingLabelStyle: NgFonts.geist(fontSize: 14, color: c.acc),
        iconColor: c.mute,
        prefixIconColor: c.mute,
        suffixIconColor: c.mute,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(NgRadius.field),
          borderSide: BorderSide(color: c.w1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(NgRadius.field),
          borderSide: BorderSide(color: c.w1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(NgRadius.field),
          borderSide: BorderSide(color: c.acc, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(NgRadius.field),
          borderSide: BorderSide(color: c.red),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(NgRadius.field),
          borderSide: BorderSide(color: c.red, width: 1.5),
        ),
      ),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: primary,
        selectionColor: primary.withValues(alpha: 0.3),
        selectionHandleColor: primary,
      ),
      // SearchDelegate renders its query/hint with the ambient text theme;
      // without these the typed query stayed near-black on the dark navy
      // search bar.
      textTheme: ThemeData(brightness: brightness).textTheme.apply(
            fontFamily: NgFonts.family,
            bodyColor: primaryText,
            displayColor: primaryText,
          ),
    );
  }

  /// Filled/elevated button style shared by both themes above.
  static ButtonStyle _filledStyle(NgPalette c) => FilledButton.styleFrom(
        backgroundColor: c.accBtn,
        foregroundColor: NgPalette.onAcc,
        disabledBackgroundColor: c.s2,
        disabledForegroundColor: c.faint,
        elevation: 0,
        minimumSize: const Size(0, 46),
        padding: const EdgeInsets.symmetric(horizontal: 18),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(NgRadius.button)),
        textStyle: NgFonts.geist(fontSize: 14, fontWeight: FontWeight.w600),
      );

  @Deprecated('Use primary instead')
  Color get primaryColor => primary;
  @Deprecated('Use secondary instead')
  Color get secondaryColor => secondary;
  @Deprecated('Use tertiary instead')
  Color get tertiaryColor => tertiary;

  late Color primary;
  late Color secondary;
  late Color tertiary;
  late Color alternate;
  late Color primaryText;
  late Color secondaryText;
  late Color primaryBackground;
  late Color secondaryBackground;
  late Color accent1;
  late Color accent2;
  late Color accent3;
  late Color accent4;
  late Color success;
  late Color warning;
  late Color error;
  late Color info;

  FFDesignTokens get designToken => FFDesignTokens(this);

  @Deprecated('Use displaySmallFamily instead')
  String get title1Family => displaySmallFamily;
  @Deprecated('Use displaySmall instead')
  TextStyle get title1 => typography.displaySmall;
  @Deprecated('Use headlineMediumFamily instead')
  String get title2Family => typography.headlineMediumFamily;
  @Deprecated('Use headlineMedium instead')
  TextStyle get title2 => typography.headlineMedium;
  @Deprecated('Use headlineSmallFamily instead')
  String get title3Family => typography.headlineSmallFamily;
  @Deprecated('Use headlineSmall instead')
  TextStyle get title3 => typography.headlineSmall;
  @Deprecated('Use titleMediumFamily instead')
  String get subtitle1Family => typography.titleMediumFamily;
  @Deprecated('Use titleMedium instead')
  TextStyle get subtitle1 => typography.titleMedium;
  @Deprecated('Use titleSmallFamily instead')
  String get subtitle2Family => typography.titleSmallFamily;
  @Deprecated('Use titleSmall instead')
  TextStyle get subtitle2 => typography.titleSmall;
  @Deprecated('Use bodyMediumFamily instead')
  String get bodyText1Family => typography.bodyMediumFamily;
  @Deprecated('Use bodyMedium instead')
  TextStyle get bodyText1 => typography.bodyMedium;
  @Deprecated('Use bodySmallFamily instead')
  String get bodyText2Family => typography.bodySmallFamily;
  @Deprecated('Use bodySmall instead')
  TextStyle get bodyText2 => typography.bodySmall;

  String get displayLargeFamily => typography.displayLargeFamily;
  bool get displayLargeIsCustom => typography.displayLargeIsCustom;
  TextStyle get displayLarge => typography.displayLarge;
  String get displayMediumFamily => typography.displayMediumFamily;
  bool get displayMediumIsCustom => typography.displayMediumIsCustom;
  TextStyle get displayMedium => typography.displayMedium;
  String get displaySmallFamily => typography.displaySmallFamily;
  bool get displaySmallIsCustom => typography.displaySmallIsCustom;
  TextStyle get displaySmall => typography.displaySmall;
  String get headlineLargeFamily => typography.headlineLargeFamily;
  bool get headlineLargeIsCustom => typography.headlineLargeIsCustom;
  TextStyle get headlineLarge => typography.headlineLarge;
  String get headlineMediumFamily => typography.headlineMediumFamily;
  bool get headlineMediumIsCustom => typography.headlineMediumIsCustom;
  TextStyle get headlineMedium => typography.headlineMedium;
  String get headlineSmallFamily => typography.headlineSmallFamily;
  bool get headlineSmallIsCustom => typography.headlineSmallIsCustom;
  TextStyle get headlineSmall => typography.headlineSmall;
  String get titleLargeFamily => typography.titleLargeFamily;
  bool get titleLargeIsCustom => typography.titleLargeIsCustom;
  TextStyle get titleLarge => typography.titleLarge;
  String get titleMediumFamily => typography.titleMediumFamily;
  bool get titleMediumIsCustom => typography.titleMediumIsCustom;
  TextStyle get titleMedium => typography.titleMedium;
  String get titleSmallFamily => typography.titleSmallFamily;
  bool get titleSmallIsCustom => typography.titleSmallIsCustom;
  TextStyle get titleSmall => typography.titleSmall;
  String get labelLargeFamily => typography.labelLargeFamily;
  bool get labelLargeIsCustom => typography.labelLargeIsCustom;
  TextStyle get labelLarge => typography.labelLarge;
  String get labelMediumFamily => typography.labelMediumFamily;
  bool get labelMediumIsCustom => typography.labelMediumIsCustom;
  TextStyle get labelMedium => typography.labelMedium;
  String get labelSmallFamily => typography.labelSmallFamily;
  bool get labelSmallIsCustom => typography.labelSmallIsCustom;
  TextStyle get labelSmall => typography.labelSmall;
  String get bodyLargeFamily => typography.bodyLargeFamily;
  bool get bodyLargeIsCustom => typography.bodyLargeIsCustom;
  TextStyle get bodyLarge => typography.bodyLarge;
  String get bodyMediumFamily => typography.bodyMediumFamily;
  bool get bodyMediumIsCustom => typography.bodyMediumIsCustom;
  TextStyle get bodyMedium => typography.bodyMedium;
  String get bodySmallFamily => typography.bodySmallFamily;
  bool get bodySmallIsCustom => typography.bodySmallIsCustom;
  TextStyle get bodySmall => typography.bodySmall;

  Typography get typography => ThemeTypography(this);
}

class LightModeTheme extends FlutterFlowTheme {
  @Deprecated('Use primary instead')
  Color get primaryColor => primary;
  @Deprecated('Use secondary instead')
  Color get secondaryColor => secondary;
  @Deprecated('Use tertiary instead')
  Color get tertiaryColor => tertiary;

  // Redesign (Claude Design handoff, 20 Oct 2026): every slot now reads
  // from NgPalette.light — warm off-white page, white cards, orange
  // accent. `primary` is the TEXT orange (darker, readable on white);
  // filled buttons that follow the redesign use NgPalette.accBtn.
  // Replaces the 27 Jul navy/gold/teal triad.
  late Color primary = NgPalette.light.acc;
  late Color secondary = NgPalette.light.accBtn;
  late Color tertiary = NgPalette.light.green;
  late Color alternate = const Color(0xFFE2E0DA);
  late Color primaryText = NgPalette.light.text;
  late Color secondaryText = NgPalette.light.mute;
  late Color primaryBackground = NgPalette.light.bg;
  late Color secondaryBackground = NgPalette.light.s1;
  late Color accent1 = const Color(0x24EF7926);
  late Color accent2 = NgPalette.light.greenBg;
  late Color accent3 = NgPalette.light.amberBg;
  late Color accent4 = const Color(0xCCFFFFFF);
  late Color success = NgPalette.light.green;
  late Color warning = NgPalette.light.amber;
  late Color error = NgPalette.light.red;
  late Color info = const Color(0xFFFFFFFF);
}

abstract class Typography {
  String get displayLargeFamily;
  bool get displayLargeIsCustom;
  TextStyle get displayLarge;
  String get displayMediumFamily;
  bool get displayMediumIsCustom;
  TextStyle get displayMedium;
  String get displaySmallFamily;
  bool get displaySmallIsCustom;
  TextStyle get displaySmall;
  String get headlineLargeFamily;
  bool get headlineLargeIsCustom;
  TextStyle get headlineLarge;
  String get headlineMediumFamily;
  bool get headlineMediumIsCustom;
  TextStyle get headlineMedium;
  String get headlineSmallFamily;
  bool get headlineSmallIsCustom;
  TextStyle get headlineSmall;
  String get titleLargeFamily;
  bool get titleLargeIsCustom;
  TextStyle get titleLarge;
  String get titleMediumFamily;
  bool get titleMediumIsCustom;
  TextStyle get titleMedium;
  String get titleSmallFamily;
  bool get titleSmallIsCustom;
  TextStyle get titleSmall;
  String get labelLargeFamily;
  bool get labelLargeIsCustom;
  TextStyle get labelLarge;
  String get labelMediumFamily;
  bool get labelMediumIsCustom;
  TextStyle get labelMedium;
  String get labelSmallFamily;
  bool get labelSmallIsCustom;
  TextStyle get labelSmall;
  String get bodyLargeFamily;
  bool get bodyLargeIsCustom;
  TextStyle get bodyLarge;
  String get bodyMediumFamily;
  bool get bodyMediumIsCustom;
  TextStyle get bodyMedium;
  String get bodySmallFamily;
  bool get bodySmallIsCustom;
  TextStyle get bodySmall;
}

class ThemeTypography extends Typography {
  ThemeTypography(this.theme);

  final FlutterFlowTheme theme;

  String get displayLargeFamily => NgFonts.family;
  bool get displayLargeIsCustom => false;
  TextStyle get displayLarge => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 64.0,
      );
  String get displayMediumFamily => NgFonts.family;
  bool get displayMediumIsCustom => false;
  TextStyle get displayMedium => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 44.0,
      );
  String get displaySmallFamily => NgFonts.family;
  bool get displaySmallIsCustom => false;
  TextStyle get displaySmall => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 36.0,
      );
  String get headlineLargeFamily => NgFonts.family;
  bool get headlineLargeIsCustom => false;
  TextStyle get headlineLarge => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 32.0,
      );
  String get headlineMediumFamily => NgFonts.family;
  bool get headlineMediumIsCustom => false;
  TextStyle get headlineMedium => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 28.0,
      );
  String get headlineSmallFamily => NgFonts.family;
  bool get headlineSmallIsCustom => false;
  TextStyle get headlineSmall => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 24.0,
      );
  String get titleLargeFamily => NgFonts.family;
  bool get titleLargeIsCustom => false;
  TextStyle get titleLarge => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 20.0,
      );
  String get titleMediumFamily => NgFonts.family;
  bool get titleMediumIsCustom => false;
  TextStyle get titleMedium => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 18.0,
      );
  String get titleSmallFamily => NgFonts.family;
  bool get titleSmallIsCustom => false;
  TextStyle get titleSmall => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 16.0,
      );
  String get labelLargeFamily => NgFonts.family;
  bool get labelLargeIsCustom => false;
  TextStyle get labelLarge => NgFonts.geist(
        color: theme.secondaryText,
        fontWeight: FontWeight.normal,
        fontSize: 16.0,
      );
  String get labelMediumFamily => NgFonts.family;
  bool get labelMediumIsCustom => false;
  TextStyle get labelMedium => NgFonts.geist(
        color: theme.secondaryText,
        fontWeight: FontWeight.normal,
        fontSize: 14.0,
      );
  String get labelSmallFamily => NgFonts.family;
  bool get labelSmallIsCustom => false;
  TextStyle get labelSmall => NgFonts.geist(
        color: theme.secondaryText,
        fontWeight: FontWeight.normal,
        fontSize: 12.0,
      );
  String get bodyLargeFamily => NgFonts.family;
  bool get bodyLargeIsCustom => false;
  TextStyle get bodyLarge => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.normal,
        fontSize: 16.0,
      );
  String get bodyMediumFamily => NgFonts.family;
  bool get bodyMediumIsCustom => false;
  TextStyle get bodyMedium => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.normal,
        fontSize: 14.0,
      );
  String get bodySmallFamily => NgFonts.family;
  bool get bodySmallIsCustom => false;
  TextStyle get bodySmall => NgFonts.geist(
        color: theme.primaryText,
        fontWeight: FontWeight.normal,
        fontSize: 12.0,
      );
}

class DarkModeTheme extends FlutterFlowTheme {
  @Deprecated('Use primary instead')
  Color get primaryColor => primary;
  @Deprecated('Use secondary instead')
  Color get secondaryColor => secondary;
  @Deprecated('Use tertiary instead')
  Color get tertiaryColor => tertiary;

  // Redesign (20 Oct 2026): the navy "Dark" variant, from
  // NgPalette.dark. Orange accent replaces the 27 Jul gold; status
  // colours are the redesign's green / amber / red.
  late Color primary = NgPalette.dark.acc;
  late Color secondary = const Color(0xFFD9701C);
  late Color tertiary = NgPalette.dark.green;
  late Color alternate = NgPalette.dark.s3;
  late Color primaryText = NgPalette.dark.text;
  late Color secondaryText = NgPalette.dark.mute;
  late Color primaryBackground = NgPalette.dark.bg;
  late Color secondaryBackground = NgPalette.dark.s1;
  late Color accent1 = const Color(0x24F68C36);
  late Color accent2 = NgPalette.dark.greenBg;
  late Color accent3 = NgPalette.dark.amberBg;
  late Color accent4 = const Color(0xB21F3550);
  late Color success = NgPalette.dark.green;
  late Color warning = NgPalette.dark.amber;
  late Color error = NgPalette.dark.red;
  late Color info = const Color(0xFFFFFFFF);
}

/// Midnight — a third, deeper-black theme option (parity brief Part 2b),
/// distinct from Dark. Same brand accent triad as Dark, but backgrounds
/// drop to near-black for AMOLED/low-light preference (the "Dim vs Lights
/// Out" pattern) instead of the brand-navy background Dark uses.
///
/// Redesign (20 Oct 2026): Midnight is the DEFAULT look of the handoff —
/// neutral near-black surfaces from NgPalette.midnight, not navy-tinted.
class MidnightModeTheme extends DarkModeTheme {
  late Color alternate = NgPalette.midnight.s3;
  late Color primaryText = NgPalette.midnight.text;
  late Color secondaryText = NgPalette.midnight.mute;
  late Color primaryBackground = NgPalette.midnight.bg;
  late Color secondaryBackground = NgPalette.midnight.s1;
  late Color accent4 = const Color(0xB21F232B);
}

class FFDesignTokens {
  const FFDesignTokens(this.theme);
  final FlutterFlowTheme theme;
  FFSpacing get spacing => const FFSpacing();
  FFRadius get radius => const FFRadius();
  FFShadows get shadow => FFShadows(theme);
}

class FFSpacing {
  const FFSpacing();
  double get xs => 4.0;
  double get sm => 8.0;
  double get md => 16.0;
  double get lg => 24.0;
  double get xl => 32.0;
}

class FFRadius {
  const FFRadius();
  double get sm => 8.0;
  double get md => 16.0;
  double get lg => 24.0;
  double get full => 9999.0;
}

class FFShadows {
  const FFShadows(this.theme);
  final FlutterFlowTheme theme;
  BoxShadow get sm => const BoxShadow(
      blurRadius: 3.0,
      color: Color(0x1A000000),
      offset: Offset(0.0, 1.0),
      spreadRadius: 0.0);
  BoxShadow get md => const BoxShadow(
      blurRadius: 6.0,
      color: Color(0x1A000000),
      offset: Offset(0.0, 3.0),
      spreadRadius: 0.0);
  BoxShadow get lg => const BoxShadow(
      blurRadius: 15.0,
      color: Color(0x1A000000),
      offset: Offset(0.0, 8.0),
      spreadRadius: 0.0);
  BoxShadow get xl => const BoxShadow(
      blurRadius: 25.0,
      color: Color(0x1A000000),
      offset: Offset(0.0, 16.0),
      spreadRadius: 0.0);
}

extension TextStyleHelper on TextStyle {
  TextStyle override({
    TextStyle? font,
    String? fontFamily,
    Color? color,
    double? fontSize,
    FontWeight? fontWeight,
    double? letterSpacing,
    FontStyle? fontStyle,
    bool useGoogleFonts = false,
    TextDecoration? decoration,
    double? lineHeight,
    List<Shadow>? shadows,
    String? package,
  }) {
    // Geist is a bundled asset, not a Google Fonts download — getFont()
    // would throw for it, so a Geist family falls through to copyWith.
    if (useGoogleFonts &&
        fontFamily != null &&
        fontFamily.isNotEmpty &&
        fontFamily != NgFonts.family &&
        fontFamily != NgFonts.monoFamily) {
      font = GoogleFonts.getFont(fontFamily,
          fontWeight: fontWeight ?? this.fontWeight,
          fontStyle: fontStyle ?? this.fontStyle);
    }

    return font != null
        ? font.copyWith(
            color: color ?? this.color,
            fontSize: fontSize ?? this.fontSize,
            letterSpacing: letterSpacing ?? this.letterSpacing,
            fontWeight: fontWeight ?? this.fontWeight,
            fontStyle: fontStyle ?? this.fontStyle,
            decoration: decoration,
            height: lineHeight,
            shadows: shadows,
          )
        : copyWith(
            fontFamily: fontFamily,
            package: package,
            color: color,
            fontSize: fontSize,
            letterSpacing: letterSpacing,
            fontWeight: fontWeight,
            fontStyle: fontStyle,
            decoration: decoration,
            height: lineHeight,
            shadows: shadows,
          );
  }
}
