// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Malayalam (`ml`).
class AppLocalizationsMl extends AppLocalizations {
  AppLocalizationsMl([String locale = 'ml']) : super(locale);

  @override
  String get arunPackersAndCouriers => 'Arun Packers And Couriers';

  @override
  String get movingYouTowardsYourFuture =>
      'നിങ്ങളെ നിങ്ങളുടെ ഭാവിയിലേക്ക് നീക്കുന്നു';

  @override
  String get nameOrPhone => 'പേര് അല്ലെങ്കിൽ ഫോൺ';

  @override
  String get enterYourNameOrPhone => 'നിങ്ങളുടെ പേര് അല്ലെങ്കിൽ ഫോൺ നൽകുക';

  @override
  String get pin => 'PIN';

  @override
  String get n4DigitPin => '4 അക്ക PIN';

  @override
  String get login => 'ലോഗിൻ';

  @override
  String get securedEncrypted => 'സുരക്ഷിതം & എൻക്രിപ്റ്റ് ചെയ്തത്';

  @override
  String get dashboard => 'ഡാഷ്ബോർഡ്';

  @override
  String get thisMonth => 'ഈ മാസം';

  @override
  String get revenue => 'വരുമാനം';

  @override
  String get labour => 'തൊഴിലാളി';

  @override
  String get expenses => 'ചെലവുകൾ';

  @override
  String get porter => 'പോർട്ടർ';

  @override
  String get netProfit => 'അറ്റാദായം';

  @override
  String get activeLeads => 'സജീവ ലീഡുകൾ';

  @override
  String get ordersMonth => 'ഓർഡറുകൾ/മാസം';

  @override
  String get outstanding => 'കുടിശ്ശിക';

  @override
  String get reminders => 'ഓർമ്മപ്പെടുത്തലുകൾ';

  @override
  String get monthlyTarget => 'മാസ ലക്ഷ്യം';

  @override
  String get edit => 'മാറ്റുക';

  @override
  String get targetThisMonth => 'ഈ മാസത്തെ ലക്ഷ്യം';

  @override
  String get eG200000 => 'e.g. 200000';

  @override
  String get save => 'സേവ് ചെയ്യുക';

  @override
  String get upcomingOrders => 'വരാനിരിക്കുന്ന ഓർഡറുകൾ';

  @override
  String get calendar => 'കലണ്ടർ ->';

  @override
  String get hotLeads => 'ഹോട്ട് ലീഡുകൾ';

  @override
  String get viewAll => 'എല്ലാം കാണുക ->';

  @override
  String get branchPerformance => 'ശാഖാ പ്രകടനം';

  @override
  String get orders => 'ഓർഡറുകൾ';

  @override
  String get leads => 'ലീഡുകൾ';

  @override
  String get operations => 'പ്രവർത്തനങ്ങൾ';

  @override
  String get payments => 'പേയ്മെന്റുകൾ';

  @override
  String get homePageExpenses => 'ചെലവുകൾ';

  @override
  String get salary => 'ശമ്പളം';

  @override
  String get settings => 'സെറ്റിംഗ്സ്';

  @override
  String get logout => 'ലോഗ് ഔട്ട്';

  @override
  String get all => 'എല്ലാം';

  @override
  String get pending => 'ബാക്കി';

  @override
  String get completed => 'പൂർത്തിയായി';

  @override
  String get cancelled => 'റദ്ദാക്കി';

  @override
  String get confirmed => 'ഉറപ്പിച്ചു';

  @override
  String get transit => 'ട്രാൻസിറ്റ്';

  @override
  String get done => 'പൂർത്തി';

  @override
  String get ord001 => 'ORD-001';

  @override
  String get rajeshKumar => 'Rajesh Kumar';

  @override
  String get chennaiBangalore => 'Chennai → Bangalore';

  @override
  String get n12500 => '₹12,500';

  @override
  String get ord002 => 'ORD-002';

  @override
  String get priyaSharma => 'Priya Sharma';

  @override
  String get mumbaiPune => 'Mumbai → Pune';

  @override
  String get n8000 => '₹8,000';

  @override
  String get ord003 => 'ORD-003';

  @override
  String get inTransit => 'യാത്രയിൽ';

  @override
  String get anandVerma => 'Anand Verma';

  @override
  String get delhiNoida => 'Delhi → Noida';

  @override
  String get n5500 => '₹5,500';

  @override
  String get ord004 => 'ORD-004';

  @override
  String get sunitaDevi => 'Sunita Devi';

  @override
  String get hyderabadChennai => 'Hyderabad → Chennai';

  @override
  String get n9200 => '₹9,200';

  @override
  String get leadsCrm => 'ലീഡുകൾ / CRM';

  @override
  String get n8 => '8';

  @override
  String get statusNew => 'പുതിയത്';

  @override
  String get n5 => '5';

  @override
  String get contacted => 'ബന്ധപ്പെട്ടു';

  @override
  String get n3 => '3';

  @override
  String get qualified => 'യോഗ്യമായവ';

  @override
  String get n2 => '2';

  @override
  String get won => 'നേടിയവ';

  @override
  String get lost => 'നഷ്ടപ്പെട്ടവ';

  @override
  String get raviMenon => 'Ravi Menon';

  @override
  String get n919840012345 => '+91 98400 12345';

  @override
  String get chennaiTn => 'Chennai, TN';

  @override
  String get newLead => 'പുതിയ ലീഡ്';

  @override
  String get deepaNair => 'Deepa Nair';

  @override
  String get n919447067890 => '+91 94470 67890';

  @override
  String get coimbatoreTn => 'Coimbatore, TN';

  @override
  String get karthikS => 'Karthik S.';

  @override
  String get n919940054321 => '+91 99400 54321';

  @override
  String get maduraiTn => 'Madurai, TN';

  @override
  String get meenaRaj => 'Meena Raj';

  @override
  String get n919380011223 => '+91 93800 11223';

  @override
  String get trichyTn => 'Trichy, TN';

  @override
  String get todaySJobs => 'ഇന്നത്തെ ജോലികൾ';

  @override
  String get n3Active => '3 സജീവം';

  @override
  String get tn01Ab1234 => 'TN-01-AB-1234';

  @override
  String get loading => 'ലോഡിംഗ്';

  @override
  String get sureshDriver => 'Suresh (Driver)';

  @override
  String get chennaiVellore => 'Chennai → Vellore';

  @override
  String get tn02Cd5678 => 'TN-02-CD-5678';

  @override
  String get muruganDriver => 'Murugan (Driver)';

  @override
  String get salemErode => 'Salem → Erode';

  @override
  String get tn03Ef9012 => 'TN-03-EF-9012';

  @override
  String get unloading => 'അൺലോഡിംഗ്';

  @override
  String get baluDriver => 'Balu (Driver)';

  @override
  String get coimbatoreOoty => 'Coimbatore → Ooty';

  @override
  String get upcoming => 'വരാനിരിക്കുന്നവ';

  @override
  String get tn04Gh3456 => 'TN-04-GH-3456';

  @override
  String get scheduled => 'ഷെഡ്യൂൾ ചെയ്തു';

  @override
  String get senthilDriver => 'Senthil (Driver)';

  @override
  String get maduraiTirunelveli => 'Madurai → Tirunelveli';

  @override
  String get vehicleTripLog => 'വാഹന യാത്രാ രേഖ';

  @override
  String get logNewTrip => 'പുതിയ യാത്ര രേഖപ്പെടുത്തുക';

  @override
  String get paymentsPageOutstanding => 'കുടിശ്ശിക';

  @override
  String get n42800 => '₹42,800';

  @override
  String get receivedMonth => 'ലഭിച്ചത് (മാസം)';

  @override
  String get n124000 => '₹1,24,000';

  @override
  String get pendingPaymentsLive => 'ബാക്കി പേയ്മെന്റുകൾ (ലൈവ്)';

  @override
  String get pendingInvoices => 'ബാക്കി ഇൻവോയ്സുകൾ';

  @override
  String get inv045 => 'INV-045';

  @override
  String get due15May => 'അവസാന തീയതി: മേയ് 15';

  @override
  String get inv046 => 'INV-046';

  @override
  String get due18May => 'അവസാന തീയതി: മേയ് 18';

  @override
  String get inv047 => 'INV-047';

  @override
  String get overdue => 'കാലാവധി കഴിഞ്ഞു';

  @override
  String get inv048 => 'INV-048';

  @override
  String get due22May => 'അവസാന തീയതി: മേയ് 22';

  @override
  String get n16800 => '₹16,800';

  @override
  String get may2025Total => 'മേയ് 2025 ആകെ';

  @override
  String get n68450 => '₹68,450';

  @override
  String get n12VsLastMonth => '↑ കഴിഞ്ഞ മാസത്തേക്കാൾ 12%';

  @override
  String get liveExpenses => 'ലൈവ് ചെലവുകൾ';

  @override
  String get byCategory => 'വിഭാഗം തിരിച്ച്';

  @override
  String get fuel => 'ഇന്ധനം';

  @override
  String get n41 => '41%';

  @override
  String get n28000 => '₹28,000';

  @override
  String get tollsPermits => 'ടോളുകളും പെർമിറ്റുകളും';

  @override
  String get n18 => '18%';

  @override
  String get maintenance => 'അറ്റകുറ്റപ്പണിയിൽ';

  @override
  String get n26 => '26%';

  @override
  String get n18000 => '₹18,000';

  @override
  String get expensePageLabour => 'തൊഴിലാളി';

  @override
  String get n15 => '15%';

  @override
  String get n9950 => '₹9,950';

  @override
  String get addExpense => 'ചെലവ് ചേർക്കുക';

  @override
  String get may2025 => 'മേയ് 2025';

  @override
  String get totalPayroll => 'ആകെ ശമ്പളം';

  @override
  String get n182000 => '₹1,82,000';

  @override
  String get liveStaffData => 'ലൈവ് ജീവനക്കാരുടെ വിവരങ്ങൾ';

  @override
  String get todaySAttendance => 'ഇന്നത്തെ ഹാജർ';

  @override
  String get label => '·';

  @override
  String get pendingAdvances => 'ബാക്കി അഡ്വാൻസുകൾ';

  @override
  String get bal => 'ബാക്കി:';

  @override
  String get staff => 'സ്റ്റാഫ്';

  @override
  String get sureshKumar => 'Suresh Kumar';

  @override
  String get driver => 'ഡ്രൈവർ';

  @override
  String get n22000 => '₹22,000';

  @override
  String get paid => 'നൽകി';

  @override
  String get muruganP => 'Murugan P.';

  @override
  String get n20000 => '₹20,000';

  @override
  String get baluS => 'Balu S.';

  @override
  String get helper => 'സഹായി';

  @override
  String get n14000 => '₹14,000';

  @override
  String get senthilR => 'Senthil R.';

  @override
  String get n21000 => '₹21,000';

  @override
  String get kalaM => 'Kala M.';

  @override
  String get officeStaff => 'ഓഫീസ് ജീവനക്കാർ';

  @override
  String get fleet => 'വാഹനങ്ങൾ';

  @override
  String get n4 => '4';

  @override
  String get active => 'സജീവം';

  @override
  String get idle => 'ഒഴിവ്';

  @override
  String get n1 => '1';

  @override
  String get service => 'സേവനം';

  @override
  String get liveFleet => 'ലൈവ് വാഹനങ്ങൾ';

  @override
  String get miniTruck407 => 'മിനി ട്രക്ക് (407)';

  @override
  String get suresh => 'Suresh';

  @override
  String get n124560Km => '1,24,560 km';

  @override
  String get largeTruckTata => 'വലിയ ട്രക്ക് (ടാറ്റ)';

  @override
  String get murugan => 'Murugan';

  @override
  String get n98340Km => '98,340 km';

  @override
  String get inService => 'സർവീസിൽ';

  @override
  String get balu => 'Balu';

  @override
  String get n212000Km => '2,12,000 km';

  @override
  String get largeTruckEicher => 'വലിയ ട്രക്ക് (ഐഷർ)';

  @override
  String get senthil => 'Senthil';

  @override
  String get n67890Km => '67,890 km';

  @override
  String get newQuotation => 'പുതിയ ക്വട്ടേഷൻ';

  @override
  String get customerDetails => 'ഉപഭോക്തൃ വിവരങ്ങൾ';

  @override
  String get customerName => 'ഉപഭോക്താവിന്റെ പേര്';

  @override
  String get enterFullName => 'പൂർണ്ണ പേര് നൽകുക';

  @override
  String get phoneNumber => 'ഫോൺ നമ്പർ';

  @override
  String get n91XxxxxXxxxx => '+91 XXXXX XXXXX';

  @override
  String get moveDetails => 'ഷിഫ്റ്റിംഗ് വിവരങ്ങൾ';

  @override
  String get fromAddress => 'എവിടെ നിന്ന് (വിലാസം)';

  @override
  String get pickupLocation => 'പിക്കപ്പ് സ്ഥലം';

  @override
  String get toAddress => 'എവിടേക്ക് (വിലാസം)';

  @override
  String get dropLocation => 'ഡ്രോപ്പ് സ്ഥലം';

  @override
  String get moveDate => 'ഷിഫ്റ്റിംഗ് തീയതി';

  @override
  String get ddMmYyyy => 'DD/MM/YYYY';

  @override
  String get floorAccess => 'നില / പ്രവേശനം';

  @override
  String get eG2ndFloorLiftAvailable => 'ഉദാ., രണ്ടാം നില, ലിഫ്റ്റ് ഉണ്ട്';

  @override
  String get estimate => 'എസ്റ്റിമേറ്റ്';

  @override
  String get quotedAmount => 'ക്വോട്ട് ചെയ്ത തുക (₹)';

  @override
  String get n000 => '0.00';

  @override
  String get notes => 'കുറിപ്പുകൾ';

  @override
  String get additionalDetails => 'കൂടുതൽ വിവരങ്ങൾ';

  @override
  String get generateQuotation => 'ക്വട്ടേഷൻ തയ്യാറാക്കുക';

  @override
  String get accounts => 'അക്കൗണ്ടുകൾ';

  @override
  String get sbiCurrentAC => 'SBI — കറന്റ് അക്കൗണ്ട്';

  @override
  String get xxxx4521 => 'XXXX 4521';

  @override
  String get n284500 => '₹2,84,500';

  @override
  String get hdfcSavingsAC => 'HDFC — സേവിംഗ്സ് അക്കൗണ്ട്';

  @override
  String get xxxx7832 => 'XXXX 7832';

  @override
  String get n112300 => '₹1,12,300';

  @override
  String get cashOnHand => 'കൈവശമുള്ള പണം';

  @override
  String get totalBalance => 'ആകെ ബാലൻസ്';

  @override
  String get n414800 => '₹4,14,800';

  @override
  String get recentTransactions => 'സമീപകാല ഇടപാടുകൾ';

  @override
  String get receivedOrd001 => 'ലഭിച്ചു — ORD-001';

  @override
  String get accountsPageN12500 => '+₹12,500';

  @override
  String get may5 => 'മേയ് 5';

  @override
  String get fuelTn01Ab1234 => 'ഇന്ധനം — TN-01-AB-1234';

  @override
  String get petrolBunk => 'പെട്രോൾ പമ്പ്';

  @override
  String get n3200 => '-₹3,200';

  @override
  String get receivedOrd002 => 'ലഭിച്ചു — ORD-002';

  @override
  String get accountsPageN8000 => '+₹8,000';

  @override
  String get may4 => 'മേയ് 4';

  @override
  String get tollChennaiNh => 'ടോൾ — ചെന്നൈ NH';

  @override
  String get nhai => 'NHAI';

  @override
  String get n480 => '-₹480';

  @override
  String get pLReport => 'പ്ലാൻ & ബില്ലിംഗ്';

  @override
  String get periodMay2025 => 'കാലയളവ്: മേയ് 2025';

  @override
  String get n192000 => '₹1,92,000';

  @override
  String get pLReportPageRevenue => 'വരുമാനം';

  @override
  String get n123550 => '₹1,23,550';

  @override
  String get pLReportPageNetProfit => 'അറ്റാദായം';

  @override
  String get n643 => '64.3%';

  @override
  String get margin => 'മാർജിൻ';

  @override
  String get topExpenses => 'പ്രധാന ചെലവുകൾ';

  @override
  String get arunPackersStaff => 'Arun Packers Staff';

  @override
  String get adminArunpackersIn => 'admin@arunpackers.in';

  @override
  String get company => 'കമ്പനി';

  @override
  String get businessName => 'ബിസിനസ് പേര്';

  @override
  String get settingsPageArunPackersAndCouriers => 'Arun Packers and Couriers';

  @override
  String get phone => 'ഫോൺ';

  @override
  String get n9144XxxxXxxx => '+91 44 XXXX XXXX';

  @override
  String get gstNumber => 'GST നമ്പർ';

  @override
  String get xxxxxxxxxxxx => 'XXXXXXXXXXXX';

  @override
  String get app => 'ആപ്പ്';

  @override
  String get notifications => 'അറിയിപ്പുകൾ';

  @override
  String get enabled => 'ഓണാണ്';

  @override
  String get darkMode => 'ഡാർക്ക് മോഡ്';

  @override
  String get on => 'ഓൺ';

  @override
  String get language => 'ഭാഷ';

  @override
  String get english => 'ഇംഗ്ലീഷ്';

  @override
  String get data => 'ഡാറ്റ';

  @override
  String get exportData => 'ഡാറ്റ എക്സ്പോർട്ട്';

  @override
  String get csvPdf => 'CSV / PDF';

  @override
  String get backup => 'ബാക്കപ്പ്';

  @override
  String get autoDaily => 'ഓട്ടോ (ദിവസേന)';

  @override
  String get appTheme => 'ആപ്പ് തീം';

  @override
  String get chooseYourPreferredColourScheme =>
      'നിങ്ങൾക്ക് ഇഷ്ടമുള്ള നിറക്രമം തിരഞ്ഞെടുക്കുക.';

  @override
  String get dark => 'ഡാർക്ക്';

  @override
  String get midnight => 'മിഡ്നൈറ്റ്';

  @override
  String get light => 'ലൈറ്റ്';

  @override
  String get calendarPageCalendar => 'കലണ്ടർ';

  @override
  String get mon => 'തിങ്കൾ';

  @override
  String get tue => 'ചൊവ്വ';

  @override
  String get wed => 'ബുധൻ';

  @override
  String get thu => 'വ്യാഴം';

  @override
  String get fri => 'വെള്ളി';

  @override
  String get sat => 'ശനി';

  @override
  String get sun => 'ഞായർ';

  @override
  String get n6 => '6';

  @override
  String get n7 => '7';

  @override
  String get n9 => '9';

  @override
  String get n10 => '10';

  @override
  String get n11 => '11';

  @override
  String get n12 => '12';

  @override
  String get n13 => '13';

  @override
  String get n14 => '14';

  @override
  String get calendarPageN15 => '15';

  @override
  String get n17 => '17';

  @override
  String get calendarPageN18 => '18';

  @override
  String get n20 => '20';

  @override
  String get n21 => '21';

  @override
  String get n22 => '22';

  @override
  String get n23 => '23';

  @override
  String get n24 => '24';

  @override
  String get n25 => '25';

  @override
  String get calendarPageN26 => '26';

  @override
  String get n27 => '27';

  @override
  String get n28 => '28';

  @override
  String get n29 => '29';

  @override
  String get n30 => '30';

  @override
  String get n31 => '31';

  @override
  String get remindersFollowUps => 'റിമൈൻഡറുകളും ഫോളോ-അപ്പുകളും';

  @override
  String get followUpRaviMenon => 'ഫോളോ-അപ്പ്: Ravi Menon';

  @override
  String get callRegardingBangaloreMoveQuote =>
      'ബെംഗളൂരു ഷിഫ്റ്റിംഗ് ക്വട്ടേഷനെക്കുറിച്ച് കോൾ';

  @override
  String get may7 => 'മേയ് 7';

  @override
  String get collectionOrd047 => 'പിരിവ്: ORD-047';

  @override
  String get overduePaymentFromAnandVerma =>
      'Anand Verma-യിൽ നിന്നുള്ള കാലാവധി കഴിഞ്ഞ പേയ്മെന്റ്';

  @override
  String get may8 => 'മേയ് 8';

  @override
  String get jobTn01Ab1234 => 'ജോലി: TN-01-AB-1234';

  @override
  String get chennaiVelloreScheduledDelivery =>
      'ചെന്നൈ → വെല്ലൂർ ഷെഡ്യൂൾ ചെയ്ത ഡെലിവറി';

  @override
  String get may9 => 'മേയ് 9';

  @override
  String get reviewMayExpenses => 'അവലോകനം: മേയ് ചെലവുകൾ';

  @override
  String get monthlyExpenseReviewWithTeam => 'ടീമുമായി മാസ ചെലവ് അവലോകനം';

  @override
  String get may12 => 'മേയ് 12';

  @override
  String get activeRemindersLive => 'സജീവ റിമൈൻഡറുകൾ (ലൈവ്)';

  @override
  String get addReminder => 'ഓർമ്മപ്പെടുത്തൽ ചേർക്കുക';

  @override
  String get materials => 'സാമഗ്രികൾ';

  @override
  String get totalSkus => 'ആകെ SKU-കൾ';

  @override
  String get lowStock => 'കുറഞ്ഞ സ്റ്റോക്ക്';

  @override
  String get inventory => 'ഇൻവെന്ററി';

  @override
  String get cardboardBoxSmall => 'കാർഡ്ബോർഡ് ബോക്സ് — ചെറുത്';

  @override
  String get reorder20 => '20-ൽ താഴെയായാൽ വീണ്ടും ഓർഡർ';

  @override
  String get n42Pcs => '42 pcs';

  @override
  String get cardboardBoxMedium => 'കാർഡ്ബോർഡ് ബോക്സ് — ഇടത്തരം';

  @override
  String get n28Pcs => '28 pcs';

  @override
  String get cardboardBoxLarge => 'കാർഡ്ബോർഡ് ബോക്സ് — വലുത്';

  @override
  String get reorder15 => '15-ൽ താഴെയായാൽ വീണ്ടും ഓർഡർ';

  @override
  String get n11Pcs => '11 pcs';

  @override
  String get bubbleWrapRoll50m => 'ബബിൾ റാപ്പ് റോൾ (50മീ)';

  @override
  String get reorder5 => '5-ൽ താഴെയായാൽ വീണ്ടും ഓർഡർ';

  @override
  String get n4Rolls => '4 rolls';

  @override
  String get stretchWrapRoll => 'സ്ട്രെച്ച് റാപ്പ് റോൾ';

  @override
  String get ok => 'ശരി';

  @override
  String get n18Rolls => '18 rolls';

  @override
  String get packingTapeBrown => 'പാക്കിംഗ് ടേപ്പ് (തവിട്ട്)';

  @override
  String get reorder10 => '10-ൽ താഴെയായാൽ വീണ്ടും ഓർഡർ';

  @override
  String get n7Pcs => '7 pcs';

  @override
  String get furnitureCoverLarge => 'ഫർണിച്ചർ കവർ (വലുത്)';

  @override
  String get n24Pcs => '24 pcs';

  @override
  String get rope50m => 'കയർ (50മീ)';

  @override
  String get n8Rolls => '8 rolls';

  @override
  String get cornerGuards => 'കോർണർ ഗാർഡുകൾ';

  @override
  String get n60Pcs => '60 pcs';

  @override
  String get addRestockItem => 'ഇനം ചേർക്കുക / സ്റ്റോക്ക് നിറയ്ക്കുക';

  @override
  String get reports => 'റിപ്പോർട്ടുകൾ';

  @override
  String get generateReports => 'റിപ്പോർട്ടുകൾ തയ്യാറാക്കുക';

  @override
  String get monthlySummary => 'മാസ സംഗ്രഹം';

  @override
  String get revenueExpensesProfitOverview => 'വരുമാനം, ചെലവ്, ലാഭം — അവലോകനം';

  @override
  String get customerReport => 'ഉപഭോക്തൃ റിപ്പോർട്ട്';

  @override
  String get topCustomersByRevenue => 'വരുമാനമനുസരിച്ച് മുൻനിര ഉപഭോക്താക്കൾ';

  @override
  String get driverPerformance => 'ഡ്രൈവർ പ്രകടനം';

  @override
  String get jobsCompletedPerDriver => 'ഓരോ ഡ്രൈവറും പൂർത്തിയാക്കിയ ജോലികൾ';

  @override
  String get expenseBreakdown => 'ചെലവ് വിഭജനം';

  @override
  String get categoryWiseExpenseAnalysis => 'വിഭാഗം തിരിച്ചുള്ള ചെലവ് വിശകലനം';

  @override
  String get revenueTrend => 'വരുമാന പ്രവണത';

  @override
  String get monthOnMonthRevenueChart => 'മാസാമാസ വരുമാന ചാർട്ട്';

  @override
  String get outstandingReport => 'ബാക്കി റിപ്പോർട്ട്';

  @override
  String get pendingPaymentsAgeing => 'ബാക്കി പേയ്മെന്റുകളും കാലയളവും';

  @override
  String get vehicleUtilisation => 'വാഹന ഉപയോഗം';

  @override
  String get fleetUsageAndIdleTimeAnalysis =>
      'വാഹന ഉപയോഗവും ഒഴിവു സമയവും — വിശകലനം';

  @override
  String get exportOptions => 'എക്സ്പോർട്ട് ഓപ്ഷനുകൾ';

  @override
  String get exportPdf => 'PDF എക്സ്പോർട്ട്';

  @override
  String get exportCsv => 'CSV എക്സ്പോർട്ട്';

  @override
  String get users => 'ഉപയോക്താക്കൾ';

  @override
  String get addNewUser => 'പുതിയ ഉപയോക്താവിനെ ചേർക്കുക';

  @override
  String get admin => 'അഡ്മിൻ';

  @override
  String get activeUsers => 'സജീവ ഉപയോക്താക്കൾ';

  @override
  String get arunKumar => 'Arun Kumar';

  @override
  String get n919840000001 => '+91 98400 00001';

  @override
  String get today => 'ഇന്ന്';

  @override
  String get sureshM => 'Suresh M.';

  @override
  String get n919840000002 => '+91 98400 00002';

  @override
  String get n919840000003 => '+91 98400 00003';

  @override
  String get yesterday => 'ഇന്നലെ';

  @override
  String get kalaR => 'Kala R.';

  @override
  String get n919840000004 => '+91 98400 00004';

  @override
  String get n919840000005 => '+91 98400 00005';

  @override
  String get n2DaysAgo => '2 ദിവസം മുമ്പ്';

  @override
  String get inactiveUsers => 'നിഷ്ക്രിയ ഉപയോക്താക്കൾ';

  @override
  String get n919840000006 => '+91 98400 00006';

  @override
  String get inactive => 'നിഷ്ക്രിയം';

  @override
  String get n5DaysAgo => '5 ദിവസം മുമ്പ്';

  @override
  String get recordPayment => 'പേയ്മെന്റ് രേഖപ്പെടുത്തുക';

  @override
  String get selectOrder => 'ഓർഡർ തിരഞ്ഞെടുക്കുക';

  @override
  String get loadingPendingOrders => 'ബാക്കി ഓർഡറുകൾ ലോഡ് ചെയ്യുന്നു...';

  @override
  String get select => 'തിരഞ്ഞെടുക്കുക';

  @override
  String get paymentEntry => 'പേയ്മെന്റ് രേഖപ്പെടുത്തൽ';

  @override
  String get customer => 'ഉപഭോക്താവ്:';

  @override
  String get totalAmount => 'ആകെ തുക:';

  @override
  String get alreadyPaid => 'ഇതിനകം അടച്ചത്:';

  @override
  String get amountReceived => 'ലഭിച്ച തുക (₹)';

  @override
  String get selectStatus => 'നില തിരഞ്ഞെടുക്കുക';

  @override
  String get paymentStatus => 'പേയ്മെന്റ് നില';

  @override
  String get partial => 'ഭാഗികം';

  @override
  String get recordPaymentPagePaid => 'നൽകി';

  @override
  String get savePayment => 'സേവ്';

  @override
  String get quickExpense => 'പെട്ടെന്നുള്ള ചെലവ്';

  @override
  String get expenseDetails => 'ചെലവ് വിവരങ്ങൾ';

  @override
  String get amount => 'തുക (₹)';

  @override
  String get selectCategory => 'വിഭാഗം തിരഞ്ഞെടുക്കുക';

  @override
  String get category => 'വിഭാഗം';

  @override
  String get vehicleMaintenance => 'വാഹന അറ്റകുറ്റപ്പണി';

  @override
  String get office => 'ഓഫീസ്';

  @override
  String get material => 'സാമഗ്രി';

  @override
  String get other => 'മറ്റുള്ളവ';

  @override
  String get date => 'തീയതി';

  @override
  String get yyyyMmDd => 'YYYY-MM-DD';

  @override
  String get linkedOrderIdOptional => 'ബന്ധിപ്പിച്ച ഓർഡർ ID (ഐച്ഛികം)';

  @override
  String get leaveBlankIfNotLinked =>
      'ബന്ധിപ്പിച്ചിട്ടില്ലെങ്കിൽ ശൂന്യമായി വിടുക';

  @override
  String get description => 'വിവരണം';

  @override
  String get briefDescription => 'ചുരുക്ക വിവരണം';

  @override
  String get saveExpense => 'ചെലവ് സേവ് ചെയ്യുക';

  @override
  String get newOrder => 'പുതിയ ഓർഡർ';

  @override
  String get newOrderPageCustomer => 'ഉപഭോക്താവ്';

  @override
  String get newOrderPageCustomerName => 'ഉപഭോക്താവിന്റെ പേര് *';

  @override
  String get fullName => 'പൂർണ്ണ പേര്';

  @override
  String get newOrderPagePhone => 'ഫോൺ *';

  @override
  String get fromCity => 'എവിടെ നിന്ന് (നഗരം) *';

  @override
  String get originCity => 'തുടക്ക നഗരം';

  @override
  String get toCity => 'എവിടേക്ക് (നഗരം) *';

  @override
  String get destinationCity => 'ലക്ഷ്യ നഗരം';

  @override
  String get pickupAddress => 'പിക്കപ്പ് വിലാസം';

  @override
  String get dropAddress => 'ഡ്രോപ്പ് വിലാസം';

  @override
  String get fromFloor => 'എവിടെ നിന്ന് (നില)';

  @override
  String get eG2ndFloor => 'ഉദാ., രണ്ടാം നില';

  @override
  String get toFloor => 'എവിടേക്ക് (നില)';

  @override
  String get eGGroundFloor => 'ഉദാ., താഴത്തെ നില';

  @override
  String get newOrderPageMoveDate => 'ഷിഫ്റ്റിംഗ് തീയതി *';

  @override
  String get tapToPickDate => 'തീയതി തിരഞ്ഞെടുക്കാൻ ടാപ്പ് ചെയ്യുക';

  @override
  String get pickDate => 'തീയതി തിരഞ്ഞെടുക്കുക';

  @override
  String get pricingClassification => 'വിലയും വർഗ്ഗീകരണവും';

  @override
  String get newOrderPageAmount => 'തുക (₹) *';

  @override
  String get selectService => 'സേവനം തിരഞ്ഞെടുക്കുക';

  @override
  String get newOrderPageService => 'സേവനം *';

  @override
  String get houseShifting => 'വീട് മാറ്റം';

  @override
  String get officeShifting => 'ഓഫീസ് മാറ്റം';

  @override
  String get vehicleTransport => 'വാഹന ഗതാഗതം';

  @override
  String get storage => 'സ്റ്റോറേജ്';

  @override
  String get packingOnly => 'പാക്കിംഗ് മാത്രം';

  @override
  String get longDistance => 'ദീർഘദൂരം';

  @override
  String get selectBranch => 'ശാഖ തിരഞ്ഞെടുക്കുക';

  @override
  String get branch => 'ശാഖ *';

  @override
  String get chennai => 'Chennai';

  @override
  String get bengaluru => 'Bengaluru';

  @override
  String get coimbatore => 'Coimbatore';

  @override
  String get selectType => 'തരം തിരഞ്ഞെടുക്കുക';

  @override
  String get orderType => 'ഓർഡർ തരം *';

  @override
  String get direct => 'നേരിട്ട്';

  @override
  String get newOrderPagePorter => 'പോർട്ടർ';

  @override
  String get porterCommission => 'പോർട്ടർ കമ്മീഷൻ %';

  @override
  String get saveOrder => 'ഓർഡർ സേവ് ചെയ്യുക';

  @override
  String get orderDetails => 'ഓർഡർ വിവരങ്ങൾ';

  @override
  String get orderDetailPageBranch => 'ശാഖ';

  @override
  String get type => 'തരം';

  @override
  String get from => 'മുതൽ';

  @override
  String get to => 'വരെ';

  @override
  String get addressFrom => 'വിലാസം (എവിടെ നിന്ന്)';

  @override
  String get addressTo => 'വിലാസം (എവിടേക്ക്)';

  @override
  String get floorFrom => 'നില (എവിടെ നിന്ന്)';

  @override
  String get floorTo => 'നില (എവിടേക്ക്)';

  @override
  String get payment => 'പേയ്മെന്റ്';

  @override
  String get orderDetailPageAmount => 'തുക';

  @override
  String get advancePaid => 'അടച്ച അഡ്വാൻസ്';

  @override
  String get trackingStatus => 'ട്രാക്കിംഗ് നില';

  @override
  String get editOrder => 'ഓർഡർ തിരുത്തുക';

  @override
  String get contact => 'ബന്ധപ്പെടാൻ';

  @override
  String get email => 'ഇമെയിൽ';

  @override
  String get emailExampleCom => 'email@example.com';

  @override
  String get newLeadPageFromCity => 'എവിടെ നിന്ന് (നഗരം)';

  @override
  String get newLeadPageToCity => 'എവിടേക്ക് (നഗരം)';

  @override
  String get approxDate => 'ഏകദേശ തീയതി *';

  @override
  String get classification => 'വർഗ്ഗീകരണം';

  @override
  String get status => 'നില *';

  @override
  String get newLeadPageNew => 'പുതിയത്';

  @override
  String get newLeadPageContacted => 'ബന്ധപ്പെട്ടു';

  @override
  String get surveyDone => 'സർവേ പൂർത്തിയായി';

  @override
  String get quoted => 'ക്വോട്ട് അയച്ചു';

  @override
  String get converted => 'ബുക്ക് ആയവ';

  @override
  String get newLeadPageLost => 'നഷ്ടപ്പെട്ടവ';

  @override
  String get howDidTheyHearAboutUs => 'അവർ ഞങ്ങളെക്കുറിച്ച് എങ്ങനെ അറിഞ്ഞു?';

  @override
  String get source => 'ഉറവിടം *';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get phoneCall => 'ഫോൺ കോൾ';

  @override
  String get website => 'വെബ്സൈറ്റ്';

  @override
  String get referral => 'റഫറൽ';

  @override
  String get walkIn => 'വാക്ക്-ഇൻ';

  @override
  String get google => 'Google';

  @override
  String get justdial => 'JustDial';

  @override
  String get anyRelevantNotes => 'ബന്ധപ്പെട്ട കുറിപ്പുകൾ';

  @override
  String get saveLead => 'ലീഡ് സേവ് ചെയ്യുക';

  @override
  String get leadDetails => 'ലീഡ് വിവരങ്ങൾ';

  @override
  String get leadDetailPageSource => 'ഉറവിടം';

  @override
  String get leadDetailPageApproxDate => 'ഏകദേശ തീയതി';

  @override
  String get convertToOrder => 'ഓർഡറാക്കി മാറ്റുക';

  @override
  String get editLead => 'ലീഡ് തിരുത്തുക';

  @override
  String get quickEntry => 'പെട്ടെന്നുള്ള എൻട്രി';

  @override
  String get whatWouldYouLikeToDo => 'നിങ്ങൾ എന്താണ് ചെയ്യാൻ ആഗ്രഹിക്കുന്നത്?';

  @override
  String get newInquiry => 'പുതിയ അന്വേഷണം';

  @override
  String get confirmBooking => 'ബുക്കിംഗ് സ്ഥിരീകരിക്കുക';

  @override
  String get cashCollectedByPorter => 'പോർട്ടർ ശേഖരിച്ച പണം (₹)';

  @override
  String get leaveBlankIfNoneCollectedYet =>
      'ഇതുവരെ ശേഖരിച്ചിട്ടില്ലെങ്കിൽ ശൂന്യമായി വിടുക';

  @override
  String get jrTitle => 'ഓർഡർ യാത്ര';

  @override
  String get jrStageLead => 'ലീഡ്';

  @override
  String get jrStageFollowUp => 'ഫോളോ-അപ്പ്';

  @override
  String get jrStageSurvey => 'സർവേ';

  @override
  String get jrStageQuote => 'ക്വോട്ടും സ്ഥിരീകരണവും';

  @override
  String get jrStageSupervisor => 'സൂപ്പർവൈസർ';

  @override
  String get jrStageMoveDay => 'ഷിഫ്റ്റിംഗ് ദിവസം';

  @override
  String get jrStageInvoice => 'ഇൻവോയ്സ്';

  @override
  String get jrStagePayment => 'പേയ്മെന്റ് & പ്രശ്നങ്ങൾ';

  @override
  String get jrStageClosed => 'അടച്ചു';

  @override
  String get jrStateDone => 'പൂർത്തി';

  @override
  String get jrStateSkipped => 'ഒഴിവാക്കി';

  @override
  String get jrStateCurrent => 'ഇപ്പോൾ';

  @override
  String get jrStatePending => 'പിന്നീട്';

  @override
  String get jrDirectOrder => 'ഒഴിവാക്കി · നേരിട്ടുള്ള ഓർഡർ';

  @override
  String get jrMoveDate => 'ഷിഫ്റ്റിംഗ് തീയതി';

  @override
  String get jrRoute => 'റൂട്ട്';

  @override
  String get jrOrderValue => 'ഓർഡർ മൂല്യം';

  @override
  String get jrNotSet => 'സജ്ജീകരിച്ചിട്ടില്ല';

  @override
  String get jrDocuments => 'രേഖകൾ';

  @override
  String get jrDocQuote => 'ക്വട്ടേഷൻ';

  @override
  String get jrDocInvoice => 'ടാക്സ് ഇൻവോയ്സ്';

  @override
  String get jrDocReceipts => 'പണ രസീതുകൾ';

  @override
  String get jrDocLr => 'ലോറി രസീത്';

  @override
  String get jrDocReady => 'തയ്യാർ · കാണാൻ അമർത്തുക';

  @override
  String jrDocAfter(String stage) {
    return '$stage കഴിഞ്ഞ്';
  }

  @override
  String jrCreated(String date) {
    return 'സൃഷ്ടിച്ചത് $date';
  }

  @override
  String jrSource(String source) {
    return 'ഉറവിടം: $source';
  }

  @override
  String jrService(String service) {
    return 'സേവനം: $service';
  }

  @override
  String get jrNoCalls => 'ഇതുവരെ കോളുകൾ രേഖപ്പെടുത്തിയിട്ടില്ല';

  @override
  String jrCallsLogged(String count) {
    return '$count കോളുകൾ രേഖപ്പെടുത്തി';
  }

  @override
  String get jrOutcomeQ => 'കോൾ എങ്ങനെയായിരുന്നു?';

  @override
  String get jrOutNoAnswer => 'ലഭ്യമല്ല';

  @override
  String get jrOutCallback => 'വീണ്ടും വിളിക്കുക';

  @override
  String get jrOutInterested => 'താൽപ്പര്യമുണ്ട്';

  @override
  String get jrOutNotInterested => 'താൽപ്പര്യമില്ല';

  @override
  String get jrCallNotes => 'കോളിലെ കുറിപ്പുകൾ';

  @override
  String get jrNextFollowUp => 'അടുത്ത ഫോളോ-അപ്പ്';

  @override
  String get jrToday => 'ഇന്ന്';

  @override
  String get jrTomorrow => 'നാളെ';

  @override
  String get jrIn2Days => '2 ദിവസത്തിൽ';

  @override
  String get jrNextWeek => 'അടുത്ത ആഴ്ച';

  @override
  String get jrPickDate => 'തീയതി തിരഞ്ഞെടുക്കുക';

  @override
  String get jrNoNext => 'ഇല്ല';

  @override
  String get jrLogCall => 'കോൾ രേഖപ്പെടുത്തുക';

  @override
  String get jrCallLogged => 'കോൾ രേഖപ്പെടുത്തി';

  @override
  String get jrPickOutcome => 'കോൾ എങ്ങനെയായിരുന്നു എന്ന് തിരഞ്ഞെടുക്കുക';

  @override
  String get jrSurveyWaiting =>
      'സർവേ ലിങ്ക് അയച്ചു · ഉപഭോക്താവിനായി കാത്തിരിക്കുന്നു';

  @override
  String get jrSurveyDone => 'ഉപഭോക്താവ് സർവേ സമർപ്പിച്ചു';

  @override
  String get jrNoSurvey => 'ഇതുവരെ സർവേ ഇല്ല';

  @override
  String get jrOpenSurveyQuote => 'സർവേയും ക്വോട്ടും തുറക്കുക';

  @override
  String get jrNoQuote => 'ഇതുവരെ ക്വോട്ട് ഇല്ല';

  @override
  String jrQuoteLine(String amount) {
    return 'ക്വോട്ട് $amount';
  }

  @override
  String jrOrderConfirmed(String id) {
    return 'ഓർഡർ $id സ്ഥിരീകരിച്ചു';
  }

  @override
  String get jrLeadLost => 'ലീഡ് നഷ്ടപ്പെട്ടതായി അടയാളപ്പെടുത്തി';

  @override
  String get jrNoSupervisor => 'ഇതുവരെ സൂപ്പർവൈസർ ഇല്ല';

  @override
  String jrSupervisorIs(String name) {
    return 'സൂപ്പർവൈസർ: $name';
  }

  @override
  String jrCrew(String count) {
    return 'ജോലിയിലുള്ള ടീം: $count';
  }

  @override
  String get jrAssignInOrder => 'സൂപ്പർവൈസറെ നിയോഗിക്കുക';

  @override
  String get jrNotStarted => 'ആരംഭിച്ചിട്ടില്ല';

  @override
  String jrMoveStarted(String time) {
    return 'ആരംഭിച്ചു $time';
  }

  @override
  String jrMoveFinished(String time) {
    return 'പൂർത്തിയായി $time';
  }

  @override
  String get jrOpenFieldJob => 'ഫീൽഡ് ജോലി തുറക്കുക';

  @override
  String get jrNoInvoice => 'ഇൻവോയ്സ് തയ്യാറാക്കിയിട്ടില്ല';

  @override
  String jrInvoiceNo(String no) {
    return 'ഇൻവോയ്സ് $no';
  }

  @override
  String get jrSigned => 'ഉപഭോക്താവ് ഒപ്പിട്ടു';

  @override
  String get jrNotSigned => 'ഉപഭോക്താവിന്റെ ഒപ്പില്ല';

  @override
  String get jrOpenOrder => 'ഓർഡർ തുറക്കുക';

  @override
  String get jrTotal => 'ആകെ';

  @override
  String get jrPaid => 'നൽകി';

  @override
  String get jrBalance => 'ബാക്കി';

  @override
  String get jrRecordPayment => 'പേയ്മെന്റ് രേഖപ്പെടുത്തുക';

  @override
  String get jrTickets => 'ടിക്കറ്റുകൾ';

  @override
  String get jrNoTickets => 'ടിക്കറ്റുകളില്ല';

  @override
  String get jrTicketHint => 'ഉദാ., AC ഫിറ്റിംഗ് ബാക്കി';

  @override
  String get jrRaiseTicket => 'ടിക്കറ്റ് ഉണ്ടാക്കുക';

  @override
  String get jrResolve => 'പരിഹരിക്കുക';

  @override
  String get jrTicketRaised => 'ടിക്കറ്റ് രേഖപ്പെടുത്തി';

  @override
  String get jrTicketResolved => 'ടിക്കറ്റ് പരിഹരിച്ചു';

  @override
  String get jrBlockTicket => 'ഒരു ടിക്കറ്റ് ഇപ്പോഴും തുറന്നിരിക്കുന്നു';

  @override
  String jrBlockBalance(String amount) {
    return '$amount ബാക്കി തുക അടയ്ക്കാനുണ്ട്';
  }

  @override
  String get jrCloseOrder => 'ഓർഡർ അടയ്ക്കുക';

  @override
  String jrClosedOn(String date) {
    return 'അടച്ചു $date';
  }

  @override
  String get jrNotClosed => 'തുറന്നത്';

  @override
  String jrPaymentLine(String amount, String mode) {
    return '$amount · $mode';
  }

  @override
  String get jrCouldNotLoad => 'ഈ യാത്ര ലോഡ് ചെയ്യാൻ കഴിഞ്ഞില്ല';

  @override
  String get jrRetry => 'വീണ്ടും ശ്രമിക്കുക';

  @override
  String jrCouldNotSave(String error) {
    return 'സേവ് ചെയ്യാൻ കഴിഞ്ഞില്ല: $error';
  }

  @override
  String get ngNavHome => 'ഹോം';

  @override
  String get ngNavLeads => 'ലീഡുകൾ';

  @override
  String get ngNavOrders => 'ഓർഡറുകൾ';

  @override
  String get ngNavOps => 'ഓപ്സ്';

  @override
  String get ngNavPay => 'പേ';

  @override
  String get ngNavMore => 'കൂടുതൽ';

  @override
  String get ngMenuDashboard => 'ഡാഷ്ബോർഡ്';

  @override
  String get ngMenuLeads => 'ലീഡുകൾ / CRM';

  @override
  String get ngMenuInbox => 'ഇൻബോക്സ്';

  @override
  String get ngMenuSurveyQuote => 'സർവേയും ക്വോട്ടും';

  @override
  String get ngMenuCalendar => 'കലണ്ടർ';

  @override
  String get ngMenuOrders => 'ഓർഡറുകൾ';

  @override
  String get ngMenuOperations => 'പ്രവർത്തനങ്ങൾ';

  @override
  String get ngMenuReviews => 'റിവ്യൂകൾ';

  @override
  String get ngMenuPayments => 'പേയ്മെന്റുകൾ';

  @override
  String get ngMenuExpenses => 'ചെലവുകൾ';

  @override
  String get ngMenuStaff => 'ജീവനക്കാർ';

  @override
  String get ngMenuTeamAttendance => 'ടീം ഹാജർ';

  @override
  String get ngMenuFleet => 'വാഹനങ്ങൾ';

  @override
  String get ngMenuMaterials => 'സാമഗ്രികൾ';

  @override
  String get ngMenuWarehouses => 'വെയർഹൗസുകൾ';

  @override
  String get ngMenuRateCards => 'റേറ്റ് കാർഡുകൾ';

  @override
  String get ngMenuLrRegister => 'LR രജിസ്റ്റർ';

  @override
  String get ngMenuOpsLog => 'ഓപ്സ് ലോഗ്';

  @override
  String get ngMenuVendors => 'വെണ്ടർമാർ';

  @override
  String get ngMenuCustomers => 'ഉപഭോക്താക്കൾ';

  @override
  String get ngMenuInsurance => 'ഇൻഷുറൻസ്';

  @override
  String get ngMenuTrips => 'യാത്രകൾ';

  @override
  String get ngMenuTasks => 'ജോലികൾ';

  @override
  String get ngMenuAccounts => 'അക്കൗണ്ടുകൾ';

  @override
  String get ngMenuPnl => 'ലാഭനഷ്ടം';

  @override
  String get ngMenuReports => 'റിപ്പോർട്ടുകൾ';

  @override
  String get ngMenuSalary => 'ശമ്പളം';

  @override
  String get ngMenuSettings => 'ക്രമീകരണങ്ങൾ';

  @override
  String get ngMenuPlatformAdmin => 'പ്ലാറ്റ്ഫോം അഡ്മിൻ';

  @override
  String get ngMenuMyJobs => 'എന്റെ ജോലികൾ';

  @override
  String get ngMenuMyTeam => 'എന്റെ ടീം';

  @override
  String get ngMenuMyEarnings => 'എന്റെ വരുമാനം';

  @override
  String get ngMenuMyAttendance => 'എന്റെ ഹാജർ';

  @override
  String get ngGroupSales => 'വിൽപ്പന';

  @override
  String get ngGroupOperations => 'പ്രവർത്തനങ്ങൾ';

  @override
  String get ngGroupMoney => 'പണം';

  @override
  String get ngGroupPeople => 'ആളുകൾ';

  @override
  String get ngGroupAssets => 'ആസ്തികൾ';

  @override
  String get ngGroupPartners => 'പങ്കാളികൾ';

  @override
  String get ngGroupSetup => 'സജ്ജീകരണം';

  @override
  String get ngGroupField => 'ഫീൽഡ്';

  @override
  String get ngGroupOther => 'മറ്റുള്ളവ';

  @override
  String get ngQuickEntry => 'പെട്ടെന്നുള്ള എൻട്രി';

  @override
  String get ngSearchModules => 'മൊഡ്യൂളുകൾ തിരയുക';

  @override
  String get ngNoModuleMatches => 'പൊരുത്തപ്പെടുന്ന മൊഡ്യൂൾ ഇല്ല';

  @override
  String get ngHelp => 'സഹായം';

  @override
  String ngOrgsSwitch(String count) {
    return '$count സ്ഥാപനങ്ങൾ · മാറാൻ ടാപ്പ് ചെയ്യുക';
  }

  @override
  String get ngRoleOwner => 'ഉടമ';

  @override
  String get ngRoleStaff => 'ജീവനക്കാരൻ';

  @override
  String get ngTodayMoves => 'ഷിഫ്റ്റിംഗുകൾ';

  @override
  String get ngTodayFollowUps => 'ഫോളോ-അപ്പുകൾ';

  @override
  String get ngToCollect => 'പിരിക്കാനുള്ളത്';

  @override
  String get ngOpenLeads => 'തുറന്ന ലീഡുകൾ';

  @override
  String get ngNoMovesYet => 'ഇതുവരെ ഷിഫ്റ്റിംഗ് ഷെഡ്യൂൾ ചെയ്തിട്ടില്ല';

  @override
  String get ngCreateFirstOrder => 'നിങ്ങളുടെ ആദ്യ ഓർഡർ സൃഷ്ടിക്കുക';

  @override
  String get ngNoLeadsYet => 'ഇതുവരെ ലീഡുകളില്ല';

  @override
  String get ngAddLead => 'ലീഡ് ചേർക്കുക';

  @override
  String get ngAllLeads => 'എല്ലാ ലീഡുകളും';

  @override
  String get ngConversion => 'പരിവർത്തനം';

  @override
  String get ngOpen => 'തുറന്നവ';

  @override
  String get ngOther => 'മറ്റുള്ളവ';

  @override
  String get ngSurveyResponse => 'സർവേ മറുപടി ലഭിച്ചു';

  @override
  String get ngFollowUpOverdue => 'ഫോളോ-അപ്പ് വൈകി';

  @override
  String get ngCall => 'വിളിക്കുക';

  @override
  String get ngWhatsApp => 'WhatsApp';

  @override
  String get ngSurvey => 'സർവേ';

  @override
  String get ngNewLead => 'പുതിയ ലീഡ്';

  @override
  String get ngNameOrPhone => 'പേര് അല്ലെങ്കിൽ ഫോൺ';

  @override
  String get ngNoLeadsMatch => 'പൊരുത്തപ്പെടുന്ന ലീഡുകളില്ല';

  @override
  String get ngLeadsEmptyHint =>
      'പുതിയ ലീഡ് വഴി അന്വേഷണം ചേർക്കുക, അത് ഇവിടെ കാണാം.';

  @override
  String get ngSurveyLinkCreated => 'സർവേ ലിങ്ക് സൃഷ്ടിച്ചു';

  @override
  String get ngCopyClose => 'പകർത്തി അടയ്ക്കുക';

  @override
  String get ngClose => 'അടയ്ക്കുക';

  @override
  String get ngTabAll => 'എല്ലാം';

  @override
  String get ngTabPending => 'നടക്കുന്നവ';

  @override
  String get ngTabCompleted => 'പൂർത്തിയായവ';

  @override
  String get ngTabCancelled => 'റദ്ദാക്കിയവ';

  @override
  String get ngToday => 'ഇന്ന്';

  @override
  String get ngTomorrow => 'നാളെ';

  @override
  String get ngYesterday => 'ഇന്നലെ';

  @override
  String get ngNoMoveDate => 'ഷിഫ്റ്റിംഗ് തീയതി ഇല്ല';

  @override
  String get ngPaid => 'അടച്ചു';

  @override
  String get ngPartPaid => 'ഭാഗികമായി അടച്ചു';

  @override
  String get ngDue => 'ബാക്കി';

  @override
  String get ngUnpaid => 'അടച്ചിട്ടില്ല';

  @override
  String get ngNewOrder => 'പുതിയ ഓർഡർ';

  @override
  String get ngNoOrdersHere => 'ഇവിടെ ഓർഡറുകളില്ല';

  @override
  String get ngRemind => 'ഓർമ്മിപ്പിക്കുക';

  @override
  String get ngRecord => 'രേഖപ്പെടുത്തുക';

  @override
  String get ngOverdue => 'വൈകിയവ';

  @override
  String get ngUpcoming => 'വരാനിരിക്കുന്നവ';

  @override
  String get ngNothingToCollect => 'പിരിക്കാൻ ഒന്നുമില്ല';

  @override
  String get ngLinkedDevice => 'ബന്ധിപ്പിച്ച ഉപകരണം';

  @override
  String get ngEnterPin => 'നിങ്ങളുടെ 4 അക്ക PIN നൽകുക';

  @override
  String get ngVerifying => 'പരിശോധിക്കുന്നു…';

  @override
  String get ngUseEmail => 'പകരം ഇമെയിൽ ലോഗിൻ ഉപയോഗിക്കുക';

  @override
  String get ngSwitchDevice => 'നിങ്ങളുടെ സ്ഥാപനമല്ലേ? ഉപകരണം മാറ്റുക';

  @override
  String get ngSecuredBy => 'Nagarva സുരക്ഷിതമാക്കിയത്';

  @override
  String get suCreate => 'നിങ്ങളുടെ ബിസിനസ് അക്കൗണ്ട് ഉണ്ടാക്കുക';

  @override
  String suStep(String n) {
    return 'ഘട്ടം $n / 4';
  }

  @override
  String get suS1 => 'മൊബൈൽ';

  @override
  String get suS2 => 'ബിസിനസ്';

  @override
  String get suS3 => 'രേഖകൾ';

  @override
  String get suS4 => 'പരിശോധന';

  @override
  String get suPhS =>
      'ഉടമയുടെ നമ്പർ നൽകൂ. ഇതുപയോഗിച്ചാണ് നിങ്ങൾ ലോഗിൻ ചെയ്യുക.';

  @override
  String get suPh => 'മൊബൈൽ നമ്പർ';

  @override
  String get suSend => 'OTP അയയ്ക്കുക';

  @override
  String get suPhBad => '10 അക്ക മൊബൈൽ നമ്പർ നൽകുക';

  @override
  String get suOtpT => 'OTP നൽകുക';

  @override
  String suOtpS(String p) {
    return '+91 $p ലേക്ക് അയച്ചു';
  }

  @override
  String get suEnter => '6 അക്ക കോഡ് ടൈപ്പ് ചെയ്യുക';

  @override
  String get suVerify => 'സ്ഥിരീകരിക്കുക';

  @override
  String get suOtpBad => '6 അക്ക OTP നൽകുക';

  @override
  String get suResend => 'OTP വീണ്ടും അയയ്ക്കുക';

  @override
  String get suResent => 'OTP വീണ്ടും അയച്ചു';

  @override
  String get suChange => 'നമ്പർ മാറ്റുക';

  @override
  String get suBzT => 'നിങ്ങളുടെ ബിസിനസിനെക്കുറിച്ച്';

  @override
  String get suBzS =>
      'ഇത് നിങ്ങളുടെ ക്വട്ടേഷനിലും ബില്ലിലും കാണും. പിന്നീട് മാറ്റാം.';

  @override
  String get suName => 'ബിസിനസ് പേര്';

  @override
  String get suNameP => 'ഉദാ. അരുൺ പാക്കേഴ്‌സ് & മൂവേഴ്‌സ്';

  @override
  String get suOwner => 'ഉടമയുടെ പേര്';

  @override
  String get suEmail => 'ഇമെയിൽ (ഐച്ഛികം)';

  @override
  String get suEmailP => 'ബില്ലിനും പാസ്‌വേഡ് റീസെറ്റിനും';

  @override
  String get suCity => 'നഗരം';

  @override
  String get suType => 'നിങ്ങൾ എന്ത് ചെയ്യുന്നു?';

  @override
  String get suTPm => 'പാക്കേഴ്‌സ് & മൂവേഴ്‌സ്';

  @override
  String get suTPmS => 'വീട്, ഓഫീസ് ഷിഫ്റ്റിംഗ്';

  @override
  String get suTTr => 'ട്രാൻസ്‌പോർട്ട്';

  @override
  String get suTTrS => 'ട്രക്കുകൾ, ട്രിപ്പുകൾ, LR';

  @override
  String get suTBo => 'രണ്ടും';

  @override
  String get suTBoS => 'ഷിഫ്റ്റിംഗും ട്രാൻസ്‌പോർട്ടും';

  @override
  String get suGst => 'GSTIN (ഐച്ഛികം)';

  @override
  String get suGstP => '15 അക്ഷര GST നമ്പർ';

  @override
  String get suRef => 'റഫറൽ കോഡ് (ഐച്ഛികം)';

  @override
  String get suNeedBz => 'ബിസിനസ് പേര്, ഉടമയുടെ പേര്, നഗരം പൂരിപ്പിക്കുക';

  @override
  String get suGstBad => 'GSTIN 15 അക്ഷരം വേണം';

  @override
  String get suEmailBad => 'ഇമെയിൽ വിലാസം പരിശോധിക്കുക';

  @override
  String get suDcT => 'നിങ്ങളുടെ ബിസിനസ് സ്ഥിരീകരിക്കുക';

  @override
  String get suDcS =>
      'ഫോട്ടോ അല്ലെങ്കിൽ PDF. അക്കൗണ്ട് തുടങ്ങും മുമ്പ് ഞങ്ങളുടെ ടീം ഇവ പരിശോധിക്കും.';

  @override
  String get suPan => 'PAN കാർഡ്';

  @override
  String get suPanS => 'ഉടമയുടെയോ ബിസിനസിന്റെയോ PAN';

  @override
  String get suGstC => 'GST സർട്ടിഫിക്കറ്റ്';

  @override
  String get suGstCS => 'GSTIN നൽകിയതിനാൽ ആവശ്യം';

  @override
  String get suShop => 'ഓഫീസ് അല്ലെങ്കിൽ ഗോഡൗൺ ഫോട്ടോ';

  @override
  String get suShopS => 'വേഗം സ്ഥിരീകരിക്കാൻ സഹായിക്കും';

  @override
  String get suUpload => 'അപ്‌ലോഡ്';

  @override
  String get suReq => 'ആവശ്യം';

  @override
  String get suOpt => 'ഐച്ഛികം';

  @override
  String get suNeedPan => 'നിങ്ങളുടെ PAN കാർഡ് അപ്‌ലോഡ് ചെയ്യുക';

  @override
  String get suNeedGstC =>
      'GST സർട്ടിഫിക്കറ്റ് അപ്‌ലോഡ് ചെയ്യുക അല്ലെങ്കിൽ GSTIN നീക്കുക';

  @override
  String get suPriv =>
      'രേഖകൾ ബിസിനസ് സ്ഥിരീകരണത്തിന് മാത്രം. നിങ്ങളുടെ ജീവനക്കാർക്കോ ഉപഭോക്താക്കൾക്കോ കാണില്ല.';

  @override
  String get suRvT => 'പരിശോധിച്ച് അയയ്ക്കുക';

  @override
  String get suEdit => 'മാറ്റുക';

  @override
  String get suNext => 'അടുത്തതായി എന്ത്';

  @override
  String get suN1 =>
      'ഞങ്ങളുടെ ടീം നിങ്ങളുടെ വിവരങ്ങൾ പരിശോധിക്കും, സാധാരണ 1 പ്രവൃത്തി ദിവസത്തിനകം.';

  @override
  String get suN3 =>
      'സൗജന്യ പ്ലാനിൽ തുടങ്ങും. എപ്പോൾ വേണമെങ്കിലും അപ്‌ഗ്രേഡ് ചെയ്യാം.';

  @override
  String get suNeedAgree => 'തുടരാൻ നിബന്ധനകൾ അംഗീകരിക്കുക';

  @override
  String get suSubmit => 'അംഗീകാരത്തിന് അയയ്ക്കുക';

  @override
  String get suContinue => 'തുടരുക';

  @override
  String get suMob => 'മൊബൈൽ';

  @override
  String get suBt => 'ബിസിനസ് തരം';

  @override
  String get suNone => 'ചേർത്തിട്ടില്ല';

  @override
  String get suPendT => 'അപേക്ഷ പരിശോധനയിലാണ്';

  @override
  String suAppId(String id) {
    return 'അപേക്ഷ $id';
  }

  @override
  String get suTl1 => 'അയച്ചു';

  @override
  String get suTl2 => 'രേഖ പരിശോധന';

  @override
  String get suTl3 => 'അക്കൗണ്ട് തയ്യാർ';

  @override
  String get suOkT => 'നിങ്ങളുടെ അക്കൗണ്ട് തയ്യാർ';

  @override
  String suOkS(String b) {
    return '$b അംഗീകരിച്ചു. നിങ്ങൾ സൗജന്യ പ്ലാനിലാണ്.';
  }

  @override
  String get suStart => 'Nagarva തുടങ്ങുക';

  @override
  String get suNoT => 'മാറ്റങ്ങൾ വേണം';

  @override
  String get suNoS =>
      'ഞങ്ങളുടെ ടീമിന് ഇതുവരെ അംഗീകരിക്കാനായില്ല. താഴെയുള്ളത് ശരിയാക്കി വീണ്ടും അയയ്ക്കുക.';

  @override
  String get suFix => 'ശരിയാക്കി വീണ്ടും അയയ്ക്കുക';

  @override
  String get suWa => 'WhatsApp-ൽ സംസാരിക്കുക';

  @override
  String get suToLogin => 'ലോഗിനിലേക്ക് മടങ്ങുക';

  @override
  String get suHave => 'ഇതിനകം അക്കൗണ്ട് ഉണ്ടോ?';

  @override
  String get suLogin => 'ലോഗിൻ';

  @override
  String get suBnP => 'അപേക്ഷ പരിശോധനയിലാണ്';

  @override
  String get suBnOk => 'അക്കൗണ്ട് അംഗീകരിച്ചു';

  @override
  String get suBnNo => 'അപേക്ഷയിൽ മാറ്റങ്ങൾ വേണം';

  @override
  String get suView => 'കാണുക';

  @override
  String get suSent => 'അപേക്ഷ അയച്ചു';

  @override
  String get lgTerms => 'ഉപയോഗ നിബന്ധനകൾ';

  @override
  String get lgPriv => 'സ്വകാര്യതാ നയം';

  @override
  String suTrT(String n) {
    return '$n ദിവസം Pro സൗജന്യമായി പരീക്ഷിക്കൂ';
  }

  @override
  String suTrUsers(String n) {
    return '$n ഉപയോക്താക്കൾ വരെ';
  }

  @override
  String get suTrOrdersAll => 'എല്ലാ മാസവും പരിധിയില്ലാത്ത ഓർഡറുകൾ';

  @override
  String suTrOrders(String n) {
    return 'മാസം $n ഓർഡറുകൾ';
  }

  @override
  String get suTrReports => 'റിപ്പോർട്ടുകളും ലാഭ-നഷ്ടവും';

  @override
  String get suTrBranches => 'ഒന്നിലധികം ശാഖകൾ';

  @override
  String suTrNote(String n) {
    return 'കാർഡ് വേണ്ട. $n ദിവസം കഴിഞ്ഞാൽ നിങ്ങൾ സ്വയം സൗജന്യ പ്ലാനിലേക്ക് മാറും. നിങ്ങളുടെ ഡാറ്റ നിലനിൽക്കും.';
  }

  @override
  String suTrBtn(String n) {
    return '$n ദിവസത്തെ Pro ട്രയൽ തുടങ്ങൂ';
  }

  @override
  String get suStayFree => 'സൗജന്യത്തിൽ തുടരൂ';

  @override
  String suTrOn(String n) {
    return 'Pro ട്രയൽ തുടങ്ങി · $n ദിവസം';
  }

  @override
  String get suFreeOn => 'നിങ്ങൾ സൗജന്യ പ്ലാനിലാണ്';

  @override
  String plTrBan(String n) {
    return 'Pro ട്രയൽ $n ദിവസത്തിൽ അവസാനിക്കും. പിന്നെ നിങ്ങൾ സൗജന്യ പ്ലാനിലേക്ക് മാറും. നിങ്ങളുടെ ഡാറ്റ നിലനിൽക്കും.';
  }

  @override
  String get plTrEnded =>
      'നിങ്ങളുടെ Pro ട്രയൽ അവസാനിച്ചു. നിങ്ങൾ സൗജന്യ പ്ലാനിലാണ്, നിങ്ങളുടെ എല്ലാ ഡാറ്റയും സുരക്ഷിതമാണ്.';

  @override
  String plTrEnds(String d, String n) {
    return 'Pro ട്രയൽ $d-ന് അവസാനിക്കും · $n ദിവസം ബാക്കി';
  }

  @override
  String get suN2b =>
      'നിങ്ങളുടെ നില അറിയാൻ എപ്പോൾ വേണമെങ്കിലും ഇതേ മൊബൈൽ നമ്പറിൽ ലോഗിൻ ചെയ്യൂ.';

  @override
  String suPendS2(String p) {
    return 'സാധാരണ 1 പ്രവൃത്തി ദിവസത്തിനുള്ളിൽ മറുപടി നൽകും. ഫലം കാണാൻ +91 $p ഉപയോഗിച്ച് ലോഗിൻ ചെയ്യൂ.';
  }

  @override
  String get suOtpUnavailable =>
      'മൊബൈൽ സൈൻ-അപ്പ് ഇതുവരെ ഓണാക്കിയിട്ടില്ല. Nagarva സഹായവുമായി ബന്ധപ്പെടൂ.';

  @override
  String get suSendFailed =>
      'OTP അയയ്ക്കാനായില്ല. നമ്പർ പരിശോധിച്ച് വീണ്ടും ശ്രമിക്കൂ.';

  @override
  String get suOtpFailed => 'ആ കോഡ് ശരിയായില്ല. പരിശോധിച്ച് വീണ്ടും ശ്രമിക്കൂ.';

  @override
  String get suUploadFailed => 'അപ്‌ലോഡ് പരാജയപ്പെട്ടു. വീണ്ടും ശ്രമിക്കൂ.';

  @override
  String get suMobileLogin => 'മൊബൈൽ നമ്പറിൽ ലോഗിൻ ചെയ്യൂ';

  @override
  String get suRefresh => 'നില നോക്കൂ';

  @override
  String suResendIn(String n) {
    return '$n സെക്കൻഡിൽ വീണ്ടും അയയ്ക്കാം';
  }

  @override
  String get suAgreeLead => 'ഇവ ഞാൻ അംഗീകരിക്കുന്നു:';

  @override
  String get ngGreetMorning => 'സുപ്രഭാതം';

  @override
  String get ngGreetAfternoon => 'ശുഭ ഉച്ച';

  @override
  String get ngGreetEvening => 'ശുഭ സന്ധ്യ';

  @override
  String ngPlanName(String plan) {
    return '$plan പ്ലാൻ';
  }

  @override
  String get ngPlanActive => 'സജീവം';

  @override
  String get ngPlanTrial => 'ട്രയൽ';

  @override
  String get ngPlanEndingSoon => 'ഉടൻ തീരും';

  @override
  String get ngPlanEnded => 'അവസാനിച്ചു';

  @override
  String ngPlanTrialEnds(String date, int days) {
    return 'ട്രയൽ $date-ന് തീരും · $days ദിവസം ബാക്കി';
  }

  @override
  String ngPlanReadOnlyIn(int days) {
    return 'ട്രയൽ കഴിഞ്ഞു · $days ദിവസത്തിൽ കാണാൻ മാത്രം';
  }

  @override
  String get ngPlanReadOnly => 'ട്രയൽ കഴിഞ്ഞു · കാണാൻ മാത്രം';

  @override
  String get ngPlanNoExpiry => 'കാലാവധി തീയതിയില്ല';

  @override
  String get ngPlanSee => 'പ്ലാനുകൾ';

  @override
  String get ngPaymentsDue => 'കുടിശ്ശിക പേയ്മെന്റുകൾ';

  @override
  String ngPaymentsDueSub(int n) {
    return '$n ഓർഡറുകൾ പൂർണ്ണമായി അടച്ചിട്ടില്ല';
  }

  @override
  String get ngOverdueFollowUps => 'വൈകിയ ഫോളോ-അപ്പുകൾ';

  @override
  String get ngOverdueFollowUpsSub => 'ആദ്യം ഇവരെ വിളിക്കൂ';

  @override
  String get ngTodaysPlan => 'ഇന്നത്തെ പ്ലാൻ';

  @override
  String get ngNothingToday => 'ഇന്ന് ഒന്നും പ്ലാൻ ചെയ്തിട്ടില്ല';

  @override
  String get ngComingUp => 'വരാനിരിക്കുന്നവ';

  @override
  String ngAgendaMove(String name) {
    return 'ഷിഫ്റ്റിംഗ് · $name';
  }

  @override
  String get ngAllDay => 'ദിവസം മുഴുവൻ';

  @override
  String get ngPeriodThisMonth => 'ഈ മാസം';

  @override
  String get ngPeriodLastMonth => 'കഴിഞ്ഞ മാസം';

  @override
  String get ngPeriod3m => 'കഴിഞ്ഞ 3 മാസം';

  @override
  String get ngPeriodFy => 'ഈ സാമ്പത്തിക വർഷം';

  @override
  String get ngPeriodAll => 'എല്ലാ കാലവും';

  @override
  String get ngPickPeriod => 'ഈ കാലയളവിലെ കണക്കുകൾ';

  @override
  String get ngProfitTarget => 'ലാഭ ലക്ഷ്യം';

  @override
  String get ngSetTarget => 'മാസ ലാഭ ലക്ഷ്യം നിശ്ചയിക്കുക';

  @override
  String get ngSetTargetSub => 'എത്തേണ്ട തുക നിശ്ചയിക്കാൻ ടാപ്പ് ചെയ്യുക';

  @override
  String get ngProfit => 'ലാഭം';

  @override
  String ngProfitAfter(String labour, String expenses) {
    return 'കൂലി $labour, ചെലവ് $expenses കഴിഞ്ഞ്';
  }

  @override
  String get ngAddExpense => 'ചെലവ് ചേർക്കുക';

  @override
  String get ngSeeAll => 'എല്ലാം കാണുക';

  @override
  String get ngHotLeads => 'ഹോട്ട് ലീഡുകൾ';

  @override
  String get ngBranches => 'ശാഖകൾ';

  @override
  String ngOrdersN(int n) {
    return '$n ഓർഡറുകൾ';
  }

  @override
  String get ngTargetDone => 'ലക്ഷ്യം നേടി';

  @override
  String get ngNoProfitYet => 'ഈ കാലയളവിൽ ഇതുവരെ ലാഭമില്ല';

  @override
  String get ngEditTarget => 'മാസ ലാഭ ലക്ഷ്യം';

  @override
  String get ngQuote => 'ക്വട്ടേഷൻ';

  @override
  String get ngTabDone => 'പൂർത്തിയായവ';

  @override
  String get ngReceived => 'ലഭിച്ചവ';

  @override
  String ngDaysLate(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n ദിവസം വൈകി',
      one: '1 ദിവസം വൈകി',
    );
    return '$_temp0';
  }

  @override
  String get ngNoPaymentsYet => 'ഇതുവരെ പേയ്മെന്റുകൾ രേഖപ്പെടുത്തിയിട്ടില്ല';

  @override
  String get ngOpsTitle => 'ഓപ്പറേഷൻസ്';

  @override
  String get ngOpsNewTrip => 'പുതിയ ട്രിപ്പ്';

  @override
  String get ngOpsCrewsOut => 'ജോലിയിലുള്ള ടീം';

  @override
  String get ngOpsVehiclesFree => 'ഒഴിവുള്ള വാഹനങ്ങൾ';

  @override
  String get ngOpsAttention => 'ശ്രദ്ധിക്കേണ്ടവ';

  @override
  String ngOpsNoCrew(String name) {
    return 'ടീം ഇല്ല · $name';
  }

  @override
  String get ngOpsAssign => 'നിയോഗിക്കുക';

  @override
  String get ngOpsAssignCrew => 'ടീമിനെ നിയോഗിക്കുക';

  @override
  String ngOpsInsuranceExpires(int n) {
    return 'ഇൻഷുറൻസ് $n ദിവസത്തിൽ തീരും';
  }

  @override
  String get ngOpsInsuranceExpired => 'ഇൻഷുറൻസ് തീർന്നു';

  @override
  String ngOpsLowStock(String name) {
    return '$name കുറവാണ്';
  }

  @override
  String ngOpsStockLeft(String qty) {
    return '$qty ബാക്കി';
  }

  @override
  String get ngOpsReorder => 'വീണ്ടും ഓർഡർ';

  @override
  String get ngOpsView => 'കാണുക';

  @override
  String get ngOpsAwaiting => 'അംഗീകാരം കാത്തിരിക്കുന്നു';

  @override
  String get ngOpsJobs => 'ജോലികൾ';

  @override
  String get ngOpsNoJobs => 'ഈ ദിവസം ഷിഫ്റ്റിംഗ് ഇല്ല';

  @override
  String get ngOpsFleet => 'ഫ്ലീറ്റ്';

  @override
  String ngOpsFleetSummary(int free, int total) {
    return '$total-ൽ $free ഒഴിവ്';
  }

  @override
  String get ngOpsInService => 'സർവീസിൽ';

  @override
  String get ngOpsOnJob => 'ജോലിയിൽ';

  @override
  String get ngOpsFree => 'ഒഴിവ്';

  @override
  String ngExpCount(int n) {
    return '$n ചെലവുകൾ';
  }

  @override
  String ngExpVsLast(int pct) {
    return 'കഴിഞ്ഞ മാസത്തേക്കാൾ $pct%';
  }

  @override
  String get ngExpThisWeek => 'ഈ ആഴ്ച';

  @override
  String get ngExpOrderOnly => 'ഓർഡറുമായി ബന്ധപ്പെട്ടവ മാത്രം';

  @override
  String get ngExpNone => 'ഈ കാലയളവിൽ ചെലവുകളില്ല';

  @override
  String get ngExpUncategorised => 'വിഭാഗമില്ലാത്തവ';

  @override
  String get ngExpDelete => 'ചെലവ് നീക്കുക';

  @override
  String get ngExpByCategory => 'വിഭാഗം തിരിച്ച്';

  @override
  String get ngExpNoCat => 'ഇതുവരെ തരംതിരിക്കാൻ ഒന്നുമില്ല';

  @override
  String get ngExpNoCatSub => 'ചെലവ് രേഖപ്പെടുത്തിയാൽ വിഭാഗങ്ങൾ ഇവിടെ കാണാം.';

  @override
  String get ngFleetNew => 'പുതിയ വാഹനം';

  @override
  String get ngFleetActive => 'സജീവം';

  @override
  String get ngFleetMaintenance => 'അറ്റകുറ്റപ്പണി';

  @override
  String get ngFleetInactive => 'നിഷ്ക്രിയം';

  @override
  String get ngFleetNone =>
      'ഇതുവരെ വാഹനങ്ങളില്ല. രേഖകളും ട്രിപ്പുകളും നോക്കാൻ ഒന്ന് ചേർക്കുക.';

  @override
  String get ngFleetDelete => 'വാഹനം നീക്കുക';

  @override
  String get ngFleetInsurance => 'ഇൻഷുറൻസ്';

  @override
  String get ngFleetPermit => 'പെർമിറ്റ്';

  @override
  String ngFleetExpires(String doc, int n) {
    return '$doc $n ദിവസത്തിൽ തീരും';
  }

  @override
  String ngFleetExpired(String doc, int n) {
    return '$doc $n ദിവസം മുമ്പ് തീർന്നു';
  }

  @override
  String get ngMatNew => 'പുതിയ സാമഗ്രി';

  @override
  String get ngMatSearch => 'സാമഗ്രികൾ തിരയുക';

  @override
  String get ngMatReorderSoon => 'ഉടൻ ഓർഡർ ചെയ്യുക';

  @override
  String get ngMatReturnable => 'തിരികെ ലഭിക്കുന്നത്';

  @override
  String ngMatMin(String n) {
    return 'കുറഞ്ഞത് $n';
  }

  @override
  String get ngMatDelete => 'സാമഗ്രി നീക്കുക';

  @override
  String get ngMatNone => 'ഇതുവരെ സാമഗ്രികളില്ല';

  @override
  String get ngTripPlanned => 'ആസൂത്രിതം';

  @override
  String get ngTripOngoing => 'നടക്കുന്നു';

  @override
  String get ngTripNone => 'ഇതുവരെ ട്രിപ്പുകളില്ല';

  @override
  String get ngTripNoNumber => '(ട്രിപ്പ് നമ്പർ ഇല്ല)';

  @override
  String get ngTripHired => 'വാടക';

  @override
  String get ngTripOwn => 'സ്വന്തം';

  @override
  String get ngTripDelete => 'ട്രിപ്പ് നീക്കുക';

  @override
  String ngCustCount(int n) {
    return '$n ഉപഭോക്താക്കൾ';
  }

  @override
  String get ngCustNew => 'പുതിയത്';

  @override
  String get ngCustSearch => 'പേര്, ഫോൺ അല്ലെങ്കിൽ കമ്പനി തിരയുക';

  @override
  String get ngCustNone => 'ഉപഭോക്താക്കളെ കണ്ടെത്തിയില്ല';

  @override
  String ngCustDue(String amount) {
    return '$amount കുടിശ്ശിക';
  }

  @override
  String get ngStaffTitle => 'ജീവനക്കാർ';

  @override
  String ngStaffSummary(int n, int monthly, int other) {
    return '$n പേർ · $monthly മാസ · $other ദിവസ / താൽക്കാലിക';
  }

  @override
  String get ngStaffAdd => 'ജീവനക്കാരനെ ചേർക്കുക';

  @override
  String get ngStaffMonthly => 'സ്ഥിര മാസ';

  @override
  String get ngStaffDaily => 'ദിവസ';

  @override
  String get ngStaffTemporary => 'താൽക്കാലിക';

  @override
  String ngStaffJoined(String date) {
    return 'ചേർന്നത് $date';
  }

  @override
  String get ngStaffAllRoles => 'എല്ലാ റോളുകളും';

  @override
  String get ngStaffNone => 'ഇതുവരെ ജീവനക്കാരില്ല';

  @override
  String get ngStaffInactive => 'നിഷ്ക്രിയർ';

  @override
  String get ngSalTitle => 'ശമ്പളം';

  @override
  String get ngSalToPay => 'നൽകാനുള്ളത്';

  @override
  String get ngSalAdvances => 'അഡ്വാൻസ്';

  @override
  String get ngSalPaid => 'നൽകിയ ശമ്പളം';

  @override
  String get ngSalBalance => 'ബാക്കി';

  @override
  String ngSalJobs(int n) {
    return '$n ജോലികൾ';
  }

  @override
  String ngSalAdvance(String amount) {
    return 'അഡ്വാൻസ് $amount';
  }

  @override
  String get ngSalNote =>
      'ഈ മാസം ഓരോ ജോലിയിലും ചേർത്ത ടീമിൽ നിന്നാണ് വരുമാനം. പണം നൽകാനോ അഡ്വാൻസ് നൽകാനോ ആളെ തുറക്കുക.';

  @override
  String get ngSetApp => 'ആപ്പ്';

  @override
  String get ngSetLanguage => 'ഭാഷ';

  @override
  String get ngSetTheme => 'തീം';

  @override
  String get ngSetThemeLight => 'ലൈറ്റ്';

  @override
  String get ngSetThemeDark => 'ഡാർക്ക്';

  @override
  String get ngSetThemeMidnight => 'മിഡ്‌നൈറ്റ്';

  @override
  String get ngSetNotifications => 'അറിയിപ്പുകൾ';

  @override
  String get ngSetNotificationsSub =>
      'ആപ്പ് തുറന്നിരിക്കുമ്പോൾ അലേർട്ടുകൾ കാണിക്കുക';

  @override
  String get ngSetBusiness => 'ബിസിനസ്';

  @override
  String get ngSetBizDetails => 'ബിസിനസ് വിവരങ്ങൾ';

  @override
  String get ngSetBizDetailsSub =>
      'പേര്, ടാഗ്‌ലൈൻ, GST, വിലാസം, ലോഗോ, ഒപ്പ്, നിബന്ധനകൾ, നമ്പറിംഗ്';

  @override
  String get ngSetCft => 'CFT & പാക്കേജുകൾ';

  @override
  String get ngSetCftSub => 'സാധന വലിപ്പം, വീട് വലിപ്പം, സംഭരണ നിരക്ക്';

  @override
  String get ngSetSecurity => 'സുരക്ഷ';

  @override
  String get ngSetLogin => 'ലോഗിൻ & സുരക്ഷ';

  @override
  String get ngSetLoginSub => 'നിങ്ങളുടെ ആപ്പ് PIN';

  @override
  String get ngSetAccount => 'അക്കൗണ്ട് & പിന്തുണ';

  @override
  String get ngSetPlan => 'പ്ലാൻ & ബില്ലിംഗ്';

  @override
  String get ngSetPlanSub => 'നിങ്ങളുടെ പ്ലാനും പരിധികളും';

  @override
  String get ngSetRecycle => 'നീക്കിയവ';

  @override
  String get ngSetRecycleSub => 'അബദ്ധത്തിൽ നീക്കിയത് തിരികെ എടുക്കുക';

  @override
  String get ngSetHelp => 'സഹായം & പിന്തുണ';

  @override
  String get ngSetHelpSub => 'പിന്തുണ, സ്വകാര്യതാ നയം, നിബന്ധനകൾ';

  @override
  String get ngSetPorter => 'Porter സംയോജനം';

  @override
  String get ngSetPorterSub =>
      'ഡാഷ്ബോർഡിൽ Porter കമ്മീഷൻ കാണിക്കുക. നിങ്ങളുടെ ബിസിനസ് Porter ഉപയോഗിക്കുന്നെങ്കിൽ മാത്രം ഓണാക്കുക.';

  @override
  String odStageOf(int n, int total, String name) {
    return 'ഘട്ടം $n / $total · $name';
  }

  @override
  String get odJourneyDone => 'എല്ലാ ഘട്ടങ്ങളും പൂർത്തിയായി';

  @override
  String get odMaps => 'മാപ്പ്';

  @override
  String get odProgress => 'പുരോഗതി';

  @override
  String get odInProgress => 'നടക്കുന്നു';

  @override
  String odMarkAs(String stage) {
    return '$stage ആയി അടയാളപ്പെടുത്തുക';
  }

  @override
  String get odDeliveredHint =>
      'ഉപഭോക്താവിന്റെ കോഡ് ഉപയോഗിച്ച് ജീവനക്കാർ ജോലി തീർക്കുമ്പോൾ ഡെലിവറി രേഖപ്പെടുത്തും.';

  @override
  String get odOpenFieldJob => 'ഫീൽഡ് ജോലി തുറക്കുക';

  @override
  String get odCrewVehicle => 'ജീവനക്കാർ & വാഹനം';

  @override
  String get odNoCrew => 'ഇതുവരെ ജീവനക്കാരെ നിയോഗിച്ചിട്ടില്ല';

  @override
  String get odNoVehicle => 'വാഹനം നിയോഗിച്ചിട്ടില്ല';

  @override
  String odSupervisorCrew(String name, int count) {
    return 'സൂപ്പർവൈസർ · $name · $count പേർ';
  }

  @override
  String odCrewCount(int count) {
    return '$count പേർ';
  }

  @override
  String get odPayment => 'പേയ്‌മെന്റ്';

  @override
  String get odTotal => 'ആകെ';

  @override
  String get odPaid => 'അടച്ചത്';

  @override
  String get odBalance => 'ബാക്കി';

  @override
  String get odPartPaid => 'ഭാഗികമായി അടച്ചു';

  @override
  String get odFullyPaid => 'അടച്ചു';

  @override
  String get odUnpaid => 'അടച്ചിട്ടില്ല';

  @override
  String get odRemind => 'ഓർമ്മിപ്പിക്കുക';

  @override
  String get odRecordPayment => 'പേയ്‌മെന്റ് രേഖപ്പെടുത്തുക';

  @override
  String get odActivity => 'പ്രവർത്തനം';

  @override
  String odAllN(int count) {
    return 'എല്ലാം $count';
  }

  @override
  String get odStageChanged => 'ഘട്ടം മാറി';

  @override
  String odPaymentReceived(String amount) {
    return 'പേയ്‌മെന്റ് ലഭിച്ചു · $amount';
  }

  @override
  String get odNoActivity => 'ഈ ഓർഡറിൽ ഇതുവരെ ഒന്നും രേഖപ്പെടുത്തിയിട്ടില്ല.';

  @override
  String get odMoveDetails => 'നീക്കത്തിന്റെ വിവരങ്ങൾ';

  @override
  String get odCancelled => 'റദ്ദാക്കി';

  @override
  String get odMore => 'കൂടുതൽ പ്രവർത്തനങ്ങൾ';

  @override
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor) {
    return 'Hi $customer, a balance of $amount is due for your move ($orderId). Thank you, $vendor';
  }

  @override
  String get odStConfirmed => 'സ്ഥിരീകരിച്ചു';

  @override
  String get odStPacking => 'പാക്കിംഗ്';

  @override
  String get odStInTransit => 'യാത്രയിൽ';

  @override
  String get odStArrived => 'എത്തി';

  @override
  String get odStDelivered => 'എത്തിച്ചു';

  @override
  String get odStCompleted => 'പൂർത്തിയായി';

  @override
  String get nlPhone => 'ഫോൺ';

  @override
  String get nlName => 'പേര്';

  @override
  String get nlRoute => 'റൂട്ട്';

  @override
  String get nlMovingFrom => 'എവിടെ നിന്ന്';

  @override
  String get nlMovingTo => 'എവിടേക്ക്';

  @override
  String get nlService => 'സേവനം';

  @override
  String get nlWhen => 'എപ്പോൾ';

  @override
  String get nlToday => 'ഇന്ന്';

  @override
  String get nlTomorrow => 'നാളെ';

  @override
  String get nlPickDate => 'തീയതി തിരഞ്ഞെടുക്കുക';

  @override
  String get nlSource => 'ഉറവിടം';

  @override
  String get nlBranch => 'ബ്രാഞ്ച്';

  @override
  String get nlNextStep => 'അടുത്ത ഘട്ടം';

  @override
  String get nlStepFollow => 'ഫോളോ-അപ്പ്';

  @override
  String get nlStepFollowSub => 'പിന്നീട് വീണ്ടും വിളിക്കുക';

  @override
  String get nlStepSurvey => 'സർവേ';

  @override
  String get nlStepSurveySub => 'സന്ദർശനം, ലിങ്ക് അല്ലെങ്കിൽ കോളിൽ';

  @override
  String get nlStepQuote => 'സർവേ ഒഴിവാക്കുക · ക്വോട്ട്';

  @override
  String get nlStepQuoteSub => 'ഈ കോളിൽ തന്നെ വില';

  @override
  String get nlStepConfirm => 'ഓർഡർ സ്ഥിരീകരിക്കുക';

  @override
  String get nlStepConfirmSub => 'ഉപഭോക്താവ് സമ്മതിച്ചു';

  @override
  String get nlMore => 'കൂടുതൽ വിവരങ്ങൾ';

  @override
  String get nlEmail => 'ഇമെയിൽ (ഐച്ഛികം)';

  @override
  String get nlNotes => 'കുറിപ്പുകൾ';

  @override
  String get nlNameRequired => 'ഉപഭോക്താവിന്റെ പേര് നൽകുക.';

  @override
  String get nlNoBranches =>
      'ലീഡ് സേവ് ചെയ്യുന്നതിന് മുമ്പ് സെറ്റിംഗ്സിൽ ബ്രാഞ്ച് ചേർക്കുക.';

  @override
  String get nlUpdateLead => 'ലീഡ് അപ്ഡേറ്റ് ചെയ്യുക';

  @override
  String get noPickup => 'പിക്കപ്പ്';

  @override
  String get noDrop => 'ഡ്രോപ്പ്';

  @override
  String get noPricing => 'വില & ഉറവിടം';

  @override
  String get ngSetFy => 'സാമ്പത്തിക വർഷം & നമ്പറിംഗ്';

  @override
  String get ngSetFySub => 'അടുത്ത വർഷത്തെ ബിൽ നമ്പറുകൾ ആരംഭിക്കുക';

  @override
  String get ngSetWa => 'WhatsApp';

  @override
  String get ngSetWaSub =>
      'നിങ്ങളുടെ സ്വന്തം നമ്പറിൽ നിന്ന് സന്ദേശങ്ങൾ അയയ്ക്കുക';

  @override
  String get ngSetAutoWa => 'ഓട്ടോ WhatsApp';

  @override
  String get ngSetAutoWaSub =>
      'ഓരോ ഘട്ടത്തിലും ഉപഭോക്താവിന് അയയ്ക്കുന്ന സന്ദേശങ്ങൾ';

  @override
  String get mdTitle => 'മൊഡ്യൂളുകൾ';

  @override
  String get mdSettingsSub => 'പാക്കേഴ്സ് & മൂവേഴ്സ്, ഗതാഗതം അല്ലെങ്കിൽ രണ്ടും';

  @override
  String get mdType => 'നിങ്ങളുടെ ബിസിനസ്';

  @override
  String get mdAdv => 'അഡ്വാൻസ്ഡ്';

  @override
  String mdCount(int count, int total) {
    return '$total-ൽ $count മൊഡ്യൂളുകൾ ഓൺ';
  }

  @override
  String mdGroupOn(int count, int total) {
    return '$total-ൽ $count ഓൺ';
  }

  @override
  String get mdNote =>
      'ഓഫ് ചെയ്ത മൊഡ്യൂളുകൾ മെനുവിൽ നിന്ന് മറയും. നിങ്ങളുടെ ഡാറ്റ സൂക്ഷിച്ചിരിക്കും, വീണ്ടും ഓൺ ചെയ്താൽ തിരികെ വരും.';

  @override
  String get mdReset => 'ഈ ബിസിനസിന് ശുപാർശ ചെയ്തതിലേക്ക് റീസെറ്റ് ചെയ്യുക';

  @override
  String mdResetDone(String type) {
    return '$type-നായി മൊഡ്യൂളുകൾ റീസെറ്റ് ചെയ്തു';
  }

  @override
  String mdTypeSet(String type) {
    return '$type തിരഞ്ഞെടുത്തു · മെനു പുതുക്കി';
  }

  @override
  String get mdOwnerOnly => 'ഉടമയ്ക്ക് മാത്രമേ മൊഡ്യൂളുകൾ മാറ്റാനാകൂ';

  @override
  String get mdSaveFailed =>
      'സേവ് ചെയ്യാനായില്ല. കണക്ഷൻ പരിശോധിച്ച് വീണ്ടും ശ്രമിക്കുക.';

  @override
  String get btPm => 'പാക്കേഴ്സ് & മൂവേഴ്സ്';

  @override
  String get btPmS => 'വീട്, ഓഫീസ്, വാഹന ഷിഫ്റ്റിംഗ്';

  @override
  String get btTr => 'ഗതാഗതം / ലോജിസ്റ്റിക്സ്';

  @override
  String get btTrS => 'ലോറികൾ, ട്രിപ്പുകൾ, ചരക്ക്, ഡ്രൈവർമാർ';

  @override
  String get btBoth => 'രണ്ടും';

  @override
  String get btBothS => 'ഷിഫ്റ്റിംഗും ഗതാഗതവും, എല്ലാം ഓൺ';

  @override
  String get btTitle => 'നിങ്ങളുടെ ബിസിനസ് എന്ത് ചെയ്യുന്നു?';

  @override
  String get btSub =>
      'ആവശ്യമുള്ള മൊഡ്യൂളുകൾ മാത്രം കാണിക്കും. സെറ്റിംഗ്സ് › മൊഡ്യൂളുകളിൽ എപ്പോഴും മാറ്റാം.';

  @override
  String get btLater => 'പിന്നീട് സെറ്റിംഗ്സ് › മൊഡ്യൂളുകളിൽ മാറ്റാം';

  @override
  String get dwTitle => 'വിജറ്റുകൾ';

  @override
  String get dwSub => 'ഉടമയുടെ ഡാഷ്ബോർഡിൽ എന്ത് കാണിക്കണം';

  @override
  String get dwNote =>
      'ഉടമയുടെ ഡാഷ്ബോർഡിൽ ഈ ക്രമത്തിൽ കാണിക്കും. അമ്പ് കൊണ്ട് മുകളിലേക്ക്, സ്വിച്ച് കൊണ്ട് മറയ്ക്കുക.';

  @override
  String dwShown(int n) {
    return 'കാണിക്കുന്നു · സ്ഥാനം $n';
  }

  @override
  String get dwHidden => 'മറച്ചു';

  @override
  String get dwUp => 'മുകളിലേക്ക്';

  @override
  String get dwToday => 'ഇന്നത്തെ കണക്കുകൾ';

  @override
  String get dwFleet => 'വാഹന നില';

  @override
  String dwFleetSub(int a, int s) {
    return '$a സജീവം · $s സർവീസിൽ';
  }

  @override
  String get dwAttendance => 'സ്റ്റാഫ് ഹാജർ';

  @override
  String get dwAttendanceSub => 'ഇന്ന് ചെക്ക്-ഇൻ';

  @override
  String get dwSaveFailed =>
      'സേവ് ചെയ്യാനായില്ല. കണക്ഷൻ പരിശോധിച്ച് വീണ്ടും ശ്രമിക്കുക.';

  @override
  String get jrShareInvoice => 'ബിൽ അയയ്ക്കുക';

  @override
  String get jrSendForSignature => 'ഒപ്പിനായി അയയ്ക്കുക';

  @override
  String get lsTitle => 'ലോഗിൻ & സുരക്ഷ';

  @override
  String get lsMy => 'നിങ്ങളുടെ ലോഗിൻ';

  @override
  String get lsMyEmail => 'ലോഗിൻ ഇമെയിൽ';

  @override
  String get lsChangePw => 'പാസ്‌വേഡ് മാറ്റുക';

  @override
  String get lsCurPw => 'നിലവിലെ പാസ്‌വേഡ്';

  @override
  String get lsNewPw => 'പുതിയ പാസ്‌വേഡ്';

  @override
  String get lsConfPw => 'പുതിയ പാസ്‌വേഡ് സ്ഥിരീകരിക്കുക';

  @override
  String get lsPwSub => 'കുറഞ്ഞത് 8 അക്ഷരങ്ങൾ';

  @override
  String get lsPwShort => 'പാസ്‌വേഡ് കുറഞ്ഞത് 8 അക്ഷരം വേണം';

  @override
  String get lsPwMismatch => 'പാസ്‌വേഡുകൾ ചേരുന്നില്ല';

  @override
  String get lsPwCurReq => 'നിലവിലെ പാസ്‌വേഡ് നൽകുക';

  @override
  String get lsPwDone => 'പാസ്‌വേഡ് മാറ്റി';

  @override
  String get lsUpdatePw => 'പാസ്‌വേഡ് അപ്ഡേറ്റ്';

  @override
  String get lsForgot =>
      'പാസ്‌വേഡ് മറന്നോ? ലോഗിൻ സ്ക്രീനിൽ \"പാസ്‌വേഡ് മറന്നോ?\" അമർത്തുക. റീസെറ്റ് ലിങ്ക് ഇമെയിൽ ചെയ്യും.';

  @override
  String get lsStaffPins => 'ജീവനക്കാരുടെ PIN';

  @override
  String get lsStaffPinsSub =>
      'ജീവനക്കാരും സൂപ്പർവൈസർമാരും PIN ഉപയോഗിച്ച് ലോഗിൻ ചെയ്യുന്നു. മറന്നാൽ പുതിയ PIN സജ്ജമാക്കുക. ആവർത്തിച്ച് തെറ്റായ PIN നൽകിയാൽ, നിങ്ങൾ റീസെറ്റ് ചെയ്യുന്നതുവരെ PIN ലോക്ക് ആകും.';

  @override
  String get lsResetPin => 'PIN റീസെറ്റ്';

  @override
  String get lsPinSet => 'PIN സജ്ജമാക്കിയത്';

  @override
  String lsLocked(int n) {
    return 'ലോക്ക് · $n തെറ്റ്';
  }

  @override
  String get lsNewPin => 'പുതിയ PIN';

  @override
  String get lsConfPin => 'PIN സ്ഥിരീകരിക്കുക';

  @override
  String get lsPinBad => 'PIN 4 അക്കം വേണം';

  @override
  String get lsPinMismatch => 'PIN ചേരുന്നില്ല';

  @override
  String lsPinSetFor(String name) {
    return 'പുതിയ PIN സജ്ജമാക്കി: $name';
  }

  @override
  String get lsTellStaff =>
      'പുതിയ PIN നേരിട്ടോ ഫോണിലോ പറയുക. ഇത് വീണ്ടും കാണിക്കില്ല.';

  @override
  String get lsSetPin => 'പുതിയ PIN സജ്ജമാക്കുക';

  @override
  String get lsSignOutAll => 'മറ്റ് എല്ലാ ഉപകരണങ്ങളിൽ നിന്നും സൈൻ ഔട്ട്';

  @override
  String get lsAllOut => 'മറ്റ് എല്ലാ ഉപകരണങ്ങളും സൈൻ ഔട്ട് ചെയ്തു';

  @override
  String get lsNoPin => 'ഇതുവരെ PIN ഇല്ല';

  @override
  String get lsOwnerOnly => 'സ്റ്റാഫ് PIN ഉടമയ്ക്ക് മാത്രമേ മാറ്റാനാകൂ.';

  @override
  String get qdTitle => 'ക്വോട്ട് ഡിസൈൻ';

  @override
  String get qdSub => 'നിങ്ങളുടെ ക്വട്ടേഷൻ PDF ഉപഭോക്താക്കൾക്ക് എങ്ങനെ കാണും.';

  @override
  String get qdTheme => 'തീം';

  @override
  String get qdColor => 'ബ്രാൻഡ് നിറം';

  @override
  String get qdLogo => 'ലോഗോ';

  @override
  String get qdLogoAdd => 'ലോഗോ അപ്‌ലോഡ്';

  @override
  String get qdLogoHint => 'PNG അല്ലെങ്കിൽ JPG, സമചതുരം നല്ലത്';

  @override
  String get qdSave => 'ഡിസൈൻ സേവ്';

  @override
  String get qdPreview => 'സാമ്പിൾ PDF കാണുക';

  @override
  String get qdSaved => 'ക്വോട്ട് ഡിസൈൻ സേവ് ചെയ്തു';

  @override
  String get qdTheme1A => 'ക്ലാസിക്';

  @override
  String get qdTheme1B => 'ബോൾഡ് ബാൻഡ്';

  @override
  String get qdTheme1C => 'സൈഡ്‌ബാർ';

  @override
  String get qdTheme1D => 'മിനിമൽ';

  @override
  String get qdTheme1E => 'കോർപ്പറേറ്റ്';

  @override
  String get qdTheme1F => 'ലെറ്റർഹെഡ്';

  @override
  String get qdThemeDesc1A => 'സെരിഫ്, വരകൾ';

  @override
  String get qdThemeDesc1B => 'നിറമുള്ള ഹെഡർ, ഉരുണ്ട പാനലുകൾ';

  @override
  String get qdThemeDesc1C => 'ഇടതുവശത്ത് വിവര കോളം';

  @override
  String get qdThemeDesc1D => 'കറുപ്പും വെളുപ്പും, എവിടെയും പ്രിന്റ്';

  @override
  String get qdThemeDesc1E => 'ബോക്സ് ഫോം, ഓഫീസ് ഷിഫ്റ്റിംഗിന്';

  @override
  String get qdThemeDesc1F => 'നടുവിൽ, ഇരട്ട വര';

  @override
  String get drvTitle => 'ഡ്രൈവർ ആപ്പ്';

  @override
  String get drvNone => 'ഇന്ന് ട്രിപ്പില്ല';

  @override
  String get drvPlanned => 'പ്ലാൻ';

  @override
  String get drvOngoing => 'ട്രിപ്പിൽ';

  @override
  String get drvStart => 'ട്രിപ്പ് തുടങ്ങുക';

  @override
  String get drvEnd => 'ട്രിപ്പ് അവസാനിപ്പിക്കുക';

  @override
  String get drvDone => 'ട്രിപ്പ് പൂർത്തി';

  @override
  String get drvFuel => 'ഇന്ധനം';

  @override
  String get drvFuelT => 'ഇന്ധനം ചേർക്കുക';

  @override
  String get drvToll => 'ടോൾ';

  @override
  String get drvTollT => 'ടോൾ ചേർക്കുക';

  @override
  String get drvLitres => 'ലിറ്റർ';

  @override
  String get drvPlaza => 'പ്ലാസ';

  @override
  String get drvAdd => 'എൻട്രി ചേർക്കുക';

  @override
  String get drvNeedStart => 'തുടക്ക ഓഡോമീറ്റർ നൽകുക';

  @override
  String get drvNeedEnd => 'അവസാന ഓഡോമീറ്റർ തുടക്കത്തേക്കാൾ കൂടുതലാകണം';

  @override
  String get drvNeedAmount => 'തുക നൽകുക';

  @override
  String get drvTripKm => 'ട്രിപ്പ് കിമീ';

  @override
  String get drvTripSpend => 'ട്രിപ്പ് ചെലവ്';

  @override
  String get drvToday => 'ഇന്നത്തെ എൻട്രികൾ';

  @override
  String get drvOdoStart => 'തുടക്ക ഓഡോമീറ്റർ';

  @override
  String get drvOdoEnd => 'അവസാന ഓഡോമീറ്റർ';

  @override
  String get mktTitle => 'Nagarva ജോലികൾ';

  @override
  String get mktSub => 'Nagarva-യിൽ ഉപഭോക്താക്കൾ ബുക്ക് ചെയ്ത ഷിഫ്റ്റിംഗുകൾ';

  @override
  String get mktTier => 'നിങ്ങളുടെ ടിയർ';

  @override
  String get mktWallet => 'വാലറ്റ്';

  @override
  String mktMinL(String m) {
    return 'ജോലി ലഭിക്കാൻ കുറഞ്ഞത് $m';
  }

  @override
  String get mktLowS => 'കുറഞ്ഞതിലും താഴെ';

  @override
  String get mktTJobs => 'ജോലികൾ';

  @override
  String get mktTWallet => 'വാലറ്റ്';

  @override
  String get mktTTier => 'ടിയർ';

  @override
  String get mktAv => 'ജോലിക്ക് ലഭ്യം';

  @override
  String mktAvOn(String c) {
    return '$c ജോബ് അലേർട്ടുകൾ ലഭിക്കുന്നു';
  }

  @override
  String get mktAvOff =>
      'ഓഫ്. പുതിയ ജോബ് അലേർട്ടുകളില്ല. സ്കോറിനെ ബാധിക്കില്ല.';

  @override
  String get mktCities => 'പിക്കപ്പ് നഗരങ്ങൾ';

  @override
  String get mktCitiesN =>
      'ഈ നഗരങ്ങളിൽ തുടങ്ങുന്ന ബുക്കിംഗുകൾക്ക് അലേർട്ട് ലഭിക്കും. സ്വന്തം നഗരം നീക്കാനാവില്ല.';

  @override
  String get mktEdit => 'മാറ്റുക';

  @override
  String get mktDone2 => 'കഴിഞ്ഞു';

  @override
  String get mktCancel => 'റദ്ദാക്കുക';

  @override
  String get mktHome => 'സ്വന്തം';

  @override
  String get mktRtAsk => 'വാഹനം മറ്റൊരു നഗരത്തിലാണോ?';

  @override
  String get mktRtAdd => 'ചേർക്കുക';

  @override
  String get mktRtEnd => 'അവസാനിപ്പിക്കുക';

  @override
  String get mktRtFrom => 'വാഹനം ഇപ്പോൾ';

  @override
  String get mktRtDate => 'പുറപ്പെടുന്ന ദിവസം';

  @override
  String mktRtOn(String f, String t) {
    return 'റിട്ടേൺ ട്രിപ്പ് · $f → $t';
  }

  @override
  String get mktRtEnded => 'റിട്ടേൺ ട്രിപ്പ് അവസാനിച്ചു';

  @override
  String get mktFNew => 'പുതിയവ';

  @override
  String get mktFAcc => 'സ്വീകരിച്ചവ';

  @override
  String get mktFDone => 'പൂർത്തിയായവ';

  @override
  String get mktENew => 'ഇപ്പോൾ പുതിയ ജോലികളില്ല. വരുമ്പോൾ അറിയിപ്പ് ലഭിക്കും.';

  @override
  String get mktEAcc => 'സ്വീകരിച്ച ജോലികളില്ല.';

  @override
  String get mktEDone => 'ഇതുവരെ പൂർത്തിയായ ജോലികളില്ല.';

  @override
  String get mktEOff => 'നിങ്ങൾ ലഭ്യമല്ല. പുതിയ ബുക്കിംഗുകൾ കാണാൻ ഓൺ ചെയ്യുക.';

  @override
  String mktLow(String a, String m) {
    return 'വാലറ്റ് $m-ൽ താഴെയാണ്. പുതിയ ജോലികൾ കാണാൻ $a ടോപ്പ്-അപ്പ് ചെയ്യുക.';
  }

  @override
  String get mktVal => 'ജോലി മൂല്യം (GST ഉൾപ്പെടെ)';

  @override
  String mktCom(String p) {
    return 'Nagarva കമ്മീഷൻ $p%';
  }

  @override
  String get mktEarn => 'നിങ്ങളുടെ വരുമാനം';

  @override
  String get mktAdv => 'Nagarva-യ്ക്ക് നൽകിയ അഡ്വാൻസ്';

  @override
  String get mktBal => 'ഡെലിവറി OTP-ക്ക് ശേഷം വാങ്ങുക';

  @override
  String get mktMasked => 'സ്വീകരിച്ച ശേഷം ഉപഭോക്താവിന്റെ പേരും ഫോണും കാണാം';

  @override
  String get mktPass => 'ഒഴിവാക്കുക';

  @override
  String get mktAccept => 'ജോലി സ്വീകരിക്കുക';

  @override
  String mktAccepted(String id) {
    return '$id നിങ്ങളുടേതാണ്. ഉപഭോക്തൃ വിവരങ്ങൾ തുറന്നു.';
  }

  @override
  String get mktPassed => 'ജോലി ഒഴിവാക്കി';

  @override
  String get mktTaken => 'മറ്റൊരു വെൻഡർ എടുത്തു';

  @override
  String get mktGoldOnly => 'ഗോൾഡ് മാത്രം';

  @override
  String get mktRl => 'റിട്ടേൺ ലോഡ്';

  @override
  String get mktS0 => 'സ്വീകരിച്ചു';

  @override
  String get mktS1 => 'വഴിയിൽ';

  @override
  String get mktS2 => 'എത്തി';

  @override
  String get mktS3 => 'ലോഡിംഗ്';

  @override
  String get mktS4 => 'യാത്രയിൽ';

  @override
  String get mktS5 => 'ഡെലിവർ ചെയ്തു';

  @override
  String mktNext(String s) {
    return '$s എന്ന് അടയാളപ്പെടുത്തുക';
  }

  @override
  String mktPhotos(int n) {
    return 'ലോഡിംഗ് ഫോട്ടോകൾ $n/3';
  }

  @override
  String get mktNeedPh => 'ആദ്യം 3 ലോഡിംഗ് ഫോട്ടോകൾ ചേർക്കുക';

  @override
  String get mktAddPh => 'ഫോട്ടോ ചേർക്കുക';

  @override
  String get mktFinish => 'OTP പരിശോധിച്ച് പൂർത്തിയാക്കുക';

  @override
  String get mktOtpBad => 'തെറ്റായ OTP. ഉപഭോക്താവുമായി ഉറപ്പാക്കുക.';

  @override
  String mktDone(String a, String c) {
    return 'പൂർത്തിയായി. $c കമ്മീഷൻ കുറച്ചു, $a അഡ്വാൻസ് ക്രെഡിറ്റ് ചെയ്തു.';
  }

  @override
  String mktRate(String r) {
    return 'ഉപഭോക്തൃ റേറ്റിംഗ് $r';
  }

  @override
  String get mktNoRate => 'ഉപഭോക്തൃ റേറ്റിംഗ് കാത്തിരിക്കുന്നു';

  @override
  String get mktTopup => 'ടോപ്പ്-അപ്പ്';

  @override
  String get mktWBal => 'വാലറ്റ് ബാലൻസ്';

  @override
  String get mktWOk => 'സജീവം · പുതിയ ജോലികൾ ലഭിക്കും';

  @override
  String get mktWWithdraw => 'പിൻവലിക്കുക';

  @override
  String mktWNote(String p) {
    return 'ഉപഭോക്താക്കൾ അഡ്വാൻസ് Nagarva-യ്ക്ക് നൽകുന്നു. ജോലി പൂർത്തിയാകുമ്പോൾ അഡ്വാൻസ് ഇവിടെ ക്രെഡിറ്റ് ചെയ്യുകയും $p% കമ്മീഷൻ കുറയ്ക്കുകയും ചെയ്യും. ജോലി ലഭിക്കാൻ കുറഞ്ഞ ബാലൻസ് നിലനിർത്തുക.';
  }

  @override
  String mktWtAdv(String id) {
    return 'അഡ്വാൻസ് · $id';
  }

  @override
  String mktWtCom(String id) {
    return 'കമ്മീഷൻ · $id';
  }

  @override
  String get mktWtTop => 'UPI ടോപ്പ്-അപ്പ്';

  @override
  String get mktWtWd => 'ബാങ്കിലേക്ക് പിൻവലിക്കൽ';

  @override
  String get mktTierF => 'നിങ്ങളുടെ സ്കോർ എങ്ങനെ';

  @override
  String get mktTierBands => 'ഗോൾഡ് 80+ · സിൽവർ 60–79 · ബ്രോൺസ് <60';

  @override
  String get mktTierGold => 'ഗോൾഡ്';

  @override
  String get mktTierSilver => 'സിൽവർ';

  @override
  String get mktTierBronze => 'ബ്രോൺസ്';

  @override
  String mktTierScore(String s) {
    return 'സ്കോർ $s / 100';
  }

  @override
  String get mktOtpAsk => 'ഉപഭോക്താവിനോട് 4 അക്ക ഡെലിവറി കോഡ് ചോദിക്കുക.';

  @override
  String get mktReqSent =>
      'അഭ്യർത്ഥന അയച്ചു. Nagarva പണം സ്ഥിരീകരിച്ചാൽ കണക്കിൽ വരും.';

  @override
  String get mktPending => 'തീർപ്പാകാത്തത്';

  @override
  String get mktHomeCity => 'ഹോം നഗരം';

  @override
  String get mktExtraCities => 'മറ്റ് നഗരങ്ങൾ, കോമ ഇട്ട് വേർതിരിക്കുക';

  @override
  String get mktNotJoined =>
      'Nagarva ജോലികൾ ലഭിക്കാൻ നിങ്ങളുടെ ഹോം നഗരം സജ്ജമാക്കുക.';

  @override
  String get mktFactorNote =>
      'Nagarva നിങ്ങളുടെ സ്കോർ ഇവയിൽ നിന്ന്, ഈ വെയ്റ്റുകളോടെ കണക്കാക്കുന്നു.';

  @override
  String get mktFRating => 'ഉപഭോക്തൃ റേറ്റിംഗ്';

  @override
  String get mktFOnTime => 'കൃത്യസമയത്ത് എത്തൽ';

  @override
  String get mktFDamage => 'നാശനഷ്ട ക്ലെയിമുകൾ';

  @override
  String get mktFAccept => 'സ്വീകരണ നിരക്ക്';

  @override
  String get mktFPhotos => 'ഫോട്ടോ പാലനം';

  @override
  String get mktFCancel => 'വെണ്ടർ റദ്ദാക്കലുകൾ';

  @override
  String get mktFJobs => 'പൂർത്തിയാക്കിയ ജോലികൾ';

  @override
  String get mktAvOnT => 'ജോബ് അലേർട്ടുകൾ വീണ്ടും ലഭിക്കും';

  @override
  String get mktAvOffT => 'ജോബ് അലേർട്ടുകൾ നിർത്തി';
}
