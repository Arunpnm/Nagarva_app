import 'package:flutter/material.dart';
import '/flutter_flow/custom_functions.dart' as functions;

import '/backend/pricing_defaults.dart';
import '/backend/storage_billing.dart';
import '/backend/supabase/org_scope.dart';
import '/backend/supabase/supabase.dart';
import '/components/ng_widgets.dart';
import '/flutter_flow/ng_tokens.dart';

/// Warehouse storage, as a revenue line ON THE ORDER.
///
/// Storage is not a separate order (brief §37): the same goods flow
/// move-in → stored → move-out, so the inbound job, the storage period
/// and the outbound delivery stay on one record.
///
/// Two states:
///  * **no stay** — offer "Move into warehouse"
///  * **in storage** — show the ACCRUING charge (§41: storage accrues, it
///    is not a single bill raised at booking) and offer release
///  * **closed** — show the settled charge
///
/// The rate is SNAPSHOTTED onto the record at booking and never re-read
/// from a rate card (§44), so a later price revision cannot re-bill goods
/// already in store. That is why the booking sheet lets the vendor edit
/// the pre-filled rate: what they agree with this customer today is what
/// this stay bills, forever.
class OrderStorageSection extends StatefulWidget {
  const OrderStorageSection({
    super.key,
    required this.orderId,
    this.orderCft,
    this.onChanged,
  });

  final String orderId;

  /// Goods volume from the order/quote, used to pre-fill the stay.
  final double? orderCft;

  final VoidCallback? onChanged;

  @override
  State<OrderStorageSection> createState() => OrderStorageSectionState();
}

class OrderStorageSectionState extends State<OrderStorageSection> {
  StorageJobsRow? _job;
  WarehousesRow? _warehouse;
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    reload();
  }

  Future<void> reload() async {
    if (!mounted) return;
    setState(() => _loading = true);
    try {
      final jobs = await StorageJobsTable().queryRows(
        queryFn: (q) => OrgScope.read(q).eq('order_id', widget.orderId),
        limit: 1,
      );
      WarehousesRow? wh;
      if (jobs.isNotEmpty && (jobs.first.warehouseId ?? '').isNotEmpty) {
        final whs = await WarehousesTable().queryRows(
          queryFn: (q) => OrgScope.read(q).eq('id', jobs.first.warehouseId!),
          limit: 1,
        );
        if (whs.isNotEmpty) wh = whs.first;
      }
      if (!mounted) return;
      setState(() {
        _job = jobs.isEmpty ? null : jobs.first;
        _warehouse = wh;
        _loading = false;
      });
    } catch (_) {
      // A storage card that fails to load must not blank the order screen.
      if (mounted) setState(() => _loading = false);
    }
  }

  StorageCharge? get _charge {
    final j = _job;
    if (j == null || j.inDate == null) return null;
    return computeStorageCharge(
      inDate: j.inDate!,
      outDate: j.outDate,
      mode: storageBillingModeFromWire(j.billingMode),
      rate: j.rate,
      minBillingDays: j.minBillingDays,
      handlingIn: j.handlingInCharge,
      handlingOut: j.handlingOutCharge,
      // A custom arrangement stores the agreed amount in `rate`.
      customAmount: j.rate,
    );
  }

  Future<void> _book() async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: NgPalette.of(context).sheet,
      shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(NgRadius.sheet))),
      builder: (_) => _StorageBookingSheet(
        orderId: widget.orderId,
        orderCft: widget.orderCft,
      ),
    );
    if (saved == true) {
      await reload();
      widget.onChanged?.call();
    }
  }

  Future<void> _release() async {
    final j = _job;
    if (j == null || j.id == null) return;
    // A stay that already has an out-date is settled. The button is hidden
    // in that state, but the guard is what actually protects the charge -
    // a double tap, a stale card or a second device must not be able to
    // re-close it and move the figure.
    if (j.outDate != null || j.status == 'closed') {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('These goods have already been released.')));
      }
      return;
    }
    final c = _charge;
    final ng = NgPalette.of(context);

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Release goods from storage?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'This closes the stay today and fixes the storage charge. '
              'The goods can then be delivered out.',
              style: NgFonts.geist(fontSize: 14),
            ),
            if (c != null) ...[
              const SizedBox(height: 10),
              Text(
                'Final storage charge: ₹${c.total.toStringAsFixed(0)}'
                '  (${c.billedUnits} ${c.unitLabel})',
                style: NgFonts.geist(fontSize: 14, 
                    fontWeight: FontWeight.w600),
              ),
              if (c.minimumApplied)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    'Includes the ${j.minBillingDays}-day minimum — the goods '
                    'were in store ${c.days} ${c.days == 1 ? 'day' : 'days'}.',
                    style: NgFonts.geist(fontSize: 12.5, 
                        color: ng.mute),
                  ),
                ),
              if (storageBillingModeFromWire(j.billingMode) ==
                  StorageBillingMode.perMonth)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    'Monthly plan — the full month is charged even on early '
                    'collection. This was disclosed at booking.',
                    style: NgFonts.geist(fontSize: 12.5, 
                        color: ng.mute),
                  ),
                ),
            ],
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Release')),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _busy = true);
    try {
      final today = DateTime.now();
      await StorageJobsTable().update(
        data: {
          'out_date':
              DateTime(today.year, today.month, today.day).toIso8601String(),
          'status': 'closed',
        },
        matchingRows: (q) => OrgScope.write(q).eq('id', j.id!),
      );
      // Re-read rather than patching the cached row: the settled charge is
      // computed from what the DB now holds, not from what we think we
      // just wrote (CLAUDE.md's refresh-the-row rule).
      await reload();
      widget.onChanged?.call();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Could not release: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ng = NgPalette.of(context);
    if (_loading) return const SizedBox.shrink();

    final j = _job;
    final c = _charge;

    return NgSectionCard(
      title: 'Warehouse storage',
      icon: Icons.warehouse_outlined,
      trailing: j == null
          ? null
          : NgPill(j.outDate == null ? 'In storage' : 'Released',
              status: j.outDate == null ? NgStatus.accent : NgStatus.neutral),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (j == null) ...[
              Text(
                'Goods are going straight to the customer. If they are being '
                'held instead, move them into a godown — rent accrues from '
                'the day they go in.',
                style: NgFonts.geist(
                    fontSize: 13, height: 1.4, color: ng.mute),
              ),
              const SizedBox(height: 14),
              NgSecondaryButton(
                icon: Icons.move_to_inbox_outlined,
                iconColor: ng.acc,
                label: 'Move into warehouse',
                height: 46,
                onPressed: _book,
              ),
            ] else ...[
              _row(ng, 'Godown', _warehouse?.name ?? '—'),
              if ((_warehouse?.city ?? '').isNotEmpty)
                _row(ng, 'City', _warehouse!.city!),
              _row(ng, 'Goods in', _fmtDate(j.inDate)),
              if (j.outDate != null) _row(ng, 'Goods out', _fmtDate(j.outDate)),
              if (j.outDate == null && j.expectedOutDate != null)
                _row(ng, 'Expected out', _fmtDate(j.expectedOutDate)),
              _row(ng, 'Plan',
                  storageBillingModeLabel(storageBillingModeFromWire(j.billingMode))),
              _row(
                  ng,
                  'Agreed rate',
                  storageBillingModeFromWire(j.billingMode) ==
                          StorageBillingMode.custom
                      ? '₹${j.rate.toStringAsFixed(0)} for the stay'
                      : '₹${j.rate.toStringAsFixed(0)} / '
                          '${storageBillingModeFromWire(j.billingMode) == StorageBillingMode.perDay ? 'day' : 'month'}'),
              if (j.totalCft > 0)
                _row(ng, 'Volume', '${j.totalCft.toStringAsFixed(0)} CFT'),
              if (j.packageCount > 0)
                _row(ng, 'Packages', '${j.packageCount}'),
              if (j.securityDeposit > 0)
                _row(ng, 'Deposit held',
                    '₹${j.securityDeposit.toStringAsFixed(0)}'),
              Divider(height: 22, color: ng.w06),
              if (c != null) ...[
                _row(ng, j.outDate == null ? 'Accrued so far' : 'Storage rent',
                    '₹${c.rent.toStringAsFixed(0)}',
                    detail: '${c.billedUnits} ${c.unitLabel}'
                        '${c.days != c.billedUnits ? ' · in store ${c.days} ${c.days == 1 ? 'day' : 'days'}' : ''}'),
                if (c.handlingIn > 0)
                  _row(ng, 'Handling in',
                      '₹${c.handlingIn.toStringAsFixed(0)}'),
                if (c.handlingOut > 0)
                  _row(ng, 'Handling out',
                      '₹${c.handlingOut.toStringAsFixed(0)}'),
                const SizedBox(height: 6),
                NgKeyValue('Storage income', functions.inrFull(c.total),
                    mono: true, strong: true),
                if (c.minimumApplied)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      'Minimum ${j.minBillingDays} days applied.',
                      style: NgFonts.geist(fontSize: 12.5, 
                          color: ng.mute),
                    ),
                  ),
              ],
              if (j.outDate == null) ...[
                const SizedBox(height: 14),
                NgPrimaryButton(
                  icon: Icons.outbox_outlined,
                  label: _busy ? 'Releasing…' : 'Release & deliver',
                  onPressed: _busy ? null : _release,
                ),
              ],
            ],
          ],
        ),
    );
  }

  Widget _row(NgPalette ng, String label, String value,
          {String? detail}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: NgFonts.geist(fontSize: 13.5, color: ng.mute)),
                  if (detail != null)
                    Text(detail,
                        style: NgFonts.geist(fontSize: 12.5, 
                            color: ng.mute)),
                ],
              ),
            ),
            Text(value,
                textAlign: TextAlign.right,
                style: NgFonts.geist(
                    fontSize: 13.5, fontWeight: FontWeight.w500, color: ng.text)),
          ],
        ),
      );

  static String _fmtDate(DateTime? d) => d == null
      ? '—'
      : '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';
}

/// Booking sheet — "move into warehouse".
class _StorageBookingSheet extends StatefulWidget {
  const _StorageBookingSheet({required this.orderId, this.orderCft});
  final String orderId;
  final double? orderCft;

  @override
  State<_StorageBookingSheet> createState() => _StorageBookingSheetState();
}

class _StorageBookingSheetState extends State<_StorageBookingSheet> {
  List<WarehousesRow> _warehouses = [];

  /// This org's own storage rates. Empty until the vendor sets them —
  /// there is no shipped table to fall back on.
  List<StorageSizeRate> _rates = const [];

  String? _warehouseId;
  String? _size;
  StorageBillingMode _mode = StorageBillingMode.perMonth;

  final _rate = TextEditingController();
  final _minDays =
      TextEditingController(text: '$kStorageDefaultMinDays');
  final _cft = TextEditingController();
  final _packages = TextEditingController();
  final _deposit = TextEditingController();
  final _handlingIn = TextEditingController();
  final _handlingOut = TextEditingController();
  final _notes = TextEditingController();
  DateTime _inDate = DateTime.now();
  DateTime? _expectedOut;

  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    if ((widget.orderCft ?? 0) > 0) {
      _cft.text = widget.orderCft!.toStringAsFixed(0);
    }
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await WarehousesTable().queryRows(
        queryFn: (q) => OrgScope.read(q).eq('active', true).order('name'),
      );
      final cfg = await PricingConfig.loadForCurrentOrg();
      if (!mounted) return;
      setState(() {
        _warehouses = rows;
        _rates = cfg.storageRates;
        _warehouseId = rows.isEmpty ? null : rows.first.id;
        _loading = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  @override
  void dispose() {
    for (final c in [
      _rate,
      _minDays,
      _cft,
      _packages,
      _deposit,
      _handlingIn,
      _handlingOut,
      _notes,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  /// Pre-fills the rate from the size template for the chosen plan.
  ///
  /// A SUGGESTION ONLY — the field stays editable and whatever is saved is
  /// what bills. The template is the vendor's default structure, not a
  /// price the product asserts (§44), and the two plans are independent
  /// numbers, so switching plan re-reads the matching column rather than
  /// converting one into the other.
  void _prefillRate() {
    final size = _size;
    if (size == null) return;
    final row = _rates.where((r) => r.size == size);
    if (row.isEmpty) return;
    final r = row.first;
    switch (_mode) {
      case StorageBillingMode.perDay:
        _rate.text = r.perDay.toStringAsFixed(0);
        _minDays.text = '${r.minDays}';
        break;
      case StorageBillingMode.perMonth:
        _rate.text = r.perMonth.toStringAsFixed(0);
        break;
      case StorageBillingMode.custom:
        break;
    }
    // Handling applies on every plan, custom included — it is loading
    // labour, not rent, so it does not depend on how the stay is billed.
    //
    // Only ever FILLS A BLANK. A vendor who has already typed a handling
    // figure for this stay has made a decision about this job, and
    // re-selecting a size must not overwrite it. Same rule the Add
    // Labour dialog follows after the 1 Sept 2026 fix, where changing
    // the staff dropdown used to clobber a typed amount.
    if (r.handlingIn > 0 && _handlingIn.text.trim().isEmpty) {
      _handlingIn.text = r.handlingIn.toStringAsFixed(0);
    }
    if (r.handlingOut > 0 && _handlingOut.text.trim().isEmpty) {
      _handlingOut.text = r.handlingOut.toStringAsFixed(0);
    }
    setState(() {});
  }

  Future<void> _save() async {
    if (_warehouseId == null) {
      setState(() => _error = 'Pick a godown.');
      return;
    }
    final rate = double.tryParse(_rate.text.trim()) ?? 0;
    if (rate <= 0) {
      setState(() => _error = 'Enter the agreed rate.');
      return;
    }
    // Goods cannot leave before they arrive. Caught here rather than left
    // to the charge calculation, which clamps negatives to zero days and
    // would quietly bill the minimum instead of flagging the typo.
    if (_expectedOut != null &&
        DateTime(_expectedOut!.year, _expectedOut!.month, _expectedOut!.day)
            .isBefore(
                DateTime(_inDate.year, _inDate.month, _inDate.day))) {
      setState(() =>
          _error = 'Expected out date is before the goods-in date.');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await StorageJobsTable().insert({
        ...OrgScope.stamp(),
        'order_id': widget.orderId,
        'warehouse_id': _warehouseId,
        'in_date':
            DateTime(_inDate.year, _inDate.month, _inDate.day).toIso8601String(),
        if (_expectedOut != null)
          'expected_out_date': DateTime(_expectedOut!.year, _expectedOut!.month,
                  _expectedOut!.day)
              .toIso8601String(),
        'total_cft': double.tryParse(_cft.text.trim()) ?? 0,
        'package_count': int.tryParse(_packages.text.trim()) ?? 0,
        'billing_mode': storageBillingModeToWire(_mode),
        // Snapshotted: a later rate-card change must not re-bill this stay.
        'rate': rate,
        'min_billing_days': int.tryParse(_minDays.text.trim()) ?? 0,
        'security_deposit': double.tryParse(_deposit.text.trim()) ?? 0,
        'handling_in_charge': double.tryParse(_handlingIn.text.trim()) ?? 0,
        'handling_out_charge': double.tryParse(_handlingOut.text.trim()) ?? 0,
        'status': 'in_storage',
        'notes': [
          if (_size != null) 'Size: $_size',
          if (_notes.text.trim().isNotEmpty) _notes.text.trim(),
        ].join(' · '),
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) {
        setState(() {
          _saving = false;
          _error = '$e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ng = NgPalette.of(context);
    return Padding(
      padding: EdgeInsets.only(
        left: 18,
        right: 18,
        top: 18,
        bottom: MediaQuery.of(context).viewInsets.bottom + 18,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Move into warehouse',
                style: NgFonts.geist(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    letterSpacing: -0.4,
                    color: ng.text)),
            const SizedBox(height: 16),
            if (_loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 30),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_warehouses.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'No active godown yet. Add one under Warehouses first — a '
                  'stay has to be somewhere.',
                  style: NgFonts.geist(fontSize: 14),
                ),
              )
            else ...[
              DropdownButtonFormField<String>(
                initialValue: _warehouseId,
                decoration: const InputDecoration(
                    labelText: 'Godown', isDense: true),
                items: _warehouses
                    .map((w) => DropdownMenuItem(
                          value: w.id,
                          child: Text(
                              [w.name, if ((w.city ?? '').isNotEmpty) w.city!]
                                  .join(' · ')),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _warehouseId = v),
              ),
              const SizedBox(height: 10),
              if (_rates.isEmpty)
                // No shipped rate table to fall back on, deliberately. The
                // vendor still books the stay — they just type the rate
                // they agreed, which is the only number that was ever
                // legitimate here.
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(
                    'No storage rates set yet. Set them under Warehouses → '
                    'Storage rates to pick a size and pre-fill, or just '
                    'enter the agreed rate below.',
                    style: NgFonts.geist(fontSize: 12.5, 
                        color: ng.mute),
                  ),
                )
              else
                DropdownButtonFormField<String>(
                  initialValue: _size,
                  decoration: const InputDecoration(
                      labelText: 'Storage size', isDense: true),
                  items: _rates
                      .map((r) => DropdownMenuItem(
                          value: r.size,
                          child: Text(
                              '${r.size}  ·  ₹${r.perDay.toStringAsFixed(0)}/day  ·  ₹${r.perMonth.toStringAsFixed(0)}/mo')))
                      .toList(),
                  onChanged: (v) {
                    _size = v;
                    _prefillRate();
                  },
                ),
              const SizedBox(height: 10),
              // Plan is chosen at booking and locked for the stay (§39).
              const NgFieldLabel('Plan'),
              NgSegmented(
                labels: const ['Daily', 'Monthly', 'Custom'],
                selected: const [
                  StorageBillingMode.perDay,
                  StorageBillingMode.perMonth,
                  StorageBillingMode.custom,
                ].indexOf(_mode),
                onSelect: (i) {
                  _mode = const [
                    StorageBillingMode.perDay,
                    StorageBillingMode.perMonth,
                    StorageBillingMode.custom,
                  ][i];
                  _prefillRate();
                },
              ),
              const SizedBox(height: 6),
              Text(
                _mode == StorageBillingMode.perMonth
                    ? 'Whole months. Early collection still pays the full '
                        'month — tell the customer at booking.'
                    : _mode == StorageBillingMode.perDay
                        ? 'Per day, with a minimum. A shorter stay still '
                            'bills the minimum.'
                        : 'Bills exactly the agreed amount for the stay.',
                style: NgFonts.geist(fontSize: 12.5, 
                    color: ng.mute),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: _field(
                      _rate,
                      _mode == StorageBillingMode.custom
                          ? 'Agreed amount (₹)'
                          : _mode == StorageBillingMode.perDay
                              ? 'Rate per day (₹)'
                              : 'Rate per month (₹)',
                      keyboard: TextInputType.number),
                ),
                if (_mode == StorageBillingMode.perDay) ...[
                  const SizedBox(width: 10),
                  Expanded(
                      child: _field(_minDays, 'Minimum days',
                          keyboard: TextInputType.number)),
                ],
              ]),
              Row(children: [
                Expanded(
                    child: _field(_cft, 'Volume (CFT)',
                        keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(
                    child: _field(_packages, 'Packages',
                        keyboard: TextInputType.number)),
              ]),
              Row(children: [
                Expanded(
                    child: _field(_handlingIn, 'Handling in (₹)',
                        keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(
                    child: _field(_handlingOut, 'Handling out (₹)',
                        keyboard: TextInputType.number)),
              ]),
              _field(_deposit, 'Security deposit (₹)',
                  keyboard: TextInputType.number),
              _dateRow(ng, 'Goods in', _inDate, (d) {
                setState(() => _inDate = d);
              }),
              _dateRow(ng, 'Expected out (optional)', _expectedOut, (d) {
                setState(() => _expectedOut = d);
              }),
              _field(_notes, 'Notes', maxLines: 2),
              if (_error != null) ...[
                const SizedBox(height: 6),
                Text(_error!,
                    style: NgFonts.geist(fontSize: 12.5, 
                        color: ng.red)),
              ],
              const SizedBox(height: 16),
              NgPrimaryButton(
                icon: Icons.move_to_inbox_outlined,
                label: _saving ? 'Saving…' : 'Move in',
                onPressed: _saving ? null : _save,
              ),
              const SizedBox(height: 8),
              NgSecondaryButton(
                label: 'Cancel',
                height: 46,
                onPressed:
                    _saving ? null : () => Navigator.of(context).pop(false),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _dateRow(NgPalette ng, String label, DateTime? value,
          ValueChanged<DateTime> onPick) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            NgFieldLabel(label),
            NgPickerField(
              icon: Icons.event_outlined,
              value: value == null
                  ? 'Pick a date'
                  : OrderStorageSectionState._fmtDate(value),
              placeholder: value == null,
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: value ?? DateTime.now(),
                  firstDate: DateTime(DateTime.now().year - 1),
                  lastDate: DateTime(DateTime.now().year + 3),
                );
                if (picked != null) onPick(picked);
              },
            ),
          ],
        ),
      );

  Widget _field(TextEditingController c, String label,
          {int maxLines = 1, TextInputType? keyboard}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            NgFieldLabel(label),
            NgInput(
              controller: c,
              maxLines: maxLines,
              keyboardType: keyboard,
              mono: keyboard == TextInputType.number,
            ),
          ],
        ),
      );
}
