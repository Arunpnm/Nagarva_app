// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get arunPackersAndCouriers => 'Arun Packers And Couriers';

  @override
  String get movingYouTowardsYourFuture => 'Moving you towards your future';

  @override
  String get nameOrPhone => 'Name or Phone';

  @override
  String get enterYourNameOrPhone => 'Enter your name or phone';

  @override
  String get pin => 'PIN';

  @override
  String get n4DigitPin => '4-digit PIN';

  @override
  String get login => 'LOGIN';

  @override
  String get securedEncrypted => 'Secured & Encrypted';

  @override
  String get dashboard => 'Dashboard';

  @override
  String get thisMonth => 'THIS MONTH';

  @override
  String get revenue => 'REVENUE';

  @override
  String get labour => 'LABOUR';

  @override
  String get expenses => 'EXPENSES';

  @override
  String get porter => 'PORTER';

  @override
  String get netProfit => 'NET PROFIT';

  @override
  String get activeLeads => 'ACTIVE LEADS';

  @override
  String get ordersMonth => 'ORDERS/MONTH';

  @override
  String get outstanding => 'OUTSTANDING';

  @override
  String get reminders => 'REMINDERS';

  @override
  String get monthlyTarget => 'MONTHLY TARGET';

  @override
  String get edit => 'Edit';

  @override
  String get targetThisMonth => 'target this month';

  @override
  String get eG200000 => 'e.g. 200000';

  @override
  String get save => 'Save';

  @override
  String get upcomingOrders => 'Upcoming Orders';

  @override
  String get calendar => 'Calendar ->';

  @override
  String get hotLeads => 'Hot Leads';

  @override
  String get viewAll => 'View All ->';

  @override
  String get branchPerformance => 'BRANCH PERFORMANCE';

  @override
  String get orders => 'Orders';

  @override
  String get leads => 'Leads';

  @override
  String get operations => 'Operations';

  @override
  String get payments => 'Payments';

  @override
  String get homePageExpenses => 'Expenses';

  @override
  String get salary => 'Salary';

  @override
  String get settings => 'Settings';

  @override
  String get logout => 'Logout';

  @override
  String get all => 'All';

  @override
  String get pending => 'Pending';

  @override
  String get completed => 'Completed';

  @override
  String get cancelled => 'Cancelled';

  @override
  String get confirmed => 'Confirmed';

  @override
  String get transit => 'Transit';

  @override
  String get done => 'Done';

  @override
  String get ord001 => 'ORD-001';

  @override
  String get rajeshKumar => 'Rajesh Kumar';

  @override
  String get chennaiBangalore => 'Chennai → Bangalore';

  @override
  String get n12500 => '₹12,500';

  @override
  String get ord002 => 'ORD-002';

  @override
  String get priyaSharma => 'Priya Sharma';

  @override
  String get mumbaiPune => 'Mumbai → Pune';

  @override
  String get n8000 => '₹8,000';

  @override
  String get ord003 => 'ORD-003';

  @override
  String get inTransit => 'In Transit';

  @override
  String get anandVerma => 'Anand Verma';

  @override
  String get delhiNoida => 'Delhi → Noida';

  @override
  String get n5500 => '₹5,500';

  @override
  String get ord004 => 'ORD-004';

  @override
  String get sunitaDevi => 'Sunita Devi';

  @override
  String get hyderabadChennai => 'Hyderabad → Chennai';

  @override
  String get n9200 => '₹9,200';

  @override
  String get leadsCrm => 'Leads / CRM';

  @override
  String get n8 => '8';

  @override
  String get statusNew => 'New';

  @override
  String get n5 => '5';

  @override
  String get contacted => 'Contacted';

  @override
  String get n3 => '3';

  @override
  String get qualified => 'Qualified';

  @override
  String get n2 => '2';

  @override
  String get won => 'Won';

  @override
  String get lost => 'Lost';

  @override
  String get raviMenon => 'Ravi Menon';

  @override
  String get n919840012345 => '+91 98400 12345';

  @override
  String get chennaiTn => 'Chennai, TN';

  @override
  String get newLead => 'New Lead';

  @override
  String get deepaNair => 'Deepa Nair';

  @override
  String get n919447067890 => '+91 94470 67890';

  @override
  String get coimbatoreTn => 'Coimbatore, TN';

  @override
  String get karthikS => 'Karthik S.';

  @override
  String get n919940054321 => '+91 99400 54321';

  @override
  String get maduraiTn => 'Madurai, TN';

  @override
  String get meenaRaj => 'Meena Raj';

  @override
  String get n919380011223 => '+91 93800 11223';

  @override
  String get trichyTn => 'Trichy, TN';

  @override
  String get todaySJobs => 'Today\'s Jobs';

  @override
  String get n3Active => '3 Active';

  @override
  String get tn01Ab1234 => 'TN-01-AB-1234';

  @override
  String get loading => 'Loading';

  @override
  String get sureshDriver => 'Suresh (Driver)';

  @override
  String get chennaiVellore => 'Chennai → Vellore';

  @override
  String get tn02Cd5678 => 'TN-02-CD-5678';

  @override
  String get muruganDriver => 'Murugan (Driver)';

  @override
  String get salemErode => 'Salem → Erode';

  @override
  String get tn03Ef9012 => 'TN-03-EF-9012';

  @override
  String get unloading => 'Unloading';

  @override
  String get baluDriver => 'Balu (Driver)';

  @override
  String get coimbatoreOoty => 'Coimbatore → Ooty';

  @override
  String get upcoming => 'Upcoming';

  @override
  String get tn04Gh3456 => 'TN-04-GH-3456';

  @override
  String get scheduled => 'Scheduled';

  @override
  String get senthilDriver => 'Senthil (Driver)';

  @override
  String get maduraiTirunelveli => 'Madurai → Tirunelveli';

  @override
  String get vehicleTripLog => 'Vehicle Trip Log';

  @override
  String get logNewTrip => 'Log New Trip';

  @override
  String get paymentsPageOutstanding => 'Outstanding';

  @override
  String get n42800 => '₹42,800';

  @override
  String get receivedMonth => 'Received (Month)';

  @override
  String get n124000 => '₹1,24,000';

  @override
  String get pendingPaymentsLive => 'Pending Payments (Live)';

  @override
  String get pendingInvoices => 'Pending Invoices';

  @override
  String get inv045 => 'INV-045';

  @override
  String get due15May => 'Due: 15 May';

  @override
  String get inv046 => 'INV-046';

  @override
  String get due18May => 'Due: 18 May';

  @override
  String get inv047 => 'INV-047';

  @override
  String get overdue => 'Overdue';

  @override
  String get inv048 => 'INV-048';

  @override
  String get due22May => 'Due: 22 May';

  @override
  String get n16800 => '₹16,800';

  @override
  String get may2025Total => 'May 2025 Total';

  @override
  String get n68450 => '₹68,450';

  @override
  String get n12VsLastMonth => '↑ 12% vs last month';

  @override
  String get liveExpenses => 'Live Expenses';

  @override
  String get byCategory => 'By Category';

  @override
  String get fuel => 'Fuel';

  @override
  String get n41 => '41%';

  @override
  String get n28000 => '₹28,000';

  @override
  String get tollsPermits => 'Tolls & Permits';

  @override
  String get n18 => '18%';

  @override
  String get maintenance => 'Maintenance';

  @override
  String get n26 => '26%';

  @override
  String get n18000 => '₹18,000';

  @override
  String get expensePageLabour => 'Labour';

  @override
  String get n15 => '15%';

  @override
  String get n9950 => '₹9,950';

  @override
  String get addExpense => 'Add Expense';

  @override
  String get may2025 => 'May 2025';

  @override
  String get totalPayroll => 'Total Payroll';

  @override
  String get n182000 => '₹1,82,000';

  @override
  String get liveStaffData => 'Live Staff Data';

  @override
  String get todaySAttendance => 'Today\'s Attendance';

  @override
  String get label => '·';

  @override
  String get pendingAdvances => 'Pending Advances';

  @override
  String get bal => 'Bal:';

  @override
  String get staff => 'Staff';

  @override
  String get sureshKumar => 'Suresh Kumar';

  @override
  String get driver => 'Driver';

  @override
  String get n22000 => '₹22,000';

  @override
  String get paid => 'Paid';

  @override
  String get muruganP => 'Murugan P.';

  @override
  String get n20000 => '₹20,000';

  @override
  String get baluS => 'Balu S.';

  @override
  String get helper => 'Helper';

  @override
  String get n14000 => '₹14,000';

  @override
  String get senthilR => 'Senthil R.';

  @override
  String get n21000 => '₹21,000';

  @override
  String get kalaM => 'Kala M.';

  @override
  String get officeStaff => 'Office Staff';

  @override
  String get fleet => 'Fleet';

  @override
  String get n4 => '4';

  @override
  String get active => 'Active';

  @override
  String get idle => 'Idle';

  @override
  String get n1 => '1';

  @override
  String get service => 'Service';

  @override
  String get liveFleet => 'Live Fleet';

  @override
  String get miniTruck407 => 'Mini Truck (407)';

  @override
  String get suresh => 'Suresh';

  @override
  String get n124560Km => '1,24,560 km';

  @override
  String get largeTruckTata => 'Large Truck (Tata)';

  @override
  String get murugan => 'Murugan';

  @override
  String get n98340Km => '98,340 km';

  @override
  String get inService => 'In Service';

  @override
  String get balu => 'Balu';

  @override
  String get n212000Km => '2,12,000 km';

  @override
  String get largeTruckEicher => 'Large Truck (Eicher)';

  @override
  String get senthil => 'Senthil';

  @override
  String get n67890Km => '67,890 km';

  @override
  String get newQuotation => 'New Quotation';

  @override
  String get customerDetails => 'Customer Details';

  @override
  String get customerName => 'Customer Name';

  @override
  String get enterFullName => 'Enter full name';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get n91XxxxxXxxxx => '+91 XXXXX XXXXX';

  @override
  String get moveDetails => 'Move Details';

  @override
  String get fromAddress => 'From Address';

  @override
  String get pickupLocation => 'Pickup location';

  @override
  String get toAddress => 'To Address';

  @override
  String get dropLocation => 'Drop location';

  @override
  String get moveDate => 'Move Date';

  @override
  String get ddMmYyyy => 'DD/MM/YYYY';

  @override
  String get floorAccess => 'Floor / Access';

  @override
  String get eG2ndFloorLiftAvailable => 'e.g. 2nd floor, lift available';

  @override
  String get estimate => 'Estimate';

  @override
  String get quotedAmount => 'Quoted Amount (₹)';

  @override
  String get n000 => '0.00';

  @override
  String get notes => 'Notes';

  @override
  String get additionalDetails => 'Additional details';

  @override
  String get generateQuotation => 'Generate Quotation';

  @override
  String get accounts => 'Accounts';

  @override
  String get sbiCurrentAC => 'SBI — Current A/C';

  @override
  String get xxxx4521 => 'XXXX 4521';

  @override
  String get n284500 => '₹2,84,500';

  @override
  String get hdfcSavingsAC => 'HDFC — Savings A/C';

  @override
  String get xxxx7832 => 'XXXX 7832';

  @override
  String get n112300 => '₹1,12,300';

  @override
  String get cashOnHand => 'Cash on Hand';

  @override
  String get totalBalance => 'Total Balance';

  @override
  String get n414800 => '₹4,14,800';

  @override
  String get recentTransactions => 'Recent Transactions';

  @override
  String get receivedOrd001 => 'Received — ORD-001';

  @override
  String get accountsPageN12500 => '+₹12,500';

  @override
  String get may5 => 'May 5';

  @override
  String get fuelTn01Ab1234 => 'Fuel — TN-01-AB-1234';

  @override
  String get petrolBunk => 'Petrol Bunk';

  @override
  String get n3200 => '-₹3,200';

  @override
  String get receivedOrd002 => 'Received — ORD-002';

  @override
  String get accountsPageN8000 => '+₹8,000';

  @override
  String get may4 => 'May 4';

  @override
  String get tollChennaiNh => 'Toll — Chennai NH';

  @override
  String get nhai => 'NHAI';

  @override
  String get n480 => '-₹480';

  @override
  String get pLReport => 'P&L Report';

  @override
  String get periodMay2025 => 'Period: May 2025';

  @override
  String get n192000 => '₹1,92,000';

  @override
  String get pLReportPageRevenue => 'Revenue';

  @override
  String get n123550 => '₹1,23,550';

  @override
  String get pLReportPageNetProfit => 'Net Profit';

  @override
  String get n643 => '64.3%';

  @override
  String get margin => 'Margin';

  @override
  String get topExpenses => 'Top Expenses';

  @override
  String get arunPackersStaff => 'Arun Packers Staff';

  @override
  String get adminArunpackersIn => 'admin@arunpackers.in';

  @override
  String get company => 'Company';

  @override
  String get businessName => 'Business Name';

  @override
  String get settingsPageArunPackersAndCouriers => 'Arun Packers and Couriers';

  @override
  String get phone => 'Phone';

  @override
  String get n9144XxxxXxxx => '+91 44 XXXX XXXX';

  @override
  String get gstNumber => 'GST Number';

  @override
  String get xxxxxxxxxxxx => 'XXXXXXXXXXXX';

  @override
  String get app => 'App';

  @override
  String get notifications => 'Notifications';

  @override
  String get enabled => 'Enabled';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String get on => 'On';

  @override
  String get language => 'Language';

  @override
  String get english => 'English';

  @override
  String get data => 'Data';

  @override
  String get exportData => 'Export Data';

  @override
  String get csvPdf => 'CSV / PDF';

  @override
  String get backup => 'Backup';

  @override
  String get autoDaily => 'Auto (Daily)';

  @override
  String get appTheme => 'App Theme';

  @override
  String get chooseYourPreferredColourScheme =>
      'Choose your preferred colour scheme.';

  @override
  String get dark => 'Dark';

  @override
  String get midnight => 'Midnight';

  @override
  String get light => 'Light';

  @override
  String get calendarPageCalendar => 'Calendar';

  @override
  String get mon => 'Mon';

  @override
  String get tue => 'Tue';

  @override
  String get wed => 'Wed';

  @override
  String get thu => 'Thu';

  @override
  String get fri => 'Fri';

  @override
  String get sat => 'Sat';

  @override
  String get sun => 'Sun';

  @override
  String get n6 => '6';

  @override
  String get n7 => '7';

  @override
  String get n9 => '9';

  @override
  String get n10 => '10';

  @override
  String get n11 => '11';

  @override
  String get n12 => '12';

  @override
  String get n13 => '13';

  @override
  String get n14 => '14';

  @override
  String get calendarPageN15 => '15';

  @override
  String get n17 => '17';

  @override
  String get calendarPageN18 => '18';

  @override
  String get n20 => '20';

  @override
  String get n21 => '21';

  @override
  String get n22 => '22';

  @override
  String get n23 => '23';

  @override
  String get n24 => '24';

  @override
  String get n25 => '25';

  @override
  String get calendarPageN26 => '26';

  @override
  String get n27 => '27';

  @override
  String get n28 => '28';

  @override
  String get n29 => '29';

  @override
  String get n30 => '30';

  @override
  String get n31 => '31';

  @override
  String get remindersFollowUps => 'Reminders & Follow-ups';

  @override
  String get followUpRaviMenon => 'Follow-up: Ravi Menon';

  @override
  String get callRegardingBangaloreMoveQuote =>
      'Call regarding Bangalore move quote';

  @override
  String get may7 => 'May 7';

  @override
  String get collectionOrd047 => 'Collection: ORD-047';

  @override
  String get overduePaymentFromAnandVerma => 'Overdue payment from Anand Verma';

  @override
  String get may8 => 'May 8';

  @override
  String get jobTn01Ab1234 => 'Job: TN-01-AB-1234';

  @override
  String get chennaiVelloreScheduledDelivery =>
      'Chennai → Vellore scheduled delivery';

  @override
  String get may9 => 'May 9';

  @override
  String get reviewMayExpenses => 'Review: May Expenses';

  @override
  String get monthlyExpenseReviewWithTeam => 'Monthly expense review with team';

  @override
  String get may12 => 'May 12';

  @override
  String get activeRemindersLive => 'Active Reminders (Live)';

  @override
  String get addReminder => 'Add Reminder';

  @override
  String get materials => 'Materials';

  @override
  String get totalSkus => 'Total SKUs';

  @override
  String get lowStock => 'Low Stock';

  @override
  String get inventory => 'Inventory';

  @override
  String get cardboardBoxSmall => 'Cardboard Box — Small';

  @override
  String get reorder20 => 'Reorder < 20';

  @override
  String get n42Pcs => '42 pcs';

  @override
  String get cardboardBoxMedium => 'Cardboard Box — Medium';

  @override
  String get n28Pcs => '28 pcs';

  @override
  String get cardboardBoxLarge => 'Cardboard Box — Large';

  @override
  String get reorder15 => 'Reorder < 15';

  @override
  String get n11Pcs => '11 pcs';

  @override
  String get bubbleWrapRoll50m => 'Bubble Wrap Roll (50m)';

  @override
  String get reorder5 => 'Reorder < 5';

  @override
  String get n4Rolls => '4 rolls';

  @override
  String get stretchWrapRoll => 'Stretch Wrap Roll';

  @override
  String get ok => 'OK';

  @override
  String get n18Rolls => '18 rolls';

  @override
  String get packingTapeBrown => 'Packing Tape (Brown)';

  @override
  String get reorder10 => 'Reorder < 10';

  @override
  String get n7Pcs => '7 pcs';

  @override
  String get furnitureCoverLarge => 'Furniture Cover (Large)';

  @override
  String get n24Pcs => '24 pcs';

  @override
  String get rope50m => 'Rope (50m)';

  @override
  String get n8Rolls => '8 rolls';

  @override
  String get cornerGuards => 'Corner Guards';

  @override
  String get n60Pcs => '60 pcs';

  @override
  String get addRestockItem => 'Add / Restock Item';

  @override
  String get reports => 'Reports';

  @override
  String get generateReports => 'Generate Reports';

  @override
  String get monthlySummary => 'Monthly Summary';

  @override
  String get revenueExpensesProfitOverview =>
      'Revenue, expenses & profit overview';

  @override
  String get customerReport => 'Customer Report';

  @override
  String get topCustomersByRevenue => 'Top customers by revenue';

  @override
  String get driverPerformance => 'Driver Performance';

  @override
  String get jobsCompletedPerDriver => 'Jobs completed per driver';

  @override
  String get expenseBreakdown => 'Expense Breakdown';

  @override
  String get categoryWiseExpenseAnalysis => 'Category-wise expense analysis';

  @override
  String get revenueTrend => 'Revenue Trend';

  @override
  String get monthOnMonthRevenueChart => 'Month-on-month revenue chart';

  @override
  String get outstandingReport => 'Outstanding Report';

  @override
  String get pendingPaymentsAgeing => 'Pending payments & ageing';

  @override
  String get vehicleUtilisation => 'Vehicle Utilisation';

  @override
  String get fleetUsageAndIdleTimeAnalysis =>
      'Fleet usage and idle time analysis';

  @override
  String get exportOptions => 'Export Options';

  @override
  String get exportPdf => 'Export PDF';

  @override
  String get exportCsv => 'Export CSV';

  @override
  String get users => 'Users';

  @override
  String get addNewUser => 'Add New User';

  @override
  String get admin => 'Admin';

  @override
  String get activeUsers => 'Active Users';

  @override
  String get arunKumar => 'Arun Kumar';

  @override
  String get n919840000001 => '+91 98400 00001';

  @override
  String get today => 'Today';

  @override
  String get sureshM => 'Suresh M.';

  @override
  String get n919840000002 => '+91 98400 00002';

  @override
  String get n919840000003 => '+91 98400 00003';

  @override
  String get yesterday => 'Yesterday';

  @override
  String get kalaR => 'Kala R.';

  @override
  String get n919840000004 => '+91 98400 00004';

  @override
  String get n919840000005 => '+91 98400 00005';

  @override
  String get n2DaysAgo => '2 days ago';

  @override
  String get inactiveUsers => 'Inactive Users';

  @override
  String get n919840000006 => '+91 98400 00006';

  @override
  String get inactive => 'Inactive';

  @override
  String get n5DaysAgo => '5 days ago';

  @override
  String get recordPayment => 'Record Payment';

  @override
  String get selectOrder => 'Select Order';

  @override
  String get loadingPendingOrders => 'Loading pending orders...';

  @override
  String get select => 'Select';

  @override
  String get paymentEntry => 'Payment Entry';

  @override
  String get customer => 'Customer:';

  @override
  String get totalAmount => 'Total Amount:';

  @override
  String get alreadyPaid => 'Already Paid:';

  @override
  String get amountReceived => 'Amount Received (₹)';

  @override
  String get selectStatus => 'Select status';

  @override
  String get paymentStatus => 'Payment Status';

  @override
  String get partial => 'partial';

  @override
  String get recordPaymentPagePaid => 'paid';

  @override
  String get savePayment => 'Save Payment';

  @override
  String get quickExpense => 'Quick Expense';

  @override
  String get expenseDetails => 'Expense Details';

  @override
  String get amount => 'Amount (₹)';

  @override
  String get selectCategory => 'Select category';

  @override
  String get category => 'Category';

  @override
  String get vehicleMaintenance => 'Vehicle Maintenance';

  @override
  String get office => 'Office';

  @override
  String get material => 'Material';

  @override
  String get other => 'Other';

  @override
  String get date => 'Date';

  @override
  String get yyyyMmDd => 'YYYY-MM-DD';

  @override
  String get linkedOrderIdOptional => 'Linked Order ID (optional)';

  @override
  String get leaveBlankIfNotLinked => 'Leave blank if not linked';

  @override
  String get description => 'Description';

  @override
  String get briefDescription => 'Brief description';

  @override
  String get saveExpense => 'Save Expense';

  @override
  String get newOrder => 'New Order';

  @override
  String get newOrderPageCustomer => 'Customer';

  @override
  String get newOrderPageCustomerName => 'Customer Name *';

  @override
  String get fullName => 'Full name';

  @override
  String get newOrderPagePhone => 'Phone *';

  @override
  String get fromCity => 'From City *';

  @override
  String get originCity => 'Origin city';

  @override
  String get toCity => 'To City *';

  @override
  String get destinationCity => 'Destination city';

  @override
  String get pickupAddress => 'Pickup address';

  @override
  String get dropAddress => 'Drop address';

  @override
  String get fromFloor => 'From Floor';

  @override
  String get eG2ndFloor => 'e.g. 2nd floor';

  @override
  String get toFloor => 'To Floor';

  @override
  String get eGGroundFloor => 'e.g. Ground floor';

  @override
  String get newOrderPageMoveDate => 'Move Date *';

  @override
  String get tapToPickDate => 'Tap to pick date';

  @override
  String get pickDate => 'Pick Date';

  @override
  String get pricingClassification => 'Pricing & Classification';

  @override
  String get newOrderPageAmount => 'Amount (₹) *';

  @override
  String get selectService => 'Select service';

  @override
  String get newOrderPageService => 'Service *';

  @override
  String get houseShifting => 'House Shifting';

  @override
  String get officeShifting => 'Office Shifting';

  @override
  String get vehicleTransport => 'Vehicle Transport';

  @override
  String get storage => 'Storage';

  @override
  String get packingOnly => 'Packing Only';

  @override
  String get longDistance => 'Long Distance';

  @override
  String get selectBranch => 'Select branch';

  @override
  String get branch => 'Branch *';

  @override
  String get chennai => 'Chennai';

  @override
  String get bengaluru => 'Bengaluru';

  @override
  String get coimbatore => 'Coimbatore';

  @override
  String get selectType => 'Select type';

  @override
  String get orderType => 'Order Type *';

  @override
  String get direct => 'Direct';

  @override
  String get newOrderPagePorter => 'Porter';

  @override
  String get porterCommission => 'Porter Commission %';

  @override
  String get saveOrder => 'Save Order';

  @override
  String get orderDetails => 'Order Details';

  @override
  String get orderDetailPageBranch => 'Branch';

  @override
  String get type => 'Type';

  @override
  String get from => 'From';

  @override
  String get to => 'To';

  @override
  String get addressFrom => 'Address (From)';

  @override
  String get addressTo => 'Address (To)';

  @override
  String get floorFrom => 'Floor (From)';

  @override
  String get floorTo => 'Floor (To)';

  @override
  String get payment => 'Payment';

  @override
  String get orderDetailPageAmount => 'Amount';

  @override
  String get advancePaid => 'Advance Paid';

  @override
  String get trackingStatus => 'Tracking Status';

  @override
  String get editOrder => 'Edit Order';

  @override
  String get contact => 'Contact';

  @override
  String get email => 'Email';

  @override
  String get emailExampleCom => 'email@example.com';

  @override
  String get newLeadPageFromCity => 'From City';

  @override
  String get newLeadPageToCity => 'To City';

  @override
  String get approxDate => 'Approx Date *';

  @override
  String get classification => 'Classification';

  @override
  String get status => 'Status *';

  @override
  String get newLeadPageNew => 'new';

  @override
  String get newLeadPageContacted => 'contacted';

  @override
  String get surveyDone => 'survey_done';

  @override
  String get quoted => 'quoted';

  @override
  String get converted => 'converted';

  @override
  String get newLeadPageLost => 'lost';

  @override
  String get howDidTheyHearAboutUs => 'How did they hear about us?';

  @override
  String get source => 'Source *';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get phoneCall => 'Phone Call';

  @override
  String get website => 'Website';

  @override
  String get referral => 'Referral';

  @override
  String get walkIn => 'Walk-in';

  @override
  String get google => 'Google';

  @override
  String get justdial => 'JustDial';

  @override
  String get anyRelevantNotes => 'Any relevant notes';

  @override
  String get saveLead => 'Save Lead';

  @override
  String get leadDetails => 'Lead Details';

  @override
  String get leadDetailPageSource => 'Source';

  @override
  String get leadDetailPageApproxDate => 'Approx. Date';

  @override
  String get convertToOrder => 'Convert to Order';

  @override
  String get editLead => 'Edit Lead';

  @override
  String get quickEntry => 'Quick Entry';

  @override
  String get whatWouldYouLikeToDo => 'What would you like to do?';

  @override
  String get newInquiry => 'New Inquiry';

  @override
  String get confirmBooking => 'Confirm Booking';

  @override
  String get cashCollectedByPorter => 'Cash Collected by Porter (₹)';

  @override
  String get leaveBlankIfNoneCollectedYet =>
      'Leave blank if none collected yet';

  @override
  String get jrTitle => 'Order journey';

  @override
  String get jrStageLead => 'Lead';

  @override
  String get jrStageFollowUp => 'Follow-up';

  @override
  String get jrStageSurvey => 'Survey';

  @override
  String get jrStageQuote => 'Quote & confirm';

  @override
  String get jrStageSupervisor => 'Supervisor';

  @override
  String get jrStageMoveDay => 'Move day';

  @override
  String get jrStageInvoice => 'Invoice';

  @override
  String get jrStagePayment => 'Payment & issues';

  @override
  String get jrStageClosed => 'Closed';

  @override
  String get jrStateDone => 'Done';

  @override
  String get jrStateSkipped => 'Skipped';

  @override
  String get jrStateCurrent => 'Now';

  @override
  String get jrStatePending => 'Later';

  @override
  String get jrDirectOrder => 'Skipped · direct order';

  @override
  String get jrMoveDate => 'Move date';

  @override
  String get jrRoute => 'Route';

  @override
  String get jrOrderValue => 'Order value';

  @override
  String get jrNotSet => 'Not set';

  @override
  String get jrDocuments => 'Documents';

  @override
  String get jrDocQuote => 'Quotation';

  @override
  String get jrDocInvoice => 'Tax invoice';

  @override
  String get jrDocReceipts => 'Money receipts';

  @override
  String get jrDocLr => 'Lorry receipt';

  @override
  String get jrDocReady => 'Ready · tap to view';

  @override
  String jrDocAfter(String stage) {
    return 'After $stage';
  }

  @override
  String jrCreated(String date) {
    return 'Created $date';
  }

  @override
  String jrSource(String source) {
    return 'Source: $source';
  }

  @override
  String jrService(String service) {
    return 'Service: $service';
  }

  @override
  String get jrNoCalls => 'No calls logged yet';

  @override
  String jrCallsLogged(String count) {
    return '$count calls logged';
  }

  @override
  String get jrOutcomeQ => 'How did the call go?';

  @override
  String get jrOutNoAnswer => 'Not reachable';

  @override
  String get jrOutCallback => 'Call back';

  @override
  String get jrOutInterested => 'Interested';

  @override
  String get jrOutNotInterested => 'Not interested';

  @override
  String get jrCallNotes => 'Notes from the call';

  @override
  String get jrNextFollowUp => 'Next follow-up';

  @override
  String get jrToday => 'Today';

  @override
  String get jrTomorrow => 'Tomorrow';

  @override
  String get jrIn2Days => 'In 2 days';

  @override
  String get jrNextWeek => 'Next week';

  @override
  String get jrPickDate => 'Pick date';

  @override
  String get jrNoNext => 'None';

  @override
  String get jrLogCall => 'Log call';

  @override
  String get jrCallLogged => 'Call logged';

  @override
  String get jrPickOutcome => 'Pick how the call went';

  @override
  String get jrSurveyWaiting => 'Survey link sent · waiting for the customer';

  @override
  String get jrSurveyDone => 'Customer submitted the survey';

  @override
  String get jrNoSurvey => 'No survey yet';

  @override
  String get jrOpenSurveyQuote => 'Open survey & quote';

  @override
  String get jrNoQuote => 'No quote yet';

  @override
  String jrQuoteLine(String amount) {
    return 'Quote $amount';
  }

  @override
  String jrOrderConfirmed(String id) {
    return 'Order $id confirmed';
  }

  @override
  String get jrLeadLost => 'Lead marked lost';

  @override
  String get jrNoSupervisor => 'No supervisor yet';

  @override
  String jrSupervisorIs(String name) {
    return 'Supervisor: $name';
  }

  @override
  String jrCrew(String count) {
    return 'Crew on the job: $count';
  }

  @override
  String get jrAssignInOrder => 'Assign supervisor';

  @override
  String get jrNotStarted => 'Not started';

  @override
  String jrMoveStarted(String time) {
    return 'Started $time';
  }

  @override
  String jrMoveFinished(String time) {
    return 'Finished $time';
  }

  @override
  String get jrOpenFieldJob => 'Open field job';

  @override
  String get jrNoInvoice => 'Invoice not generated';

  @override
  String jrInvoiceNo(String no) {
    return 'Invoice $no';
  }

  @override
  String get jrSigned => 'Customer signed';

  @override
  String get jrNotSigned => 'Customer signature missing';

  @override
  String get jrOpenOrder => 'Open order';

  @override
  String get jrTotal => 'Total';

  @override
  String get jrPaid => 'Paid';

  @override
  String get jrBalance => 'Balance';

  @override
  String get jrRecordPayment => 'Record payment';

  @override
  String get jrTickets => 'Tickets';

  @override
  String get jrNoTickets => 'No tickets';

  @override
  String get jrTicketHint => 'e.g. AC fitting pending';

  @override
  String get jrRaiseTicket => 'Raise ticket';

  @override
  String get jrResolve => 'Resolve';

  @override
  String get jrTicketRaised => 'Ticket raised';

  @override
  String get jrTicketResolved => 'Ticket resolved';

  @override
  String get jrBlockTicket => 'A ticket is still open';

  @override
  String jrBlockBalance(String amount) {
    return 'Balance of $amount is due';
  }

  @override
  String get jrCloseOrder => 'Close order';

  @override
  String jrClosedOn(String date) {
    return 'Closed $date';
  }

  @override
  String get jrNotClosed => 'Open';

  @override
  String jrPaymentLine(String amount, String mode) {
    return '$amount · $mode';
  }

  @override
  String get jrCouldNotLoad => 'Could not load this journey';

  @override
  String get jrRetry => 'Retry';

  @override
  String jrCouldNotSave(String error) {
    return 'Could not save: $error';
  }

  @override
  String get ngNavHome => 'Home';

  @override
  String get ngNavLeads => 'Leads';

  @override
  String get ngNavOrders => 'Orders';

  @override
  String get ngNavOps => 'Ops';

  @override
  String get ngNavPay => 'Pay';

  @override
  String get ngNavMore => 'More';

  @override
  String get ngMenuDashboard => 'Dashboard';

  @override
  String get ngMenuLeads => 'Leads / CRM';

  @override
  String get ngMenuInbox => 'Inbox';

  @override
  String get ngMenuSurveyQuote => 'Survey & Quote';

  @override
  String get ngMenuCalendar => 'Calendar';

  @override
  String get ngMenuOrders => 'Orders';

  @override
  String get ngMenuOperations => 'Operations';

  @override
  String get ngMenuReviews => 'Reviews';

  @override
  String get ngMenuPayments => 'Payments';

  @override
  String get ngMenuExpenses => 'Expenses';

  @override
  String get ngMenuStaff => 'Staff';

  @override
  String get ngMenuTeamAttendance => 'Team Attendance';

  @override
  String get ngMenuFleet => 'Fleet';

  @override
  String get ngMenuMaterials => 'Materials';

  @override
  String get ngMenuWarehouses => 'Warehouses';

  @override
  String get ngMenuRateCards => 'Rate Cards';

  @override
  String get ngMenuLrRegister => 'LR Register';

  @override
  String get ngMenuOpsLog => 'Ops Log';

  @override
  String get ngMenuVendors => 'Vendors';

  @override
  String get ngMenuCustomers => 'Customers';

  @override
  String get ngMenuInsurance => 'Insurance';

  @override
  String get ngMenuTrips => 'Trips';

  @override
  String get ngMenuTasks => 'Tasks';

  @override
  String get ngMenuAccounts => 'Accounts';

  @override
  String get ngMenuPnl => 'P & L';

  @override
  String get ngMenuReports => 'Reports';

  @override
  String get ngMenuSalary => 'Salary';

  @override
  String get ngMenuSettings => 'Settings';

  @override
  String get ngMenuPlatformAdmin => 'Platform Admin';

  @override
  String get ngMenuMyJobs => 'My Jobs';

  @override
  String get ngMenuMyTeam => 'My Team';

  @override
  String get ngMenuMyEarnings => 'My Earnings';

  @override
  String get ngMenuMyAttendance => 'My Attendance';

  @override
  String get ngGroupSales => 'Sales';

  @override
  String get ngGroupOperations => 'Operations';

  @override
  String get ngGroupMoney => 'Money';

  @override
  String get ngGroupPeople => 'People';

  @override
  String get ngGroupAssets => 'Assets';

  @override
  String get ngGroupPartners => 'Partners';

  @override
  String get ngGroupSetup => 'Setup';

  @override
  String get ngGroupField => 'Field';

  @override
  String get ngGroupOther => 'Other';

  @override
  String get ngQuickEntry => 'Quick entry';

  @override
  String get ngSearchModules => 'Search modules';

  @override
  String get ngNoModuleMatches => 'No module matches';

  @override
  String get ngHelp => 'Help';

  @override
  String ngOrgsSwitch(String count) {
    return '$count orgs · tap to switch';
  }

  @override
  String get ngRoleOwner => 'Owner';

  @override
  String get ngRoleStaff => 'Staff';

  @override
  String get ngTodayMoves => 'Moves';

  @override
  String get ngTodayFollowUps => 'Follow-ups';

  @override
  String get ngToCollect => 'To collect';

  @override
  String get ngOpenLeads => 'Open leads';

  @override
  String get ngNoMovesYet => 'No moves scheduled yet';

  @override
  String get ngCreateFirstOrder => 'Create your first order';

  @override
  String get ngNoLeadsYet => 'No leads yet';

  @override
  String get ngAddLead => 'Add a lead';

  @override
  String get ngAllLeads => 'All leads';

  @override
  String get ngConversion => 'Conversion';

  @override
  String get ngOpen => 'Open';

  @override
  String get ngOther => 'Other';

  @override
  String get ngSurveyResponse => 'Survey response received';

  @override
  String get ngFollowUpOverdue => 'Follow-up overdue';

  @override
  String get ngCall => 'Call';

  @override
  String get ngWhatsApp => 'WhatsApp';

  @override
  String get ngSurvey => 'Survey';

  @override
  String get ngNewLead => 'New lead';

  @override
  String get ngNameOrPhone => 'Name or phone';

  @override
  String get ngNoLeadsMatch => 'No leads match';

  @override
  String get ngLeadsEmptyHint =>
      'Add an enquiry with New lead and it will show up here.';

  @override
  String get ngSurveyLinkCreated => 'Survey link created';

  @override
  String get ngCopyClose => 'Copy & close';

  @override
  String get ngClose => 'Close';

  @override
  String get ngTabAll => 'All';

  @override
  String get ngTabPending => 'Pending';

  @override
  String get ngTabCompleted => 'Completed';

  @override
  String get ngTabCancelled => 'Cancelled';

  @override
  String get ngToday => 'Today';

  @override
  String get ngTomorrow => 'Tomorrow';

  @override
  String get ngYesterday => 'Yesterday';

  @override
  String get ngNoMoveDate => 'No move date';

  @override
  String get ngPaid => 'Paid';

  @override
  String get ngPartPaid => 'Part paid';

  @override
  String get ngDue => 'Due';

  @override
  String get ngUnpaid => 'Unpaid';

  @override
  String get ngNewOrder => 'New order';

  @override
  String get ngNoOrdersHere => 'No orders here';

  @override
  String get ngRemind => 'Remind';

  @override
  String get ngRecord => 'Record';

  @override
  String get ngOverdue => 'Overdue';

  @override
  String get ngUpcoming => 'Upcoming';

  @override
  String get ngNothingToCollect => 'Nothing to collect';

  @override
  String get ngLinkedDevice => 'Linked device';

  @override
  String get ngEnterPin => 'Enter your 4-digit PIN';

  @override
  String get ngVerifying => 'Verifying…';

  @override
  String get ngUseEmail => 'Use email login instead';

  @override
  String get ngSwitchDevice => 'Not your organization? Switch device';

  @override
  String get ngSecuredBy => 'Secured by Nagarva';

  @override
  String get suCreate => 'Create your business account';

  @override
  String suStep(String n) {
    return 'Step $n of 4';
  }

  @override
  String get suS1 => 'Mobile';

  @override
  String get suS2 => 'Business';

  @override
  String get suS3 => 'Documents';

  @override
  String get suS4 => 'Review';

  @override
  String get suPhS => 'Use the owner\'s number. You will log in with it.';

  @override
  String get suPh => 'Mobile number';

  @override
  String get suSend => 'Send OTP';

  @override
  String get suPhBad => 'Enter a 10-digit mobile number';

  @override
  String get suOtpT => 'Enter the OTP';

  @override
  String suOtpS(String p) {
    return 'Sent to +91 $p';
  }

  @override
  String get suEnter => 'Type the 6-digit code';

  @override
  String get suVerify => 'Verify';

  @override
  String get suOtpBad => 'Enter the 6-digit OTP';

  @override
  String get suResend => 'Resend OTP';

  @override
  String get suResent => 'OTP sent again';

  @override
  String get suChange => 'Change number';

  @override
  String get suBzT => 'About your business';

  @override
  String get suBzS =>
      'This appears on your quotes and invoices. You can change it later.';

  @override
  String get suName => 'Business name';

  @override
  String get suNameP => 'e.g. Arun Packers & Movers';

  @override
  String get suOwner => 'Owner name';

  @override
  String get suEmail => 'Email (optional)';

  @override
  String get suEmailP => 'For invoices and password reset';

  @override
  String get suCity => 'City';

  @override
  String get suType => 'What do you do?';

  @override
  String get suTPm => 'Packers & movers';

  @override
  String get suTPmS => 'House and office shifting';

  @override
  String get suTTr => 'Transport';

  @override
  String get suTTrS => 'Trucks, trips and LR';

  @override
  String get suTBo => 'Both';

  @override
  String get suTBoS => 'Shifting and transport';

  @override
  String get suGst => 'GSTIN (optional)';

  @override
  String get suGstP => '15-character GST number';

  @override
  String get suRef => 'Referral code (optional)';

  @override
  String get suNeedBz => 'Fill business name, owner name and city';

  @override
  String get suGstBad => 'GSTIN should be 15 characters';

  @override
  String get suEmailBad => 'Check the email address';

  @override
  String get suDcT => 'Verify your business';

  @override
  String get suDcS =>
      'Photos or PDFs. Our team checks these before your account goes live.';

  @override
  String get suPan => 'PAN card';

  @override
  String get suPanS => 'Owner or business PAN';

  @override
  String get suGstC => 'GST certificate';

  @override
  String get suGstCS => 'Needed because you added a GSTIN';

  @override
  String get suShop => 'Office or godown photo';

  @override
  String get suShopS => 'Helps us verify faster';

  @override
  String get suUpload => 'Upload';

  @override
  String get suReq => 'Required';

  @override
  String get suOpt => 'Optional';

  @override
  String get suNeedPan => 'Upload your PAN card';

  @override
  String get suNeedGstC => 'Upload the GST certificate or remove the GSTIN';

  @override
  String get suPriv =>
      'Documents are used only to verify your business. They are not shown to your staff or customers.';

  @override
  String get suRvT => 'Check and submit';

  @override
  String get suEdit => 'Edit';

  @override
  String get suNext => 'What happens next';

  @override
  String get suN1 =>
      'Our team checks your details, usually within 1 working day.';

  @override
  String get suN3 => 'You start on the Free plan. Upgrade any time.';

  @override
  String get suNeedAgree => 'Accept the terms to continue';

  @override
  String get suSubmit => 'Submit for approval';

  @override
  String get suContinue => 'Continue';

  @override
  String get suMob => 'Mobile';

  @override
  String get suBt => 'Business type';

  @override
  String get suNone => 'Not added';

  @override
  String get suPendT => 'Application under review';

  @override
  String suAppId(String id) {
    return 'Application $id';
  }

  @override
  String get suTl1 => 'Submitted';

  @override
  String get suTl2 => 'Documents check';

  @override
  String get suTl3 => 'Account ready';

  @override
  String get suOkT => 'Your account is ready';

  @override
  String suOkS(String b) {
    return '$b is approved. Choose how you want to start.';
  }

  @override
  String get suStart => 'Start using Nagarva';

  @override
  String get suNoT => 'Changes needed';

  @override
  String get suNoS =>
      'Our team could not approve the application yet. Fix the item below and submit again.';

  @override
  String get suFix => 'Fix and resubmit';

  @override
  String get suWa => 'Chat with us on WhatsApp';

  @override
  String get suToLogin => 'Back to login';

  @override
  String get suHave => 'Already have an account?';

  @override
  String get suLogin => 'Log in';

  @override
  String get suBnP => 'Application under review';

  @override
  String get suBnOk => 'Account approved';

  @override
  String get suBnNo => 'Changes needed on your application';

  @override
  String get suView => 'View';

  @override
  String get suSent => 'Application submitted';

  @override
  String get lgTerms => 'Terms of use';

  @override
  String get lgPriv => 'Privacy policy';

  @override
  String suTrT(String n) {
    return 'Try Pro free for $n days';
  }

  @override
  String suTrUsers(String n) {
    return 'Up to $n users';
  }

  @override
  String get suTrOrdersAll => 'Unlimited orders every month';

  @override
  String suTrOrders(String n) {
    return '$n orders a month';
  }

  @override
  String get suTrReports => 'Reports and P&L';

  @override
  String get suTrBranches => 'Multiple branches';

  @override
  String suTrNote(String n) {
    return 'No card needed. After $n days you move to the Free plan automatically. Your data stays.';
  }

  @override
  String suTrBtn(String n) {
    return 'Start $n-day Pro trial';
  }

  @override
  String get suStayFree => 'Stay on Free';

  @override
  String suTrOn(String n) {
    return 'Pro trial started · $n days';
  }

  @override
  String get suFreeOn => 'You are on the Free plan';

  @override
  String plTrBan(String n) {
    return 'Pro trial ends in $n days. Then you move to the Free plan. Your data stays.';
  }

  @override
  String get plTrEnded =>
      'Your Pro trial has ended. You are on the Free plan and all your data is safe.';

  @override
  String plTrEnds(String d, String n) {
    return 'Pro trial ends on $d · $n days left';
  }

  @override
  String get suN2b =>
      'Log in with this mobile number any time to check your status.';

  @override
  String suPendS2(String p) {
    return 'We usually reply within 1 working day. Log in with +91 $p to see the result.';
  }

  @override
  String get suOtpUnavailable =>
      'Mobile sign-up is not switched on yet. Please contact Nagarva support.';

  @override
  String get suSendFailed =>
      'Could not send the OTP. Check the number and try again.';

  @override
  String get suOtpFailed => 'That code did not work. Check it and try again.';

  @override
  String get suUploadFailed => 'Upload failed. Try again.';

  @override
  String get suMobileLogin => 'Log in with mobile number';

  @override
  String get suRefresh => 'Check status';

  @override
  String suResendIn(String n) {
    return 'Resend in ${n}s';
  }

  @override
  String get suAgreeLead => 'I agree to the';

  @override
  String get ngGreetMorning => 'Good morning';

  @override
  String get ngGreetAfternoon => 'Good afternoon';

  @override
  String get ngGreetEvening => 'Good evening';

  @override
  String ngPlanName(String plan) {
    return '$plan plan';
  }

  @override
  String get ngPlanActive => 'Active';

  @override
  String get ngPlanTrial => 'Trial';

  @override
  String get ngPlanEndingSoon => 'Ending soon';

  @override
  String get ngPlanEnded => 'Ended';

  @override
  String ngPlanTrialEnds(String date, int days) {
    return 'Trial ends $date · $days days left';
  }

  @override
  String ngPlanReadOnlyIn(int days) {
    return 'Trial ended · view only in $days days';
  }

  @override
  String get ngPlanReadOnly => 'Trial ended · view only';

  @override
  String get ngPlanNoExpiry => 'No expiry date';

  @override
  String get ngPlanSee => 'Plans';

  @override
  String get ngPaymentsDue => 'Payments due';

  @override
  String ngPaymentsDueSub(int n) {
    return '$n orders not fully paid';
  }

  @override
  String get ngOverdueFollowUps => 'Overdue follow-ups';

  @override
  String get ngOverdueFollowUpsSub => 'Call these first';

  @override
  String get ngTodaysPlan => 'Today\'s plan';

  @override
  String get ngNothingToday => 'Nothing planned for today';

  @override
  String get ngComingUp => 'Coming up';

  @override
  String ngAgendaMove(String name) {
    return 'Move · $name';
  }

  @override
  String get ngAllDay => 'All day';

  @override
  String get ngPeriodThisMonth => 'This month';

  @override
  String get ngPeriodLastMonth => 'Last month';

  @override
  String get ngPeriod3m => 'Last 3 months';

  @override
  String get ngPeriodFy => 'This financial year';

  @override
  String get ngPeriodAll => 'All time';

  @override
  String get ngPickPeriod => 'Show figures for';

  @override
  String get ngProfitTarget => 'Profit target';

  @override
  String get ngSetTarget => 'Set a monthly profit target';

  @override
  String get ngSetTargetSub => 'Tap to set the number you want to reach';

  @override
  String get ngProfit => 'Profit';

  @override
  String ngProfitAfter(String labour, String expenses) {
    return 'After labour $labour and expenses $expenses';
  }

  @override
  String get ngAddExpense => 'Add expense';

  @override
  String get ngSeeAll => 'See all';

  @override
  String get ngHotLeads => 'Hot leads';

  @override
  String get ngBranches => 'Branches';

  @override
  String ngOrdersN(int n) {
    return '$n orders';
  }

  @override
  String get ngTargetDone => 'Target met';

  @override
  String get ngNoProfitYet => 'No profit yet this period';

  @override
  String get ngEditTarget => 'Monthly profit target';

  @override
  String get ngQuote => 'Quote';

  @override
  String get ngTabDone => 'Done';

  @override
  String get ngReceived => 'Received';

  @override
  String ngDaysLate(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n days late',
      one: '1 day late',
    );
    return '$_temp0';
  }

  @override
  String get ngNoPaymentsYet => 'No payments recorded yet';

  @override
  String get ngOpsTitle => 'Operations';

  @override
  String get ngOpsNewTrip => 'New trip';

  @override
  String get ngOpsCrewsOut => 'Crews out';

  @override
  String get ngOpsVehiclesFree => 'Vehicles free';

  @override
  String get ngOpsAttention => 'Needs attention';

  @override
  String ngOpsNoCrew(String name) {
    return 'No crew · $name';
  }

  @override
  String get ngOpsAssign => 'Assign';

  @override
  String get ngOpsAssignCrew => 'Assign crew';

  @override
  String ngOpsInsuranceExpires(int n) {
    return 'Insurance expires in $n days';
  }

  @override
  String get ngOpsInsuranceExpired => 'Insurance expired';

  @override
  String ngOpsLowStock(String name) {
    return '$name running low';
  }

  @override
  String ngOpsStockLeft(String qty) {
    return '$qty left';
  }

  @override
  String get ngOpsReorder => 'Reorder';

  @override
  String get ngOpsView => 'View';

  @override
  String get ngOpsAwaiting => 'Awaiting approval';

  @override
  String get ngOpsJobs => 'Jobs';

  @override
  String get ngOpsNoJobs => 'No moves on this day';

  @override
  String get ngOpsFleet => 'Fleet';

  @override
  String ngOpsFleetSummary(int free, int total) {
    return '$free of $total free';
  }

  @override
  String get ngOpsInService => 'In service';

  @override
  String get ngOpsOnJob => 'On a job';

  @override
  String get ngOpsFree => 'Free';

  @override
  String ngExpCount(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n expenses',
      one: '1 expense',
    );
    return '$_temp0';
  }

  @override
  String ngExpVsLast(int pct) {
    return '$pct% vs last month';
  }

  @override
  String get ngExpThisWeek => 'This week';

  @override
  String get ngExpOrderOnly => 'Order-linked only';

  @override
  String get ngExpNone => 'No expenses in this period';

  @override
  String get ngExpUncategorised => 'Uncategorised';

  @override
  String get ngExpDelete => 'Delete expense';

  @override
  String get ngExpByCategory => 'By category';

  @override
  String get ngExpNoCat => 'Nothing to break down yet';

  @override
  String get ngExpNoCatSub =>
      'Categories appear here once you record an expense.';

  @override
  String get ngFleetNew => 'New vehicle';

  @override
  String get ngFleetActive => 'Active';

  @override
  String get ngFleetMaintenance => 'Maintenance';

  @override
  String get ngFleetInactive => 'Inactive';

  @override
  String get ngFleetNone =>
      'No vehicles yet. Add one to track documents and trips.';

  @override
  String get ngFleetDelete => 'Delete vehicle';

  @override
  String get ngFleetInsurance => 'Insurance';

  @override
  String get ngFleetPermit => 'Permit';

  @override
  String ngFleetExpires(String doc, int n) {
    return '$doc expires in $n days';
  }

  @override
  String ngFleetExpired(String doc, int n) {
    return '$doc expired $n days ago';
  }

  @override
  String get ngMatNew => 'New material';

  @override
  String get ngMatSearch => 'Search materials';

  @override
  String get ngMatReorderSoon => 'Reorder soon';

  @override
  String get ngMatReturnable => 'Returnable';

  @override
  String ngMatMin(String n) {
    return 'min $n';
  }

  @override
  String get ngMatDelete => 'Delete material';

  @override
  String get ngMatNone => 'No materials here yet';

  @override
  String get ngTripPlanned => 'Planned';

  @override
  String get ngTripOngoing => 'Ongoing';

  @override
  String get ngTripNone => 'No trips yet';

  @override
  String get ngTripNoNumber => '(no trip no.)';

  @override
  String get ngTripHired => 'Hired';

  @override
  String get ngTripOwn => 'Own';

  @override
  String get ngTripDelete => 'Delete trip';

  @override
  String ngCustCount(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n customers',
      one: '1 customer',
    );
    return '$_temp0';
  }

  @override
  String get ngCustNew => 'New';

  @override
  String get ngCustSearch => 'Search name, phone or company';

  @override
  String get ngCustNone => 'No customers found';

  @override
  String ngCustDue(String amount) {
    return '$amount due';
  }

  @override
  String get ngStaffTitle => 'Staff';

  @override
  String ngStaffSummary(int n, int monthly, int other) {
    return '$n people · $monthly monthly · $other daily / temporary';
  }

  @override
  String get ngStaffAdd => 'Add staff';

  @override
  String get ngStaffMonthly => 'Fixed monthly';

  @override
  String get ngStaffDaily => 'Daily';

  @override
  String get ngStaffTemporary => 'Temporary';

  @override
  String ngStaffJoined(String date) {
    return 'Joined $date';
  }

  @override
  String get ngStaffAllRoles => 'All roles';

  @override
  String get ngStaffNone => 'No staff here yet';

  @override
  String get ngStaffInactive => 'Inactive';

  @override
  String get ngSalTitle => 'Salary';

  @override
  String get ngSalToPay => 'To pay';

  @override
  String get ngSalAdvances => 'Advances';

  @override
  String get ngSalPaid => 'Salary paid';

  @override
  String get ngSalBalance => 'Balance';

  @override
  String ngSalJobs(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n jobs',
      one: '1 job',
    );
    return '$_temp0';
  }

  @override
  String ngSalAdvance(String amount) {
    return 'Advance $amount';
  }

  @override
  String get ngSalNote =>
      'Earnings come from the crew entered on each job this month. Open a person to pay or give an advance.';

  @override
  String get ngSetApp => 'App';

  @override
  String get ngSetLanguage => 'Language';

  @override
  String get ngSetTheme => 'Theme';

  @override
  String get ngSetThemeLight => 'Light';

  @override
  String get ngSetThemeDark => 'Dark';

  @override
  String get ngSetThemeMidnight => 'Midnight';

  @override
  String get ngSetNotifications => 'Notifications';

  @override
  String get ngSetNotificationsSub => 'Show alerts while the app is open';

  @override
  String get ngSetBusiness => 'Business';

  @override
  String get ngSetBizDetails => 'Business details';

  @override
  String get ngSetBizDetailsSub =>
      'Name, tagline, GST, address, logo, signature, terms, numbering';

  @override
  String get ngSetCft => 'CFT & packages';

  @override
  String get ngSetCftSub => 'Item volumes, house sizes and storage rates';

  @override
  String get ngSetSecurity => 'Security';

  @override
  String get ngSetLogin => 'Login & security';

  @override
  String get ngSetLoginSub => 'Your app PIN';

  @override
  String get ngSetAccount => 'Account & support';

  @override
  String get ngSetPlan => 'Plan & billing';

  @override
  String get ngSetPlanSub => 'Your plan and its limits';

  @override
  String get ngSetRecycle => 'Deleted items';

  @override
  String get ngSetRecycleSub => 'Restore anything deleted by mistake';

  @override
  String get ngSetHelp => 'Help & support';

  @override
  String get ngSetHelpSub => 'Support contact, privacy policy and terms';

  @override
  String get ngSetPorter => 'Porter integration';

  @override
  String get ngSetPorterSub =>
      'Show Porter commission on the dashboard. Turn on only if your business uses Porter.';

  @override
  String odStageOf(int n, int total, String name) {
    return 'Stage $n of $total · $name';
  }

  @override
  String get odJourneyDone => 'All stages done';

  @override
  String get odMaps => 'Maps';

  @override
  String get odProgress => 'Progress';

  @override
  String get odInProgress => 'In progress';

  @override
  String odMarkAs(String stage) {
    return 'Mark as $stage';
  }

  @override
  String get odDeliveredHint =>
      'Delivered is recorded when the crew finishes the job with the customer\'s code.';

  @override
  String get odOpenFieldJob => 'Open field job';

  @override
  String get odCrewVehicle => 'Crew & vehicle';

  @override
  String get odNoCrew => 'No crew assigned yet';

  @override
  String get odNoVehicle => 'No vehicle assigned';

  @override
  String odSupervisorCrew(String name, int count) {
    return 'Supervisor · $name · $count crew';
  }

  @override
  String odCrewCount(int count) {
    return '$count crew';
  }

  @override
  String get odPayment => 'Payment';

  @override
  String get odTotal => 'Total';

  @override
  String get odPaid => 'Paid';

  @override
  String get odBalance => 'Balance';

  @override
  String get odPartPaid => 'Part paid';

  @override
  String get odFullyPaid => 'Paid';

  @override
  String get odUnpaid => 'Unpaid';

  @override
  String get odRemind => 'Remind';

  @override
  String get odRecordPayment => 'Record payment';

  @override
  String get odActivity => 'Activity';

  @override
  String odAllN(int count) {
    return 'All $count';
  }

  @override
  String get odStageChanged => 'Stage changed';

  @override
  String odPaymentReceived(String amount) {
    return 'Payment received · $amount';
  }

  @override
  String get odNoActivity => 'Nothing recorded on this order yet.';

  @override
  String get odMoveDetails => 'Move details';

  @override
  String get odCancelled => 'Cancelled';

  @override
  String get odMore => 'More actions';

  @override
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor) {
    return 'Hi $customer, a balance of $amount is due for your move ($orderId). Thank you, $vendor';
  }

  @override
  String get odStConfirmed => 'Confirmed';

  @override
  String get odStPacking => 'Packing';

  @override
  String get odStInTransit => 'In transit';

  @override
  String get odStArrived => 'Arrived';

  @override
  String get odStDelivered => 'Delivered';

  @override
  String get odStCompleted => 'Completed';

  @override
  String get nlPhone => 'Phone';

  @override
  String get nlName => 'Name';

  @override
  String get nlRoute => 'Route';

  @override
  String get nlMovingFrom => 'Moving from';

  @override
  String get nlMovingTo => 'Moving to';

  @override
  String get nlService => 'Service';

  @override
  String get nlWhen => 'When';

  @override
  String get nlToday => 'Today';

  @override
  String get nlTomorrow => 'Tomorrow';

  @override
  String get nlPickDate => 'Pick date';

  @override
  String get nlSource => 'Source';

  @override
  String get nlBranch => 'Branch';

  @override
  String get nlNextStep => 'Next step';

  @override
  String get nlStepFollow => 'Follow-up';

  @override
  String get nlStepFollowSub => 'Call again later';

  @override
  String get nlStepSurvey => 'Survey';

  @override
  String get nlStepSurveySub => 'Visit, link or on call';

  @override
  String get nlStepQuote => 'Skip survey · Quote';

  @override
  String get nlStepQuoteSub => 'Price on this call';

  @override
  String get nlStepConfirm => 'Confirm order';

  @override
  String get nlStepConfirmSub => 'Customer agreed now';

  @override
  String get nlMore => 'More details';

  @override
  String get nlEmail => 'Email (optional)';

  @override
  String get nlNotes => 'Notes';

  @override
  String get nlNameRequired => 'Enter the customer\'s name.';

  @override
  String get nlNoBranches => 'Add a branch in Settings before saving leads.';

  @override
  String get nlUpdateLead => 'Update lead';

  @override
  String get noPickup => 'Pickup';

  @override
  String get noDrop => 'Drop';

  @override
  String get noPricing => 'Price & source';

  @override
  String get ngSetFy => 'Financial year & numbering';

  @override
  String get ngSetFySub => 'Start next year\'s invoice and receipt numbers';

  @override
  String get ngSetWa => 'WhatsApp';

  @override
  String get ngSetWaSub => 'Send messages from your own number';

  @override
  String get ngSetAutoWa => 'Auto WhatsApp';

  @override
  String get ngSetAutoWaSub => 'Messages sent to the customer at each stage';

  @override
  String get mdTitle => 'Modules';

  @override
  String get mdSettingsSub => 'Packers & movers, transport or both';

  @override
  String get mdType => 'Your business';

  @override
  String get mdAdv => 'Advanced';

  @override
  String mdCount(int count, int total) {
    return '$count of $total modules on';
  }

  @override
  String mdGroupOn(int count, int total) {
    return '$count of $total on';
  }

  @override
  String get mdNote =>
      'Turned-off modules disappear from the menu. Your data stays saved and comes back when you turn the module on again.';

  @override
  String get mdReset => 'Reset to recommended for this business type';

  @override
  String mdResetDone(String type) {
    return 'Modules reset for $type';
  }

  @override
  String mdTypeSet(String type) {
    return '$type selected · menu updated';
  }

  @override
  String get mdOwnerOnly => 'Only the owner can change modules';

  @override
  String get mdSaveFailed =>
      'Could not save. Check your connection and try again.';

  @override
  String get btPm => 'Packers & Movers';

  @override
  String get btPmS => 'House, office and vehicle shifting';

  @override
  String get btTr => 'Transport / Logistics';

  @override
  String get btTrS => 'Trucks, trips, freight and drivers';

  @override
  String get btBoth => 'Both';

  @override
  String get btBothS => 'Shifting and transport, everything on';

  @override
  String get btTitle => 'What does your business do?';

  @override
  String get btSub =>
      'We will show only the modules you need. You can change this any time in Settings › Modules.';

  @override
  String get btLater => 'You can change this later in Settings › Modules';

  @override
  String get dwTitle => 'Widgets';

  @override
  String get dwSub => 'Choose what the owner dashboard shows';

  @override
  String get dwNote =>
      'Owner dashboard shows these in this order. Use the arrow to move one up, the switch to hide it.';

  @override
  String dwShown(int n) {
    return 'Shown · position $n';
  }

  @override
  String get dwHidden => 'Hidden';

  @override
  String get dwUp => 'Up';

  @override
  String get dwToday => 'Today\'s numbers';

  @override
  String get dwFleet => 'Fleet status';

  @override
  String dwFleetSub(int a, int s) {
    return '$a active · $s in service';
  }

  @override
  String get dwAttendance => 'Staff attendance';

  @override
  String get dwAttendanceSub => 'checked in today';

  @override
  String get dwSaveFailed =>
      'Could not save. Check your connection and try again.';

  @override
  String get jrShareInvoice => 'Share invoice';

  @override
  String get jrSendForSignature => 'Send for signature';

  @override
  String get lsTitle => 'Login & security';

  @override
  String get lsMy => 'Your login';

  @override
  String get lsMyEmail => 'Login email';

  @override
  String get lsChangePw => 'Change password';

  @override
  String get lsCurPw => 'Current password';

  @override
  String get lsNewPw => 'New password';

  @override
  String get lsConfPw => 'Confirm new password';

  @override
  String get lsPwSub => 'Use at least 8 characters';

  @override
  String get lsPwShort => 'Password must be at least 8 characters';

  @override
  String get lsPwMismatch => 'Passwords do not match';

  @override
  String get lsPwCurReq => 'Enter your current password';

  @override
  String get lsPwDone => 'Password updated';

  @override
  String get lsUpdatePw => 'Update password';

  @override
  String get lsForgot =>
      'Forgot your password? Use \"Forgot password?\" on the login screen. We email you a reset link.';

  @override
  String get lsStaffPins => 'Staff PINs';

  @override
  String get lsStaffPinsSub =>
      'Staff and supervisors log in with a PIN. Set a new one if they forget it. Repeated wrong tries lock the PIN until you reset it.';

  @override
  String get lsResetPin => 'Reset PIN';

  @override
  String get lsPinSet => 'PIN set';

  @override
  String lsLocked(int n) {
    return 'Locked · $n wrong tries';
  }

  @override
  String get lsNewPin => 'New PIN';

  @override
  String get lsConfPin => 'Confirm PIN';

  @override
  String get lsPinBad => 'PIN must be 4 digits';

  @override
  String get lsPinMismatch => 'PINs do not match';

  @override
  String lsPinSetFor(String name) {
    return 'New PIN set for $name';
  }

  @override
  String get lsTellStaff =>
      'Tell the staff member their new PIN in person or by phone. It is never shown again.';

  @override
  String get lsSetPin => 'Set new PIN';

  @override
  String get lsSignOutAll => 'Sign out all other devices';

  @override
  String get lsAllOut => 'All other devices signed out';

  @override
  String get lsNoPin => 'No PIN yet';

  @override
  String get lsOwnerOnly => 'Only the owner can reset staff PINs.';

  @override
  String get qdTitle => 'Quote design';

  @override
  String get qdSub => 'How your quotation PDF looks to customers.';

  @override
  String get qdTheme => 'Theme';

  @override
  String get qdColor => 'Brand colour';

  @override
  String get qdLogo => 'Logo';

  @override
  String get qdLogoAdd => 'Upload logo';

  @override
  String get qdLogoHint => 'PNG or JPG, square works best';

  @override
  String get qdSave => 'Save design';

  @override
  String get qdPreview => 'Preview sample PDF';

  @override
  String get qdSaved => 'Quote design saved';

  @override
  String get qdTheme1A => 'Classic';

  @override
  String get qdTheme1B => 'Bold band';

  @override
  String get qdTheme1C => 'Sidebar';

  @override
  String get qdTheme1D => 'Minimal';

  @override
  String get qdTheme1E => 'Corporate';

  @override
  String get qdTheme1F => 'Letterhead';

  @override
  String get qdThemeDesc1A => 'Serif, ruled lines';

  @override
  String get qdThemeDesc1B => 'Colour header, rounded panels';

  @override
  String get qdThemeDesc1C => 'Details column on the left';

  @override
  String get qdThemeDesc1D => 'Black and white, prints anywhere';

  @override
  String get qdThemeDesc1E => 'Boxed form, for office moves';

  @override
  String get qdThemeDesc1F => 'Centred, double rule';

  @override
  String get drvTitle => 'Driver app';

  @override
  String get drvNone => 'No trip assigned today';

  @override
  String get drvPlanned => 'Planned';

  @override
  String get drvOngoing => 'On trip';

  @override
  String get drvStart => 'Start trip';

  @override
  String get drvEnd => 'End trip';

  @override
  String get drvDone => 'Trip completed';

  @override
  String get drvFuel => 'Fuel';

  @override
  String get drvFuelT => 'Add fuel';

  @override
  String get drvToll => 'Toll';

  @override
  String get drvTollT => 'Add toll';

  @override
  String get drvLitres => 'Litres';

  @override
  String get drvPlaza => 'Plaza';

  @override
  String get drvAdd => 'Add entry';

  @override
  String get drvNeedStart => 'Enter start odometer';

  @override
  String get drvNeedEnd => 'End odometer must be more than start';

  @override
  String get drvNeedAmount => 'Enter the amount';

  @override
  String get drvTripKm => 'Trip km';

  @override
  String get drvTripSpend => 'Trip spend';

  @override
  String get drvToday => 'Today’s entries';

  @override
  String get drvOdoStart => 'Start odometer';

  @override
  String get drvOdoEnd => 'End odometer';

  @override
  String get mktTitle => 'Nagarva jobs';

  @override
  String get mktSub => 'Moves booked by customers on Nagarva';

  @override
  String get mktTier => 'Your tier';

  @override
  String get mktWallet => 'Wallet';

  @override
  String mktMinL(String m) {
    return 'Min $m to get jobs';
  }

  @override
  String get mktLowS => 'Below minimum';

  @override
  String get mktTJobs => 'Jobs';

  @override
  String get mktTWallet => 'Wallet';

  @override
  String get mktTTier => 'Tier';

  @override
  String get mktAv => 'Available for jobs';

  @override
  String mktAvOn(String c) {
    return 'Getting job alerts for $c';
  }

  @override
  String get mktAvOff => 'Off. No new job alerts. Your score is not affected.';

  @override
  String get mktCities => 'Pickup cities';

  @override
  String get mktCitiesN =>
      'You get alerts for bookings that start in these cities. Home city cannot be removed.';

  @override
  String get mktEdit => 'Edit';

  @override
  String get mktDone2 => 'Done';

  @override
  String get mktCancel => 'Cancel';

  @override
  String get mktHome => 'home';

  @override
  String get mktRtAsk => 'Truck in another city?';

  @override
  String get mktRtAdd => 'Add';

  @override
  String get mktRtEnd => 'End';

  @override
  String get mktRtFrom => 'Truck is now in';

  @override
  String get mktRtDate => 'Leaving on';

  @override
  String mktRtOn(String f, String t) {
    return 'Return trip · $f → $t';
  }

  @override
  String get mktRtEnded => 'Return trip ended';

  @override
  String get mktFNew => 'New';

  @override
  String get mktFAcc => 'Accepted';

  @override
  String get mktFDone => 'Completed';

  @override
  String get mktENew =>
      'No new jobs right now. You will get a notification when one comes in.';

  @override
  String get mktEAcc => 'No accepted jobs.';

  @override
  String get mktEDone => 'No completed jobs yet.';

  @override
  String get mktEOff =>
      'You are not available. Turn on Available for jobs to see new bookings.';

  @override
  String mktLow(String a, String m) {
    return 'Wallet is below $m. Top up $a to see new jobs.';
  }

  @override
  String get mktVal => 'Job value (incl. GST)';

  @override
  String mktCom(String p) {
    return 'Nagarva commission $p%';
  }

  @override
  String get mktEarn => 'You earn';

  @override
  String get mktAdv => 'Advance paid to Nagarva';

  @override
  String get mktBal => 'Collect after delivery OTP';

  @override
  String get mktMasked => 'Customer name and phone unlock after you accept';

  @override
  String get mktPass => 'Pass';

  @override
  String get mktAccept => 'Accept job';

  @override
  String mktAccepted(String id) {
    return '$id is yours. Customer details unlocked.';
  }

  @override
  String get mktPassed => 'Job passed';

  @override
  String get mktTaken => 'Taken by another vendor';

  @override
  String get mktGoldOnly => 'Gold only';

  @override
  String get mktRl => 'Return load';

  @override
  String get mktS0 => 'Accepted';

  @override
  String get mktS1 => 'On the way';

  @override
  String get mktS2 => 'Arrived';

  @override
  String get mktS3 => 'Loading';

  @override
  String get mktS4 => 'In transit';

  @override
  String get mktS5 => 'Delivered';

  @override
  String mktNext(String s) {
    return 'Mark $s';
  }

  @override
  String mktPhotos(int n) {
    return 'Loading photos $n/3';
  }

  @override
  String get mktNeedPh => 'Add 3 loading photos first';

  @override
  String get mktAddPh => 'Add photo';

  @override
  String get mktFinish => 'Verify OTP & complete';

  @override
  String get mktOtpBad => 'Wrong OTP. Check with the customer.';

  @override
  String mktDone(String a, String c) {
    return 'Completed. $c commission deducted, $a advance credited.';
  }

  @override
  String mktRate(String r) {
    return 'Customer rating $r';
  }

  @override
  String get mktNoRate => 'Awaiting customer rating';

  @override
  String get mktTopup => 'Top up';

  @override
  String get mktWBal => 'Wallet balance';

  @override
  String get mktWOk => 'Active · you get new jobs';

  @override
  String get mktWWithdraw => 'Withdraw';

  @override
  String mktWNote(String p) {
    return 'Customers pay the advance to Nagarva. When you complete a job, the advance is credited here and the $p% commission is deducted. Keep the minimum balance to receive jobs.';
  }

  @override
  String mktWtAdv(String id) {
    return 'Advance · $id';
  }

  @override
  String mktWtCom(String id) {
    return 'Commission · $id';
  }

  @override
  String get mktWtTop => 'UPI top-up';

  @override
  String get mktWtWd => 'Withdrawal to bank';

  @override
  String get mktTierF => 'How your score is made';

  @override
  String get mktTierBands => 'Gold 80+ · Silver 60–79 · Bronze <60';

  @override
  String get mktTierGold => 'Gold';

  @override
  String get mktTierSilver => 'Silver';

  @override
  String get mktTierBronze => 'Bronze';

  @override
  String mktTierScore(String s) {
    return 'Score $s / 100';
  }

  @override
  String get mktOtpAsk => 'Ask the customer for the 4-digit delivery code.';

  @override
  String get mktReqSent =>
      'Request sent. It counts once Nagarva confirms the payment.';

  @override
  String get mktPending => 'Pending';

  @override
  String get mktHomeCity => 'Home city';

  @override
  String get mktExtraCities => 'Other cities, separated by commas';

  @override
  String get mktNotJoined =>
      'Set your home city to start getting Nagarva jobs.';

  @override
  String get mktFactorNote =>
      'Nagarva works out your score from these, with these weights.';

  @override
  String get mktFRating => 'Customer rating';

  @override
  String get mktFOnTime => 'On-time arrival';

  @override
  String get mktFDamage => 'Damage claims';

  @override
  String get mktFAccept => 'Acceptance rate';

  @override
  String get mktFPhotos => 'Photo compliance';

  @override
  String get mktFCancel => 'Vendor cancellations';

  @override
  String get mktFJobs => 'Jobs completed';

  @override
  String get mktAvOnT => 'You will get job alerts again';

  @override
  String get mktAvOffT => 'Job alerts paused';
}
