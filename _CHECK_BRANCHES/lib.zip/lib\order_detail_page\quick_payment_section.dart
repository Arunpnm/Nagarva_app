import '/backend/fy_numbering.dart';
import 'package:flutter/material.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import '/backend/whatsapp_cloud.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '/backend/audit_log_service.dart';
import '/backend/customer_lookup.dart';
import '/backend/edge_function_errors.dart';
import '/backend/supabase/supabase.dart';
import '/backend/supabase/org_scope.dart';
import '/backend/upi_payment.dart';
import '/config/app_config.dart';
import '/components/ng_widgets.dart';
import '/flutter_flow/ng_tokens.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';

/// Quick Payment Update — Order Details Session 1, item 2.
///
/// A lighter, order-scoped sibling of RecordPaymentPage (which already
/// exists, pre-dates this session, and stays as-is for the cross-order
/// collection workflow off the Payments tab). This section embeds the same
/// underlying mechanism directly in Order Details so recording a payment
/// doesn't require leaving the page: insert into `payment_entries`, and
/// `orders.paid_total`/`payment_status` update themselves via the DB
/// trigger from 20260718_payment_entries.sql — this widget never writes
/// those two columns directly.
///
/// Two things RecordPaymentPage's flow does NOT do, which this adds:
///   1. Mints a receipt number via `next_doc_number(org, 'receipt', branch,
///      fy)` for the confirmation toast and the ledger narration. The
///      kickoff brief is explicit that this session ships no new SQL
///      ("the schema is complete... report rather than write a
///      migration"). `payment_entries` DOES have a `receipt_no`
///      column and this method writes it (see below) - the note that
///      it has none was wrong, corrected 2 Sep 2026 —
///      so the number is consumed from the series (it will not be handed
///      out again) but not persisted on the row. The Documents grid's
///      Money Receipt document (item 4) is the durable, printable record
///      of a specific receipt number; this is just the in-the-moment
///      confirmation.
///   2. A `ledger_entries` row (party_type customer, credit = amount
///      collected) for AR/statement reporting. Requires a real
///      `customers.id` (`party_id` is NOT NULL) — resolved via
///      [CustomerLookup.findOrCreate], same helper new_order_page now
///      calls at creation. If the order still has no usable phone, the
///      ledger post is skipped (payment + receipt still succeed) — see
///      CustomerLookup's doc comment for why a junk phone must never mint
///      a customer row.
class QuickPaymentSection extends StatefulWidget {
  const QuickPaymentSection({super.key, required this.orderId, this.onSaved});

  final String orderId;

  /// Fired after a successful save — this section is embedded inline
  /// (not pushed as its own route), so OrderDetailPage's onPageRefresh
  /// (which only fires on route pop) can't catch this write on its own.
  /// The brief calls for "single fan-out invalidation" of the P&L card
  /// after a payment; this callback is that fan-out.
  final VoidCallback? onSaved;

  @override
  State<QuickPaymentSection> createState() => QuickPaymentSectionState();
}

class QuickPaymentSectionState extends State<QuickPaymentSection> {
  bool _loading = true;
  bool _saving = false;
  bool _requesting = false;
  bool _notFound = false;
  OrdersRow? _order;
  String _mode = 'cash';
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  double get _balance {
    final o = _order;
    if (o == null) return 0;
    // paid_total is the whole of money-in: the sync_order_paid_total
    // trigger sums payment_entries onto it. `- advance_paid` was removed
    // 16 Sept 2026 (see CLAUDE.md) - it was 0 on every live order, so
    // this is the same number today, and one source instead of two.
    return (o.amount ?? 0) - o.paidTotal;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  /// Public so OrderDetailPage's onPageRefresh can re-pull balance after an
  /// external write (e.g. an edit to orders.amount) — same GlobalKey wiring
  /// as OrderPnlSection/QuotationBreakdownSection.
  Future<void> reload() => _load();

  Future<void> _load() async {
    if (!mounted) return;
    setState(() => _loading = true);
    try {
      final rows = await OrdersTable().queryRows(
        queryFn: (q) => OrgScope.read(q).eq('id', widget.orderId),
      );
      if (!mounted) return;
      setState(() {
        _order = rows.isNotEmpty ? rows.first : null;
        _notFound = rows.isEmpty;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() {
        _loading = false;
        _notFound = true;
      });
    }
  }

  // Fixed alongside OrderDetailPage.currentFy() (RLS/numbering audit, 12
  // Aug 2026) — was emitting '2627', which never matched number_series'
  // hyphenated 'YYYY-YY' seed values, so every receipt silently drew from
  // an auto-created unprefixed series instead of the intended one.
  String _currentFy() {
    final now = DateTime.now();
    final startYear = now.month >= 4 ? now.year : now.year - 1;
    return '$startYear-${((startYear + 1) % 100).toString().padLeft(2, '0')}';
  }

  Future<String?> _defaultAccountId(String orgId) async {
    try {
      final rows = await OrgScope.read(
              SupaFlow.client.from('bank_accounts').select('id,account_type'))
          .eq('is_default', true)
          .limit(1);
      if (rows.isNotEmpty) return rows.first['id'] as String?;
      // No default set — fall back to any active cash account rather than
      // leaving the payment/ledger row with no account at all.
      final cashRows = await OrgScope.read(
              SupaFlow.client.from('bank_accounts').select('id'))
          .eq('account_type', 'cash')
          .eq('active', true)
          .limit(1);
      return cashRows.isNotEmpty ? cashRows.first['id'] as String? : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _save() async {
    final o = _order;
    if (o == null) return;
    final amount = double.tryParse(_amountCtrl.text.trim()) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Enter an amount.')));
      return;
    }
    final balance = _balance;
    if (amount > balance) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('More than balance due'),
          content: Text(
              'Balance due is ₹${balance.toStringAsFixed(0)} but you entered '
              '₹${amount.toStringAsFixed(0)}. Record anyway?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                child: const Text('Record')),
          ],
        ),
      );
      if (ok != true) return;
    }

    setState(() => _saving = true);
    try {
      final orgId = OrgScope.currentOrgId!;
      final accountId = await _defaultAccountId(orgId);

      String? receiptNo;
      try {
        // One org-wide series per doc type per FY, not per-branch — see
        // order_detail_page_widget.dart's _nextInvoiceNo for the reasoning
        // (12 Aug 2026 numbering-scheme decision).
        receiptNo = await allocateWithRollover(context, () async => await SupaFlow.client.rpc('next_doc_number', params: {
          'p_org': orgId,
          'p_doc_type': 'receipt',
          'p_branch': null,
          'p_fy': _currentFy(),
        }) as String?);
      } catch (e) {
        // Was a blanket `catch (_) { receiptNo = null; }`: it recorded the
        // payment with NO receipt number and still showed a success
        // snackbar, so an unnumbered financial record could be created and
        // nobody would ever know. Every other allocator call site in this
        // app (invoice, proforma, voucher, money receipt, LR) lets the
        // exception propagate — this was the only one that hid it.
        //
        // It is also not a hypothetical: from 1 April 2027 _currentFy()
        // rolls to a FY with no number_series row and this fails on EVERY
        // payment until the rollover is run.
        //
        // Deliberately not a hard block. Item 32b's rule is that money
        // already received must always be recordable, so the vendor is
        // told exactly what failed and decides. next_doc_number RAISEs
        // P0001 (20260812_next_doc_number_fail_loud.sql), which
        // extractDbErrorMessage surfaces verbatim; anything else falls
        // back rather than leaking Postgres internals into the UI.
        if (!mounted) return;
        final reason = extractDbErrorMessage(e,
            fallback: 'The receipt number could not be generated.');
        final proceed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('No receipt number'),
            content: Text(
                '$reason\n\nRecord this ₹${amount.toStringAsFixed(0)} payment '
                'without a receipt number? You can still issue a numbered '
                'Money Receipt for it later from Documents.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(false),
                  child: const Text('Cancel')),
              FilledButton(
                  onPressed: () => Navigator.of(dialogContext).pop(true),
                  child: const Text('Record anyway')),
            ],
          ),
        );
        if (proceed != true) return;
        receiptNo = null;
      }

      await PaymentEntriesTable().insert({
        ...OrgScope.stamp(orgId: orgId),
        'order_id': o.id,
        'amount': amount,
        'mode': _mode,
        'note': _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
        if (accountId != null) 'account_id': accountId,
      });
      WhatsAppCloud.paymentReceived(
          orderId: o.id, customer: o.customer, phone: o.phone, amount: amount);

      // Resolve/backfill customer_id defensively — new_order_page now sets
      // it at creation, but orders created before that fix (or with no
      // usable phone at creation time) can still reach payment unlinked.
      var customerId = o.customerId;
      if (customerId == null) {
        customerId = await CustomerLookup.findOrCreate(
          orgId: orgId,
          name: o.customer,
          phone: o.phone,
        );
        if (customerId != null) {
          await OrdersTable().update(
            data: {'customer_id': customerId},
            matchingRows: (q) => OrgScope.write(q, orgId: orgId).eq('id', o.id!),
          );
        }
      }

      if (customerId != null) {
        await SupaFlow.client.from('ledger_entries').insert({
          'org_id': orgId,
          'party_type': 'customer',
          'party_id': customerId,
          'entry_type': 'payment',
          'ref_table': 'orders',
          'ref_id': o.id,
          'narration': receiptNo != null
              ? 'Payment received — receipt $receiptNo'
              : 'Payment received',
          'debit': 0,
          'credit': amount,
          if (accountId != null) 'account_id': accountId,
        });
      }

      await AuditLogService.log(
        entityType: 'orders',
        entityId: o.id!,
        action: 'payment_recorded',
        oldValue: {'paid_total': o.paidTotal},
        newValue: {
          'amount': amount,
          'mode': _mode,
          if (receiptNo != null) 'receipt_no': receiptNo,
        },
        changedFields: const ['paid_total', 'payment_status'],
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(receiptNo != null
            ? '₹${amount.toStringAsFixed(0)} recorded — receipt $receiptNo.'
            : '₹${amount.toStringAsFixed(0)} recorded.'),
      ));
      _amountCtrl.clear();
      _noteCtrl.clear();
      await _load();
      widget.onSaved?.call();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Could not save: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _modeChip(NgPalette ng, String value, String label,
      IconData icon) {
    final selected = _mode == value;
    return Expanded(
      child: NgOptionCard(
        icon: icon,
        title: label,
        subtitle: '',
        selected: selected,
        onTap: () => setState(() => _mode = value),
      ),
    );
  }

  // ---- Item 19 Phase 1: request payment by UPI --------------------------

  /// Builds a `upi://pay` link for this order's outstanding balance and
  /// hands it to the vendor to send on.
  ///
  /// This records NOTHING. A customer paying through the link is invisible
  /// to the app until somebody enters it above — same as cash. Phase 1 is
  /// a faster way to ask for money, not a collection pipeline, and the
  /// sheet says so rather than implying the payment will appear by itself.
  Future<void> _requestByUpi() async {
    final o = _order;
    if (o == null) return;
    setState(() => _requesting = true);
    UpiPayee? payee;
    String? error;
    try {
      payee = await resolveOrgUpiPayee();
    } catch (e) {
      error = '$e';
    }
    if (!mounted) return;
    setState(() => _requesting = false);

    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not read your UPI ID: $error')));
      return;
    }
    if (payee == null || !isPlausibleVpa(payee.vpa)) {
      await _promptForUpiId(missing: payee == null);
      return;
    }
    await _showUpiRequestSheet(payee);
  }

  /// Shown when the org has no usable UPI ID. Arun's call (Item 19): the
  /// empty state is "Set your UPI ID" and it must go somewhere — a dead
  /// message telling a vendor to find a setting themselves is the same
  /// dead end as a button that does nothing.
  Future<void> _promptForUpiId({required bool missing}) async {
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Set your UPI ID'),
        content: Text(missing
            ? 'You have not added a UPI ID yet, so there is nothing for a '
                'customer to pay to. Add it in Settings → Business Profile '
                'and it will also appear on your invoices and quotations.'
            : 'Your saved UPI ID does not look like a valid address '
                '(it should look like name@bank). Fix it in Settings → '
                'Business Profile.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Not now')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Open Settings')),
        ],
      ),
    );
    if (go == true && mounted) {
      context.pushNamed(SettingsPageWidget.routeName);
    }
  }

  Future<void> _showUpiRequestSheet(UpiPayee payee) async {
    final o = _order!;
    // Defaults to the outstanding balance and stays editable — a customer
    // paying a part amount is normal, and forcing the full balance would
    // just push the vendor back to typing the number by hand.
    final amountCtrl =
        TextEditingController(text: _balance.toStringAsFixed(0));

    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: NgPalette.of(context).sheet,
      shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(NgRadius.sheet))),
      builder: (ctx) {
        final ng = NgPalette.of(ctx);
        return Padding(
          padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: StatefulBuilder(
            builder: (ctx, setSheet) {
              final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
              final uri = buildUpiUri(
                vpa: payee.vpa,
                payeeName: payee.name,
                amount: amount,
                note: 'Order ${o.id}',
              );
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('Request payment by UPI',
                      style: NgFonts.geist(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.4,
                          color: ng.text)),
                  const SizedBox(height: 4),
                  Text('Paid to ${payee.vpa}',
                      style: NgFonts.mono(fontSize: 12.5, color: ng.mute)),
                  const SizedBox(height: 18),
                  NgFieldLabel(
                      'Amount · balance ${functions.inrFull(_balance)}'),
                  NgInput(
                    controller: amountCtrl,
                    keyboardType: TextInputType.number,
                    hint: '₹ 0',
                    mono: true,
                    onChanged: (_) => setSheet(() {}),
                  ),
                  const SizedBox(height: 18),
                  NgPrimaryButton(
                    icon: Icons.send_rounded,
                    label: 'Send on WhatsApp',
                    onPressed: amount <= 0
                        ? null
                        : () async {
                            Navigator.pop(ctx);
                            await _sendUpiOnWhatsApp(payee, amount, uri);
                          },
                  ),
                  const SizedBox(height: 8),
                  NgSecondaryButton(
                    icon: Icons.content_copy_rounded,
                    label: 'Copy UPI link',
                    height: 46,
                    onPressed: amount <= 0
                        ? null
                        : () async {
                            await Clipboard.setData(ClipboardData(text: uri));
                            if (ctx.mounted) Navigator.pop(ctx);
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('UPI link copied.')));
                          },
                  ),
                  const SizedBox(height: 12),
                  // Says plainly what this does not do. A vendor who
                  // believes a sent link auto-reconciles will stop
                  // recording payments, and their books go wrong quietly.
                  Text(
                    'Opens in the customer\'s UPI app. Payments are not '
                    'detected automatically — record it once you '
                    'receive it.',
                    style: NgFonts.geist(fontSize: 12, color: ng.mute),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
    amountCtrl.dispose();
  }

  Future<void> _sendUpiOnWhatsApp(
      UpiPayee payee, double amount, String uri) async {
    final o = _order!;
    final message = buildUpiRequestMessage(
      orgName: payee.name,
      customerName: o.customer.trim().isEmpty ? 'there' : o.customer,
      orderId: o.id ?? '',
      amount: amount,
      vpa: payee.vpa,
      upiUri: uri,
    );
    try {
      final ok = await launchUrl(
        Uri.parse(buildWhatsAppLink(phone: o.phone, message: message)),
        mode: LaunchMode.externalApplication,
      );
      if (ok) return;
    } catch (_) {
      // Fall through to the clipboard path below.
    }
    await Clipboard.setData(ClipboardData(text: message));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Could not open WhatsApp — message copied instead.')));
  }

  @override
  Widget build(BuildContext context) {
    final ng = NgPalette.of(context);
    if (_loading) {
      return NgCard(
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: const Center(
            child: SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(strokeWidth: 2))),
      );
    }
    if (_notFound || _order == null) return const SizedBox.shrink();
    if (_balance <= 0) {
      // Fully paid (or overpaid) — nothing to quick-collect. History lives
      // on RecordPaymentPage/PaymentsPage; this section is entry-only.
      return const SizedBox.shrink();
    }
    // Order Details Session 1, item 5: Mark Order Complete locks the P&L —
    // a closed order (even one Mark Complete let through with a non-zero
    // balance) must not still be quietly collectible from here.
    if ((_order!.status ?? '').toLowerCase() == 'closed') {
      return const SizedBox.shrink();
    }

    // Rendered inside the overview's bottom sheet, so laid out as a
    // sheet (title, fields, primary action) rather than a card.
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: Container(
            width: 36,
            height: 4,
            margin: const EdgeInsets.only(bottom: 14),
            decoration: BoxDecoration(
                color: ng.w15, borderRadius: BorderRadius.circular(2)),
          ),
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Text('Record payment',
                  style: NgFonts.geist(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.4,
                      color: ng.text)),
            ),
            Text('Balance ${functions.inrFull(_balance)}',
                style: NgFonts.geist(
                    fontSize: 13, fontWeight: FontWeight.w600, color: ng.acc)),
          ],
        ),
        const SizedBox(height: 18),
        const NgFieldLabel('Amount received'),
        NgInput(
          controller: _amountCtrl,
          keyboardType: TextInputType.number,
          hint: '₹ 0',
          mono: true,
        ),
        const SizedBox(height: 18),
        const NgFieldLabel('Paid by'),
        Row(
          children: [
            _modeChip(ng, 'cash', 'Cash', Icons.payments_outlined),
            const SizedBox(width: 8),
            _modeChip(ng, 'upi', 'UPI', Icons.qr_code_2_rounded),
            const SizedBox(width: 8),
            _modeChip(ng, 'bank', 'Bank', Icons.account_balance_outlined),
          ],
        ),
        const SizedBox(height: 18),
        NgInput(controller: _noteCtrl, hint: 'Note (optional)'),
        const SizedBox(height: 18),
        NgPrimaryButton(
          icon: Icons.check_circle_rounded,
          label: _saving ? 'Saving…' : 'Record payment',
          onPressed: _saving ? null : _save,
        ),
        // Item 19 Phase 1. Sits UNDER Record Payment deliberately:
        // recording money already received is the more common action
        // and stays the primary one. Asking for money is secondary.
        const SizedBox(height: 8),
        NgSecondaryButton(
          icon: Icons.qr_code_2_rounded,
          iconColor: ng.acc,
          label: _requesting ? 'Preparing…' : 'Request payment by UPI',
          height: 46,
          onPressed: _requesting ? null : _requestByUpi,
        ),
      ],
    );
  }
}
