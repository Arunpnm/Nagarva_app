// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Telugu (`te`).
class AppLocalizationsTe extends AppLocalizations {
  AppLocalizationsTe([String locale = 'te']) : super(locale);

  @override
  String get arunPackersAndCouriers => 'Arun Packers And Couriers';

  @override
  String get movingYouTowardsYourFuture =>
      'మిమ్మల్ని మీ భవిష్యత్తు వైపు తీసుకెళ్తున్నాం';

  @override
  String get nameOrPhone => 'పేరు లేదా ఫోన్';

  @override
  String get enterYourNameOrPhone => 'మీ పేరు లేదా ఫోన్ నమోదు చేయండి';

  @override
  String get pin => 'PIN';

  @override
  String get n4DigitPin => '4 అంకెల PIN';

  @override
  String get login => 'లాగిన్';

  @override
  String get securedEncrypted => 'సురక్షితం & ఎన్‌క్రిప్ట్ చేయబడింది';

  @override
  String get dashboard => 'డాష్‌బోర్డ్';

  @override
  String get thisMonth => 'ఈ నెల';

  @override
  String get revenue => 'ఆదాయం';

  @override
  String get labour => 'కూలీలు';

  @override
  String get expenses => 'ఖర్చులు';

  @override
  String get porter => 'పోర్టర్';

  @override
  String get netProfit => 'నికర లాభం';

  @override
  String get activeLeads => 'యాక్టివ్ లీడ్‌లు';

  @override
  String get ordersMonth => 'ఆర్డర్‌లు/నెల';

  @override
  String get outstanding => 'బాకీ';

  @override
  String get reminders => 'రిమైండర్లు';

  @override
  String get monthlyTarget => 'నెలవారీ లక్ష్యం';

  @override
  String get edit => 'మార్చు';

  @override
  String get targetThisMonth => 'ఈ నెల లక్ష్యం';

  @override
  String get eG200000 => 'e.g. 200000';

  @override
  String get save => 'సేవ్';

  @override
  String get upcomingOrders => 'రాబోయే ఆర్డర్‌లు';

  @override
  String get calendar => 'క్యాలెండర్ ->';

  @override
  String get hotLeads => 'హాట్ లీడ్‌లు';

  @override
  String get viewAll => 'అన్నీ చూడండి ->';

  @override
  String get branchPerformance => 'శాఖ పనితీరు';

  @override
  String get orders => 'ఆర్డర్‌లు';

  @override
  String get leads => 'లీడ్‌లు';

  @override
  String get operations => 'కార్యకలాపాలు';

  @override
  String get payments => 'చెల్లింపులు';

  @override
  String get homePageExpenses => 'ఖర్చులు';

  @override
  String get salary => 'జీతం';

  @override
  String get settings => 'సెట్టింగ్‌లు';

  @override
  String get logout => 'లాగ్ అవుట్';

  @override
  String get all => 'అన్నీ';

  @override
  String get pending => 'పెండింగ్';

  @override
  String get completed => 'పూర్తయింది';

  @override
  String get cancelled => 'రద్దు';

  @override
  String get confirmed => 'ఖరారు';

  @override
  String get transit => 'ట్రాన్సిట్';

  @override
  String get done => 'పూర్తి';

  @override
  String get ord001 => 'ORD-001';

  @override
  String get rajeshKumar => 'Rajesh Kumar';

  @override
  String get chennaiBangalore => 'Chennai → Bangalore';

  @override
  String get n12500 => '₹12,500';

  @override
  String get ord002 => 'ORD-002';

  @override
  String get priyaSharma => 'Priya Sharma';

  @override
  String get mumbaiPune => 'Mumbai → Pune';

  @override
  String get n8000 => '₹8,000';

  @override
  String get ord003 => 'ORD-003';

  @override
  String get inTransit => 'ప్రయాణంలో';

  @override
  String get anandVerma => 'Anand Verma';

  @override
  String get delhiNoida => 'Delhi → Noida';

  @override
  String get n5500 => '₹5,500';

  @override
  String get ord004 => 'ORD-004';

  @override
  String get sunitaDevi => 'Sunita Devi';

  @override
  String get hyderabadChennai => 'Hyderabad → Chennai';

  @override
  String get n9200 => '₹9,200';

  @override
  String get leadsCrm => 'లీడ్‌లు / CRM';

  @override
  String get n8 => '8';

  @override
  String get statusNew => 'కొత్త';

  @override
  String get n5 => '5';

  @override
  String get contacted => 'సంప్రదించారు';

  @override
  String get n3 => '3';

  @override
  String get qualified => 'అర్హత పొందినవి';

  @override
  String get n2 => '2';

  @override
  String get won => 'గెలిచినవి';

  @override
  String get lost => 'పోయినవి';

  @override
  String get raviMenon => 'Ravi Menon';

  @override
  String get n919840012345 => '+91 98400 12345';

  @override
  String get chennaiTn => 'Chennai, TN';

  @override
  String get newLead => 'కొత్త లీడ్';

  @override
  String get deepaNair => 'Deepa Nair';

  @override
  String get n919447067890 => '+91 94470 67890';

  @override
  String get coimbatoreTn => 'Coimbatore, TN';

  @override
  String get karthikS => 'Karthik S.';

  @override
  String get n919940054321 => '+91 99400 54321';

  @override
  String get maduraiTn => 'Madurai, TN';

  @override
  String get meenaRaj => 'Meena Raj';

  @override
  String get n919380011223 => '+91 93800 11223';

  @override
  String get trichyTn => 'Trichy, TN';

  @override
  String get todaySJobs => 'ఈరోజు పనులు';

  @override
  String get n3Active => '3 యాక్టివ్';

  @override
  String get tn01Ab1234 => 'TN-01-AB-1234';

  @override
  String get loading => 'లోడింగ్';

  @override
  String get sureshDriver => 'Suresh (Driver)';

  @override
  String get chennaiVellore => 'Chennai → Vellore';

  @override
  String get tn02Cd5678 => 'TN-02-CD-5678';

  @override
  String get muruganDriver => 'Murugan (Driver)';

  @override
  String get salemErode => 'Salem → Erode';

  @override
  String get tn03Ef9012 => 'TN-03-EF-9012';

  @override
  String get unloading => 'అన్‌లోడింగ్';

  @override
  String get baluDriver => 'Balu (Driver)';

  @override
  String get coimbatoreOoty => 'Coimbatore → Ooty';

  @override
  String get upcoming => 'రాబోయేవి';

  @override
  String get tn04Gh3456 => 'TN-04-GH-3456';

  @override
  String get scheduled => 'షెడ్యూల్ చేయబడింది';

  @override
  String get senthilDriver => 'Senthil (Driver)';

  @override
  String get maduraiTirunelveli => 'Madurai → Tirunelveli';

  @override
  String get vehicleTripLog => 'వాహన ట్రిప్ లాగ్';

  @override
  String get logNewTrip => 'కొత్త ట్రిప్ నమోదు';

  @override
  String get paymentsPageOutstanding => 'బాకీ';

  @override
  String get n42800 => '₹42,800';

  @override
  String get receivedMonth => 'అందినది (నెల)';

  @override
  String get n124000 => '₹1,24,000';

  @override
  String get pendingPaymentsLive => 'పెండింగ్ చెల్లింపులు (లైవ్)';

  @override
  String get pendingInvoices => 'పెండింగ్ ఇన్‌వాయిస్‌లు';

  @override
  String get inv045 => 'INV-045';

  @override
  String get due15May => 'గడువు: మే 15';

  @override
  String get inv046 => 'INV-046';

  @override
  String get due18May => 'గడువు: మే 18';

  @override
  String get inv047 => 'INV-047';

  @override
  String get overdue => 'గడువు మించింది';

  @override
  String get inv048 => 'INV-048';

  @override
  String get due22May => 'గడువు: మే 22';

  @override
  String get n16800 => '₹16,800';

  @override
  String get may2025Total => 'మే 2025 మొత్తం';

  @override
  String get n68450 => '₹68,450';

  @override
  String get n12VsLastMonth => '↑ గత నెల కంటే 12%';

  @override
  String get liveExpenses => 'లైవ్ ఖర్చులు';

  @override
  String get byCategory => 'విభాగం వారీగా';

  @override
  String get fuel => 'ఇంధనం';

  @override
  String get n41 => '41%';

  @override
  String get n28000 => '₹28,000';

  @override
  String get tollsPermits => 'టోల్స్ & పర్మిట్లు';

  @override
  String get n18 => '18%';

  @override
  String get maintenance => 'మరమ్మతులో';

  @override
  String get n26 => '26%';

  @override
  String get n18000 => '₹18,000';

  @override
  String get expensePageLabour => 'కూలీలు';

  @override
  String get n15 => '15%';

  @override
  String get n9950 => '₹9,950';

  @override
  String get addExpense => 'ఖర్చు జోడించు';

  @override
  String get may2025 => 'మే 2025';

  @override
  String get totalPayroll => 'మొత్తం జీతాలు';

  @override
  String get n182000 => '₹1,82,000';

  @override
  String get liveStaffData => 'లైవ్ సిబ్బంది డేటా';

  @override
  String get todaySAttendance => 'ఈరోజు హాజరు';

  @override
  String get label => '·';

  @override
  String get pendingAdvances => 'పెండింగ్ అడ్వాన్సులు';

  @override
  String get bal => 'బాకీ:';

  @override
  String get staff => 'సిబ్బంది';

  @override
  String get sureshKumar => 'Suresh Kumar';

  @override
  String get driver => 'డ్రైవర్';

  @override
  String get n22000 => '₹22,000';

  @override
  String get paid => 'చెల్లించారు';

  @override
  String get muruganP => 'Murugan P.';

  @override
  String get n20000 => '₹20,000';

  @override
  String get baluS => 'Balu S.';

  @override
  String get helper => 'సహాయకుడు';

  @override
  String get n14000 => '₹14,000';

  @override
  String get senthilR => 'Senthil R.';

  @override
  String get n21000 => '₹21,000';

  @override
  String get kalaM => 'Kala M.';

  @override
  String get officeStaff => 'ఆఫీస్ సిబ్బంది';

  @override
  String get fleet => 'వాహనాలు';

  @override
  String get n4 => '4';

  @override
  String get active => 'యాక్టివ్';

  @override
  String get idle => 'ఖాళీ';

  @override
  String get n1 => '1';

  @override
  String get service => 'సేవ';

  @override
  String get liveFleet => 'లైవ్ వాహనాలు';

  @override
  String get miniTruck407 => 'మినీ ట్రక్ (407)';

  @override
  String get suresh => 'Suresh';

  @override
  String get n124560Km => '1,24,560 km';

  @override
  String get largeTruckTata => 'పెద్ద ట్రక్ (టాటా)';

  @override
  String get murugan => 'Murugan';

  @override
  String get n98340Km => '98,340 km';

  @override
  String get inService => 'సర్వీస్‌లో';

  @override
  String get balu => 'Balu';

  @override
  String get n212000Km => '2,12,000 km';

  @override
  String get largeTruckEicher => 'పెద్ద ట్రక్ (ఐషర్)';

  @override
  String get senthil => 'Senthil';

  @override
  String get n67890Km => '67,890 km';

  @override
  String get newQuotation => 'కొత్త కొటేషన్';

  @override
  String get customerDetails => 'కస్టమర్ వివరాలు';

  @override
  String get customerName => 'కస్టమర్ పేరు';

  @override
  String get enterFullName => 'పూర్తి పేరు నమోదు చేయండి';

  @override
  String get phoneNumber => 'ఫోన్ నంబర్';

  @override
  String get n91XxxxxXxxxx => '+91 XXXXX XXXXX';

  @override
  String get moveDetails => 'షిఫ్టింగ్ వివరాలు';

  @override
  String get fromAddress => 'ఎక్కడి నుండి (చిరునామా)';

  @override
  String get pickupLocation => 'పికప్ ప్రదేశం';

  @override
  String get toAddress => 'ఎక్కడికి (చిరునామా)';

  @override
  String get dropLocation => 'డ్రాప్ ప్రదేశం';

  @override
  String get moveDate => 'షిఫ్టింగ్ తేదీ';

  @override
  String get ddMmYyyy => 'DD/MM/YYYY';

  @override
  String get floorAccess => 'అంతస్తు / ప్రవేశం';

  @override
  String get eG2ndFloorLiftAvailable => 'ఉదా., 2వ అంతస్తు, లిఫ్ట్ ఉంది';

  @override
  String get estimate => 'అంచనా';

  @override
  String get quotedAmount => 'కోట్ చేసిన మొత్తం (₹)';

  @override
  String get n000 => '0.00';

  @override
  String get notes => 'నోట్స్';

  @override
  String get additionalDetails => 'అదనపు వివరాలు';

  @override
  String get generateQuotation => 'కొటేషన్ రూపొందించండి';

  @override
  String get accounts => 'ఖాతాలు';

  @override
  String get sbiCurrentAC => 'SBI — కరెంట్ ఖాతా';

  @override
  String get xxxx4521 => 'XXXX 4521';

  @override
  String get n284500 => '₹2,84,500';

  @override
  String get hdfcSavingsAC => 'HDFC — సేవింగ్స్ ఖాతా';

  @override
  String get xxxx7832 => 'XXXX 7832';

  @override
  String get n112300 => '₹1,12,300';

  @override
  String get cashOnHand => 'చేతిలో నగదు';

  @override
  String get totalBalance => 'మొత్తం నిల్వ';

  @override
  String get n414800 => '₹4,14,800';

  @override
  String get recentTransactions => 'ఇటీవలి లావాదేవీలు';

  @override
  String get receivedOrd001 => 'అందింది — ORD-001';

  @override
  String get accountsPageN12500 => '+₹12,500';

  @override
  String get may5 => 'మే 5';

  @override
  String get fuelTn01Ab1234 => 'ఇంధనం — TN-01-AB-1234';

  @override
  String get petrolBunk => 'పెట్రోల్ బంక్';

  @override
  String get n3200 => '-₹3,200';

  @override
  String get receivedOrd002 => 'అందింది — ORD-002';

  @override
  String get accountsPageN8000 => '+₹8,000';

  @override
  String get may4 => 'మే 4';

  @override
  String get tollChennaiNh => 'టోల్ — చెన్నై NH';

  @override
  String get nhai => 'NHAI';

  @override
  String get n480 => '-₹480';

  @override
  String get pLReport => 'ప్లాన్ & బిల్లింగ్';

  @override
  String get periodMay2025 => 'కాలం: మే 2025';

  @override
  String get n192000 => '₹1,92,000';

  @override
  String get pLReportPageRevenue => 'ఆదాయం';

  @override
  String get n123550 => '₹1,23,550';

  @override
  String get pLReportPageNetProfit => 'నికర లాభం';

  @override
  String get n643 => '64.3%';

  @override
  String get margin => 'మార్జిన్';

  @override
  String get topExpenses => 'ప్రధాన ఖర్చులు';

  @override
  String get arunPackersStaff => 'Arun Packers Staff';

  @override
  String get adminArunpackersIn => 'admin@arunpackers.in';

  @override
  String get company => 'కంపెనీ';

  @override
  String get businessName => 'వ్యాపారం పేరు';

  @override
  String get settingsPageArunPackersAndCouriers => 'Arun Packers and Couriers';

  @override
  String get phone => 'ఫోన్';

  @override
  String get n9144XxxxXxxx => '+91 44 XXXX XXXX';

  @override
  String get gstNumber => 'GST నంబర్';

  @override
  String get xxxxxxxxxxxx => 'XXXXXXXXXXXX';

  @override
  String get app => 'యాప్';

  @override
  String get notifications => 'నోటిఫికేషన్లు';

  @override
  String get enabled => 'ఆన్‌లో ఉంది';

  @override
  String get darkMode => 'డార్క్ మోడ్';

  @override
  String get on => 'ఆన్';

  @override
  String get language => 'భాష';

  @override
  String get english => 'ఇంగ్లీష్';

  @override
  String get data => 'డేటా';

  @override
  String get exportData => 'డేటా ఎగుమతి';

  @override
  String get csvPdf => 'CSV / PDF';

  @override
  String get backup => 'బ్యాకప్';

  @override
  String get autoDaily => 'ఆటో (రోజువారీ)';

  @override
  String get appTheme => 'యాప్ థీమ్';

  @override
  String get chooseYourPreferredColourScheme =>
      'మీకు నచ్చిన రంగుల పథకాన్ని ఎంచుకోండి.';

  @override
  String get dark => 'డార్క్';

  @override
  String get midnight => 'మిడ్‌నైట్';

  @override
  String get light => 'లైట్';

  @override
  String get calendarPageCalendar => 'క్యాలెండర్';

  @override
  String get mon => 'సోమ';

  @override
  String get tue => 'మంగళ';

  @override
  String get wed => 'బుధ';

  @override
  String get thu => 'గురు';

  @override
  String get fri => 'శుక్ర';

  @override
  String get sat => 'శని';

  @override
  String get sun => 'ఆది';

  @override
  String get n6 => '6';

  @override
  String get n7 => '7';

  @override
  String get n9 => '9';

  @override
  String get n10 => '10';

  @override
  String get n11 => '11';

  @override
  String get n12 => '12';

  @override
  String get n13 => '13';

  @override
  String get n14 => '14';

  @override
  String get calendarPageN15 => '15';

  @override
  String get n17 => '17';

  @override
  String get calendarPageN18 => '18';

  @override
  String get n20 => '20';

  @override
  String get n21 => '21';

  @override
  String get n22 => '22';

  @override
  String get n23 => '23';

  @override
  String get n24 => '24';

  @override
  String get n25 => '25';

  @override
  String get calendarPageN26 => '26';

  @override
  String get n27 => '27';

  @override
  String get n28 => '28';

  @override
  String get n29 => '29';

  @override
  String get n30 => '30';

  @override
  String get n31 => '31';

  @override
  String get remindersFollowUps => 'రిమైండర్‌లు & ఫాలో-అప్‌లు';

  @override
  String get followUpRaviMenon => 'ఫాలో-అప్: Ravi Menon';

  @override
  String get callRegardingBangaloreMoveQuote =>
      'బెంగళూరు షిఫ్టింగ్ కోట్ గురించి కాల్';

  @override
  String get may7 => 'మే 7';

  @override
  String get collectionOrd047 => 'వసూలు: ORD-047';

  @override
  String get overduePaymentFromAnandVerma =>
      'Anand Verma నుండి గడువు మించిన చెల్లింపు';

  @override
  String get may8 => 'మే 8';

  @override
  String get jobTn01Ab1234 => 'పని: TN-01-AB-1234';

  @override
  String get chennaiVelloreScheduledDelivery =>
      'చెన్నై → వెల్లూరు షెడ్యూల్డ్ డెలివరీ';

  @override
  String get may9 => 'మే 9';

  @override
  String get reviewMayExpenses => 'సమీక్ష: మే ఖర్చులు';

  @override
  String get monthlyExpenseReviewWithTeam => 'టీమ్‌తో నెలవారీ ఖర్చు సమీక్ష';

  @override
  String get may12 => 'మే 12';

  @override
  String get activeRemindersLive => 'యాక్టివ్ రిమైండర్‌లు (లైవ్)';

  @override
  String get addReminder => 'రిమైండర్ జోడించు';

  @override
  String get materials => 'సామగ్రి';

  @override
  String get totalSkus => 'మొత్తం SKUలు';

  @override
  String get lowStock => 'తక్కువ స్టాక్';

  @override
  String get inventory => 'ఇన్వెంటరీ';

  @override
  String get cardboardBoxSmall => 'కార్డ్‌బోర్డ్ బాక్స్ — చిన్నది';

  @override
  String get reorder20 => '20 కంటే తగ్గితే మళ్లీ ఆర్డర్';

  @override
  String get n42Pcs => '42 pcs';

  @override
  String get cardboardBoxMedium => 'కార్డ్‌బోర్డ్ బాక్స్ — మధ్యస్థం';

  @override
  String get n28Pcs => '28 pcs';

  @override
  String get cardboardBoxLarge => 'కార్డ్‌బోర్డ్ బాక్స్ — పెద్దది';

  @override
  String get reorder15 => '15 కంటే తగ్గితే మళ్లీ ఆర్డర్';

  @override
  String get n11Pcs => '11 pcs';

  @override
  String get bubbleWrapRoll50m => 'బబుల్ ర్యాప్ రోల్ (50మీ)';

  @override
  String get reorder5 => '5 కంటే తగ్గితే మళ్లీ ఆర్డర్';

  @override
  String get n4Rolls => '4 rolls';

  @override
  String get stretchWrapRoll => 'స్ట్రెచ్ ర్యాప్ రోల్';

  @override
  String get ok => 'సరే';

  @override
  String get n18Rolls => '18 rolls';

  @override
  String get packingTapeBrown => 'ప్యాకింగ్ టేప్ (గోధుమ)';

  @override
  String get reorder10 => '10 కంటే తగ్గితే మళ్లీ ఆర్డర్';

  @override
  String get n7Pcs => '7 pcs';

  @override
  String get furnitureCoverLarge => 'ఫర్నిచర్ కవర్ (పెద్దది)';

  @override
  String get n24Pcs => '24 pcs';

  @override
  String get rope50m => 'తాడు (50మీ)';

  @override
  String get n8Rolls => '8 rolls';

  @override
  String get cornerGuards => 'కార్నర్ గార్డులు';

  @override
  String get n60Pcs => '60 pcs';

  @override
  String get addRestockItem => 'వస్తువు జోడించండి / స్టాక్ నింపండి';

  @override
  String get reports => 'నివేదికలు';

  @override
  String get generateReports => 'నివేదికలు రూపొందించండి';

  @override
  String get monthlySummary => 'నెలవారీ సారాంశం';

  @override
  String get revenueExpensesProfitOverview => 'ఆదాయం, ఖర్చు & లాభం అవలోకనం';

  @override
  String get customerReport => 'కస్టమర్ నివేదిక';

  @override
  String get topCustomersByRevenue => 'ఆదాయం ప్రకారం ప్రముఖ కస్టమర్లు';

  @override
  String get driverPerformance => 'డ్రైవర్ పనితీరు';

  @override
  String get jobsCompletedPerDriver => 'ఒక్కో డ్రైవర్ పూర్తి చేసిన పనులు';

  @override
  String get expenseBreakdown => 'ఖర్చుల విభజన';

  @override
  String get categoryWiseExpenseAnalysis => 'వర్గాల వారీ ఖర్చు విశ్లేషణ';

  @override
  String get revenueTrend => 'ఆదాయ ధోరణి';

  @override
  String get monthOnMonthRevenueChart => 'నెల నెలా ఆదాయ చార్ట్';

  @override
  String get outstandingReport => 'బాకీ నివేదిక';

  @override
  String get pendingPaymentsAgeing => 'పెండింగ్ చెల్లింపులు & కాలవ్యవధి';

  @override
  String get vehicleUtilisation => 'వాహన వినియోగం';

  @override
  String get fleetUsageAndIdleTimeAnalysis =>
      'వాహన వినియోగం & ఖాళీ సమయ విశ్లేషణ';

  @override
  String get exportOptions => 'ఎగుమతి ఎంపికలు';

  @override
  String get exportPdf => 'PDF ఎగుమతి';

  @override
  String get exportCsv => 'CSV ఎగుమతి';

  @override
  String get users => 'వినియోగదారులు';

  @override
  String get addNewUser => 'కొత్త వినియోగదారుని జోడించండి';

  @override
  String get admin => 'అడ్మిన్';

  @override
  String get activeUsers => 'యాక్టివ్ వినియోగదారులు';

  @override
  String get arunKumar => 'Arun Kumar';

  @override
  String get n919840000001 => '+91 98400 00001';

  @override
  String get today => 'ఈరోజు';

  @override
  String get sureshM => 'Suresh M.';

  @override
  String get n919840000002 => '+91 98400 00002';

  @override
  String get n919840000003 => '+91 98400 00003';

  @override
  String get yesterday => 'నిన్న';

  @override
  String get kalaR => 'Kala R.';

  @override
  String get n919840000004 => '+91 98400 00004';

  @override
  String get n919840000005 => '+91 98400 00005';

  @override
  String get n2DaysAgo => '2 రోజుల క్రితం';

  @override
  String get inactiveUsers => 'నిష్క్రియ వినియోగదారులు';

  @override
  String get n919840000006 => '+91 98400 00006';

  @override
  String get inactive => 'నిష్క్రియ';

  @override
  String get n5DaysAgo => '5 రోజుల క్రితం';

  @override
  String get recordPayment => 'చెల్లింపు నమోదు';

  @override
  String get selectOrder => 'ఆర్డర్ ఎంచుకోండి';

  @override
  String get loadingPendingOrders => 'పెండింగ్ ఆర్డర్‌లు లోడ్ అవుతున్నాయి...';

  @override
  String get select => 'ఎంచుకోండి';

  @override
  String get paymentEntry => 'చెల్లింపు నమోదు';

  @override
  String get customer => 'కస్టమర్:';

  @override
  String get totalAmount => 'మొత్తం:';

  @override
  String get alreadyPaid => 'ఇప్పటికే చెల్లించింది:';

  @override
  String get amountReceived => 'అందిన మొత్తం (₹)';

  @override
  String get selectStatus => 'స్థితి ఎంచుకోండి';

  @override
  String get paymentStatus => 'చెల్లింపు స్థితి';

  @override
  String get partial => 'పాక్షికం';

  @override
  String get recordPaymentPagePaid => 'చెల్లించారు';

  @override
  String get savePayment => 'సేవ్';

  @override
  String get quickExpense => 'త్వరిత ఖర్చు';

  @override
  String get expenseDetails => 'ఖర్చు వివరాలు';

  @override
  String get amount => 'మొత్తం (₹)';

  @override
  String get selectCategory => 'వర్గం ఎంచుకోండి';

  @override
  String get category => 'విభాగం';

  @override
  String get vehicleMaintenance => 'వాహన మరమ్మతు';

  @override
  String get office => 'ఆఫీస్';

  @override
  String get material => 'సామగ్రి';

  @override
  String get other => 'ఇతరం';

  @override
  String get date => 'తేదీ';

  @override
  String get yyyyMmDd => 'YYYY-MM-DD';

  @override
  String get linkedOrderIdOptional => 'లింక్ చేసిన ఆర్డర్ ID (ఐచ్ఛికం)';

  @override
  String get leaveBlankIfNotLinked => 'లింక్ లేకపోతే ఖాళీగా వదలండి';

  @override
  String get description => 'వివరణ';

  @override
  String get briefDescription => 'సంక్షిప్త వివరణ';

  @override
  String get saveExpense => 'ఖర్చు సేవ్ చేయి';

  @override
  String get newOrder => 'కొత్త ఆర్డర్';

  @override
  String get newOrderPageCustomer => 'కస్టమర్';

  @override
  String get newOrderPageCustomerName => 'కస్టమర్ పేరు *';

  @override
  String get fullName => 'పూర్తి పేరు';

  @override
  String get newOrderPagePhone => 'ఫోన్ *';

  @override
  String get fromCity => 'ఎక్కడి నుండి (నగరం) *';

  @override
  String get originCity => 'ప్రారంభ నగరం';

  @override
  String get toCity => 'ఎక్కడికి (నగరం) *';

  @override
  String get destinationCity => 'గమ్య నగరం';

  @override
  String get pickupAddress => 'పికప్ చిరునామా';

  @override
  String get dropAddress => 'డ్రాప్ చిరునామా';

  @override
  String get fromFloor => 'ఎక్కడి నుండి (అంతస్తు)';

  @override
  String get eG2ndFloor => 'ఉదా., 2వ అంతస్తు';

  @override
  String get toFloor => 'ఎక్కడికి (అంతస్తు)';

  @override
  String get eGGroundFloor => 'ఉదా., గ్రౌండ్ ఫ్లోర్';

  @override
  String get newOrderPageMoveDate => 'షిఫ్టింగ్ తేదీ *';

  @override
  String get tapToPickDate => 'తేదీ ఎంచుకోవడానికి నొక్కండి';

  @override
  String get pickDate => 'తేదీ ఎంచుకోండి';

  @override
  String get pricingClassification => 'ధర & వర్గీకరణ';

  @override
  String get newOrderPageAmount => 'మొత్తం (₹) *';

  @override
  String get selectService => 'సేవ ఎంచుకోండి';

  @override
  String get newOrderPageService => 'సేవ *';

  @override
  String get houseShifting => 'ఇల్లు షిఫ్టింగ్';

  @override
  String get officeShifting => 'ఆఫీస్ షిఫ్టింగ్';

  @override
  String get vehicleTransport => 'వాహన రవాణా';

  @override
  String get storage => 'స్టోరేజ్';

  @override
  String get packingOnly => 'ప్యాకింగ్ మాత్రమే';

  @override
  String get longDistance => 'దూర ప్రయాణం';

  @override
  String get selectBranch => 'శాఖ ఎంచుకోండి';

  @override
  String get branch => 'శాఖ *';

  @override
  String get chennai => 'Chennai';

  @override
  String get bengaluru => 'Bengaluru';

  @override
  String get coimbatore => 'Coimbatore';

  @override
  String get selectType => 'రకం ఎంచుకోండి';

  @override
  String get orderType => 'ఆర్డర్ రకం *';

  @override
  String get direct => 'నేరుగా';

  @override
  String get newOrderPagePorter => 'పోర్టర్';

  @override
  String get porterCommission => 'పోర్టర్ కమీషన్ %';

  @override
  String get saveOrder => 'ఆర్డర్ సేవ్ చేయండి';

  @override
  String get orderDetails => 'ఆర్డర్ వివరాలు';

  @override
  String get orderDetailPageBranch => 'బ్రాంచ్';

  @override
  String get type => 'రకం';

  @override
  String get from => 'నుండి';

  @override
  String get to => 'వరకు';

  @override
  String get addressFrom => 'చిరునామా (ఎక్కడి నుండి)';

  @override
  String get addressTo => 'చిరునామా (ఎక్కడికి)';

  @override
  String get floorFrom => 'అంతస్తు (ఎక్కడి నుండి)';

  @override
  String get floorTo => 'అంతస్తు (ఎక్కడికి)';

  @override
  String get payment => 'చెల్లింపు';

  @override
  String get orderDetailPageAmount => 'మొత్తం';

  @override
  String get advancePaid => 'చెల్లించిన అడ్వాన్స్';

  @override
  String get trackingStatus => 'ట్రాకింగ్ స్థితి';

  @override
  String get editOrder => 'ఆర్డర్ సవరించండి';

  @override
  String get contact => 'సంప్రదింపు';

  @override
  String get email => 'ఈమెయిల్';

  @override
  String get emailExampleCom => 'email@example.com';

  @override
  String get newLeadPageFromCity => 'ఎక్కడి నుండి (నగరం)';

  @override
  String get newLeadPageToCity => 'ఎక్కడికి (నగరం)';

  @override
  String get approxDate => 'సుమారు తేదీ *';

  @override
  String get classification => 'వర్గీకరణ';

  @override
  String get status => 'స్థితి *';

  @override
  String get newLeadPageNew => 'కొత్త';

  @override
  String get newLeadPageContacted => 'సంప్రదించారు';

  @override
  String get surveyDone => 'సర్వే పూర్తయింది';

  @override
  String get quoted => 'కోట్ పంపారు';

  @override
  String get converted => 'బుక్ అయినవి';

  @override
  String get newLeadPageLost => 'పోయినవి';

  @override
  String get howDidTheyHearAboutUs => 'వారు మా గురించి ఎలా తెలుసుకున్నారు?';

  @override
  String get source => 'మూలం *';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get phoneCall => 'ఫోన్ కాల్';

  @override
  String get website => 'వెబ్‌సైట్';

  @override
  String get referral => 'రిఫరల్';

  @override
  String get walkIn => 'వాక్-ఇన్';

  @override
  String get google => 'Google';

  @override
  String get justdial => 'JustDial';

  @override
  String get anyRelevantNotes => 'సంబంధిత గమనికలు';

  @override
  String get saveLead => 'లీడ్ సేవ్ చేయండి';

  @override
  String get leadDetails => 'లీడ్ వివరాలు';

  @override
  String get leadDetailPageSource => 'మూలం';

  @override
  String get leadDetailPageApproxDate => 'సుమారు తేదీ';

  @override
  String get convertToOrder => 'ఆర్డర్‌గా మార్చండి';

  @override
  String get editLead => 'లీడ్ సవరించండి';

  @override
  String get quickEntry => 'త్వరిత నమోదు';

  @override
  String get whatWouldYouLikeToDo => 'మీరు ఏమి చేయాలనుకుంటున్నారు?';

  @override
  String get newInquiry => 'కొత్త విచారణ';

  @override
  String get confirmBooking => 'బుకింగ్ నిర్ధారించండి';

  @override
  String get cashCollectedByPorter => 'పోర్టర్ వసూలు చేసిన నగదు (₹)';

  @override
  String get leaveBlankIfNoneCollectedYet =>
      'ఇంకా వసూలు చేయకపోతే ఖాళీగా వదలండి';

  @override
  String get jrTitle => 'ఆర్డర్ ప్రయాణం';

  @override
  String get jrStageLead => 'లీడ్';

  @override
  String get jrStageFollowUp => 'ఫాలో-అప్';

  @override
  String get jrStageSurvey => 'సర్వే';

  @override
  String get jrStageQuote => 'కోట్ & నిర్ధారణ';

  @override
  String get jrStageSupervisor => 'సూపర్‌వైజర్';

  @override
  String get jrStageMoveDay => 'షిఫ్టింగ్ రోజు';

  @override
  String get jrStageInvoice => 'ఇన్‌వాయిస్';

  @override
  String get jrStagePayment => 'చెల్లింపు & సమస్యలు';

  @override
  String get jrStageClosed => 'ముగిసింది';

  @override
  String get jrStateDone => 'పూర్తి';

  @override
  String get jrStateSkipped => 'దాటవేశారు';

  @override
  String get jrStateCurrent => 'ఇప్పుడు';

  @override
  String get jrStatePending => 'తర్వాత';

  @override
  String get jrDirectOrder => 'దాటవేశారు · నేరుగా ఆర్డర్';

  @override
  String get jrMoveDate => 'షిఫ్టింగ్ తేదీ';

  @override
  String get jrRoute => 'రూట్';

  @override
  String get jrOrderValue => 'ఆర్డర్ విలువ';

  @override
  String get jrNotSet => 'సెట్ చేయలేదు';

  @override
  String get jrDocuments => 'పత్రాలు';

  @override
  String get jrDocQuote => 'కొటేషన్';

  @override
  String get jrDocInvoice => 'ట్యాక్స్ ఇన్వాయిస్';

  @override
  String get jrDocReceipts => 'నగదు రసీదులు';

  @override
  String get jrDocLr => 'లారీ రసీదు';

  @override
  String get jrDocReady => 'సిద్ధం · చూడటానికి నొక్కండి';

  @override
  String jrDocAfter(String stage) {
    return '$stage తర్వాత';
  }

  @override
  String jrCreated(String date) {
    return 'సృష్టించారు $date';
  }

  @override
  String jrSource(String source) {
    return 'మూలం: $source';
  }

  @override
  String jrService(String service) {
    return 'సేవ: $service';
  }

  @override
  String get jrNoCalls => 'ఇంకా కాల్స్ నమోదు కాలేదు';

  @override
  String jrCallsLogged(String count) {
    return '$count కాల్స్ నమోదయ్యాయి';
  }

  @override
  String get jrOutcomeQ => 'కాల్ ఎలా జరిగింది?';

  @override
  String get jrOutNoAnswer => 'అందుబాటులో లేరు';

  @override
  String get jrOutCallback => 'మళ్ళీ కాల్';

  @override
  String get jrOutInterested => 'ఆసక్తి ఉంది';

  @override
  String get jrOutNotInterested => 'ఆసక్తి లేదు';

  @override
  String get jrCallNotes => 'కాల్ గమనికలు';

  @override
  String get jrNextFollowUp => 'తదుపరి ఫాలో-అప్';

  @override
  String get jrToday => 'ఈరోజు';

  @override
  String get jrTomorrow => 'రేపు';

  @override
  String get jrIn2Days => '2 రోజుల్లో';

  @override
  String get jrNextWeek => 'వచ్చే వారం';

  @override
  String get jrPickDate => 'తేదీ ఎంచుకోండి';

  @override
  String get jrNoNext => 'లేదు';

  @override
  String get jrLogCall => 'కాల్ నమోదు';

  @override
  String get jrCallLogged => 'కాల్ నమోదైంది';

  @override
  String get jrPickOutcome => 'కాల్ ఎలా జరిగిందో ఎంచుకోండి';

  @override
  String get jrSurveyWaiting => 'సర్వే లింక్ పంపారు · కస్టమర్ కోసం వేచి ఉంది';

  @override
  String get jrSurveyDone => 'కస్టమర్ సర్వే సమర్పించారు';

  @override
  String get jrNoSurvey => 'ఇంకా సర్వే లేదు';

  @override
  String get jrOpenSurveyQuote => 'సర్వే & కోట్ తెరవండి';

  @override
  String get jrNoQuote => 'ఇంకా కోట్ లేదు';

  @override
  String jrQuoteLine(String amount) {
    return 'కోట్ $amount';
  }

  @override
  String jrOrderConfirmed(String id) {
    return 'ఆర్డర్ $id నిర్ధారించబడింది';
  }

  @override
  String get jrLeadLost => 'లీడ్ కోల్పోయినట్లు గుర్తించారు';

  @override
  String get jrNoSupervisor => 'ఇంకా సూపర్‌వైజర్ లేరు';

  @override
  String jrSupervisorIs(String name) {
    return 'సూపర్‌వైజర్: $name';
  }

  @override
  String jrCrew(String count) {
    return 'పనిలో ఉన్న టీమ్: $count';
  }

  @override
  String get jrAssignInOrder => 'సూపర్‌వైజర్ కేటాయించు';

  @override
  String get jrNotStarted => 'ప్రారంభం కాలేదు';

  @override
  String jrMoveStarted(String time) {
    return 'ప్రారంభం $time';
  }

  @override
  String jrMoveFinished(String time) {
    return 'పూర్తి $time';
  }

  @override
  String get jrOpenFieldJob => 'ఫీల్డ్ పని తెరవండి';

  @override
  String get jrNoInvoice => 'ఇన్‌వాయిస్ రూపొందించలేదు';

  @override
  String jrInvoiceNo(String no) {
    return 'ఇన్‌వాయిస్ $no';
  }

  @override
  String get jrSigned => 'కస్టమర్ సంతకం చేశారు';

  @override
  String get jrNotSigned => 'కస్టమర్ సంతకం లేదు';

  @override
  String get jrOpenOrder => 'ఆర్డర్ తెరువు';

  @override
  String get jrTotal => 'మొత్తం';

  @override
  String get jrPaid => 'చెల్లించారు';

  @override
  String get jrBalance => 'బాకీ';

  @override
  String get jrRecordPayment => 'చెల్లింపు నమోదు';

  @override
  String get jrTickets => 'టికెట్లు';

  @override
  String get jrNoTickets => 'టికెట్లు లేవు';

  @override
  String get jrTicketHint => 'ఉదా., AC ఫిట్టింగ్ పెండింగ్';

  @override
  String get jrRaiseTicket => 'టికెట్ పెట్టు';

  @override
  String get jrResolve => 'పరిష్కరించు';

  @override
  String get jrTicketRaised => 'టికెట్ నమోదైంది';

  @override
  String get jrTicketResolved => 'టికెట్ పరిష్కరించబడింది';

  @override
  String get jrBlockTicket => 'ఒక టికెట్ ఇంకా ఓపెన్';

  @override
  String jrBlockBalance(String amount) {
    return '$amount బాకీ చెల్లించాలి';
  }

  @override
  String get jrCloseOrder => 'ఆర్డర్ మూసివేయి';

  @override
  String jrClosedOn(String date) {
    return 'మూసివేశారు $date';
  }

  @override
  String get jrNotClosed => 'ఓపెన్';

  @override
  String jrPaymentLine(String amount, String mode) {
    return '$amount · $mode';
  }

  @override
  String get jrCouldNotLoad => 'ఈ ప్రయాణాన్ని లోడ్ చేయలేకపోయాం';

  @override
  String get jrRetry => 'మళ్లీ ప్రయత్నించండి';

  @override
  String jrCouldNotSave(String error) {
    return 'సేవ్ చేయలేకపోయాం: $error';
  }

  @override
  String get ngNavHome => 'హోమ్';

  @override
  String get ngNavLeads => 'లీడ్‌లు';

  @override
  String get ngNavOrders => 'ఆర్డర్‌లు';

  @override
  String get ngNavOps => 'ఆప్స్';

  @override
  String get ngNavPay => 'చెల్లింపు';

  @override
  String get ngNavMore => 'మరిన్ని';

  @override
  String get ngMenuDashboard => 'డాష్‌బోర్డ్';

  @override
  String get ngMenuLeads => 'లీడ్‌లు / CRM';

  @override
  String get ngMenuInbox => 'ఇన్‌బాక్స్';

  @override
  String get ngMenuSurveyQuote => 'సర్వే & కోట్';

  @override
  String get ngMenuCalendar => 'క్యాలెండర్';

  @override
  String get ngMenuOrders => 'ఆర్డర్‌లు';

  @override
  String get ngMenuOperations => 'కార్యకలాపాలు';

  @override
  String get ngMenuReviews => 'రివ్యూలు';

  @override
  String get ngMenuPayments => 'చెల్లింపులు';

  @override
  String get ngMenuExpenses => 'ఖర్చులు';

  @override
  String get ngMenuStaff => 'సిబ్బంది';

  @override
  String get ngMenuTeamAttendance => 'టీమ్ హాజరు';

  @override
  String get ngMenuFleet => 'వాహనాలు';

  @override
  String get ngMenuMaterials => 'సామగ్రి';

  @override
  String get ngMenuWarehouses => 'గిడ్డంగులు';

  @override
  String get ngMenuRateCards => 'రేట్ కార్డులు';

  @override
  String get ngMenuLrRegister => 'LR రిజిస్టర్';

  @override
  String get ngMenuOpsLog => 'ఆప్స్ లాగ్';

  @override
  String get ngMenuVendors => 'వెండర్లు';

  @override
  String get ngMenuCustomers => 'కస్టమర్లు';

  @override
  String get ngMenuInsurance => 'బీమా';

  @override
  String get ngMenuTrips => 'ట్రిప్‌లు';

  @override
  String get ngMenuTasks => 'పనులు';

  @override
  String get ngMenuAccounts => 'ఖాతాలు';

  @override
  String get ngMenuPnl => 'లాభనష్టాలు';

  @override
  String get ngMenuReports => 'నివేదికలు';

  @override
  String get ngMenuSalary => 'జీతం';

  @override
  String get ngMenuSettings => 'సెట్టింగ్‌లు';

  @override
  String get ngMenuPlatformAdmin => 'ప్లాట్‌ఫామ్ అడ్మిన్';

  @override
  String get ngMenuMyJobs => 'నా పనులు';

  @override
  String get ngMenuMyTeam => 'నా టీమ్';

  @override
  String get ngMenuMyEarnings => 'నా సంపాదన';

  @override
  String get ngMenuMyAttendance => 'నా హాజరు';

  @override
  String get ngGroupSales => 'అమ్మకాలు';

  @override
  String get ngGroupOperations => 'కార్యకలాపాలు';

  @override
  String get ngGroupMoney => 'డబ్బు';

  @override
  String get ngGroupPeople => 'సిబ్బంది';

  @override
  String get ngGroupAssets => 'ఆస్తులు';

  @override
  String get ngGroupPartners => 'భాగస్వాములు';

  @override
  String get ngGroupSetup => 'సెటప్';

  @override
  String get ngGroupField => 'ఫీల్డ్';

  @override
  String get ngGroupOther => 'ఇతరాలు';

  @override
  String get ngQuickEntry => 'త్వరిత నమోదు';

  @override
  String get ngSearchModules => 'మాడ్యూల్స్ వెతకండి';

  @override
  String get ngNoModuleMatches => 'సరిపోలే మాడ్యూల్ లేదు';

  @override
  String get ngHelp => 'సహాయం';

  @override
  String ngOrgsSwitch(String count) {
    return '$count సంస్థలు · మార్చడానికి నొక్కండి';
  }

  @override
  String get ngRoleOwner => 'యజమాని';

  @override
  String get ngRoleStaff => 'సిబ్బంది';

  @override
  String get ngTodayMoves => 'షిఫ్టింగ్‌లు';

  @override
  String get ngTodayFollowUps => 'ఫాలో-అప్‌లు';

  @override
  String get ngToCollect => 'వసూలు చేయాల్సింది';

  @override
  String get ngOpenLeads => 'ఓపెన్ లీడ్‌లు';

  @override
  String get ngNoMovesYet => 'ఇంకా షిఫ్టింగ్ షెడ్యూల్ కాలేదు';

  @override
  String get ngCreateFirstOrder => 'మీ మొదటి ఆర్డర్ సృష్టించండి';

  @override
  String get ngNoLeadsYet => 'ఇంకా లీడ్‌లు లేవు';

  @override
  String get ngAddLead => 'లీడ్ జోడించండి';

  @override
  String get ngAllLeads => 'అన్ని లీడ్‌లు';

  @override
  String get ngConversion => 'కన్వర్షన్';

  @override
  String get ngOpen => 'ఓపెన్';

  @override
  String get ngOther => 'ఇతరాలు';

  @override
  String get ngSurveyResponse => 'సర్వే స్పందన అందింది';

  @override
  String get ngFollowUpOverdue => 'ఫాలో-అప్ ఆలస్యమైంది';

  @override
  String get ngCall => 'కాల్';

  @override
  String get ngWhatsApp => 'WhatsApp';

  @override
  String get ngSurvey => 'సర్వే';

  @override
  String get ngNewLead => 'కొత్త లీడ్';

  @override
  String get ngNameOrPhone => 'పేరు లేదా ఫోన్';

  @override
  String get ngNoLeadsMatch => 'సరిపోలే లీడ్‌లు లేవు';

  @override
  String get ngLeadsEmptyHint =>
      'కొత్త లీడ్‌తో విచారణ జోడించండి, అది ఇక్కడ కనిపిస్తుంది.';

  @override
  String get ngSurveyLinkCreated => 'సర్వే లింక్ సృష్టించబడింది';

  @override
  String get ngCopyClose => 'కాపీ చేసి మూసివేయండి';

  @override
  String get ngClose => 'మూసివేయండి';

  @override
  String get ngTabAll => 'అన్నీ';

  @override
  String get ngTabPending => 'పెండింగ్';

  @override
  String get ngTabCompleted => 'పూర్తయినవి';

  @override
  String get ngTabCancelled => 'రద్దయినవి';

  @override
  String get ngToday => 'ఈరోజు';

  @override
  String get ngTomorrow => 'రేపు';

  @override
  String get ngYesterday => 'నిన్న';

  @override
  String get ngNoMoveDate => 'షిఫ్టింగ్ తేదీ లేదు';

  @override
  String get ngPaid => 'చెల్లించారు';

  @override
  String get ngPartPaid => 'పాక్షికంగా చెల్లించారు';

  @override
  String get ngDue => 'బాకీ';

  @override
  String get ngUnpaid => 'చెల్లించలేదు';

  @override
  String get ngNewOrder => 'కొత్త ఆర్డర్';

  @override
  String get ngNoOrdersHere => 'ఇక్కడ ఆర్డర్‌లు లేవు';

  @override
  String get ngRemind => 'గుర్తు చేయండి';

  @override
  String get ngRecord => 'నమోదు చేయండి';

  @override
  String get ngOverdue => 'ఆలస్యమైనవి';

  @override
  String get ngUpcoming => 'రాబోయేవి';

  @override
  String get ngNothingToCollect => 'వసూలు చేయాల్సింది ఏమీ లేదు';

  @override
  String get ngLinkedDevice => 'లింక్ చేసిన పరికరం';

  @override
  String get ngEnterPin => 'మీ 4 అంకెల PIN నమోదు చేయండి';

  @override
  String get ngVerifying => 'ధృవీకరిస్తోంది…';

  @override
  String get ngUseEmail => 'బదులుగా ఈమెయిల్ లాగిన్ వాడండి';

  @override
  String get ngSwitchDevice => 'మీ సంస్థ కాదా? పరికరం మార్చండి';

  @override
  String get ngSecuredBy => 'Nagarva ద్వారా సురక్షితం';

  @override
  String get suCreate => 'మీ బిజినెస్ ఖాతా సృష్టించండి';

  @override
  String suStep(String n) {
    return 'దశ $n / 4';
  }

  @override
  String get suS1 => 'మొబైల్';

  @override
  String get suS2 => 'బిజినెస్';

  @override
  String get suS3 => 'పత్రాలు';

  @override
  String get suS4 => 'సమీక్ష';

  @override
  String get suPhS => 'యజమాని నంబర్ ఉపయోగించండి. దీనితోనే మీరు లాగిన్ అవుతారు.';

  @override
  String get suPh => 'మొబైల్ నంబర్';

  @override
  String get suSend => 'OTP పంపు';

  @override
  String get suPhBad => '10 అంకెల మొబైల్ నంబర్ ఇవ్వండి';

  @override
  String get suOtpT => 'OTP ఇవ్వండి';

  @override
  String suOtpS(String p) {
    return '+91 $p కు పంపాం';
  }

  @override
  String get suEnter => '6 అంకెల కోడ్ టైప్ చేయండి';

  @override
  String get suVerify => 'నిర్ధారించు';

  @override
  String get suOtpBad => '6 అంకెల OTP ఇవ్వండి';

  @override
  String get suResend => 'OTP మళ్లీ పంపు';

  @override
  String get suResent => 'OTP మళ్లీ పంపాం';

  @override
  String get suChange => 'నంబర్ మార్చు';

  @override
  String get suBzT => 'మీ బిజినెస్ గురించి';

  @override
  String get suBzS =>
      'ఇది మీ కొటేషన్లు, బిల్లులపై కనిపిస్తుంది. తర్వాత మార్చవచ్చు.';

  @override
  String get suName => 'బిజినెస్ పేరు';

  @override
  String get suNameP => 'ఉదా. అరుణ్ ప్యాకర్స్ & మూవర్స్';

  @override
  String get suOwner => 'యజమాని పేరు';

  @override
  String get suEmail => 'ఈమెయిల్ (ఐచ్ఛికం)';

  @override
  String get suEmailP => 'బిల్లులు, పాస్‌వర్డ్ రీసెట్ కోసం';

  @override
  String get suCity => 'నగరం';

  @override
  String get suType => 'మీరు ఏం చేస్తారు?';

  @override
  String get suTPm => 'ప్యాకర్స్ & మూవర్స్';

  @override
  String get suTPmS => 'ఇల్లు, ఆఫీస్ షిఫ్టింగ్';

  @override
  String get suTTr => 'ట్రాన్స్‌పోర్ట్';

  @override
  String get suTTrS => 'ట్రక్కులు, ట్రిప్‌లు, LR';

  @override
  String get suTBo => 'రెండూ';

  @override
  String get suTBoS => 'షిఫ్టింగ్, ట్రాన్స్‌పోర్ట్';

  @override
  String get suGst => 'GSTIN (ఐచ్ఛికం)';

  @override
  String get suGstP => '15 అక్షరాల GST నంబర్';

  @override
  String get suRef => 'రెఫరల్ కోడ్ (ఐచ్ఛికం)';

  @override
  String get suNeedBz => 'బిజినెస్ పేరు, యజమాని పేరు, నగరం నింపండి';

  @override
  String get suGstBad => 'GSTIN 15 అక్షరాలు ఉండాలి';

  @override
  String get suEmailBad => 'ఈమెయిల్ చిరునామా సరిచూడండి';

  @override
  String get suDcT => 'మీ బిజినెస్ ధృవీకరించండి';

  @override
  String get suDcS =>
      'ఫోటోలు లేదా PDF. ఖాతా ప్రారంభానికి ముందు మా బృందం వీటిని పరిశీలిస్తుంది.';

  @override
  String get suPan => 'PAN కార్డ్';

  @override
  String get suPanS => 'యజమాని లేదా బిజినెస్ PAN';

  @override
  String get suGstC => 'GST సర్టిఫికెట్';

  @override
  String get suGstCS => 'మీరు GSTIN ఇచ్చినందున అవసరం';

  @override
  String get suShop => 'ఆఫీస్ లేదా గోదాము ఫోటో';

  @override
  String get suShopS => 'త్వరగా ధృవీకరించడానికి సహాయపడుతుంది';

  @override
  String get suUpload => 'అప్‌లోడ్';

  @override
  String get suReq => 'అవసరం';

  @override
  String get suOpt => 'ఐచ్ఛికం';

  @override
  String get suNeedPan => 'మీ PAN కార్డ్ అప్‌లోడ్ చేయండి';

  @override
  String get suNeedGstC =>
      'GST సర్టిఫికెట్ అప్‌లోడ్ చేయండి లేదా GSTIN తీసివేయండి';

  @override
  String get suPriv =>
      'పత్రాలు బిజినెస్ ధృవీకరణకు మాత్రమే. మీ సిబ్బందికి, కస్టమర్లకు కనిపించవు.';

  @override
  String get suRvT => 'సరిచూసి పంపండి';

  @override
  String get suEdit => 'మార్చు';

  @override
  String get suNext => 'తర్వాత ఏం జరుగుతుంది';

  @override
  String get suN1 =>
      'మా బృందం మీ వివరాలు పరిశీలిస్తుంది, సాధారణంగా 1 పని దినంలో.';

  @override
  String get suN3 =>
      'మీరు ఉచిత ప్లాన్‌తో మొదలుపెడతారు. ఎప్పుడైనా అప్‌గ్రేడ్ చేయవచ్చు.';

  @override
  String get suNeedAgree => 'కొనసాగడానికి నిబంధనలు అంగీకరించండి';

  @override
  String get suSubmit => 'ఆమోదానికి పంపు';

  @override
  String get suContinue => 'కొనసాగించు';

  @override
  String get suMob => 'మొబైల్';

  @override
  String get suBt => 'బిజినెస్ రకం';

  @override
  String get suNone => 'జోడించలేదు';

  @override
  String get suPendT => 'దరఖాస్తు పరిశీలనలో ఉంది';

  @override
  String suAppId(String id) {
    return 'దరఖాస్తు $id';
  }

  @override
  String get suTl1 => 'పంపారు';

  @override
  String get suTl2 => 'పత్రాల పరిశీలన';

  @override
  String get suTl3 => 'ఖాతా సిద్ధం';

  @override
  String get suOkT => 'మీ ఖాతా సిద్ధం';

  @override
  String suOkS(String b) {
    return '$b ఆమోదించబడింది. మీరు ఉచిత ప్లాన్‌లో ఉన్నారు.';
  }

  @override
  String get suStart => 'Nagarva ప్రారంభించండి';

  @override
  String get suNoT => 'మార్పులు అవసరం';

  @override
  String get suNoS =>
      'మా బృందం ఇంకా ఆమోదించలేకపోయింది. కింద ఉన్నది సరిచేసి మళ్లీ పంపండి.';

  @override
  String get suFix => 'సరిచేసి మళ్లీ పంపు';

  @override
  String get suWa => 'WhatsApp లో మాట్లాడండి';

  @override
  String get suToLogin => 'లాగిన్‌కు వెనక్కి';

  @override
  String get suHave => 'ఇప్పటికే ఖాతా ఉందా?';

  @override
  String get suLogin => 'లాగిన్';

  @override
  String get suBnP => 'దరఖాస్తు పరిశీలనలో ఉంది';

  @override
  String get suBnOk => 'ఖాతా ఆమోదించబడింది';

  @override
  String get suBnNo => 'దరఖాస్తులో మార్పులు అవసరం';

  @override
  String get suView => 'చూడండి';

  @override
  String get suSent => 'దరఖాస్తు పంపబడింది';

  @override
  String get lgTerms => 'వినియోగ నిబంధనలు';

  @override
  String get lgPriv => 'గోప్యతా విధానం';

  @override
  String suTrT(String n) {
    return '$n రోజులు Pro ఉచితంగా ప్రయత్నించండి';
  }

  @override
  String suTrUsers(String n) {
    return '$n మంది వినియోగదారుల వరకు';
  }

  @override
  String get suTrOrdersAll => 'ప్రతి నెలా అపరిమిత ఆర్డర్లు';

  @override
  String suTrOrders(String n) {
    return 'నెలకు $n ఆర్డర్లు';
  }

  @override
  String get suTrReports => 'నివేదికలు మరియు లాభ-నష్టాలు';

  @override
  String get suTrBranches => 'అనేక శాఖలు';

  @override
  String suTrNote(String n) {
    return 'కార్డ్ అవసరం లేదు. $n రోజుల తర్వాత మీరు ఆటోమేటిక్‌గా ఉచిత ప్లాన్‌కి మారతారు. మీ డేటా అలాగే ఉంటుంది.';
  }

  @override
  String suTrBtn(String n) {
    return '$n రోజుల Pro ట్రయల్ ప్రారంభించండి';
  }

  @override
  String get suStayFree => 'ఉచితంలోనే ఉండండి';

  @override
  String suTrOn(String n) {
    return 'Pro ట్రయల్ ప్రారంభమైంది · $n రోజులు';
  }

  @override
  String get suFreeOn => 'మీరు ఉచిత ప్లాన్‌లో ఉన్నారు';

  @override
  String plTrBan(String n) {
    return 'Pro ట్రయల్ $n రోజుల్లో ముగుస్తుంది. తర్వాత మీరు ఉచిత ప్లాన్‌కి మారతారు. మీ డేటా అలాగే ఉంటుంది.';
  }

  @override
  String get plTrEnded =>
      'మీ Pro ట్రయల్ ముగిసింది. మీరు ఉచిత ప్లాన్‌లో ఉన్నారు, మీ డేటా అంతా సురక్షితంగా ఉంది.';

  @override
  String plTrEnds(String d, String n) {
    return 'Pro ట్రయల్ $d న ముగుస్తుంది · $n రోజులు మిగిలాయి';
  }

  @override
  String get suN2b =>
      'మీ స్థితి చూడడానికి ఎప్పుడైనా ఇదే మొబైల్ నంబర్‌తో లాగిన్ అవ్వండి.';

  @override
  String suPendS2(String p) {
    return 'సాధారణంగా 1 పని దినంలో జవాబిస్తాం. ఫలితం చూడడానికి +91 $p తో లాగిన్ అవ్వండి.';
  }

  @override
  String get suOtpUnavailable =>
      'మొబైల్ సైన్-అప్ ఇంకా ఆన్ కాలేదు. దయచేసి Nagarva సహాయాన్ని సంప్రదించండి.';

  @override
  String get suSendFailed => 'OTP పంపలేకపోయాం. నంబర్ చూసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get suOtpFailed => 'ఆ కోడ్ పని చేయలేదు. చూసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get suUploadFailed => 'అప్‌లోడ్ విఫలమైంది. మళ్లీ ప్రయత్నించండి.';

  @override
  String get suMobileLogin => 'మొబైల్ నంబర్‌తో లాగిన్ అవ్వండి';

  @override
  String get suRefresh => 'స్థితి చూడండి';

  @override
  String suResendIn(String n) {
    return '$n సెకన్లలో మళ్లీ పంపండి';
  }

  @override
  String get suAgreeLead => 'వీటికి అంగీకరిస్తున్నాను:';

  @override
  String get ngGreetMorning => 'శుభోదయం';

  @override
  String get ngGreetAfternoon => 'శుభ మధ్యాహ్నం';

  @override
  String get ngGreetEvening => 'శుభ సాయంత్రం';

  @override
  String ngPlanName(String plan) {
    return '$plan ప్లాన్';
  }

  @override
  String get ngPlanActive => 'యాక్టివ్';

  @override
  String get ngPlanTrial => 'ట్రయల్';

  @override
  String get ngPlanEndingSoon => 'త్వరలో ముగుస్తుంది';

  @override
  String get ngPlanEnded => 'ముగిసింది';

  @override
  String ngPlanTrialEnds(String date, int days) {
    return 'ట్రయల్ $dateన ముగుస్తుంది · $days రోజులు మిగిలాయి';
  }

  @override
  String ngPlanReadOnlyIn(int days) {
    return 'ట్రయల్ ముగిసింది · $days రోజుల్లో చూడటానికి మాత్రమే';
  }

  @override
  String get ngPlanReadOnly => 'ట్రయల్ ముగిసింది · చూడటానికి మాత్రమే';

  @override
  String get ngPlanNoExpiry => 'గడువు తేదీ లేదు';

  @override
  String get ngPlanSee => 'ప్లాన్‌లు';

  @override
  String get ngPaymentsDue => 'బకాయి చెల్లింపులు';

  @override
  String ngPaymentsDueSub(int n) {
    return '$n ఆర్డర్‌లు పూర్తిగా చెల్లించలేదు';
  }

  @override
  String get ngOverdueFollowUps => 'ఆలస్యమైన ఫాలో-అప్‌లు';

  @override
  String get ngOverdueFollowUpsSub => 'ముందుగా వీరికి కాల్ చేయండి';

  @override
  String get ngTodaysPlan => 'నేటి ప్రణాళిక';

  @override
  String get ngNothingToday => 'ఈ రోజు ఏమీ ప్లాన్ చేయలేదు';

  @override
  String get ngComingUp => 'రాబోయేవి';

  @override
  String ngAgendaMove(String name) {
    return 'షిఫ్టింగ్ · $name';
  }

  @override
  String get ngAllDay => 'రోజంతా';

  @override
  String get ngPeriodThisMonth => 'ఈ నెల';

  @override
  String get ngPeriodLastMonth => 'గత నెల';

  @override
  String get ngPeriod3m => 'గత 3 నెలలు';

  @override
  String get ngPeriodFy => 'ఈ ఆర్థిక సంవత్సరం';

  @override
  String get ngPeriodAll => 'మొత్తం';

  @override
  String get ngPickPeriod => 'ఈ కాలానికి గణాంకాలు';

  @override
  String get ngProfitTarget => 'లాభ లక్ష్యం';

  @override
  String get ngSetTarget => 'నెలవారీ లాభ లక్ష్యం పెట్టండి';

  @override
  String get ngSetTargetSub => 'చేరాలనుకునే మొత్తం పెట్టడానికి నొక్కండి';

  @override
  String get ngProfit => 'లాభం';

  @override
  String ngProfitAfter(String labour, String expenses) {
    return 'కూలీ $labour, ఖర్చులు $expenses తర్వాత';
  }

  @override
  String get ngAddExpense => 'ఖర్చు జోడించండి';

  @override
  String get ngSeeAll => 'అన్నీ చూడండి';

  @override
  String get ngHotLeads => 'హాట్ లీడ్‌లు';

  @override
  String get ngBranches => 'శాఖలు';

  @override
  String ngOrdersN(int n) {
    return '$n ఆర్డర్‌లు';
  }

  @override
  String get ngTargetDone => 'లక్ష్యం చేరింది';

  @override
  String get ngNoProfitYet => 'ఈ కాలంలో ఇంకా లాభం లేదు';

  @override
  String get ngEditTarget => 'నెలవారీ లాభ లక్ష్యం';

  @override
  String get ngQuote => 'కొటేషన్';

  @override
  String get ngTabDone => 'పూర్తయినవి';

  @override
  String get ngReceived => 'అందినవి';

  @override
  String ngDaysLate(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n రోజులు ఆలస్యం',
      one: '1 రోజు ఆలస్యం',
    );
    return '$_temp0';
  }

  @override
  String get ngNoPaymentsYet => 'ఇంకా చెల్లింపులు నమోదు కాలేదు';

  @override
  String get ngOpsTitle => 'ఆపరేషన్స్';

  @override
  String get ngOpsNewTrip => 'కొత్త ట్రిప్';

  @override
  String get ngOpsCrewsOut => 'పనిలో బృందాలు';

  @override
  String get ngOpsVehiclesFree => 'ఖాళీ వాహనాలు';

  @override
  String get ngOpsAttention => 'శ్రద్ధ అవసరం';

  @override
  String ngOpsNoCrew(String name) {
    return 'బృందం లేదు · $name';
  }

  @override
  String get ngOpsAssign => 'కేటాయించు';

  @override
  String get ngOpsAssignCrew => 'బృందాన్ని కేటాయించు';

  @override
  String ngOpsInsuranceExpires(int n) {
    return 'బీమా $n రోజుల్లో ముగుస్తుంది';
  }

  @override
  String get ngOpsInsuranceExpired => 'బీమా ముగిసింది';

  @override
  String ngOpsLowStock(String name) {
    return '$name తక్కువగా ఉంది';
  }

  @override
  String ngOpsStockLeft(String qty) {
    return '$qty మిగిలింది';
  }

  @override
  String get ngOpsReorder => 'మళ్లీ ఆర్డర్';

  @override
  String get ngOpsView => 'చూడు';

  @override
  String get ngOpsAwaiting => 'ఆమోదం కోసం వేచి ఉంది';

  @override
  String get ngOpsJobs => 'పనులు';

  @override
  String get ngOpsNoJobs => 'ఈ రోజు షిఫ్టింగ్ లేదు';

  @override
  String get ngOpsFleet => 'ఫ్లీట్';

  @override
  String ngOpsFleetSummary(int free, int total) {
    return '$totalలో $free ఖాళీ';
  }

  @override
  String get ngOpsInService => 'సర్వీస్‌లో';

  @override
  String get ngOpsOnJob => 'పనిలో';

  @override
  String get ngOpsFree => 'ఖాళీ';

  @override
  String ngExpCount(int n) {
    return '$n ఖర్చులు';
  }

  @override
  String ngExpVsLast(int pct) {
    return 'గత నెలతో $pct%';
  }

  @override
  String get ngExpThisWeek => 'ఈ వారం';

  @override
  String get ngExpOrderOnly => 'ఆర్డర్‌కు చెందినవి మాత్రమే';

  @override
  String get ngExpNone => 'ఈ కాలంలో ఖర్చులు లేవు';

  @override
  String get ngExpUncategorised => 'వర్గం లేనివి';

  @override
  String get ngExpDelete => 'ఖర్చు తొలగించు';

  @override
  String get ngExpByCategory => 'వర్గం వారీగా';

  @override
  String get ngExpNoCat => 'ఇంకా విభజించడానికి ఏమీ లేదు';

  @override
  String get ngExpNoCatSub =>
      'ఖర్చు నమోదు చేసిన తర్వాత వర్గాలు ఇక్కడ కనిపిస్తాయి.';

  @override
  String get ngFleetNew => 'కొత్త వాహనం';

  @override
  String get ngFleetActive => 'యాక్టివ్';

  @override
  String get ngFleetMaintenance => 'నిర్వహణ';

  @override
  String get ngFleetInactive => 'నిష్క్రియం';

  @override
  String get ngFleetNone =>
      'ఇంకా వాహనాలు లేవు. పత్రాలు, ట్రిప్‌లు చూడటానికి ఒకటి జోడించండి.';

  @override
  String get ngFleetDelete => 'వాహనం తొలగించు';

  @override
  String get ngFleetInsurance => 'బీమా';

  @override
  String get ngFleetPermit => 'పర్మిట్';

  @override
  String ngFleetExpires(String doc, int n) {
    return '$doc $n రోజుల్లో ముగుస్తుంది';
  }

  @override
  String ngFleetExpired(String doc, int n) {
    return '$doc $n రోజుల క్రితం ముగిసింది';
  }

  @override
  String get ngMatNew => 'కొత్త సామగ్రి';

  @override
  String get ngMatSearch => 'సామగ్రి వెతకండి';

  @override
  String get ngMatReorderSoon => 'త్వరలో మళ్లీ ఆర్డర్';

  @override
  String get ngMatReturnable => 'తిరిగి వచ్చేది';

  @override
  String ngMatMin(String n) {
    return 'కనీసం $n';
  }

  @override
  String get ngMatDelete => 'సామగ్రి తొలగించు';

  @override
  String get ngMatNone => 'ఇంకా సామగ్రి లేదు';

  @override
  String get ngTripPlanned => 'ప్లాన్ చేసినవి';

  @override
  String get ngTripOngoing => 'జరుగుతున్నవి';

  @override
  String get ngTripNone => 'ఇంకా ట్రిప్‌లు లేవు';

  @override
  String get ngTripNoNumber => '(ట్రిప్ నంబర్ లేదు)';

  @override
  String get ngTripHired => 'అద్దె';

  @override
  String get ngTripOwn => 'సొంతం';

  @override
  String get ngTripDelete => 'ట్రిప్ తొలగించు';

  @override
  String ngCustCount(int n) {
    return '$n కస్టమర్లు';
  }

  @override
  String get ngCustNew => 'కొత్త';

  @override
  String get ngCustSearch => 'పేరు, ఫోన్ లేదా కంపెనీ వెతకండి';

  @override
  String get ngCustNone => 'కస్టమర్లు దొరకలేదు';

  @override
  String ngCustDue(String amount) {
    return '$amount బకాయి';
  }

  @override
  String get ngStaffTitle => 'సిబ్బంది';

  @override
  String ngStaffSummary(int n, int monthly, int other) {
    return '$n మంది · $monthly నెలవారీ · $other రోజువారీ / తాత్కాలిక';
  }

  @override
  String get ngStaffAdd => 'సిబ్బంది జోడించు';

  @override
  String get ngStaffMonthly => 'స్థిర నెలవారీ';

  @override
  String get ngStaffDaily => 'రోజువారీ';

  @override
  String get ngStaffTemporary => 'తాత్కాలిక';

  @override
  String ngStaffJoined(String date) {
    return 'చేరింది $date';
  }

  @override
  String get ngStaffAllRoles => 'అన్ని పాత్రలు';

  @override
  String get ngStaffNone => 'ఇంకా సిబ్బంది లేరు';

  @override
  String get ngStaffInactive => 'నిష్క్రియులు';

  @override
  String get ngSalTitle => 'జీతం';

  @override
  String get ngSalToPay => 'చెల్లించాల్సింది';

  @override
  String get ngSalAdvances => 'అడ్వాన్స్‌లు';

  @override
  String get ngSalPaid => 'చెల్లించిన జీతం';

  @override
  String get ngSalBalance => 'బ్యాలెన్స్';

  @override
  String ngSalJobs(int n) {
    return '$n పనులు';
  }

  @override
  String ngSalAdvance(String amount) {
    return 'అడ్వాన్స్ $amount';
  }

  @override
  String get ngSalNote =>
      'ఈ నెల ప్రతి పనిలో నమోదు చేసిన బృందం నుండి సంపాదన వస్తుంది. చెల్లించడానికి లేదా అడ్వాన్స్ ఇవ్వడానికి వ్యక్తిని తెరవండి.';

  @override
  String get ngSetApp => 'యాప్';

  @override
  String get ngSetLanguage => 'భాష';

  @override
  String get ngSetTheme => 'థీమ్';

  @override
  String get ngSetThemeLight => 'లైట్';

  @override
  String get ngSetThemeDark => 'డార్క్';

  @override
  String get ngSetThemeMidnight => 'మిడ్‌నైట్';

  @override
  String get ngSetNotifications => 'నోటిఫికేషన్‌లు';

  @override
  String get ngSetNotificationsSub => 'యాప్ తెరిచి ఉన్నప్పుడు హెచ్చరికలు చూపు';

  @override
  String get ngSetBusiness => 'వ్యాపారం';

  @override
  String get ngSetBizDetails => 'వ్యాపార వివరాలు';

  @override
  String get ngSetBizDetailsSub =>
      'పేరు, ట్యాగ్‌లైన్, GST, చిరునామా, లోగో, సంతకం, నిబంధనలు, నంబరింగ్';

  @override
  String get ngSetCft => 'CFT & ప్యాకేజీలు';

  @override
  String get ngSetCftSub => 'వస్తువుల పరిమాణం, ఇంటి పరిమాణం, నిల్వ రేట్లు';

  @override
  String get ngSetSecurity => 'భద్రత';

  @override
  String get ngSetLogin => 'లాగిన్ & భద్రత';

  @override
  String get ngSetLoginSub => 'మీ యాప్ PIN';

  @override
  String get ngSetAccount => 'ఖాతా & సహాయం';

  @override
  String get ngSetPlan => 'ప్లాన్ & బిల్లింగ్';

  @override
  String get ngSetPlanSub => 'మీ ప్లాన్, పరిమితులు';

  @override
  String get ngSetRecycle => 'తొలగించినవి';

  @override
  String get ngSetRecycleSub => 'పొరపాటున తొలగించినవి తిరిగి తెచ్చుకోండి';

  @override
  String get ngSetHelp => 'సహాయం & మద్దతు';

  @override
  String get ngSetHelpSub => 'సహాయ సంప్రదింపు, గోప్యతా విధానం, నిబంధనలు';

  @override
  String get ngSetPorter => 'Porter అనుసంధానం';

  @override
  String get ngSetPorterSub =>
      'డ్యాష్‌బోర్డ్‌లో Porter కమిషన్ చూపు. మీ వ్యాపారం Porter వాడితేనే ఆన్ చేయండి.';

  @override
  String odStageOf(int n, int total, String name) {
    return 'దశ $n / $total · $name';
  }

  @override
  String get odJourneyDone => 'అన్ని దశలు పూర్తయ్యాయి';

  @override
  String get odMaps => 'మ్యాప్స్';

  @override
  String get odProgress => 'పురోగతి';

  @override
  String get odInProgress => 'జరుగుతోంది';

  @override
  String odMarkAs(String stage) {
    return '$stageగా గుర్తించండి';
  }

  @override
  String get odDeliveredHint =>
      'కస్టమర్ కోడ్‌తో సిబ్బంది పని ముగించినప్పుడు డెలివరీ నమోదవుతుంది.';

  @override
  String get odOpenFieldJob => 'ఫీల్డ్ జాబ్ తెరవండి';

  @override
  String get odCrewVehicle => 'సిబ్బంది & వాహనం';

  @override
  String get odNoCrew => 'ఇంకా సిబ్బంది కేటాయించలేదు';

  @override
  String get odNoVehicle => 'వాహనం కేటాయించలేదు';

  @override
  String odSupervisorCrew(String name, int count) {
    return 'సూపర్‌వైజర్ · $name · $count మంది';
  }

  @override
  String odCrewCount(int count) {
    return '$count మంది';
  }

  @override
  String get odPayment => 'చెల్లింపు';

  @override
  String get odTotal => 'మొత్తం';

  @override
  String get odPaid => 'చెల్లించారు';

  @override
  String get odBalance => 'బాకీ';

  @override
  String get odPartPaid => 'పాక్షిక చెల్లింపు';

  @override
  String get odFullyPaid => 'చెల్లించబడింది';

  @override
  String get odUnpaid => 'చెల్లించలేదు';

  @override
  String get odRemind => 'గుర్తుచేయండి';

  @override
  String get odRecordPayment => 'చెల్లింపు నమోదు';

  @override
  String get odActivity => 'కార్యకలాపం';

  @override
  String odAllN(int count) {
    return 'అన్నీ $count';
  }

  @override
  String get odStageChanged => 'దశ మారింది';

  @override
  String odPaymentReceived(String amount) {
    return 'చెల్లింపు అందింది · $amount';
  }

  @override
  String get odNoActivity => 'ఈ ఆర్డర్‌పై ఇంకా ఏమీ నమోదు కాలేదు.';

  @override
  String get odMoveDetails => 'తరలింపు వివరాలు';

  @override
  String get odCancelled => 'రద్దయింది';

  @override
  String get odMore => 'మరిన్ని చర్యలు';

  @override
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor) {
    return 'Hi $customer, a balance of $amount is due for your move ($orderId). Thank you, $vendor';
  }

  @override
  String get odStConfirmed => 'నిర్ధారించబడింది';

  @override
  String get odStPacking => 'ప్యాకింగ్';

  @override
  String get odStInTransit => 'రవాణాలో';

  @override
  String get odStArrived => 'చేరుకుంది';

  @override
  String get odStDelivered => 'డెలివర్ అయింది';

  @override
  String get odStCompleted => 'పూర్తయింది';

  @override
  String get nlPhone => 'ఫోన్';

  @override
  String get nlName => 'పేరు';

  @override
  String get nlRoute => 'మార్గం';

  @override
  String get nlMovingFrom => 'ఎక్కడి నుండి';

  @override
  String get nlMovingTo => 'ఎక్కడికి';

  @override
  String get nlService => 'సేవ';

  @override
  String get nlWhen => 'ఎప్పుడు';

  @override
  String get nlToday => 'ఈరోజు';

  @override
  String get nlTomorrow => 'రేపు';

  @override
  String get nlPickDate => 'తేదీ ఎంచుకోండి';

  @override
  String get nlSource => 'మూలం';

  @override
  String get nlBranch => 'శాఖ';

  @override
  String get nlNextStep => 'తదుపరి అడుగు';

  @override
  String get nlStepFollow => 'ఫాలో-అప్';

  @override
  String get nlStepFollowSub => 'తర్వాత మళ్లీ కాల్';

  @override
  String get nlStepSurvey => 'సర్వే';

  @override
  String get nlStepSurveySub => 'సందర్శన, లింక్ లేదా కాల్‌లో';

  @override
  String get nlStepQuote => 'సర్వే దాటవేయి · కోట్';

  @override
  String get nlStepQuoteSub => 'ఈ కాల్‌లోనే ధర';

  @override
  String get nlStepConfirm => 'ఆర్డర్ నిర్ధారించండి';

  @override
  String get nlStepConfirmSub => 'కస్టమర్ ఇప్పుడే ఒప్పుకున్నారు';

  @override
  String get nlMore => 'మరిన్ని వివరాలు';

  @override
  String get nlEmail => 'ఇమెయిల్ (ఐచ్ఛికం)';

  @override
  String get nlNotes => 'గమనికలు';

  @override
  String get nlNameRequired => 'కస్టమర్ పేరు నమోదు చేయండి.';

  @override
  String get nlNoBranches =>
      'లీడ్‌లు సేవ్ చేసే ముందు సెట్టింగ్స్‌లో శాఖ జోడించండి.';

  @override
  String get nlUpdateLead => 'లీడ్ నవీకరించండి';

  @override
  String get noPickup => 'పికప్';

  @override
  String get noDrop => 'డ్రాప్';

  @override
  String get noPricing => 'ధర & మూలం';

  @override
  String get ngSetFy => 'ఆర్థిక సంవత్సరం & నంబరింగ్';

  @override
  String get ngSetFySub => 'వచ్చే సంవత్సరం బిల్లు నంబర్లు ప్రారంభించండి';

  @override
  String get ngSetWa => 'WhatsApp';

  @override
  String get ngSetWaSub => 'మీ స్వంత నంబర్ నుండి సందేశాలు పంపండి';

  @override
  String get ngSetAutoWa => 'ఆటో WhatsApp';

  @override
  String get ngSetAutoWaSub => 'ప్రతి దశలో కస్టమర్‌కు పంపే సందేశాలు';

  @override
  String get mdTitle => 'మాడ్యూల్స్';

  @override
  String get mdSettingsSub => 'ప్యాకర్స్ & మూవర్స్, రవాణా లేదా రెండూ';

  @override
  String get mdType => 'మీ వ్యాపారం';

  @override
  String get mdAdv => 'అధునాతన';

  @override
  String mdCount(int count, int total) {
    return '$totalలో $count మాడ్యూల్స్ ఆన్';
  }

  @override
  String mdGroupOn(int count, int total) {
    return '$totalలో $count ఆన్';
  }

  @override
  String get mdNote =>
      'ఆఫ్ చేసిన మాడ్యూల్స్ మెనూ నుండి కనిపించవు. మీ డేటా సేవ్ అయి ఉంటుంది, మళ్లీ ఆన్ చేస్తే తిరిగి వస్తుంది.';

  @override
  String get mdReset => 'ఈ వ్యాపారానికి సూచించినదానికి రీసెట్ చేయండి';

  @override
  String mdResetDone(String type) {
    return '$typeకి మాడ్యూల్స్ రీసెట్ అయ్యాయి';
  }

  @override
  String mdTypeSet(String type) {
    return '$type ఎంచుకున్నారు · మెనూ అప్‌డేట్ అయింది';
  }

  @override
  String get mdOwnerOnly => 'యజమాని మాత్రమే మాడ్యూల్స్ మార్చగలరు';

  @override
  String get mdSaveFailed => 'సేవ్ కాలేదు. కనెక్షన్ చూసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get btPm => 'ప్యాకర్స్ & మూవర్స్';

  @override
  String get btPmS => 'ఇల్లు, ఆఫీస్, వాహనం షిఫ్టింగ్';

  @override
  String get btTr => 'రవాణా / లాజిస్టిక్స్';

  @override
  String get btTrS => 'లారీలు, ట్రిప్పులు, సరుకు, డ్రైవర్లు';

  @override
  String get btBoth => 'రెండూ';

  @override
  String get btBothS => 'షిఫ్టింగ్ మరియు రవాణా, అన్నీ ఆన్';

  @override
  String get btTitle => 'మీ వ్యాపారం ఏం చేస్తుంది?';

  @override
  String get btSub =>
      'అవసరమైన మాడ్యూల్స్ మాత్రమే చూపిస్తాం. సెట్టింగ్స్ › మాడ్యూల్స్‌లో ఎప్పుడైనా మార్చవచ్చు.';

  @override
  String get btLater => 'తర్వాత సెట్టింగ్స్ › మాడ్యూల్స్‌లో మార్చవచ్చు';

  @override
  String get dwTitle => 'విడ్జెట్‌లు';

  @override
  String get dwSub => 'యజమాని డ్యాష్‌బోర్డ్‌లో ఏమి చూపాలి';

  @override
  String get dwNote =>
      'యజమాని డ్యాష్‌బోర్డ్‌లో ఈ క్రమంలో చూపిస్తాయి. బాణంతో పైకి, స్విచ్‌తో దాచండి.';

  @override
  String dwShown(int n) {
    return 'చూపిస్తోంది · స్థానం $n';
  }

  @override
  String get dwHidden => 'దాచారు';

  @override
  String get dwUp => 'పైకి';

  @override
  String get dwToday => 'ఈరోజు గణాంకాలు';

  @override
  String get dwFleet => 'వాహనాల స్థితి';

  @override
  String dwFleetSub(int a, int s) {
    return '$a యాక్టివ్ · $s సర్వీస్‌లో';
  }

  @override
  String get dwAttendance => 'సిబ్బంది హాజరు';

  @override
  String get dwAttendanceSub => 'ఈరోజు చెక్-ఇన్';

  @override
  String get dwSaveFailed => 'సేవ్ కాలేదు. కనెక్షన్ చూసి మళ్లీ ప్రయత్నించండి.';

  @override
  String get jrShareInvoice => 'బిల్లు పంపు';

  @override
  String get jrSendForSignature => 'సంతకానికి పంపు';

  @override
  String get lsTitle => 'లాగిన్ & భద్రత';

  @override
  String get lsMy => 'మీ లాగిన్';

  @override
  String get lsMyEmail => 'లాగిన్ ఈమెయిల్';

  @override
  String get lsChangePw => 'పాస్‌వర్డ్ మార్చు';

  @override
  String get lsCurPw => 'ప్రస్తుత పాస్‌వర్డ్';

  @override
  String get lsNewPw => 'కొత్త పాస్‌వర్డ్';

  @override
  String get lsConfPw => 'కొత్త పాస్‌వర్డ్ నిర్ధారించండి';

  @override
  String get lsPwSub => 'కనీసం 8 అక్షరాలు';

  @override
  String get lsPwShort => 'పాస్‌వర్డ్ కనీసం 8 అక్షరాలు ఉండాలి';

  @override
  String get lsPwMismatch => 'పాస్‌వర్డ్‌లు సరిపోలలేదు';

  @override
  String get lsPwCurReq => 'ప్రస్తుత పాస్‌వర్డ్ ఇవ్వండి';

  @override
  String get lsPwDone => 'పాస్‌వర్డ్ మారింది';

  @override
  String get lsUpdatePw => 'పాస్‌వర్డ్ అప్‌డేట్';

  @override
  String get lsForgot =>
      'పాస్‌వర్డ్ మర్చిపోయారా? లాగిన్ స్క్రీన్‌లో \"పాస్‌వర్డ్ మర్చిపోయారా?\" నొక్కండి. రీసెట్ లింక్ ఈమెయిల్ చేస్తాం.';

  @override
  String get lsStaffPins => 'సిబ్బంది PIN లు';

  @override
  String get lsStaffPinsSub =>
      'సిబ్బంది, సూపర్‌వైజర్లు PIN తో లాగిన్ అవుతారు. మర్చిపోతే కొత్త PIN సెట్ చేయండి. పదేపదే తప్పు PIN వేస్తే, మీరు రీసెట్ చేసే వరకు PIN లాక్ అవుతుంది.';

  @override
  String get lsResetPin => 'PIN రీసెట్';

  @override
  String get lsPinSet => 'PIN సెట్';

  @override
  String lsLocked(int n) {
    return 'లాక్ · $n తప్పులు';
  }

  @override
  String get lsNewPin => 'కొత్త PIN';

  @override
  String get lsConfPin => 'PIN నిర్ధారించండి';

  @override
  String get lsPinBad => 'PIN 4 అంకెలు ఉండాలి';

  @override
  String get lsPinMismatch => 'PIN లు సరిపోలలేదు';

  @override
  String lsPinSetFor(String name) {
    return 'కొత్త PIN సెట్ అయింది: $name';
  }

  @override
  String get lsTellStaff =>
      'కొత్త PIN ను నేరుగా లేదా ఫోన్‌లో చెప్పండి. ఇది మళ్ళీ చూపబడదు.';

  @override
  String get lsSetPin => 'కొత్త PIN సెట్ చేయి';

  @override
  String get lsSignOutAll => 'మిగతా అన్ని పరికరాల నుండి సైన్ అవుట్';

  @override
  String get lsAllOut => 'మిగతా అన్ని పరికరాలు సైన్ అవుట్ అయ్యాయి';

  @override
  String get lsNoPin => 'ఇంకా PIN లేదు';

  @override
  String get lsOwnerOnly => 'సిబ్బంది PIN‌ను యజమాని మాత్రమే రీసెట్ చేయగలరు.';

  @override
  String get qdTitle => 'కోట్ డిజైన్';

  @override
  String get qdSub => 'మీ కోటేషన్ PDF కస్టమర్లకు ఎలా కనిపిస్తుంది.';

  @override
  String get qdTheme => 'థీమ్';

  @override
  String get qdColor => 'బ్రాండ్ రంగు';

  @override
  String get qdLogo => 'లోగో';

  @override
  String get qdLogoAdd => 'లోగో అప్‌లోడ్';

  @override
  String get qdLogoHint => 'PNG లేదా JPG, చతురస్రం బాగుంటుంది';

  @override
  String get qdSave => 'డిజైన్ సేవ్';

  @override
  String get qdPreview => 'నమూనా PDF చూడండి';

  @override
  String get qdSaved => 'కోట్ డిజైన్ సేవ్ అయింది';

  @override
  String get qdTheme1A => 'క్లాసిక్';

  @override
  String get qdTheme1B => 'బోల్డ్ బ్యాండ్';

  @override
  String get qdTheme1C => 'సైడ్‌బార్';

  @override
  String get qdTheme1D => 'మినిమల్';

  @override
  String get qdTheme1E => 'కార్పొరేట్';

  @override
  String get qdTheme1F => 'లెటర్‌హెడ్';

  @override
  String get qdThemeDesc1A => 'సెరిఫ్, గీతలు';

  @override
  String get qdThemeDesc1B => 'రంగు హెడర్, గుండ్రని ప్యానెల్స్';

  @override
  String get qdThemeDesc1C => 'ఎడమవైపు వివరాల కాలమ్';

  @override
  String get qdThemeDesc1D => 'నలుపు తెలుపు, ఎక్కడైనా ప్రింట్';

  @override
  String get qdThemeDesc1E => 'బాక్స్ ఫారమ్, ఆఫీస్ షిఫ్టింగ్‌కి';

  @override
  String get qdThemeDesc1F => 'మధ్యలో, డబుల్ గీత';

  @override
  String get drvTitle => 'డ్రైవర్ యాప్';

  @override
  String get drvNone => 'ఈరోజు ట్రిప్ లేదు';

  @override
  String get drvPlanned => 'ప్లాన్';

  @override
  String get drvOngoing => 'ట్రిప్‌లో';

  @override
  String get drvStart => 'ట్రిప్ మొదలు';

  @override
  String get drvEnd => 'ట్రిప్ ముగించు';

  @override
  String get drvDone => 'ట్రిప్ పూర్తి';

  @override
  String get drvFuel => 'ఇంధనం';

  @override
  String get drvFuelT => 'ఇంధనం జోడించు';

  @override
  String get drvToll => 'టోల్';

  @override
  String get drvTollT => 'టోల్ జోడించు';

  @override
  String get drvLitres => 'లీటర్లు';

  @override
  String get drvPlaza => 'ప్లాజా';

  @override
  String get drvAdd => 'ఎంట్రీ జోడించు';

  @override
  String get drvNeedStart => 'మొదలు ఓడోమీటర్ ఇవ్వండి';

  @override
  String get drvNeedEnd => 'ముగింపు ఓడోమీటర్ మొదలు కంటే ఎక్కువ ఉండాలి';

  @override
  String get drvNeedAmount => 'మొత్తం ఇవ్వండి';

  @override
  String get drvTripKm => 'ట్రిప్ కిమీ';

  @override
  String get drvTripSpend => 'ట్రిప్ ఖర్చు';

  @override
  String get drvToday => 'ఈరోజు ఎంట్రీలు';

  @override
  String get drvOdoStart => 'మొదలు ఓడోమీటర్';

  @override
  String get drvOdoEnd => 'ముగింపు ఓడోమీటర్';

  @override
  String get mktTitle => 'Nagarva పనులు';

  @override
  String get mktSub => 'Nagarva లో కస్టమర్లు బుక్ చేసిన షిఫ్టింగ్‌లు';

  @override
  String get mktTier => 'మీ టియర్';

  @override
  String get mktWallet => 'వాలెట్';

  @override
  String mktMinL(String m) {
    return 'పనులు పొందడానికి కనీసం $m';
  }

  @override
  String get mktLowS => 'కనీసం కంటే తక్కువ';

  @override
  String get mktTJobs => 'పనులు';

  @override
  String get mktTWallet => 'వాలెట్';

  @override
  String get mktTTier => 'టియర్';

  @override
  String get mktAv => 'పనికి అందుబాటులో';

  @override
  String mktAvOn(String c) {
    return '$c జాబ్ అలర్ట్‌లు వస్తున్నాయి';
  }

  @override
  String get mktAvOff =>
      'ఆఫ్. కొత్త జాబ్ అలర్ట్‌లు లేవు. స్కోర్‌పై ప్రభావం లేదు.';

  @override
  String get mktCities => 'పికప్ నగరాలు';

  @override
  String get mktCitiesN =>
      'ఈ నగరాల్లో మొదలయ్యే బుకింగ్‌లకు అలర్ట్ వస్తుంది. సొంత నగరం తీసివేయలేరు.';

  @override
  String get mktEdit => 'మార్చు';

  @override
  String get mktDone2 => 'పూర్తి';

  @override
  String get mktCancel => 'రద్దు';

  @override
  String get mktHome => 'సొంత';

  @override
  String get mktRtAsk => 'వాహనం వేరే నగరంలో ఉందా?';

  @override
  String get mktRtAdd => 'జోడించు';

  @override
  String get mktRtEnd => 'ముగించు';

  @override
  String get mktRtFrom => 'వాహనం ఇప్పుడు ఉన్నది';

  @override
  String get mktRtDate => 'బయలుదేరే తేదీ';

  @override
  String mktRtOn(String f, String t) {
    return 'రిటర్న్ ట్రిప్ · $f → $t';
  }

  @override
  String get mktRtEnded => 'రిటర్న్ ట్రిప్ ముగిసింది';

  @override
  String get mktFNew => 'కొత్తవి';

  @override
  String get mktFAcc => 'అంగీకరించినవి';

  @override
  String get mktFDone => 'పూర్తయినవి';

  @override
  String get mktENew =>
      'ఇప్పుడు కొత్త పనులు లేవు. వచ్చినప్పుడు నోటిఫికేషన్ వస్తుంది.';

  @override
  String get mktEAcc => 'అంగీకరించిన పనులు లేవు.';

  @override
  String get mktEDone => 'ఇంకా పూర్తయిన పనులు లేవు.';

  @override
  String get mktEOff =>
      'మీరు అందుబాటులో లేరు. కొత్త బుకింగ్‌ల కోసం ఆన్ చేయండి.';

  @override
  String mktLow(String a, String m) {
    return 'వాలెట్ $m కంటే తక్కువ. కొత్త పనులు చూడడానికి $a టాప్-అప్ చేయండి.';
  }

  @override
  String get mktVal => 'పని విలువ (GST తో)';

  @override
  String mktCom(String p) {
    return 'Nagarva కమీషన్ $p%';
  }

  @override
  String get mktEarn => 'మీ సంపాదన';

  @override
  String get mktAdv => 'Nagarva కు చెల్లించిన అడ్వాన్స్';

  @override
  String get mktBal => 'డెలివరీ OTP తర్వాత వసూలు';

  @override
  String get mktMasked => 'అంగీకరించాక కస్టమర్ పేరు, ఫోన్ కనిపిస్తాయి';

  @override
  String get mktPass => 'వదిలేయి';

  @override
  String get mktAccept => 'పని అంగీకరించు';

  @override
  String mktAccepted(String id) {
    return '$id మీది. కస్టమర్ వివరాలు తెరుచుకున్నాయి.';
  }

  @override
  String get mktPassed => 'పని వదిలేశారు';

  @override
  String get mktTaken => 'వేరే వెండర్ తీసుకున్నారు';

  @override
  String get mktGoldOnly => 'గోల్డ్ మాత్రమే';

  @override
  String get mktRl => 'రిటర్న్ లోడ్';

  @override
  String get mktS0 => 'అంగీకారం';

  @override
  String get mktS1 => 'దారిలో';

  @override
  String get mktS2 => 'చేరుకున్నారు';

  @override
  String get mktS3 => 'లోడింగ్';

  @override
  String get mktS4 => 'ప్రయాణంలో';

  @override
  String get mktS5 => 'డెలివరీ';

  @override
  String mktNext(String s) {
    return '$s గా గుర్తించు';
  }

  @override
  String mktPhotos(int n) {
    return 'లోడింగ్ ఫోటోలు $n/3';
  }

  @override
  String get mktNeedPh => 'ముందు 3 లోడింగ్ ఫోటోలు జోడించండి';

  @override
  String get mktAddPh => 'ఫోటో జోడించు';

  @override
  String get mktFinish => 'OTP ధృవీకరించి పూర్తి చేయి';

  @override
  String get mktOtpBad => 'తప్పు OTP. కస్టమర్‌తో సరిచూడండి.';

  @override
  String mktDone(String a, String c) {
    return 'పూర్తయింది. $c కమీషన్ తగ్గించారు, $a అడ్వాన్స్ జమ.';
  }

  @override
  String mktRate(String r) {
    return 'కస్టమర్ రేటింగ్ $r';
  }

  @override
  String get mktNoRate => 'కస్టమర్ రేటింగ్ రావాలి';

  @override
  String get mktTopup => 'టాప్-అప్';

  @override
  String get mktWBal => 'వాలెట్ బ్యాలెన్స్';

  @override
  String get mktWOk => 'యాక్టివ్ · కొత్త పనులు వస్తాయి';

  @override
  String get mktWWithdraw => 'విత్‌డ్రా';

  @override
  String mktWNote(String p) {
    return 'కస్టమర్లు అడ్వాన్స్ Nagarva కు చెల్లిస్తారు. పని పూర్తయ్యాక అడ్వాన్స్ ఇక్కడ జమ అవుతుంది, $p% కమీషన్ తగ్గుతుంది. పనులు పొందడానికి కనీస బ్యాలెన్స్ ఉంచండి.';
  }

  @override
  String mktWtAdv(String id) {
    return 'అడ్వాన్స్ · $id';
  }

  @override
  String mktWtCom(String id) {
    return 'కమీషన్ · $id';
  }

  @override
  String get mktWtTop => 'UPI టాప్-అప్';

  @override
  String get mktWtWd => 'బ్యాంక్‌కు విత్‌డ్రా';

  @override
  String get mktTierF => 'మీ స్కోర్ ఎలా వస్తుంది';

  @override
  String get mktTierBands => 'గోల్డ్ 80+ · సిల్వర్ 60–79 · బ్రాంజ్ <60';

  @override
  String get mktTierGold => 'గోల్డ్';

  @override
  String get mktTierSilver => 'సిల్వర్';

  @override
  String get mktTierBronze => 'బ్రాంజ్';

  @override
  String mktTierScore(String s) {
    return 'స్కోర్ $s / 100';
  }

  @override
  String get mktOtpAsk => 'కస్టమర్‌ను 4 అంకెల డెలివరీ కోడ్ అడగండి.';

  @override
  String get mktReqSent =>
      'అభ్యర్థన పంపబడింది. Nagarva చెల్లింపును నిర్ధారించాక లెక్కలోకి వస్తుంది.';

  @override
  String get mktPending => 'పెండింగ్';

  @override
  String get mktHomeCity => 'హోమ్ నగరం';

  @override
  String get mktExtraCities => 'ఇతర నగరాలు, కామాలతో వేరు చేయండి';

  @override
  String get mktNotJoined =>
      'Nagarva జాబ్‌లు పొందడానికి మీ హోమ్ నగరం సెట్ చేయండి.';

  @override
  String get mktFactorNote =>
      'Nagarva మీ స్కోర్‌ను వీటి నుండి, ఈ వెయిట్‌లతో లెక్కిస్తుంది.';

  @override
  String get mktFRating => 'కస్టమర్ రేటింగ్';

  @override
  String get mktFOnTime => 'సమయానికి చేరుకోవడం';

  @override
  String get mktFDamage => 'నష్ట క్లెయిమ్‌లు';

  @override
  String get mktFAccept => 'అంగీకార రేటు';

  @override
  String get mktFPhotos => 'ఫోటో పాటింపు';

  @override
  String get mktFCancel => 'వెండర్ రద్దులు';

  @override
  String get mktFJobs => 'పూర్తయిన జాబ్‌లు';

  @override
  String get mktAvOnT => 'జాబ్ అలర్ట్‌లు మళ్ళీ వస్తాయి';

  @override
  String get mktAvOffT => 'జాబ్ అలర్ట్‌లు ఆపారు';
}
