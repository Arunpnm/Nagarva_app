import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'pdf_branding.dart';

/// Business tax-invoice PDF (A4) for the packers & movers trade.
///
/// Layout follows the APC invoice template that was the functional spec —
/// see `nagarva_document_field_spec.md` §3 for the full field-by-field diff
/// this file was extended to close (Session 3, Tier 2, task #42): Bill No/
/// LR cross-reference/Delivery Date/Vehicle No, a Bill To block distinct
/// from Move From (billing party can differ from the consignor), package/
/// weight info, HSN/SAC 996719, Payment Remark/Remark, GST Paid By +
/// Reverse Charge YES/NO, Total Freight In Words, and a PAID watermark.
///
/// Branding is [org] (an already-resolved [OrgProfile] — organizations
/// columns first, that same org's `settings.business_profile` jsonb as
/// fallback, see pdf_branding.dart) and [boilerplate] (`app_settings`
/// category 'documents', for the footer). This file used to inline its own
/// header/footer/branding-map lookup (from before [OrgProfile]/
/// [DocumentBoilerplate] existed) — folded onto the shared builder now,
/// per the "follow-up can fold it in later" note that used to sit on
/// PdfBranding.headerBand.
///
/// Fonts: Noto Sans via PdfGoogleFonts (fetched once, cached) because the
/// built-in Helvetica has no ₹ glyph.

/// Renders a GST rate the way an invoice states it: 18, 2.5, 0.25 — never
/// "18.0". Kept next to its only caller rather than in a util file,
/// because it exists for this one presentation rule.
String _ratePct(double v) {
  final s = v.toStringAsFixed(2);
  return s.replaceFirst(RegExp(r'\.?0+$'), '');
}

class InvoicePdf {
  static Future<Uint8List> generate({
    required String invoiceNo,
    required OrgProfile org,
    required DocumentBoilerplate boilerplate,
    required String customerName,
    String? customerPhone,
    String? fromCity,
    String? toCity,
    String? fromAddress,
    String? toAddress,
    required double baseAmount,
    required bool interstate,
    required double igst,
    required double cgst,
    required double sgst,
    required double total,
    /// The rate actually charged, for the tax rows' labels.
    ///
    /// They were hardcoded 'IGST @ 5%' / 'CGST @ 2.5%' / 'SGST @ 2.5%'
    /// while the AMOUNTS came from the order's real quote_gst_pct — so a
    /// live invoice printed "CGST @ 2.5%  Rs3,239.00" against a taxable
    /// value of Rs30,500, which is 9%. A tax invoice must state the rate
    /// it charges; a stated rate that contradicts the tax beside it is a
    /// compliance defect, not a typo.
    ///
    /// Same half-fixed bug twice: the 12 Aug 2026 pass corrected the
    /// hardcoded 5% in the CALCULATION and left it in the LABELS.
    double gstPct = 5,
    Uint8List? logoBytes,
    Uint8List? signatureBytes,
    // Customer's e-signature captured via the public /sign link
    // (fix brief #2, item 3). All three are null on an unsigned invoice.
    Uint8List? customerSignatureBytes,
    String? customerSignedByName,
    String? customerSignedByPhone,
    DateTime? customerSignedAt,
    // Part 8 addendum item 3: true when customerSignatureBytes came from
    // the QUOTE's signature (documentType: 'quote'), not an invoice-
    // specific one — the invoice lookup found nothing and this order's
    // quotation_id was used to fall back. Must never be presented as if
    // signed on the invoice itself; see the provenance line below. Ignored
    // when customerSignatureBytes is null.
    bool signatureInherited = false,
    String? inheritedFromQuoteRef,
    // ---- Tier A additions (Session 3, field spec §3) ---------------------
    DateTime? billingDate,
    String? lrNo,
    DateTime? deliveryDate,
    String? vehicleNo,
    // Billing party can differ from the consignor (corporate relocation
    // billed to the employer, not the employee) — orders.billing_party_*
    // (migration 009). Falls back to the consignor/customer when null.
    String? billingPartyName,
    String? billingPartyGstin,
    String? billingPartyAddress,
    String? billingPartyPhone,
    int? packageCount,
    num? actualWeightKg,
    num? chargedWeightKg,
    String hsnSacCode = '996719',
    String? paymentRemark,
    String? remark,
    // Same charge heads the quotation shows (kDefaultChargeFields labels),
    // non-zero only — the caller resolves this (quotations.charges when
    // the order has a linked quote, else a single fallback line built from
    // [baseAmount]) so this file stays a pure renderer.
    List<MapEntry<String, num>> particulars = const [],
    // No dedicated orders column exists for this (field spec §3: "GST Paid
    // By — [SCHEMA GAP]") — the caller resolves it from the linked
    // lr_register row's gst_payable_by when one exists. Null renders the
    // same "Consignee" default this file has always shown.
    String? gstPayableBy,
    bool reverseCharge = false,
    // Total (freight) in words — via the DB's amount_in_words() RPC, never
    // reimplemented in Dart (Indian lakh/crore numbering has enough edge
    // cases that duplicating it client-side would drift). Null just omits
    // the strip rather than guessing.
    String? amountInWords,
    // Diagonal green semi-transparent stamp when the order is settled.
    bool isPaid = false,
  }) async {
    final fonts = await PdfBranding.loadFonts();
    final billedOn = billingDate ?? DateTime.now();

    final doc = pw.Document();

    pw.Widget kv(String label, String value, {bool boldValue = false}) =>
        PdfBranding.kv(label, value, fonts, boldValue: boldValue);

    // ---- Signature band geometry ----------------------------------------
    // Each cell is a fixed height AND the caption block under each rule is a
    // fixed height. That is what pins every signature rule to the same y.
    // The previous band was a bare pw.Row of three children with different
    // intrinsic heights, so the customer rule, the signatory rule and the
    // payment panel each settled at a different baseline - the misalignment
    // was structural, not a spacing tweak.
    const signBandHeight = 124.0;
    const signCaptionHeight = 40.0;

    pw.Widget signCell({
      Uint8List? image,
      String? emptyNote,
      required String caption,
      String? line2,
      String? line3,
      String? footnote,
    }) =>
        pw.Container(
          height: signBandHeight,
          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Expanded(
                child: pw.Center(
                  child: image != null
                      ? pw.Image(pw.MemoryImage(image), fit: pw.BoxFit.contain)
                      : pw.Text(
                          emptyNote ?? '',
                          textAlign: pw.TextAlign.center,
                          style: pw.TextStyle(
                              font: fonts.regular,
                              fontSize: 8,
                              fontStyle: pw.FontStyle.italic,
                              color: PdfBranding.grey),
                        ),
                ),
              ),
              pw.Container(height: .8, color: PdfColors.grey600),
              pw.SizedBox(
                height: signCaptionHeight,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    pw.SizedBox(height: 3),
                    pw.Text(caption,
                        textAlign: pw.TextAlign.center,
                        style: pw.TextStyle(font: fonts.bold, fontSize: 8.5)),
                    if (line2 != null)
                      pw.Text(line2,
                          textAlign: pw.TextAlign.center,
                          style: pw.TextStyle(
                              font: fonts.regular,
                              fontSize: 7.5,
                              color: PdfBranding.grey)),
                    if (line3 != null)
                      pw.Text(line3,
                          textAlign: pw.TextAlign.center,
                          style: pw.TextStyle(
                              font: fonts.regular,
                              fontSize: 7.5,
                              color: PdfBranding.grey)),
                    if (footnote != null)
                      pw.Text(footnote,
                          textAlign: pw.TextAlign.center,
                          style: pw.TextStyle(
                              font: fonts.regular,
                              fontSize: 6.5,
                              fontStyle: pw.FontStyle.italic,
                              color: PdfBranding.grey)),
                  ],
                ),
              ),
            ],
          ),
        );

    // Explicit height rather than stretching: the band Row is laid out
    // inside an unbounded-height Container, so a stretched divider makes
    // the flex constraints unbounded and the whole page fails to lay out.
    pw.Widget vRule() => pw.Container(
        width: .8, height: signBandHeight, color: PdfColors.grey400);

    final resolvedBillToName =
        (billingPartyName ?? '').trim().isNotEmpty ? billingPartyName! : customerName;
    final resolvedBillToGstin = billingPartyGstin;
    final resolvedBillToAddress = billingPartyAddress;
    final resolvedBillToPhone =
        (billingPartyPhone ?? '').trim().isNotEmpty ? billingPartyPhone : customerPhone;

    final particularsRows = particulars.isNotEmpty
        ? particulars
        : [MapEntry('Freight & Moving Services', baseAmount)];

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(28),
        theme: pw.ThemeData.withFont(base: fonts.regular, bold: fonts.bold),
        build: (ctx) => pw.Stack(
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                // ---- Header ----------------------------------------------
                PdfBranding.headerFull(
                  org: org,
                  docLabel: 'BILL (TAX INVOICE)',
                  fonts: fonts,
                  logoBytes: logoBytes,
                ),
                pw.SizedBox(height: 14),

                // ---- Bill To / Move From-To + invoice meta --------------
                pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Expanded(
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text('BILL TO',
                              style: pw.TextStyle(
                                  font: fonts.bold,
                                  fontSize: 9,
                                  color: PdfBranding.navy)),
                          pw.SizedBox(height: 3),
                          pw.Text(resolvedBillToName,
                              style:
                                  pw.TextStyle(font: fonts.bold, fontSize: 11)),
                          if ((resolvedBillToPhone ?? '').isNotEmpty)
                            kv('Phone', resolvedBillToPhone!),
                          if ((resolvedBillToGstin ?? '').isNotEmpty)
                            kv('GSTIN', resolvedBillToGstin!),
                          if ((resolvedBillToAddress ?? '').isNotEmpty)
                            kv('Address', resolvedBillToAddress!),
                        ],
                      ),
                    ),
                    pw.SizedBox(width: 14),
                    pw.Expanded(
                      child: pw.Row(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Expanded(
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text('MOVE FROM',
                                    style: pw.TextStyle(
                                        font: fonts.bold,
                                        fontSize: 8.5,
                                        color: PdfBranding.navy)),
                                pw.Text(fromAddress ?? fromCity ?? '—',
                                    style: pw.TextStyle(
                                        font: fonts.regular, fontSize: 8.5)),
                              ],
                            ),
                          ),
                          pw.Expanded(
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text('MOVE TO',
                                    style: pw.TextStyle(
                                        font: fonts.bold,
                                        fontSize: 8.5,
                                        color: PdfBranding.navy)),
                                pw.Text(toAddress ?? toCity ?? '—',
                                    style: pw.TextStyle(
                                        font: fonts.regular, fontSize: 8.5)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    pw.SizedBox(width: 14),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        kv('Bill No', invoiceNo, boldValue: true),
                        kv('Billing Date', PdfBranding.fmtDate(billedOn)),
                        if ((lrNo ?? '').isNotEmpty) kv('LR No', lrNo!),
                        if (deliveryDate != null)
                          kv('Delivery Date', PdfBranding.fmtDate(deliveryDate)),
                        if ((vehicleNo ?? '').isNotEmpty)
                          kv('Vehicle No', vehicleNo!),
                        kv('Place of Supply', fromCity ?? '—'),
                      ],
                    ),
                  ],
                ),
                pw.SizedBox(height: 10),

                // ---- Package / weight / HSN info row ---------------------
                pw.Wrap(
                  spacing: 16,
                  runSpacing: 2,
                  children: [
                    if (packageCount != null)
                      kv('Packages', '$packageCount'),
                    if (actualWeightKg != null)
                      kv('Actual Weight', '${actualWeightKg} Kg'),
                    if (chargedWeightKg != null)
                      kv('Charged Weight', '${chargedWeightKg} Kg'),
                    kv('HSN/SAC', hsnSacCode),
                  ],
                ),
                pw.SizedBox(height: 10),

                // ---- Particulars table ------------------------------------
                pw.Table(
                  columnWidths: {
                    0: const pw.FlexColumnWidth(6),
                    1: const pw.FlexColumnWidth(2),
                    2: const pw.FlexColumnWidth(2),
                  },
                  border:
                      pw.TableBorder.all(color: PdfColors.grey400, width: .5),
                  children: [
                    pw.TableRow(
                      decoration:
                          const pw.BoxDecoration(color: PdfBranding.navy),
                      children: [
                        for (final h in ['PARTICULARS', 'SAC', 'AMOUNT'])
                          pw.Padding(
                            padding: const pw.EdgeInsets.symmetric(
                                horizontal: 8, vertical: 6),
                            child: pw.Text(h,
                                textAlign: h == 'AMOUNT'
                                    ? pw.TextAlign.right
                                    : pw.TextAlign.left,
                                style: pw.TextStyle(
                                    font: fonts.bold,
                                    fontSize: 9,
                                    color: PdfColors.white)),
                          ),
                      ],
                    ),
                    for (var i = 0; i < particularsRows.length; i++)
                      pw.TableRow(
                        decoration: pw.BoxDecoration(
                            color: i.isOdd
                                ? PdfBranding.lightRow
                                : PdfColors.white),
                        children: [
                          pw.Padding(
                            padding: const pw.EdgeInsets.symmetric(
                                horizontal: 8, vertical: 6),
                            child: pw.Text(particularsRows[i].key,
                                style:
                                    pw.TextStyle(font: fonts.regular, fontSize: 9)),
                          ),
                          pw.Padding(
                            padding: const pw.EdgeInsets.symmetric(
                                horizontal: 8, vertical: 6),
                            child: pw.Text(hsnSacCode,
                                style:
                                    pw.TextStyle(font: fonts.regular, fontSize: 9)),
                          ),
                          pw.Padding(
                            padding: const pw.EdgeInsets.symmetric(
                                horizontal: 8, vertical: 6),
                            child: pw.Text(
                                PdfBranding.rupees(particularsRows[i].value),
                                textAlign: pw.TextAlign.right,
                                style:
                                    pw.TextStyle(font: fonts.regular, fontSize: 9)),
                          ),
                        ],
                      ),
                  ],
                ),
                pw.SizedBox(height: 8),
                if ((paymentRemark ?? '').isNotEmpty)
                  kv('Payment Remark', paymentRemark!),
                if ((remark ?? '').isNotEmpty) kv('Remark', remark!),
                pw.SizedBox(height: 10),

                // ---- Totals ------------------------------------------------
                pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Expanded(
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          kv('GST Payable by', gstPayableBy ?? 'Consignee'),
                          // Printed ONLY when reverse charge genuinely
                          // applies. This used to render
                          // `reverseCharge ? 'YES' : 'NO'` unconditionally,
                          // so every invoice ever issued — three of them
                          // live — asserted "Reverse Charge: NO" as a
                          // positive tax position, taken from
                          // `orders.reverse_charge`, a column NO UI writes.
                          // Verified 10 Sept 2026: it is `false` on all 7
                          // orders from a column DEFAULT, not null, so a
                          // null-guard would never have fired — the test
                          // has to be on the value being true.
                          // Absent is honest; "NO" is a claim. Whether a
                          // document should ever assert the negative, and
                          // on what basis, is a CA question and is open.
                          if (reverseCharge)
                            kv('Reverse Charge', 'YES'),
                          kv(
                              'Tax Type',
                              interstate
                                  ? 'IGST (Interstate)'
                                  : 'CGST + SGST (Intrastate)'),
                        ],
                      ),
                    ),
                    pw.SizedBox(
                      width: 220,
                      child: pw.Column(
                        children: [
                          _totalRow('Taxable Value', PdfBranding.rupees(baseAmount),
                              fonts.regular, fonts.bold),
                          if (interstate)
                            _totalRow('IGST @ ${_ratePct(gstPct)}%',
                                PdfBranding.rupees(igst),
                                fonts.regular, fonts.bold)
                          else ...[
                            _totalRow('CGST @ ${_ratePct(gstPct / 2)}%',
                                PdfBranding.rupees(cgst),
                                fonts.regular, fonts.bold),
                            _totalRow('SGST @ ${_ratePct(gstPct / 2)}%',
                                PdfBranding.rupees(sgst),
                                fonts.regular, fonts.bold),
                          ],
                          pw.Container(
                            margin: const pw.EdgeInsets.only(top: 4),
                            padding: const pw.EdgeInsets.symmetric(
                                horizontal: 8, vertical: 6),
                            decoration: pw.BoxDecoration(
                              color: PdfBranding.navy,
                              borderRadius: pw.BorderRadius.circular(4),
                            ),
                            child: pw.Row(
                              mainAxisAlignment:
                                  pw.MainAxisAlignment.spaceBetween,
                              children: [
                                pw.Text('GRAND TOTAL',
                                    style: pw.TextStyle(
                                        font: fonts.bold,
                                        fontSize: 10,
                                        color: PdfColors.white)),
                                pw.Text(PdfBranding.rupees(total),
                                    style: pw.TextStyle(
                                        font: fonts.bold,
                                        fontSize: 11,
                                        color: PdfBranding.gold)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                if ((amountInWords ?? '').isNotEmpty) ...[
                  pw.SizedBox(height: 8),
                  pw.Container(
                    padding: const pw.EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: pw.BoxDecoration(
                      color: PdfBranding.lightRow,
                      borderRadius: pw.BorderRadius.circular(4),
                    ),
                    child: pw.RichText(
                      text: pw.TextSpan(children: [
                        pw.TextSpan(
                            text: 'Total Freight In Words: ',
                            style: pw.TextStyle(
                                font: fonts.bold,
                                fontSize: 8.5,
                                color: PdfBranding.navy)),
                        pw.TextSpan(
                            text: amountInWords,
                            style:
                                pw.TextStyle(font: fonts.regular, fontSize: 8.5)),
                      ]),
                    ),
                  ),
                ],
                pw.SizedBox(height: 16),

                // ---- Bank + signature band -------------------------------
                // One bordered strip, three equal cells divided by rules -
                // bank/UPI, customer acceptance, authorised signatory - with
                // every signature rule on a common baseline (see signCell).
                pw.Container(
                  decoration: pw.BoxDecoration(
                    border: pw.Border.all(color: PdfColors.grey400, width: .8),
                  ),
                  child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Expanded(
                        child: pw.Container(
                          height: signBandHeight,
                          padding: const pw.EdgeInsets.all(8),
                          child: pw.Column(
                            crossAxisAlignment: pw.CrossAxisAlignment.start,
                            children: [
                              pw.Text('PAYMENT DETAILS',
                                  style: pw.TextStyle(
                                      font: fonts.bold,
                                      fontSize: 8.5,
                                      color: PdfBranding.navy)),
                              pw.SizedBox(height: 3),
                              if ((org.beneficiaryName ?? '').isNotEmpty)
                                kv('Beneficiary', org.beneficiaryName!),
                              if ((org.bankName ?? '').isNotEmpty)
                                kv('Bank', org.bankName!),
                              if ((org.bankAccountNo ?? '').isNotEmpty)
                                kv('A/c No', org.bankAccountNo!),
                              if ((org.bankIfsc ?? '').isNotEmpty)
                                kv('IFSC', org.bankIfsc!),
                              if ((org.upiId ?? '').isNotEmpty)
                                kv('UPI', org.upiId!),
                              if ((org.upiDisplayNumber ?? '').isNotEmpty)
                                kv('PhonePe/GPay', org.upiDisplayNumber!),
                              // NOTHING when the vendor has no bank
                              // details. This used to print "Add bank &
                              // UPI details in Settings." — an
                              // instruction addressed to the VENDOR,
                              // printed on the tax invoice the CUSTOMER
                              // receives. Seen 7 Sept 2026 by rendering a
                              // real invoice rather than reading the
                              // code.
                              //
                              // A customer cannot act on it and should
                              // never have been shown it: it tells them
                              // their mover has not finished setting up
                              // their software, on the document that is
                              // supposed to be the most formal thing the
                              // business produces. An empty panel says
                              // "pay another way"; this said "we are
                              // half-configured".
                              //
                              // In-app prompts belong in the app. The
                              // Settings screen already has one.
                            ],
                          ),
                        ),
                      ),
                      vRule(),
                      pw.Expanded(
                        child: signCell(
                          image: customerSignatureBytes,
                          emptyNote: 'Awaiting customer signature',
                          caption: customerSignatureBytes == null
                              ? 'Receiver Signature'
                              : 'Accepted by ${customerSignedByName ?? 'Customer'}',
                          line2: (customerSignedByPhone ?? '').isNotEmpty
                              ? customerSignedByPhone
                              : null,
                          line3: customerSignedAt == null
                              ? null
                              : PdfBranding.fmtDateTime(customerSignedAt),
                          // An inherited quote signature must never read as if
                          // it were signed on the invoice itself - quote
                          // acceptance and delivery confirmation are legally
                          // different things, so this is stated, not implied.
                          footnote:
                              (customerSignatureBytes != null && signatureInherited)
                                  ? 'Signature carried forward from quotation'
                                      '${inheritedFromQuoteRef == null ? '' : ' $inheritedFromQuoteRef'}'
                                  : null,
                        ),
                      ),
                      vRule(),
                      pw.Expanded(
                        child: signCell(
                          image: signatureBytes,
                          emptyNote: '',
                          caption: (org.signatoryName ?? '').isNotEmpty
                              ? org.signatoryName!
                              : 'Authorized Signatory',
                          line2: 'for ${org.name}',
                        ),
                      ),
                    ],
                  ),
                ),
                pw.SizedBox(height: 14),
                pw.Text('NOTE',
                    style: pw.TextStyle(
                        font: fonts.bold, fontSize: 8.5, color: PdfBranding.navy)),
                pw.SizedBox(height: 3),
                pw.Text(boilerplate.invoiceNote,
                    style: pw.TextStyle(
                        font: fonts.regular, fontSize: 7.5, color: PdfBranding.grey)),
                pw.SizedBox(height: 10),
                PdfBranding.termsBlock(fonts, boilerplate.standardTerms),
                pw.Spacer(),
                PdfBranding.footerFull(fonts, org: org, boilerplate: boilerplate),
              ],
            ),
            if (isPaid)
              pw.Positioned.fill(
                child: pw.Center(
                  child: pw.Transform.rotate(
                    angle: 0.5,
                    child: pw.Opacity(
                      opacity: 0.28,
                      child: pw.Text(
                        'PAID',
                        style: pw.TextStyle(
                          font: fonts.bold,
                          fontSize: 96,
                          color: PdfColors.green700,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );

    return doc.save();
  }

  static pw.Widget _totalRow(
          String label, String value, pw.Font regular, pw.Font bold) =>
      pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 2),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(label, style: pw.TextStyle(font: regular, fontSize: 9)),
            pw.Text(value, style: pw.TextStyle(font: bold, fontSize: 9)),
          ],
        ),
      );
}
