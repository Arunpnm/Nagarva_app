// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Tamil (`ta`).
class AppLocalizationsTa extends AppLocalizations {
  AppLocalizationsTa([String locale = 'ta']) : super(locale);

  @override
  String get arunPackersAndCouriers => 'Arun Packers And Couriers';

  @override
  String get movingYouTowardsYourFuture =>
      'உங்கள் எதிர்காலத்தை நோக்கி உங்களை நகர்த்துகிறோம்';

  @override
  String get nameOrPhone => 'பெயர் அல்லது எண்';

  @override
  String get enterYourNameOrPhone =>
      'உங்கள் பெயர் அல்லது தொலைபேசி எண்ணை உள்ளிடவும்';

  @override
  String get pin => 'PIN';

  @override
  String get n4DigitPin => '4 இலக்க PIN';

  @override
  String get login => 'உள்நுழை';

  @override
  String get securedEncrypted => 'பாதுகாப்பானது & மறையாக்கப்பட்டது';

  @override
  String get dashboard => 'டாஷ்போர்டு';

  @override
  String get thisMonth => 'இந்த மாதம்';

  @override
  String get revenue => 'வருவாய்';

  @override
  String get labour => 'தொழிலாளர்';

  @override
  String get expenses => 'செலவுகள்';

  @override
  String get porter => 'போர்ட்டர்';

  @override
  String get netProfit => 'நிகர லாபம்';

  @override
  String get activeLeads => 'செயலில் உள்ள லீடுகள்';

  @override
  String get ordersMonth => 'ஆர்டர்கள்/மாதம்';

  @override
  String get outstanding => 'நிலுவை';

  @override
  String get reminders => 'நினைவூட்டல்கள்';

  @override
  String get monthlyTarget => 'மாத இலக்கு';

  @override
  String get edit => 'திருத்து';

  @override
  String get targetThisMonth => 'இந்த மாத இலக்கு';

  @override
  String get eG200000 => 'e.g. 200000';

  @override
  String get save => 'சேமி';

  @override
  String get upcomingOrders => 'வரவிருக்கும் ஆர்டர்கள்';

  @override
  String get calendar => 'நாட்காட்டி ->';

  @override
  String get hotLeads => 'சூடான லீடுகள்';

  @override
  String get viewAll => 'அனைத்தும் பார் ->';

  @override
  String get branchPerformance => 'கிளை செயல்திறன்';

  @override
  String get orders => 'ஆர்டர்கள்';

  @override
  String get leads => 'லீடுகள்';

  @override
  String get operations => 'செயல்பாடுகள்';

  @override
  String get payments => 'கட்டணங்கள்';

  @override
  String get homePageExpenses => 'செலவுகள்';

  @override
  String get salary => 'சம்பளம்';

  @override
  String get settings => 'அமைப்புகள்';

  @override
  String get logout => 'வெளியேறு';

  @override
  String get all => 'அனைத்தும்';

  @override
  String get pending => 'நிலுவை';

  @override
  String get completed => 'முடிந்தது';

  @override
  String get cancelled => 'ரத்து';

  @override
  String get confirmed => 'உறுதி';

  @override
  String get transit => 'பயணம்';

  @override
  String get done => 'முடிந்தது';

  @override
  String get ord001 => 'ORD-001';

  @override
  String get rajeshKumar => 'Rajesh Kumar';

  @override
  String get chennaiBangalore => 'Chennai → Bangalore';

  @override
  String get n12500 => '₹12,500';

  @override
  String get ord002 => 'ORD-002';

  @override
  String get priyaSharma => 'Priya Sharma';

  @override
  String get mumbaiPune => 'Mumbai → Pune';

  @override
  String get n8000 => '₹8,000';

  @override
  String get ord003 => 'ORD-003';

  @override
  String get inTransit => 'பயணத்தில்';

  @override
  String get anandVerma => 'Anand Verma';

  @override
  String get delhiNoida => 'Delhi → Noida';

  @override
  String get n5500 => '₹5,500';

  @override
  String get ord004 => 'ORD-004';

  @override
  String get sunitaDevi => 'Sunita Devi';

  @override
  String get hyderabadChennai => 'Hyderabad → Chennai';

  @override
  String get n9200 => '₹9,200';

  @override
  String get leadsCrm => 'லீடுகள் / CRM';

  @override
  String get n8 => '8';

  @override
  String get statusNew => 'புதிய';

  @override
  String get n5 => '5';

  @override
  String get contacted => 'தொடர்பு கொண்டது';

  @override
  String get n3 => '3';

  @override
  String get qualified => 'தகுதியானது';

  @override
  String get n2 => '2';

  @override
  String get won => 'வென்றவை';

  @override
  String get lost => 'இழந்தவை';

  @override
  String get raviMenon => 'Ravi Menon';

  @override
  String get n919840012345 => '+91 98400 12345';

  @override
  String get chennaiTn => 'Chennai, TN';

  @override
  String get newLead => 'புதிய லீட்';

  @override
  String get deepaNair => 'Deepa Nair';

  @override
  String get n919447067890 => '+91 94470 67890';

  @override
  String get coimbatoreTn => 'Coimbatore, TN';

  @override
  String get karthikS => 'Karthik S.';

  @override
  String get n919940054321 => '+91 99400 54321';

  @override
  String get maduraiTn => 'Madurai, TN';

  @override
  String get meenaRaj => 'Meena Raj';

  @override
  String get n919380011223 => '+91 93800 11223';

  @override
  String get trichyTn => 'Trichy, TN';

  @override
  String get todaySJobs => 'இன்றைய வேலைகள்';

  @override
  String get n3Active => '3 செயலில்';

  @override
  String get tn01Ab1234 => 'TN-01-AB-1234';

  @override
  String get loading => 'ஏற்றுதல்';

  @override
  String get sureshDriver => 'Suresh (Driver)';

  @override
  String get chennaiVellore => 'Chennai → Vellore';

  @override
  String get tn02Cd5678 => 'TN-02-CD-5678';

  @override
  String get muruganDriver => 'Murugan (Driver)';

  @override
  String get salemErode => 'Salem → Erode';

  @override
  String get tn03Ef9012 => 'TN-03-EF-9012';

  @override
  String get unloading => 'இறக்குதல்';

  @override
  String get baluDriver => 'Balu (Driver)';

  @override
  String get coimbatoreOoty => 'Coimbatore → Ooty';

  @override
  String get upcoming => 'வரவிருப்பவை';

  @override
  String get tn04Gh3456 => 'TN-04-GH-3456';

  @override
  String get scheduled => 'திட்டமிடப்பட்டது';

  @override
  String get senthilDriver => 'Senthil (Driver)';

  @override
  String get maduraiTirunelveli => 'Madurai → Tirunelveli';

  @override
  String get vehicleTripLog => 'வாகன பயணப் பதிவு';

  @override
  String get logNewTrip => 'புதிய பயணம் பதிவு செய்';

  @override
  String get paymentsPageOutstanding => 'நிலுவை';

  @override
  String get n42800 => '₹42,800';

  @override
  String get receivedMonth => 'பெறப்பட்டது (மாதம்)';

  @override
  String get n124000 => '₹1,24,000';

  @override
  String get pendingPaymentsLive => 'நிலுவைப் பணம் (நேரலை)';

  @override
  String get pendingInvoices => 'நிலுவை இன்வாய்ஸ்கள்';

  @override
  String get inv045 => 'INV-045';

  @override
  String get due15May => 'செலுத்த வேண்டியது: மே 15';

  @override
  String get inv046 => 'INV-046';

  @override
  String get due18May => 'செலுத்த வேண்டியது: மே 18';

  @override
  String get inv047 => 'INV-047';

  @override
  String get overdue => 'தவணை கடந்தது';

  @override
  String get inv048 => 'INV-048';

  @override
  String get due22May => 'செலுத்த வேண்டியது: மே 22';

  @override
  String get n16800 => '₹16,800';

  @override
  String get may2025Total => 'மே 2025 மொத்தம்';

  @override
  String get n68450 => '₹68,450';

  @override
  String get n12VsLastMonth => '↑ கடந்த மாதத்தை விட 12%';

  @override
  String get liveExpenses => 'நேரலைச் செலவுகள்';

  @override
  String get byCategory => 'வகை வாரியாக';

  @override
  String get fuel => 'எரிபொருள்';

  @override
  String get n41 => '41%';

  @override
  String get n28000 => '₹28,000';

  @override
  String get tollsPermits => 'சுங்கம் & அனுமதிகள்';

  @override
  String get n18 => '18%';

  @override
  String get maintenance => 'பழுது நீக்கத்தில்';

  @override
  String get n26 => '26%';

  @override
  String get n18000 => '₹18,000';

  @override
  String get expensePageLabour => 'தொழிலாளர்';

  @override
  String get n15 => '15%';

  @override
  String get n9950 => '₹9,950';

  @override
  String get addExpense => 'செலவு சேர்';

  @override
  String get may2025 => 'மே 2025';

  @override
  String get totalPayroll => 'மொத்த சம்பளம்';

  @override
  String get n182000 => '₹1,82,000';

  @override
  String get liveStaffData => 'நேரலை ஊழியர் தரவு';

  @override
  String get todaySAttendance => 'இன்றைய வருகை';

  @override
  String get label => '·';

  @override
  String get pendingAdvances => 'நிலுவை முன்பணங்கள்';

  @override
  String get bal => 'மீதம்:';

  @override
  String get staff => 'ஊழியர்';

  @override
  String get sureshKumar => 'Suresh Kumar';

  @override
  String get driver => 'ஓட்டுநர்';

  @override
  String get n22000 => '₹22,000';

  @override
  String get paid => 'செலுத்தியது';

  @override
  String get muruganP => 'Murugan P.';

  @override
  String get n20000 => '₹20,000';

  @override
  String get baluS => 'Balu S.';

  @override
  String get helper => 'உதவியாளர்';

  @override
  String get n14000 => '₹14,000';

  @override
  String get senthilR => 'Senthil R.';

  @override
  String get n21000 => '₹21,000';

  @override
  String get kalaM => 'Kala M.';

  @override
  String get officeStaff => 'அலுவலக ஊழியர்';

  @override
  String get fleet => 'வாகனங்கள்';

  @override
  String get n4 => '4';

  @override
  String get active => 'செயலில்';

  @override
  String get idle => 'சும்மா';

  @override
  String get n1 => '1';

  @override
  String get service => 'சேவை';

  @override
  String get liveFleet => 'நேரலை வாகனங்கள்';

  @override
  String get miniTruck407 => 'மினி லாரி (407)';

  @override
  String get suresh => 'Suresh';

  @override
  String get n124560Km => '1,24,560 km';

  @override
  String get largeTruckTata => 'பெரிய லாரி (டாடா)';

  @override
  String get murugan => 'Murugan';

  @override
  String get n98340Km => '98,340 km';

  @override
  String get inService => 'சர்வீஸில்';

  @override
  String get balu => 'Balu';

  @override
  String get n212000Km => '2,12,000 km';

  @override
  String get largeTruckEicher => 'பெரிய லாரி (ஐஷர்)';

  @override
  String get senthil => 'Senthil';

  @override
  String get n67890Km => '67,890 km';

  @override
  String get newQuotation => 'புதிய மதிப்பீடு';

  @override
  String get customerDetails => 'வாடிக்கையாளர் விவரங்கள்';

  @override
  String get customerName => 'வாடிக்கையாளர் பெயர்';

  @override
  String get enterFullName => 'முழுப் பெயரை உள்ளிடவும்';

  @override
  String get phoneNumber => 'தொலைபேசி எண்';

  @override
  String get n91XxxxxXxxxx => '+91 XXXXX XXXXX';

  @override
  String get moveDetails => 'இடமாற்ற விவரங்கள்';

  @override
  String get fromAddress => 'எங்கிருந்து (முகவரி)';

  @override
  String get pickupLocation => 'ஏற்றும் இடம்';

  @override
  String get toAddress => 'எங்கு (முகவரி)';

  @override
  String get dropLocation => 'இறக்கும் இடம்';

  @override
  String get moveDate => 'இடமாற்ற தேதி';

  @override
  String get ddMmYyyy => 'DD/MM/YYYY';

  @override
  String get floorAccess => 'மாடி / அணுகல்';

  @override
  String get eG2ndFloorLiftAvailable => 'எ.கா., 2வது மாடி, லிஃப்ட் உள்ளது';

  @override
  String get estimate => 'மதிப்பீடு';

  @override
  String get quotedAmount => 'குறிப்பிட்ட தொகை (₹)';

  @override
  String get n000 => '0.00';

  @override
  String get notes => 'குறிப்புகள்';

  @override
  String get additionalDetails => 'கூடுதல் விவரங்கள்';

  @override
  String get generateQuotation => 'மதிப்பீட்டை உருவாக்கு';

  @override
  String get accounts => 'கணக்குகள்';

  @override
  String get sbiCurrentAC => 'SBI — நடப்புக் கணக்கு';

  @override
  String get xxxx4521 => 'XXXX 4521';

  @override
  String get n284500 => '₹2,84,500';

  @override
  String get hdfcSavingsAC => 'HDFC — சேமிப்புக் கணக்கு';

  @override
  String get xxxx7832 => 'XXXX 7832';

  @override
  String get n112300 => '₹1,12,300';

  @override
  String get cashOnHand => 'கையிருப்புப் பணம்';

  @override
  String get totalBalance => 'மொத்த இருப்பு';

  @override
  String get n414800 => '₹4,14,800';

  @override
  String get recentTransactions => 'சமீபத்திய பரிவர்த்தனைகள்';

  @override
  String get receivedOrd001 => 'பெறப்பட்டது — ORD-001';

  @override
  String get accountsPageN12500 => '+₹12,500';

  @override
  String get may5 => 'மே 5';

  @override
  String get fuelTn01Ab1234 => 'எரிபொருள் — TN-01-AB-1234';

  @override
  String get petrolBunk => 'பெட்ரோல் பங்க்';

  @override
  String get n3200 => '-₹3,200';

  @override
  String get receivedOrd002 => 'பெறப்பட்டது — ORD-002';

  @override
  String get accountsPageN8000 => '+₹8,000';

  @override
  String get may4 => 'மே 4';

  @override
  String get tollChennaiNh => 'சுங்கம் — சென்னை NH';

  @override
  String get nhai => 'NHAI';

  @override
  String get n480 => '-₹480';

  @override
  String get pLReport => 'லாப நஷ்ட அறிக்கை';

  @override
  String get periodMay2025 => 'காலம்: மே 2025';

  @override
  String get n192000 => '₹1,92,000';

  @override
  String get pLReportPageRevenue => 'வருவாய்';

  @override
  String get n123550 => '₹1,23,550';

  @override
  String get pLReportPageNetProfit => 'நிகர லாபம்';

  @override
  String get n643 => '64.3%';

  @override
  String get margin => 'லாப வரம்பு';

  @override
  String get topExpenses => 'முக்கிய செலவுகள்';

  @override
  String get arunPackersStaff => 'Arun Packers Staff';

  @override
  String get adminArunpackersIn => 'admin@arunpackers.in';

  @override
  String get company => 'நிறுவனம்';

  @override
  String get businessName => 'வணிகப் பெயர்';

  @override
  String get settingsPageArunPackersAndCouriers => 'Arun Packers and Couriers';

  @override
  String get phone => 'தொலைபேசி';

  @override
  String get n9144XxxxXxxx => '+91 44 XXXX XXXX';

  @override
  String get gstNumber => 'GST எண்';

  @override
  String get xxxxxxxxxxxx => 'XXXXXXXXXXXX';

  @override
  String get app => 'ஆப்';

  @override
  String get notifications => 'அறிவிப்புகள்';

  @override
  String get enabled => 'இயக்கத்தில்';

  @override
  String get darkMode => 'இருண்ட பயன்முறை';

  @override
  String get on => 'இயக்கம்';

  @override
  String get language => 'மொழி';

  @override
  String get english => 'ஆங்கிலம்';

  @override
  String get data => 'தரவு';

  @override
  String get exportData => 'தரவை ஏற்றுமதி செய்';

  @override
  String get csvPdf => 'CSV / PDF';

  @override
  String get backup => 'காப்புப்பிரதி';

  @override
  String get autoDaily => 'தானியங்கி (தினசரி)';

  @override
  String get appTheme => 'செயலி தீம்';

  @override
  String get chooseYourPreferredColourScheme =>
      'உங்களுக்குப் பிடித்த வண்ணத் திட்டத்தைத் தேர்வுசெய்யவும்.';

  @override
  String get dark => 'இருள்';

  @override
  String get midnight => 'நள்ளிரவு';

  @override
  String get light => 'வெளிச்சம்';

  @override
  String get calendarPageCalendar => 'நாட்காட்டி';

  @override
  String get mon => 'திங்';

  @override
  String get tue => 'செவ்';

  @override
  String get wed => 'புத';

  @override
  String get thu => 'வியா';

  @override
  String get fri => 'வெள்';

  @override
  String get sat => 'சனி';

  @override
  String get sun => 'ஞாயி';

  @override
  String get n6 => '6';

  @override
  String get n7 => '7';

  @override
  String get n9 => '9';

  @override
  String get n10 => '10';

  @override
  String get n11 => '11';

  @override
  String get n12 => '12';

  @override
  String get n13 => '13';

  @override
  String get n14 => '14';

  @override
  String get calendarPageN15 => '15';

  @override
  String get n17 => '17';

  @override
  String get calendarPageN18 => '18';

  @override
  String get n20 => '20';

  @override
  String get n21 => '21';

  @override
  String get n22 => '22';

  @override
  String get n23 => '23';

  @override
  String get n24 => '24';

  @override
  String get n25 => '25';

  @override
  String get calendarPageN26 => '26';

  @override
  String get n27 => '27';

  @override
  String get n28 => '28';

  @override
  String get n29 => '29';

  @override
  String get n30 => '30';

  @override
  String get n31 => '31';

  @override
  String get remindersFollowUps => 'நினைவூட்டல்கள் & பின்தொடர்தல்';

  @override
  String get followUpRaviMenon => 'பின்தொடர்தல்: Ravi Menon';

  @override
  String get callRegardingBangaloreMoveQuote =>
      'பெங்களூரு இடமாற்ற மதிப்பீடு பற்றி அழைப்பு';

  @override
  String get may7 => 'மே 7';

  @override
  String get collectionOrd047 => 'வசூல்: ORD-047';

  @override
  String get overduePaymentFromAnandVerma =>
      'Anand Verma-விடமிருந்து தவணை கடந்த பணம்';

  @override
  String get may8 => 'மே 8';

  @override
  String get jobTn01Ab1234 => 'வேலை: TN-01-AB-1234';

  @override
  String get chennaiVelloreScheduledDelivery =>
      'சென்னை → வேலூர் திட்டமிட்ட டெலிவரி';

  @override
  String get may9 => 'மே 9';

  @override
  String get reviewMayExpenses => 'மதிப்பாய்வு: மே செலவுகள்';

  @override
  String get monthlyExpenseReviewWithTeam =>
      'குழுவுடன் மாதச் செலவு மதிப்பாய்வு';

  @override
  String get may12 => 'மே 12';

  @override
  String get activeRemindersLive => 'செயலில் உள்ள நினைவூட்டல்கள் (நேரலை)';

  @override
  String get addReminder => 'நினைவூட்டல் சேர்';

  @override
  String get materials => 'பொருட்கள்';

  @override
  String get totalSkus => 'மொத்த SKU-கள்';

  @override
  String get lowStock => 'குறைந்த இருப்பு';

  @override
  String get inventory => 'சரக்கு இருப்பு';

  @override
  String get cardboardBoxSmall => 'அட்டைப் பெட்டி — சிறியது';

  @override
  String get reorder20 => '20-க்குக் கீழ் மீண்டும் வாங்கு';

  @override
  String get n42Pcs => '42 pcs';

  @override
  String get cardboardBoxMedium => 'அட்டைப் பெட்டி — நடுத்தரம்';

  @override
  String get n28Pcs => '28 pcs';

  @override
  String get cardboardBoxLarge => 'அட்டைப் பெட்டி — பெரியது';

  @override
  String get reorder15 => '15-க்குக் கீழ் மீண்டும் வாங்கு';

  @override
  String get n11Pcs => '11 pcs';

  @override
  String get bubbleWrapRoll50m => 'பபிள் ரேப் ரோல் (50மீ)';

  @override
  String get reorder5 => '5-க்குக் கீழ் மீண்டும் வாங்கு';

  @override
  String get n4Rolls => '4 rolls';

  @override
  String get stretchWrapRoll => 'ஸ்ட்ரெச் ரேப் ரோல்';

  @override
  String get ok => 'சரி';

  @override
  String get n18Rolls => '18 rolls';

  @override
  String get packingTapeBrown => 'பேக்கிங் டேப் (பழுப்பு)';

  @override
  String get reorder10 => '10-க்குக் கீழ் மீண்டும் வாங்கு';

  @override
  String get n7Pcs => '7 pcs';

  @override
  String get furnitureCoverLarge => 'மரச்சாமான் உறை (பெரியது)';

  @override
  String get n24Pcs => '24 pcs';

  @override
  String get rope50m => 'கயிறு (50மீ)';

  @override
  String get n8Rolls => '8 rolls';

  @override
  String get cornerGuards => 'மூலைக் காப்புகள்';

  @override
  String get n60Pcs => '60 pcs';

  @override
  String get addRestockItem => 'பொருள் சேர் / இருப்பு நிரப்பு';

  @override
  String get reports => 'அறிக்கைகள்';

  @override
  String get generateReports => 'அறிக்கைகளை உருவாக்கு';

  @override
  String get monthlySummary => 'மாதச் சுருக்கம்';

  @override
  String get revenueExpensesProfitOverview =>
      'வருவாய், செலவு & லாபக் கண்ணோட்டம்';

  @override
  String get customerReport => 'வாடிக்கையாளர் அறிக்கை';

  @override
  String get topCustomersByRevenue => 'வருவாய்ப்படி முன்னணி வாடிக்கையாளர்கள்';

  @override
  String get driverPerformance => 'ஓட்டுநர் செயல்திறன்';

  @override
  String get jobsCompletedPerDriver => 'ஓட்டுநர் வாரியாக முடித்த வேலைகள்';

  @override
  String get expenseBreakdown => 'செலவுப் பிரிப்பு';

  @override
  String get categoryWiseExpenseAnalysis => 'வகை வாரியான செலவுப் பகுப்பாய்வு';

  @override
  String get revenueTrend => 'வருவாய்ப் போக்கு';

  @override
  String get monthOnMonthRevenueChart => 'மாதா மாத வருவாய் வரைபடம்';

  @override
  String get outstandingReport => 'நிலுவை அறிக்கை';

  @override
  String get pendingPaymentsAgeing => 'நிலுவைப் பணம் & காலம்';

  @override
  String get vehicleUtilisation => 'வாகனப் பயன்பாடு';

  @override
  String get fleetUsageAndIdleTimeAnalysis =>
      'வாகனப் பயன்பாடு & சும்மா இருந்த நேரப் பகுப்பாய்வு';

  @override
  String get exportOptions => 'ஏற்றுமதி விருப்பங்கள்';

  @override
  String get exportPdf => 'PDF ஏற்றுமதி';

  @override
  String get exportCsv => 'CSV ஏற்றுமதி';

  @override
  String get users => 'பயனர்கள்';

  @override
  String get addNewUser => 'புதிய பயனர் சேர்';

  @override
  String get admin => 'நிர்வாகி';

  @override
  String get activeUsers => 'செயலில் உள்ள பயனர்கள்';

  @override
  String get arunKumar => 'Arun Kumar';

  @override
  String get n919840000001 => '+91 98400 00001';

  @override
  String get today => 'இன்று';

  @override
  String get sureshM => 'Suresh M.';

  @override
  String get n919840000002 => '+91 98400 00002';

  @override
  String get n919840000003 => '+91 98400 00003';

  @override
  String get yesterday => 'நேற்று';

  @override
  String get kalaR => 'Kala R.';

  @override
  String get n919840000004 => '+91 98400 00004';

  @override
  String get n919840000005 => '+91 98400 00005';

  @override
  String get n2DaysAgo => '2 நாட்களுக்கு முன்';

  @override
  String get inactiveUsers => 'செயலற்ற பயனர்கள்';

  @override
  String get n919840000006 => '+91 98400 00006';

  @override
  String get inactive => 'செயலற்றது';

  @override
  String get n5DaysAgo => '5 நாட்களுக்கு முன்';

  @override
  String get recordPayment => 'பணம் பதிவு';

  @override
  String get selectOrder => 'ஆர்டரைத் தேர்ந்தெடு';

  @override
  String get loadingPendingOrders => 'நிலுவை ஆர்டர்கள் ஏற்றப்படுகின்றன...';

  @override
  String get select => 'தேர்ந்தெடு';

  @override
  String get paymentEntry => 'பணப் பதிவு';

  @override
  String get customer => 'வாடிக்கையாளர்:';

  @override
  String get totalAmount => 'மொத்தத் தொகை:';

  @override
  String get alreadyPaid => 'ஏற்கனவே செலுத்தியது:';

  @override
  String get amountReceived => 'பெற்ற தொகை (₹)';

  @override
  String get selectStatus => 'நிலையைத் தேர்ந்தெடு';

  @override
  String get paymentStatus => 'பண நிலை';

  @override
  String get partial => 'பகுதி';

  @override
  String get recordPaymentPagePaid => 'செலுத்தியது';

  @override
  String get savePayment => 'சேமி';

  @override
  String get quickExpense => 'விரைவுச் செலவு';

  @override
  String get expenseDetails => 'செலவு விவரங்கள்';

  @override
  String get amount => 'தொகை (₹)';

  @override
  String get selectCategory => 'வகையைத் தேர்ந்தெடு';

  @override
  String get category => 'வகை';

  @override
  String get vehicleMaintenance => 'வாகனப் பராமரிப்பு';

  @override
  String get office => 'அலுவலகம்';

  @override
  String get material => 'பொருள்';

  @override
  String get other => 'மற்றவை';

  @override
  String get date => 'தேதி';

  @override
  String get yyyyMmDd => 'YYYY-MM-DD';

  @override
  String get linkedOrderIdOptional => 'இணைந்த ஆர்டர் ID (விருப்பம்)';

  @override
  String get leaveBlankIfNotLinked => 'இணைக்கவில்லையெனில் காலியாக விடவும்';

  @override
  String get description => 'விவரம்';

  @override
  String get briefDescription => 'சுருக்கமான விளக்கம்';

  @override
  String get saveExpense => 'செலவைச் சேமி';

  @override
  String get newOrder => 'புதிய ஆர்டர்';

  @override
  String get newOrderPageCustomer => 'வாடிக்கையாளர்';

  @override
  String get newOrderPageCustomerName => 'வாடிக்கையாளர் பெயர் *';

  @override
  String get fullName => 'முழுப் பெயர்';

  @override
  String get newOrderPagePhone => 'தொலைபேசி *';

  @override
  String get fromCity => 'எங்கிருந்து (நகரம்) *';

  @override
  String get originCity => 'தொடக்க நகரம்';

  @override
  String get toCity => 'எங்கு (நகரம்) *';

  @override
  String get destinationCity => 'சேருமிட நகரம்';

  @override
  String get pickupAddress => 'ஏற்றும் முகவரி';

  @override
  String get dropAddress => 'இறக்கும் முகவரி';

  @override
  String get fromFloor => 'எங்கிருந்து (மாடி)';

  @override
  String get eG2ndFloor => 'எ.கா., 2வது மாடி';

  @override
  String get toFloor => 'எங்கு (மாடி)';

  @override
  String get eGGroundFloor => 'எ.கா., தரைத்தளம்';

  @override
  String get newOrderPageMoveDate => 'இடமாற்றத் தேதி *';

  @override
  String get tapToPickDate => 'தேதியைத் தேர்ந்தெடுக்கத் தட்டவும்';

  @override
  String get pickDate => 'தேதியைத் தேர்ந்தெடு';

  @override
  String get pricingClassification => 'விலை & வகைப்பாடு';

  @override
  String get newOrderPageAmount => 'தொகை (₹) *';

  @override
  String get selectService => 'சேவையைத் தேர்ந்தெடு';

  @override
  String get newOrderPageService => 'சேவை *';

  @override
  String get houseShifting => 'வீடு மாற்றம்';

  @override
  String get officeShifting => 'அலுவலக மாற்றம்';

  @override
  String get vehicleTransport => 'வாகனப் போக்குவரத்து';

  @override
  String get storage => 'சேமிப்பு';

  @override
  String get packingOnly => 'பேக்கிங் மட்டும்';

  @override
  String get longDistance => 'நீண்ட தூரம்';

  @override
  String get selectBranch => 'கிளையைத் தேர்ந்தெடு';

  @override
  String get branch => 'கிளை *';

  @override
  String get chennai => 'Chennai';

  @override
  String get bengaluru => 'Bengaluru';

  @override
  String get coimbatore => 'Coimbatore';

  @override
  String get selectType => 'வகையைத் தேர்ந்தெடு';

  @override
  String get orderType => 'ஆர்டர் வகை *';

  @override
  String get direct => 'நேரடி';

  @override
  String get newOrderPagePorter => 'போர்ட்டர்';

  @override
  String get porterCommission => 'போர்ட்டர் கமிஷன் %';

  @override
  String get saveOrder => 'ஆர்டரைச் சேமி';

  @override
  String get orderDetails => 'ஆர்டர் விவரங்கள்';

  @override
  String get orderDetailPageBranch => 'கிளை';

  @override
  String get type => 'வகை';

  @override
  String get from => 'இருந்து';

  @override
  String get to => 'வரை';

  @override
  String get addressFrom => 'முகவரி (எங்கிருந்து)';

  @override
  String get addressTo => 'முகவரி (எங்கு)';

  @override
  String get floorFrom => 'மாடி (எங்கிருந்து)';

  @override
  String get floorTo => 'மாடி (எங்கு)';

  @override
  String get payment => 'பணம்';

  @override
  String get orderDetailPageAmount => 'தொகை';

  @override
  String get advancePaid => 'செலுத்திய முன்பணம்';

  @override
  String get trackingStatus => 'கண்காணிப்பு நிலை';

  @override
  String get editOrder => 'ஆர்டரைத் திருத்து';

  @override
  String get contact => 'தொடர்பு';

  @override
  String get email => 'மின்னஞ்சல்';

  @override
  String get emailExampleCom => 'email@example.com';

  @override
  String get newLeadPageFromCity => 'எங்கிருந்து (நகரம்)';

  @override
  String get newLeadPageToCity => 'எங்கு (நகரம்)';

  @override
  String get approxDate => 'தோராயத் தேதி *';

  @override
  String get classification => 'வகைப்பாடு';

  @override
  String get status => 'நிலை *';

  @override
  String get newLeadPageNew => 'புதிய';

  @override
  String get newLeadPageContacted => 'தொடர்பு கொண்டது';

  @override
  String get surveyDone => 'சர்வே முடிந்தது';

  @override
  String get quoted => 'மதிப்பீடு அனுப்பப்பட்டது';

  @override
  String get converted => 'மாறியவை';

  @override
  String get newLeadPageLost => 'இழந்தவை';

  @override
  String get howDidTheyHearAboutUs =>
      'எங்களைப் பற்றி அவர்கள் எப்படி அறிந்தார்கள்?';

  @override
  String get source => 'மூலம் *';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get phoneCall => 'தொலைபேசி அழைப்பு';

  @override
  String get website => 'இணையதளம்';

  @override
  String get referral => 'பரிந்துரை';

  @override
  String get walkIn => 'நேரடி';

  @override
  String get google => 'Google';

  @override
  String get justdial => 'JustDial';

  @override
  String get anyRelevantNotes => 'தொடர்புடைய குறிப்புகள்';

  @override
  String get saveLead => 'லீடைச் சேமி';

  @override
  String get leadDetails => 'லீட் விவரங்கள்';

  @override
  String get leadDetailPageSource => 'மூலம்';

  @override
  String get leadDetailPageApproxDate => 'தோராயத் தேதி';

  @override
  String get convertToOrder => 'ஆர்டராக மாற்று';

  @override
  String get editLead => 'லீடைத் திருத்து';

  @override
  String get quickEntry => 'விரைவுப் பதிவு';

  @override
  String get whatWouldYouLikeToDo => 'நீங்கள் என்ன செய்ய விரும்புகிறீர்கள்?';

  @override
  String get newInquiry => 'புதிய விசாரணை';

  @override
  String get confirmBooking => 'முன்பதிவை உறுதிசெய்';

  @override
  String get cashCollectedByPorter => 'போர்ட்டர் வசூலித்த பணம் (₹)';

  @override
  String get leaveBlankIfNoneCollectedYet =>
      'இன்னும் வசூலிக்கவில்லையெனில் காலியாக விடவும்';

  @override
  String get jrTitle => 'ஆர்டர் பயணம்';

  @override
  String get jrStageLead => 'லீட்';

  @override
  String get jrStageFollowUp => 'பின்தொடர்';

  @override
  String get jrStageSurvey => 'சர்வே';

  @override
  String get jrStageQuote => 'மதிப்பீடு & உறுதி';

  @override
  String get jrStageSupervisor => 'மேற்பார்வையாளர்';

  @override
  String get jrStageMoveDay => 'இடமாற்ற நாள்';

  @override
  String get jrStageInvoice => 'இன்வாய்ஸ்';

  @override
  String get jrStagePayment => 'பணம் & சிக்கல்கள்';

  @override
  String get jrStageClosed => 'முடிந்தது';

  @override
  String get jrStateDone => 'முடிந்தது';

  @override
  String get jrStateSkipped => 'தவிர்க்கப்பட்டது';

  @override
  String get jrStateCurrent => 'இப்போது';

  @override
  String get jrStatePending => 'பிறகு';

  @override
  String get jrDirectOrder => 'தவிர்க்கப்பட்டது · நேரடி ஆர்டர்';

  @override
  String get jrMoveDate => 'இடமாற்ற தேதி';

  @override
  String get jrRoute => 'வழி';

  @override
  String get jrOrderValue => 'ஆர்டர் மதிப்பு';

  @override
  String get jrNotSet => 'அமைக்கவில்லை';

  @override
  String get jrDocuments => 'ஆவணங்கள்';

  @override
  String get jrDocQuote => 'கொட்டேஷன்';

  @override
  String get jrDocInvoice => 'வரி இன்வாய்ஸ்';

  @override
  String get jrDocReceipts => 'பண ரசீதுகள்';

  @override
  String get jrDocLr => 'லாரி ரசீது';

  @override
  String get jrDocReady => 'தயார் · பார்க்கத் தட்டு';

  @override
  String jrDocAfter(String stage) {
    return '$stage பிறகு';
  }

  @override
  String jrCreated(String date) {
    return 'உருவாக்கியது $date';
  }

  @override
  String jrSource(String source) {
    return 'மூலம்: $source';
  }

  @override
  String jrService(String service) {
    return 'சேவை: $service';
  }

  @override
  String get jrNoCalls => 'இன்னும் அழைப்பு எதுவும் பதிவு இல்லை';

  @override
  String jrCallsLogged(String count) {
    return '$count அழைப்புகள் பதிவு';
  }

  @override
  String get jrOutcomeQ => 'அழைப்பு எப்படி இருந்தது?';

  @override
  String get jrOutNoAnswer => 'தொடர்பு கிடைக்கவில்லை';

  @override
  String get jrOutCallback => 'பிறகு அழை';

  @override
  String get jrOutInterested => 'ஆர்வம் உண்டு';

  @override
  String get jrOutNotInterested => 'ஆர்வம் இல்லை';

  @override
  String get jrCallNotes => 'அழைப்புக் குறிப்புகள்';

  @override
  String get jrNextFollowUp => 'அடுத்த பின்தொடர்தல்';

  @override
  String get jrToday => 'இன்று';

  @override
  String get jrTomorrow => 'நாளை';

  @override
  String get jrIn2Days => '2 நாளில்';

  @override
  String get jrNextWeek => 'அடுத்த வாரம்';

  @override
  String get jrPickDate => 'தேதியைத் தேர்ந்தெடு';

  @override
  String get jrNoNext => 'இல்லை';

  @override
  String get jrLogCall => 'அழைப்பைப் பதிவு செய்';

  @override
  String get jrCallLogged => 'அழைப்பு பதிவு செய்யப்பட்டது';

  @override
  String get jrPickOutcome => 'அழைப்பு எப்படி இருந்தது எனத் தேர்ந்தெடுக்கவும்';

  @override
  String get jrSurveyWaiting =>
      'சர்வே இணைப்பு அனுப்பப்பட்டது · வாடிக்கையாளருக்காகக் காத்திருக்கிறது';

  @override
  String get jrSurveyDone => 'வாடிக்கையாளர் சர்வேயைச் சமர்ப்பித்தார்';

  @override
  String get jrNoSurvey => 'இன்னும் சர்வே இல்லை';

  @override
  String get jrOpenSurveyQuote => 'சர்வே & மதிப்பீட்டைத் திற';

  @override
  String get jrNoQuote => 'இன்னும் மதிப்பீடு இல்லை';

  @override
  String jrQuoteLine(String amount) {
    return 'மதிப்பீடு $amount';
  }

  @override
  String jrOrderConfirmed(String id) {
    return 'ஆர்டர் $id உறுதி';
  }

  @override
  String get jrLeadLost => 'லீட் இழந்ததாகக் குறிக்கப்பட்டது';

  @override
  String get jrNoSupervisor => 'இன்னும் மேற்பார்வையாளர் இல்லை';

  @override
  String jrSupervisorIs(String name) {
    return 'மேற்பார்வையாளர்: $name';
  }

  @override
  String jrCrew(String count) {
    return 'வேலையில் உள்ள குழு: $count';
  }

  @override
  String get jrAssignInOrder => 'மேற்பார்வையாளரை ஒதுக்கு';

  @override
  String get jrNotStarted => 'தொடங்கவில்லை';

  @override
  String jrMoveStarted(String time) {
    return 'தொடங்கியது $time';
  }

  @override
  String jrMoveFinished(String time) {
    return 'முடிந்தது $time';
  }

  @override
  String get jrOpenFieldJob => 'களப் பணியைத் திற';

  @override
  String get jrNoInvoice => 'இன்வாய்ஸ் உருவாக்கப்படவில்லை';

  @override
  String jrInvoiceNo(String no) {
    return 'இன்வாய்ஸ் $no';
  }

  @override
  String get jrSigned => 'வாடிக்கையாளர் கையொப்பமிட்டார்';

  @override
  String get jrNotSigned => 'கையொப்பம் இல்லை';

  @override
  String get jrOpenOrder => 'ஆர்டரைத் திற';

  @override
  String get jrTotal => 'மொத்தம்';

  @override
  String get jrPaid => 'செலுத்தியது';

  @override
  String get jrBalance => 'மீதி';

  @override
  String get jrRecordPayment => 'பணம் பதிவு';

  @override
  String get jrTickets => 'டிக்கெட்கள்';

  @override
  String get jrNoTickets => 'டிக்கெட்கள் இல்லை';

  @override
  String get jrTicketHint => 'எ.கா., AC பொருத்துதல் நிலுவையில்';

  @override
  String get jrRaiseTicket => 'டிக்கெட் பதிவு செய்';

  @override
  String get jrResolve => 'தீர்';

  @override
  String get jrTicketRaised => 'டிக்கெட் பதிவு செய்யப்பட்டது';

  @override
  String get jrTicketResolved => 'டிக்கெட் தீர்க்கப்பட்டது';

  @override
  String get jrBlockTicket => 'ஒரு டிக்கெட் இன்னும் திறந்துள்ளது';

  @override
  String jrBlockBalance(String amount) {
    return '$amount மீதத் தொகை நிலுவையில் உள்ளது';
  }

  @override
  String get jrCloseOrder => 'ஆர்டரை மூடு';

  @override
  String jrClosedOn(String date) {
    return 'மூடப்பட்டது $date';
  }

  @override
  String get jrNotClosed => 'திறந்தது';

  @override
  String jrPaymentLine(String amount, String mode) {
    return '$amount · $mode';
  }

  @override
  String get jrCouldNotLoad => 'இந்தப் பயணத்தை ஏற்ற முடியவில்லை';

  @override
  String get jrRetry => 'மீண்டும் முயல்க';

  @override
  String jrCouldNotSave(String error) {
    return 'சேமிக்க முடியவில்லை: $error';
  }

  @override
  String get ngNavHome => 'முகப்பு';

  @override
  String get ngNavLeads => 'லீடுகள்';

  @override
  String get ngNavOrders => 'ஆர்டர்கள்';

  @override
  String get ngNavOps => 'செயல்';

  @override
  String get ngNavPay => 'பணம்';

  @override
  String get ngNavMore => 'மேலும்';

  @override
  String get ngMenuDashboard => 'டாஷ்போர்டு';

  @override
  String get ngMenuLeads => 'லீடுகள் / CRM';

  @override
  String get ngMenuInbox => 'இன்பாக்ஸ்';

  @override
  String get ngMenuSurveyQuote => 'சர்வே & மதிப்பீடு';

  @override
  String get ngMenuCalendar => 'நாட்காட்டி';

  @override
  String get ngMenuOrders => 'ஆர்டர்கள்';

  @override
  String get ngMenuOperations => 'செயல்பாடுகள்';

  @override
  String get ngMenuReviews => 'மதிப்புரைகள்';

  @override
  String get ngMenuPayments => 'பணம் வசூல்';

  @override
  String get ngMenuExpenses => 'செலவுகள்';

  @override
  String get ngMenuStaff => 'ஊழியர்கள்';

  @override
  String get ngMenuTeamAttendance => 'குழு வருகை';

  @override
  String get ngMenuFleet => 'வாகனங்கள்';

  @override
  String get ngMenuMaterials => 'பொருட்கள்';

  @override
  String get ngMenuWarehouses => 'கிடங்குகள்';

  @override
  String get ngMenuRateCards => 'கட்டண அட்டைகள்';

  @override
  String get ngMenuLrRegister => 'LR பதிவேடு';

  @override
  String get ngMenuOpsLog => 'செயல் பதிவு';

  @override
  String get ngMenuVendors => 'விற்பனையாளர்கள்';

  @override
  String get ngMenuCustomers => 'வாடிக்கையாளர்கள்';

  @override
  String get ngMenuInsurance => 'காப்பீடு';

  @override
  String get ngMenuTrips => 'பயணங்கள்';

  @override
  String get ngMenuTasks => 'பணிகள்';

  @override
  String get ngMenuAccounts => 'கணக்குகள்';

  @override
  String get ngMenuPnl => 'லாப நஷ்டம்';

  @override
  String get ngMenuReports => 'அறிக்கைகள்';

  @override
  String get ngMenuSalary => 'சம்பளம்';

  @override
  String get ngMenuSettings => 'அமைப்புகள்';

  @override
  String get ngMenuPlatformAdmin => 'தள நிர்வாகி';

  @override
  String get ngMenuMyJobs => 'என் வேலைகள்';

  @override
  String get ngMenuMyTeam => 'என் குழு';

  @override
  String get ngMenuMyEarnings => 'என் வருமானம்';

  @override
  String get ngMenuMyAttendance => 'என் வருகை';

  @override
  String get ngGroupSales => 'விற்பனை';

  @override
  String get ngGroupOperations => 'செயல்பாடுகள்';

  @override
  String get ngGroupMoney => 'பணம்';

  @override
  String get ngGroupPeople => 'மக்கள்';

  @override
  String get ngGroupAssets => 'சொத்துக்கள்';

  @override
  String get ngGroupPartners => 'கூட்டாளர்கள்';

  @override
  String get ngGroupSetup => 'அமைப்பு';

  @override
  String get ngGroupField => 'களம்';

  @override
  String get ngGroupOther => 'மற்றவை';

  @override
  String get ngQuickEntry => 'விரைவுப் பதிவு';

  @override
  String get ngSearchModules => 'தொகுதிகளைத் தேடு';

  @override
  String get ngNoModuleMatches => 'பொருந்தும் தொகுதி இல்லை';

  @override
  String get ngHelp => 'உதவி';

  @override
  String ngOrgsSwitch(String count) {
    return '$count நிறுவனங்கள் · மாற்றத் தட்டவும்';
  }

  @override
  String get ngRoleOwner => 'உரிமையாளர்';

  @override
  String get ngRoleStaff => 'ஊழியர்';

  @override
  String get ngTodayMoves => 'இடமாற்றங்கள்';

  @override
  String get ngTodayFollowUps => 'பின்தொடர்தல்கள்';

  @override
  String get ngToCollect => 'வசூலிக்க வேண்டியது';

  @override
  String get ngOpenLeads => 'திறந்த லீடுகள்';

  @override
  String get ngNoMovesYet => 'இன்னும் இடமாற்றம் திட்டமிடவில்லை';

  @override
  String get ngCreateFirstOrder => 'உங்கள் முதல் ஆர்டரை உருவாக்கு';

  @override
  String get ngNoLeadsYet => 'இன்னும் லீடுகள் இல்லை';

  @override
  String get ngAddLead => 'லீட் சேர்';

  @override
  String get ngAllLeads => 'அனைத்து லீடுகள்';

  @override
  String get ngConversion => 'மாற்ற விகிதம்';

  @override
  String get ngOpen => 'திறந்தவை';

  @override
  String get ngOther => 'மற்றவை';

  @override
  String get ngSurveyResponse => 'சர்வே பதில் கிடைத்தது';

  @override
  String get ngFollowUpOverdue => 'பின்தொடர்தல் தாமதம்';

  @override
  String get ngCall => 'அழை';

  @override
  String get ngWhatsApp => 'WhatsApp';

  @override
  String get ngSurvey => 'சர்வே';

  @override
  String get ngNewLead => 'புதிய லீட்';

  @override
  String get ngNameOrPhone => 'பெயர் அல்லது தொலைபேசி';

  @override
  String get ngNoLeadsMatch => 'பொருந்தும் லீடுகள் இல்லை';

  @override
  String get ngLeadsEmptyHint =>
      'புதிய லீட் மூலம் விசாரணையைச் சேர்க்கவும், அது இங்கே தோன்றும்.';

  @override
  String get ngSurveyLinkCreated => 'சர்வே இணைப்பு உருவாக்கப்பட்டது';

  @override
  String get ngCopyClose => 'நகலெடுத்து மூடு';

  @override
  String get ngClose => 'மூடு';

  @override
  String get ngTabAll => 'அனைத்தும்';

  @override
  String get ngTabPending => 'நடப்பில்';

  @override
  String get ngTabCompleted => 'முடிந்தவை';

  @override
  String get ngTabCancelled => 'ரத்தானவை';

  @override
  String get ngToday => 'இன்று';

  @override
  String get ngTomorrow => 'நாளை';

  @override
  String get ngYesterday => 'நேற்று';

  @override
  String get ngNoMoveDate => 'இடமாற்றத் தேதி இல்லை';

  @override
  String get ngPaid => 'செலுத்தியது';

  @override
  String get ngPartPaid => 'பகுதி செலுத்தியது';

  @override
  String get ngDue => 'நிலுவை';

  @override
  String get ngUnpaid => 'செலுத்தவில்லை';

  @override
  String get ngNewOrder => 'புதிய ஆர்டர்';

  @override
  String get ngNoOrdersHere => 'இங்கே ஆர்டர்கள் இல்லை';

  @override
  String get ngRemind => 'நினைவூட்டு';

  @override
  String get ngRecord => 'பதிவு செய்';

  @override
  String get ngOverdue => 'தாமதமானவை';

  @override
  String get ngUpcoming => 'வரவிருப்பவை';

  @override
  String get ngNothingToCollect => 'வசூலிக்க எதுவும் இல்லை';

  @override
  String get ngLinkedDevice => 'இணைக்கப்பட்ட சாதனம்';

  @override
  String get ngEnterPin => 'உங்கள் 4 இலக்க PIN-ஐ உள்ளிடவும்';

  @override
  String get ngVerifying => 'சரிபார்க்கிறது…';

  @override
  String get ngUseEmail => 'பதிலாக மின்னஞ்சல் மூலம் உள்நுழை';

  @override
  String get ngSwitchDevice => 'உங்கள் நிறுவனம் இல்லையா? சாதனத்தை மாற்று';

  @override
  String get ngSecuredBy => 'Nagarva மூலம் பாதுகாக்கப்பட்டது';

  @override
  String get suCreate => 'உங்கள் வணிகக் கணக்கை உருவாக்கவும்';

  @override
  String suStep(String n) {
    return 'படி $n / 4';
  }

  @override
  String get suS1 => 'மொபைல்';

  @override
  String get suS2 => 'வணிகம்';

  @override
  String get suS3 => 'ஆவணங்கள்';

  @override
  String get suS4 => 'சரிபார்ப்பு';

  @override
  String get suPhS =>
      'உரிமையாளரின் எண்ணைப் பயன்படுத்துங்கள். இதன் மூலமே உள்நுழைவீர்கள்.';

  @override
  String get suPh => 'மொபைல் எண்';

  @override
  String get suSend => 'OTP அனுப்பு';

  @override
  String get suPhBad => '10 இலக்க மொபைல் எண்ணை உள்ளிடவும்';

  @override
  String get suOtpT => 'OTP-ஐ உள்ளிடவும்';

  @override
  String suOtpS(String p) {
    return '+91 $p க்கு அனுப்பப்பட்டது';
  }

  @override
  String get suEnter => '6 இலக்கக் குறியீட்டை உள்ளிடவும்';

  @override
  String get suVerify => 'சரிபார்';

  @override
  String get suOtpBad => '6 இலக்க OTP-ஐ உள்ளிடவும்';

  @override
  String get suResend => 'OTP மீண்டும் அனுப்பு';

  @override
  String get suResent => 'OTP மீண்டும் அனுப்பப்பட்டது';

  @override
  String get suChange => 'எண்ணை மாற்று';

  @override
  String get suBzT => 'உங்கள் வணிகம் பற்றி';

  @override
  String get suBzS =>
      'இது உங்கள் மேற்கோள்கள் மற்றும் பில்களில் வரும். பிறகு மாற்றலாம்.';

  @override
  String get suName => 'வணிகப் பெயர்';

  @override
  String get suNameP => 'எ.கா. அருண் பேக்கர்ஸ் & மூவர்ஸ்';

  @override
  String get suOwner => 'உரிமையாளர் பெயர்';

  @override
  String get suEmail => 'மின்னஞ்சல் (விருப்பம்)';

  @override
  String get suEmailP => 'பில் மற்றும் கடவுச்சொல் மீட்டமைப்புக்கு';

  @override
  String get suCity => 'நகரம்';

  @override
  String get suType => 'நீங்கள் என்ன செய்கிறீர்கள்?';

  @override
  String get suTPm => 'பேக்கர்ஸ் & மூவர்ஸ்';

  @override
  String get suTPmS => 'வீடு மற்றும் அலுவலக இடமாற்றம்';

  @override
  String get suTTr => 'போக்குவரத்து';

  @override
  String get suTTrS => 'லாரிகள், பயணங்கள், LR';

  @override
  String get suTBo => 'இரண்டும்';

  @override
  String get suTBoS => 'இடமாற்றம் மற்றும் போக்குவரத்து';

  @override
  String get suGst => 'GSTIN (விருப்பம்)';

  @override
  String get suGstP => '15 எழுத்து GST எண்';

  @override
  String get suRef => 'பரிந்துரைக் குறியீடு (விருப்பம்)';

  @override
  String get suNeedBz => 'வணிகப் பெயர், உரிமையாளர் பெயர், நகரம் நிரப்பவும்';

  @override
  String get suGstBad => 'GSTIN 15 எழுத்துகளாக இருக்க வேண்டும்';

  @override
  String get suEmailBad => 'மின்னஞ்சல் முகவரியைச் சரிபார்க்கவும்';

  @override
  String get suDcT => 'உங்கள் வணிகத்தைச் சரிபார்க்கவும்';

  @override
  String get suDcS =>
      'புகைப்படம் அல்லது PDF. கணக்கு செயல்படும் முன் எங்கள் குழு இவற்றைச் சரிபார்க்கும்.';

  @override
  String get suPan => 'PAN கார்டு';

  @override
  String get suPanS => 'உரிமையாளர் அல்லது வணிக PAN';

  @override
  String get suGstC => 'GST சான்றிதழ்';

  @override
  String get suGstCS => 'GSTIN சேர்த்ததால் தேவை';

  @override
  String get suShop => 'அலுவலகம் அல்லது கிடங்கு புகைப்படம்';

  @override
  String get suShopS => 'விரைவாகச் சரிபார்க்க உதவும்';

  @override
  String get suUpload => 'பதிவேற்று';

  @override
  String get suReq => 'தேவை';

  @override
  String get suOpt => 'விருப்பம்';

  @override
  String get suNeedPan => 'உங்கள் PAN கார்டைப் பதிவேற்றவும்';

  @override
  String get suNeedGstC =>
      'GST சான்றிதழைப் பதிவேற்றவும் அல்லது GSTIN-ஐ நீக்கவும்';

  @override
  String get suPriv =>
      'ஆவணங்கள் வணிகச் சரிபார்ப்புக்கு மட்டுமே. உங்கள் ஊழியர்கள் அல்லது வாடிக்கையாளர்களுக்குக் காட்டப்படாது.';

  @override
  String get suRvT => 'சரிபார்த்து அனுப்பவும்';

  @override
  String get suEdit => 'மாற்று';

  @override
  String get suNext => 'அடுத்து என்ன';

  @override
  String get suN1 =>
      'எங்கள் குழு உங்கள் விவரங்களைச் சரிபார்க்கும், பொதுவாக 1 வேலை நாளில்.';

  @override
  String get suN3 =>
      'இலவசத் திட்டத்தில் தொடங்குவீர்கள். எப்போது வேண்டுமானாலும் மேம்படுத்தலாம்.';

  @override
  String get suNeedAgree => 'தொடர விதிமுறைகளை ஏற்கவும்';

  @override
  String get suSubmit => 'ஒப்புதலுக்கு அனுப்பு';

  @override
  String get suContinue => 'தொடர்க';

  @override
  String get suMob => 'மொபைல்';

  @override
  String get suBt => 'வணிக வகை';

  @override
  String get suNone => 'சேர்க்கவில்லை';

  @override
  String get suPendT => 'விண்ணப்பம் பரிசீலனையில் உள்ளது';

  @override
  String suAppId(String id) {
    return 'விண்ணப்பம் $id';
  }

  @override
  String get suTl1 => 'அனுப்பப்பட்டது';

  @override
  String get suTl2 => 'ஆவணச் சரிபார்ப்பு';

  @override
  String get suTl3 => 'கணக்கு தயார்';

  @override
  String get suOkT => 'உங்கள் கணக்கு தயார்';

  @override
  String suOkS(String b) {
    return '$b அங்கீகரிக்கப்பட்டது. நீங்கள் இலவசத் திட்டத்தில் உள்ளீர்கள்.';
  }

  @override
  String get suStart => 'Nagarva-வைத் தொடங்கு';

  @override
  String get suNoT => 'மாற்றங்கள் தேவை';

  @override
  String get suNoS =>
      'எங்கள் குழுவால் இன்னும் அங்கீகரிக்க முடியவில்லை. கீழே உள்ளதைச் சரிசெய்து மீண்டும் அனுப்பவும்.';

  @override
  String get suFix => 'சரிசெய்து மீண்டும் அனுப்பு';

  @override
  String get suWa => 'WhatsApp-ல் பேசுங்கள்';

  @override
  String get suToLogin => 'உள்நுழைவுக்குத் திரும்பு';

  @override
  String get suHave => 'ஏற்கனவே கணக்கு உள்ளதா?';

  @override
  String get suLogin => 'உள்நுழை';

  @override
  String get suBnP => 'விண்ணப்பம் பரிசீலனையில் உள்ளது';

  @override
  String get suBnOk => 'கணக்கு அங்கீகரிக்கப்பட்டது';

  @override
  String get suBnNo => 'விண்ணப்பத்தில் மாற்றங்கள் தேவை';

  @override
  String get suView => 'பார்';

  @override
  String get suSent => 'விண்ணப்பம் அனுப்பப்பட்டது';

  @override
  String get lgTerms => 'பயன்பாட்டு விதிமுறைகள்';

  @override
  String get lgPriv => 'தனியுரிமைக் கொள்கை';

  @override
  String suTrT(String n) {
    return '$n நாட்கள் Pro-ஐ இலவசமாக முயற்சிக்கவும்';
  }

  @override
  String suTrUsers(String n) {
    return '$n பயனர்கள் வரை';
  }

  @override
  String get suTrOrdersAll => 'ஒவ்வொரு மாதமும் வரம்பற்ற ஆர்டர்கள்';

  @override
  String suTrOrders(String n) {
    return 'மாதத்திற்கு $n ஆர்டர்கள்';
  }

  @override
  String get suTrReports => 'அறிக்கைகள் மற்றும் லாப-நஷ்டம்';

  @override
  String get suTrBranches => 'பல கிளைகள்';

  @override
  String suTrNote(String n) {
    return 'கார்டு தேவையில்லை. $n நாட்களுக்குப் பிறகு தானாகவே இலவச திட்டத்திற்கு மாறுவீர்கள். உங்கள் தரவு அப்படியே இருக்கும்.';
  }

  @override
  String suTrBtn(String n) {
    return '$n நாள் Pro சோதனையைத் தொடங்கு';
  }

  @override
  String get suStayFree => 'இலவசத்திலேயே இருங்கள்';

  @override
  String suTrOn(String n) {
    return 'Pro சோதனை தொடங்கியது · $n நாட்கள்';
  }

  @override
  String get suFreeOn => 'நீங்கள் இலவச திட்டத்தில் உள்ளீர்கள்';

  @override
  String plTrBan(String n) {
    return 'Pro சோதனை $n நாட்களில் முடியும். பிறகு இலவச திட்டத்திற்கு மாறுவீர்கள். உங்கள் தரவு அப்படியே இருக்கும்.';
  }

  @override
  String get plTrEnded =>
      'உங்கள் Pro சோதனை முடிந்தது. நீங்கள் இலவச திட்டத்தில் உள்ளீர்கள், உங்கள் தரவு அனைத்தும் பாதுகாப்பாக உள்ளது.';

  @override
  String plTrEnds(String d, String n) {
    return 'Pro சோதனை $d அன்று முடியும் · $n நாட்கள் உள்ளன';
  }

  @override
  String get suN2b =>
      'உங்கள் நிலையைப் பார்க்க எப்போது வேண்டுமானாலும் இந்த மொபைல் எண்ணில் உள்நுழையுங்கள்.';

  @override
  String suPendS2(String p) {
    return 'பொதுவாக 1 வேலை நாளுக்குள் பதில் அளிப்போம். முடிவைப் பார்க்க +91 $p மூலம் உள்நுழையுங்கள்.';
  }

  @override
  String get suOtpUnavailable =>
      'மொபைல் பதிவு இன்னும் இயக்கப்படவில்லை. Nagarva உதவியைத் தொடர்பு கொள்ளுங்கள்.';

  @override
  String get suSendFailed =>
      'OTP அனுப்ப முடியவில்லை. எண்ணைச் சரிபார்த்து மீண்டும் முயற்சிக்கவும்.';

  @override
  String get suOtpFailed =>
      'அந்தக் குறியீடு வேலை செய்யவில்லை. சரிபார்த்து மீண்டும் முயற்சிக்கவும்.';

  @override
  String get suUploadFailed =>
      'பதிவேற்றம் தோல்வியடைந்தது. மீண்டும் முயற்சிக்கவும்.';

  @override
  String get suMobileLogin => 'மொபைல் எண்ணில் உள்நுழையுங்கள்';

  @override
  String get suRefresh => 'நிலையைப் பார்';

  @override
  String suResendIn(String n) {
    return '$n வினாடிகளில் மீண்டும் அனுப்பு';
  }

  @override
  String get suAgreeLead => 'இவற்றை ஏற்கிறேன்:';

  @override
  String get ngGreetMorning => 'காலை வணக்கம்';

  @override
  String get ngGreetAfternoon => 'மதிய வணக்கம்';

  @override
  String get ngGreetEvening => 'மாலை வணக்கம்';

  @override
  String ngPlanName(String plan) {
    return '$plan திட்டம்';
  }

  @override
  String get ngPlanActive => 'செயலில்';

  @override
  String get ngPlanTrial => 'சோதனை';

  @override
  String get ngPlanEndingSoon => 'விரைவில் முடிகிறது';

  @override
  String get ngPlanEnded => 'முடிந்தது';

  @override
  String ngPlanTrialEnds(String date, int days) {
    return 'சோதனை $date அன்று முடியும் · $days நாட்கள் மீதம்';
  }

  @override
  String ngPlanReadOnlyIn(int days) {
    return 'சோதனை முடிந்தது · $days நாட்களில் பார்வை மட்டும்';
  }

  @override
  String get ngPlanReadOnly => 'சோதனை முடிந்தது · பார்வை மட்டும்';

  @override
  String get ngPlanNoExpiry => 'காலாவதி தேதி இல்லை';

  @override
  String get ngPlanSee => 'திட்டங்கள்';

  @override
  String get ngPaymentsDue => 'நிலுவை கட்டணங்கள்';

  @override
  String ngPaymentsDueSub(int n) {
    return '$n ஆர்டர்கள் முழுமையாக செலுத்தப்படவில்லை';
  }

  @override
  String get ngOverdueFollowUps => 'தாமதமான பின்தொடர்தல்கள்';

  @override
  String get ngOverdueFollowUpsSub => 'இவர்களை முதலில் அழைக்கவும்';

  @override
  String get ngTodaysPlan => 'இன்றைய திட்டம்';

  @override
  String get ngNothingToday => 'இன்று எதுவும் திட்டமிடப்படவில்லை';

  @override
  String get ngComingUp => 'வரவிருப்பவை';

  @override
  String ngAgendaMove(String name) {
    return 'இடமாற்றம் · $name';
  }

  @override
  String get ngAllDay => 'நாள் முழுவதும்';

  @override
  String get ngPeriodThisMonth => 'இந்த மாதம்';

  @override
  String get ngPeriodLastMonth => 'கடந்த மாதம்';

  @override
  String get ngPeriod3m => 'கடந்த 3 மாதங்கள்';

  @override
  String get ngPeriodFy => 'இந்த நிதியாண்டு';

  @override
  String get ngPeriodAll => 'எல்லா காலமும்';

  @override
  String get ngPickPeriod => 'இதற்கான எண்களைக் காட்டு';

  @override
  String get ngProfitTarget => 'லாப இலக்கு';

  @override
  String get ngSetTarget => 'மாத லாப இலக்கை அமைக்கவும்';

  @override
  String get ngSetTargetSub => 'அடைய விரும்பும் தொகையை அமைக்க தட்டவும்';

  @override
  String get ngProfit => 'லாபம்';

  @override
  String ngProfitAfter(String labour, String expenses) {
    return 'கூலி $labour, செலவு $expenses கழித்து';
  }

  @override
  String get ngAddExpense => 'செலவு சேர்';

  @override
  String get ngSeeAll => 'அனைத்தும்';

  @override
  String get ngHotLeads => 'சூடான லீடுகள்';

  @override
  String get ngBranches => 'கிளைகள்';

  @override
  String ngOrdersN(int n) {
    return '$n ஆர்டர்கள்';
  }

  @override
  String get ngTargetDone => 'இலக்கு எட்டப்பட்டது';

  @override
  String get ngNoProfitYet => 'இந்தக் காலத்தில் இன்னும் லாபம் இல்லை';

  @override
  String get ngEditTarget => 'மாத லாப இலக்கு';

  @override
  String get ngQuote => 'மதிப்பீடு';

  @override
  String get ngTabDone => 'முடிந்தவை';

  @override
  String get ngReceived => 'பெறப்பட்டவை';

  @override
  String ngDaysLate(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n நாள் தாமதம்',
      one: '1 நாள் தாமதம்',
    );
    return '$_temp0';
  }

  @override
  String get ngNoPaymentsYet => 'இன்னும் கட்டணம் பதிவு செய்யப்படவில்லை';

  @override
  String get ngOpsTitle => 'செயல்பாடுகள்';

  @override
  String get ngOpsNewTrip => 'புதிய பயணம்';

  @override
  String get ngOpsCrewsOut => 'வேலையில் குழுக்கள்';

  @override
  String get ngOpsVehiclesFree => 'காலி வாகனங்கள்';

  @override
  String get ngOpsAttention => 'கவனம் தேவை';

  @override
  String ngOpsNoCrew(String name) {
    return 'குழு இல்லை · $name';
  }

  @override
  String get ngOpsAssign => 'ஒதுக்கு';

  @override
  String get ngOpsAssignCrew => 'குழுவை ஒதுக்கு';

  @override
  String ngOpsInsuranceExpires(int n) {
    return 'காப்பீடு $n நாட்களில் முடியும்';
  }

  @override
  String get ngOpsInsuranceExpired => 'காப்பீடு முடிந்தது';

  @override
  String ngOpsLowStock(String name) {
    return '$name குறைவாக உள்ளது';
  }

  @override
  String ngOpsStockLeft(String qty) {
    return '$qty மீதம்';
  }

  @override
  String get ngOpsReorder => 'மீண்டும் ஆர்டர்';

  @override
  String get ngOpsView => 'பார்';

  @override
  String get ngOpsAwaiting => 'ஒப்புதலுக்காக காத்திருக்கிறது';

  @override
  String get ngOpsJobs => 'வேலைகள்';

  @override
  String get ngOpsNoJobs => 'இந்த நாளில் இடமாற்றம் இல்லை';

  @override
  String get ngOpsFleet => 'வாகனங்கள்';

  @override
  String ngOpsFleetSummary(int free, int total) {
    return '$total-ல் $free காலி';
  }

  @override
  String get ngOpsInService => 'சர்வீஸில்';

  @override
  String get ngOpsOnJob => 'வேலையில்';

  @override
  String get ngOpsFree => 'காலி';

  @override
  String ngExpCount(int n) {
    return '$n செலவுகள்';
  }

  @override
  String ngExpVsLast(int pct) {
    return 'கடந்த மாதத்துடன் $pct%';
  }

  @override
  String get ngExpThisWeek => 'இந்த வாரம்';

  @override
  String get ngExpOrderOnly => 'ஆர்டருடன் இணைந்தவை மட்டும்';

  @override
  String get ngExpNone => 'இந்தக் காலத்தில் செலவுகள் இல்லை';

  @override
  String get ngExpUncategorised => 'வகைப்படுத்தப்படாதவை';

  @override
  String get ngExpDelete => 'செலவை நீக்கு';

  @override
  String get ngExpByCategory => 'வகை வாரியாக';

  @override
  String get ngExpNoCat => 'இன்னும் பிரிக்க எதுவும் இல்லை';

  @override
  String get ngExpNoCatSub => 'செலவைப் பதிவு செய்தவுடன் வகைகள் இங்கே தோன்றும்.';

  @override
  String get ngFleetNew => 'புதிய வாகனம்';

  @override
  String get ngFleetActive => 'செயலில்';

  @override
  String get ngFleetMaintenance => 'பராமரிப்பு';

  @override
  String get ngFleetInactive => 'செயலற்றது';

  @override
  String get ngFleetNone =>
      'இன்னும் வாகனங்கள் இல்லை. ஆவணங்கள், பயணங்களைக் கண்காணிக்க ஒன்றைச் சேர்க்கவும்.';

  @override
  String get ngFleetDelete => 'வாகனத்தை நீக்கு';

  @override
  String get ngFleetInsurance => 'காப்பீடு';

  @override
  String get ngFleetPermit => 'அனுமதி';

  @override
  String ngFleetExpires(String doc, int n) {
    return '$doc $n நாட்களில் முடியும்';
  }

  @override
  String ngFleetExpired(String doc, int n) {
    return '$doc $n நாட்களுக்கு முன் முடிந்தது';
  }

  @override
  String get ngMatNew => 'புதிய பொருள்';

  @override
  String get ngMatSearch => 'பொருட்களைத் தேடு';

  @override
  String get ngMatReorderSoon => 'விரைவில் ஆர்டர் செய்';

  @override
  String get ngMatReturnable => 'திரும்பப் பெறக்கூடியது';

  @override
  String ngMatMin(String n) {
    return 'குறைந்தது $n';
  }

  @override
  String get ngMatDelete => 'பொருளை நீக்கு';

  @override
  String get ngMatNone => 'இன்னும் பொருட்கள் இல்லை';

  @override
  String get ngTripPlanned => 'திட்டமிடப்பட்டது';

  @override
  String get ngTripOngoing => 'நடப்பில்';

  @override
  String get ngTripNone => 'இன்னும் பயணங்கள் இல்லை';

  @override
  String get ngTripNoNumber => '(பயண எண் இல்லை)';

  @override
  String get ngTripHired => 'வாடகை';

  @override
  String get ngTripOwn => 'சொந்தம்';

  @override
  String get ngTripDelete => 'பயணத்தை நீக்கு';

  @override
  String ngCustCount(int n) {
    return '$n வாடிக்கையாளர்கள்';
  }

  @override
  String get ngCustNew => 'புதியது';

  @override
  String get ngCustSearch => 'பெயர், தொலைபேசி அல்லது நிறுவனம் தேடு';

  @override
  String get ngCustNone => 'வாடிக்கையாளர்கள் இல்லை';

  @override
  String ngCustDue(String amount) {
    return '$amount நிலுவை';
  }

  @override
  String get ngStaffTitle => 'ஊழியர்கள்';

  @override
  String ngStaffSummary(int n, int monthly, int other) {
    return '$n பேர் · $monthly மாத · $other தினசரி / தற்காலிக';
  }

  @override
  String get ngStaffAdd => 'ஊழியர் சேர்';

  @override
  String get ngStaffMonthly => 'நிலையான மாத';

  @override
  String get ngStaffDaily => 'தினசரி';

  @override
  String get ngStaffTemporary => 'தற்காலிக';

  @override
  String ngStaffJoined(String date) {
    return 'சேர்ந்தது $date';
  }

  @override
  String get ngStaffAllRoles => 'அனைத்து பணிகள்';

  @override
  String get ngStaffNone => 'இன்னும் ஊழியர்கள் இல்லை';

  @override
  String get ngStaffInactive => 'செயலற்றவர்கள்';

  @override
  String get ngSalTitle => 'சம்பளம்';

  @override
  String get ngSalToPay => 'செலுத்த வேண்டியது';

  @override
  String get ngSalAdvances => 'முன்பணம்';

  @override
  String get ngSalPaid => 'செலுத்திய சம்பளம்';

  @override
  String get ngSalBalance => 'நிலுவை';

  @override
  String ngSalJobs(int n) {
    return '$n வேலைகள்';
  }

  @override
  String ngSalAdvance(String amount) {
    return 'முன்பணம் $amount';
  }

  @override
  String get ngSalNote =>
      'இந்த மாதம் ஒவ்வொரு வேலையிலும் பதிவு செய்த குழுவிலிருந்து வருமானம் கணக்கிடப்படுகிறது. சம்பளம் அல்லது முன்பணம் கொடுக்க ஒருவரைத் திறக்கவும்.';

  @override
  String get ngSetApp => 'செயலி';

  @override
  String get ngSetLanguage => 'மொழி';

  @override
  String get ngSetTheme => 'தீம்';

  @override
  String get ngSetThemeLight => 'ஒளி';

  @override
  String get ngSetThemeDark => 'இருள்';

  @override
  String get ngSetThemeMidnight => 'நள்ளிரவு';

  @override
  String get ngSetNotifications => 'அறிவிப்புகள்';

  @override
  String get ngSetNotificationsSub =>
      'செயலி திறந்திருக்கும்போது எச்சரிக்கைகளைக் காட்டு';

  @override
  String get ngSetBusiness => 'வணிகம்';

  @override
  String get ngSetBizDetails => 'வணிக விவரங்கள்';

  @override
  String get ngSetBizDetailsSub =>
      'பெயர், டேக்லைன், GST, முகவரி, லோகோ, கையொப்பம், விதிமுறைகள், எண்ணிடல்';

  @override
  String get ngSetCft => 'CFT & தொகுப்புகள்';

  @override
  String get ngSetCftSub =>
      'பொருள் அளவுகள், வீட்டு அளவுகள், சேமிப்பு கட்டணங்கள்';

  @override
  String get ngSetSecurity => 'பாதுகாப்பு';

  @override
  String get ngSetLogin => 'உள்நுழைவு & பாதுகாப்பு';

  @override
  String get ngSetLoginSub => 'உங்கள் செயலி PIN';

  @override
  String get ngSetAccount => 'கணக்கு & உதவி';

  @override
  String get ngSetPlan => 'திட்டம் & கட்டணம்';

  @override
  String get ngSetPlanSub => 'உங்கள் திட்டமும் வரம்புகளும்';

  @override
  String get ngSetRecycle => 'நீக்கப்பட்டவை';

  @override
  String get ngSetRecycleSub => 'தவறாக நீக்கியதை மீட்டெடு';

  @override
  String get ngSetHelp => 'உதவி & ஆதரவு';

  @override
  String get ngSetHelpSub => 'உதவி தொடர்பு, தனியுரிமைக் கொள்கை, விதிமுறைகள்';

  @override
  String get ngSetPorter => 'Porter இணைப்பு';

  @override
  String get ngSetPorterSub =>
      'டாஷ்போர்டில் Porter கமிஷனைக் காட்டு. உங்கள் வணிகம் Porter பயன்படுத்தினால் மட்டும் இயக்கவும்.';

  @override
  String odStageOf(int n, int total, String name) {
    return 'நிலை $n / $total · $name';
  }

  @override
  String get odJourneyDone => 'அனைத்து நிலைகளும் முடிந்தன';

  @override
  String get odMaps => 'வரைபடம்';

  @override
  String get odProgress => 'முன்னேற்றம்';

  @override
  String get odInProgress => 'நடைபெறுகிறது';

  @override
  String odMarkAs(String stage) {
    return '$stage எனக் குறி';
  }

  @override
  String get odDeliveredHint =>
      'வாடிக்கையாளர் குறியீட்டுடன் குழு பணியை முடிக்கும்போது டெலிவரி பதிவாகும்.';

  @override
  String get odOpenFieldJob => 'களப் பணியைத் திற';

  @override
  String get odCrewVehicle => 'குழு & வாகனம்';

  @override
  String get odNoCrew => 'இன்னும் குழு ஒதுக்கப்படவில்லை';

  @override
  String get odNoVehicle => 'வாகனம் ஒதுக்கப்படவில்லை';

  @override
  String odSupervisorCrew(String name, int count) {
    return 'மேற்பார்வையாளர் · $name · $count பேர்';
  }

  @override
  String odCrewCount(int count) {
    return '$count பேர்';
  }

  @override
  String get odPayment => 'கட்டணம்';

  @override
  String get odTotal => 'மொத்தம்';

  @override
  String get odPaid => 'செலுத்தியது';

  @override
  String get odBalance => 'நிலுவை';

  @override
  String get odPartPaid => 'பகுதி செலுத்தியது';

  @override
  String get odFullyPaid => 'செலுத்தப்பட்டது';

  @override
  String get odUnpaid => 'செலுத்தவில்லை';

  @override
  String get odRemind => 'நினைவூட்டு';

  @override
  String get odRecordPayment => 'கட்டணத்தைப் பதிவு செய்';

  @override
  String get odActivity => 'செயல்பாடு';

  @override
  String odAllN(int count) {
    return 'அனைத்தும் $count';
  }

  @override
  String get odStageChanged => 'நிலை மாறியது';

  @override
  String odPaymentReceived(String amount) {
    return 'கட்டணம் பெறப்பட்டது · $amount';
  }

  @override
  String get odNoActivity => 'இந்த ஆர்டரில் இன்னும் எதுவும் பதிவாகவில்லை.';

  @override
  String get odMoveDetails => 'நகர்வு விவரங்கள்';

  @override
  String get odCancelled => 'ரத்து செய்யப்பட்டது';

  @override
  String get odMore => 'மேலும் செயல்கள்';

  @override
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor) {
    return 'Hi $customer, a balance of $amount is due for your move ($orderId). Thank you, $vendor';
  }

  @override
  String get odStConfirmed => 'உறுதி';

  @override
  String get odStPacking => 'பேக்கிங்';

  @override
  String get odStInTransit => 'பயணத்தில்';

  @override
  String get odStArrived => 'வந்தடைந்தது';

  @override
  String get odStDelivered => 'ஒப்படைக்கப்பட்டது';

  @override
  String get odStCompleted => 'முடிந்தது';

  @override
  String get nlPhone => 'தொலைபேசி';

  @override
  String get nlName => 'பெயர்';

  @override
  String get nlRoute => 'வழி';

  @override
  String get nlMovingFrom => 'எங்கிருந்து';

  @override
  String get nlMovingTo => 'எங்கு';

  @override
  String get nlService => 'சேவை';

  @override
  String get nlWhen => 'எப்போது';

  @override
  String get nlToday => 'இன்று';

  @override
  String get nlTomorrow => 'நாளை';

  @override
  String get nlPickDate => 'தேதி தேர்வு';

  @override
  String get nlSource => 'மூலம்';

  @override
  String get nlBranch => 'கிளை';

  @override
  String get nlNextStep => 'அடுத்த படி';

  @override
  String get nlStepFollow => 'பின்தொடர்';

  @override
  String get nlStepFollowSub => 'பின்னர் அழை';

  @override
  String get nlStepSurvey => 'ஆய்வு';

  @override
  String get nlStepSurveySub => 'நேரில், இணைப்பு அல்லது அழைப்பில்';

  @override
  String get nlStepQuote => 'ஆய்வு தவிர் · விலை';

  @override
  String get nlStepQuoteSub => 'இந்த அழைப்பிலேயே விலை';

  @override
  String get nlStepConfirm => 'ஆர்டர் உறுதி';

  @override
  String get nlStepConfirmSub => 'வாடிக்கையாளர் ஒப்புக்கொண்டார்';

  @override
  String get nlMore => 'மேலும் விவரங்கள்';

  @override
  String get nlEmail => 'மின்னஞ்சல் (விருப்பம்)';

  @override
  String get nlNotes => 'குறிப்புகள்';

  @override
  String get nlNameRequired => 'வாடிக்கையாளர் பெயரை உள்ளிடவும்.';

  @override
  String get nlNoBranches =>
      'லீட்களைச் சேமிக்கும் முன் அமைப்புகளில் ஒரு கிளையைச் சேர்க்கவும்.';

  @override
  String get nlUpdateLead => 'லீடைப் புதுப்பி';

  @override
  String get noPickup => 'ஏற்றும் இடம்';

  @override
  String get noDrop => 'இறக்கும் இடம்';

  @override
  String get noPricing => 'விலை & மூலம்';

  @override
  String get ngSetFy => 'நிதியாண்டு & எண்ணிடல்';

  @override
  String get ngSetFySub => 'அடுத்த ஆண்டு பில் எண்களைத் தொடங்கு';

  @override
  String get ngSetWa => 'WhatsApp';

  @override
  String get ngSetWaSub => 'உங்கள் சொந்த எண்ணிலிருந்து செய்திகள் அனுப்பு';

  @override
  String get ngSetAutoWa => 'தானியங்கி WhatsApp';

  @override
  String get ngSetAutoWaSub =>
      'ஒவ்வொரு கட்டத்திலும் வாடிக்கையாளருக்கு அனுப்பப்படும் செய்திகள்';

  @override
  String get mdTitle => 'மாட்யூல்கள்';

  @override
  String get mdSettingsSub =>
      'பேக்கர்ஸ் & மூவர்ஸ், போக்குவரத்து அல்லது இரண்டும்';

  @override
  String get mdType => 'உங்கள் வணிகம்';

  @override
  String get mdAdv => 'மேம்பட்டவை';

  @override
  String mdCount(int count, int total) {
    return '$total-ல் $count மாட்யூல்கள் இயக்கத்தில்';
  }

  @override
  String mdGroupOn(int count, int total) {
    return '$total-ல் $count இயக்கத்தில்';
  }

  @override
  String get mdNote =>
      'அணைத்த மாட்யூல்கள் மெனுவிலிருந்து மறையும். உங்கள் தரவு சேமிக்கப்பட்டிருக்கும், மீண்டும் இயக்கினால் திரும்ப வரும்.';

  @override
  String get mdReset => 'இந்த வணிகத்துக்குப் பரிந்துரைத்ததற்கு மீட்டமை';

  @override
  String mdResetDone(String type) {
    return '$type-க்கு மாட்யூல்கள் மீட்டமைக்கப்பட்டன';
  }

  @override
  String mdTypeSet(String type) {
    return '$type தேர்வு · மெனு புதுப்பிக்கப்பட்டது';
  }

  @override
  String get mdOwnerOnly => 'உரிமையாளர் மட்டுமே மாட்யூல்களை மாற்ற முடியும்';

  @override
  String get mdSaveFailed =>
      'சேமிக்க முடியவில்லை. இணைப்பைச் சரிபார்த்து மீண்டும் முயலவும்.';

  @override
  String get btPm => 'பேக்கர்ஸ் & மூவர்ஸ்';

  @override
  String get btPmS => 'வீடு, அலுவலகம், வாகன இடமாற்றம்';

  @override
  String get btTr => 'போக்குவரத்து / லாஜிஸ்டிக்ஸ்';

  @override
  String get btTrS => 'லாரி, பயணம், சரக்கு, ஓட்டுநர்';

  @override
  String get btBoth => 'இரண்டும்';

  @override
  String get btBothS => 'இடமாற்றம் & போக்குவரத்து, அனைத்தும் இயக்கத்தில்';

  @override
  String get btTitle => 'உங்கள் வணிகம் என்ன செய்கிறது?';

  @override
  String get btSub =>
      'தேவையான மாட்யூல்களை மட்டும் காட்டுவோம். அமைப்புகள் › மாட்யூல்களில் எப்போதும் மாற்றலாம்.';

  @override
  String get btLater => 'பிறகு அமைப்புகள் › மாட்யூல்களில் மாற்றலாம்';

  @override
  String get dwTitle => 'விட்ஜெட்கள்';

  @override
  String get dwSub => 'உரிமையாளர் டாஷ்போர்டில் என்ன காட்ட வேண்டும்';

  @override
  String get dwNote =>
      'உரிமையாளர் டாஷ்போர்டில் இந்த வரிசையில் காட்டப்படும். அம்பால் மேலே நகர்த்து, சுவிட்சால் மறை.';

  @override
  String dwShown(int n) {
    return 'காட்டப்படுகிறது · இடம் $n';
  }

  @override
  String get dwHidden => 'மறைக்கப்பட்டது';

  @override
  String get dwUp => 'மேலே';

  @override
  String get dwToday => 'இன்றைய எண்ணிக்கைகள்';

  @override
  String get dwFleet => 'வாகன நிலை';

  @override
  String dwFleetSub(int a, int s) {
    return '$a செயலில் · $s சர்வீஸில்';
  }

  @override
  String get dwAttendance => 'ஊழியர் வருகை';

  @override
  String get dwAttendanceSub => 'இன்று வருகை பதிவு';

  @override
  String get dwSaveFailed =>
      'சேமிக்க முடியவில்லை. இணைப்பைச் சரிபார்த்து மீண்டும் முயலவும்.';

  @override
  String get jrShareInvoice => 'பில் அனுப்பு';

  @override
  String get jrSendForSignature => 'கையொப்பத்திற்கு அனுப்பு';

  @override
  String get lsTitle => 'உள்நுழைவு & பாதுகாப்பு';

  @override
  String get lsMy => 'உங்கள் உள்நுழைவு';

  @override
  String get lsMyEmail => 'உள்நுழைவு மின்னஞ்சல்';

  @override
  String get lsChangePw => 'கடவுச்சொல்லை மாற்று';

  @override
  String get lsCurPw => 'தற்போதைய கடவுச்சொல்';

  @override
  String get lsNewPw => 'புதிய கடவுச்சொல்';

  @override
  String get lsConfPw => 'புதிய கடவுச்சொல்லை உறுதிசெய்';

  @override
  String get lsPwSub => 'குறைந்தது 8 எழுத்துகள்';

  @override
  String get lsPwShort => 'கடவுச்சொல் குறைந்தது 8 எழுத்துகள் வேண்டும்';

  @override
  String get lsPwMismatch => 'கடவுச்சொற்கள் பொருந்தவில்லை';

  @override
  String get lsPwCurReq => 'தற்போதைய கடவுச்சொல்லை உள்ளிடுங்கள்';

  @override
  String get lsPwDone => 'கடவுச்சொல் மாற்றப்பட்டது';

  @override
  String get lsUpdatePw => 'கடவுச்சொல்லைப் புதுப்பி';

  @override
  String get lsForgot =>
      'கடவுச்சொல் மறந்துவிட்டதா? உள்நுழைவுத் திரையில் \"கடவுச்சொல் மறந்ததா?\" அழுத்துங்கள். மீட்டமைப்பு இணைப்பை மின்னஞ்சல் செய்வோம்.';

  @override
  String get lsStaffPins => 'பணியாளர் PIN';

  @override
  String get lsStaffPinsSub =>
      'பணியாளர்களும் மேற்பார்வையாளர்களும் PIN மூலம் உள்நுழைவார்கள். மறந்தால் புதிய PIN அமைக்கவும். பலமுறை தவறான PIN போட்டால், நீங்கள் மீட்டமைக்கும் வரை PIN பூட்டப்படும்.';

  @override
  String get lsResetPin => 'PIN மீட்டமை';

  @override
  String get lsPinSet => 'PIN அமைத்தது';

  @override
  String lsLocked(int n) {
    return 'பூட்டப்பட்டது · $n தவறு';
  }

  @override
  String get lsNewPin => 'புதிய PIN';

  @override
  String get lsConfPin => 'PIN உறுதிசெய்';

  @override
  String get lsPinBad => 'PIN 4 இலக்கம் வேண்டும்';

  @override
  String get lsPinMismatch => 'PIN பொருந்தவில்லை';

  @override
  String lsPinSetFor(String name) {
    return 'புதிய PIN அமைக்கப்பட்டது: $name';
  }

  @override
  String get lsTellStaff =>
      'புதிய PIN-ஐ நேரில் அல்லது போனில் சொல்லுங்கள். இது மீண்டும் காட்டப்படாது.';

  @override
  String get lsSetPin => 'புதிய PIN அமை';

  @override
  String get lsSignOutAll => 'மற்ற எல்லா சாதனங்களிலும் வெளியேறு';

  @override
  String get lsAllOut => 'மற்ற எல்லா சாதனங்களும் வெளியேறின';

  @override
  String get lsNoPin => 'இன்னும் PIN இல்லை';

  @override
  String get lsOwnerOnly => 'ஊழியர் PIN-ஐ உரிமையாளர் மட்டுமே மாற்ற முடியும்.';

  @override
  String get qdTitle => 'மேற்கோள் வடிவம்';

  @override
  String get qdSub =>
      'வாடிக்கையாளருக்கு உங்கள் மேற்கோள் PDF எப்படித் தெரியும்.';

  @override
  String get qdTheme => 'தீம்';

  @override
  String get qdColor => 'பிராண்ட் நிறம்';

  @override
  String get qdLogo => 'லோகோ';

  @override
  String get qdLogoAdd => 'லோகோ பதிவேற்று';

  @override
  String get qdLogoHint => 'PNG அல்லது JPG, சதுரம் சிறந்தது';

  @override
  String get qdSave => 'வடிவத்தைச் சேமி';

  @override
  String get qdPreview => 'மாதிரி PDF பார்';

  @override
  String get qdSaved => 'மேற்கோள் வடிவம் சேமிக்கப்பட்டது';

  @override
  String get qdTheme1A => 'கிளாசிக்';

  @override
  String get qdTheme1B => 'போல்ட் பேண்ட்';

  @override
  String get qdTheme1C => 'சைட்பார்';

  @override
  String get qdTheme1D => 'மினிமல்';

  @override
  String get qdTheme1E => 'கார்ப்பரேட்';

  @override
  String get qdTheme1F => 'லெட்டர்ஹெட்';

  @override
  String get qdThemeDesc1A => 'செரிஃப், கோடுகள்';

  @override
  String get qdThemeDesc1B => 'வண்ணத் தலைப்பு, வட்டப் பேனல்கள்';

  @override
  String get qdThemeDesc1C => 'இடப்பக்க விவரங்கள்';

  @override
  String get qdThemeDesc1D => 'கருப்பு வெள்ளை, எங்கும் அச்சிடலாம்';

  @override
  String get qdThemeDesc1E => 'பெட்டி வடிவம், அலுவலக நகர்வுக்கு';

  @override
  String get qdThemeDesc1F => 'மையம், இரட்டைக் கோடு';

  @override
  String get drvTitle => 'ஓட்டுநர் செயலி';

  @override
  String get drvNone => 'இன்று பயணம் இல்லை';

  @override
  String get drvPlanned => 'திட்டம்';

  @override
  String get drvOngoing => 'பயணத்தில்';

  @override
  String get drvStart => 'பயணம் தொடங்கு';

  @override
  String get drvEnd => 'பயணம் முடி';

  @override
  String get drvDone => 'பயணம் முடிந்தது';

  @override
  String get drvFuel => 'எரிபொருள்';

  @override
  String get drvFuelT => 'எரிபொருள் சேர்';

  @override
  String get drvToll => 'சுங்கம்';

  @override
  String get drvTollT => 'சுங்கம் சேர்';

  @override
  String get drvLitres => 'லிட்டர்';

  @override
  String get drvPlaza => 'சுங்கச்சாவடி';

  @override
  String get drvAdd => 'பதிவு சேர்';

  @override
  String get drvNeedStart => 'தொடக்க ஓடோமீட்டர் உள்ளிடு';

  @override
  String get drvNeedEnd => 'முடிவு ஓடோமீட்டர் தொடக்கத்தை விட அதிகம் வேண்டும்';

  @override
  String get drvNeedAmount => 'தொகையை உள்ளிடு';

  @override
  String get drvTripKm => 'பயண கிமீ';

  @override
  String get drvTripSpend => 'பயணச் செலவு';

  @override
  String get drvToday => 'இன்றைய பதிவுகள்';

  @override
  String get drvOdoStart => 'தொடக்க ஓடோமீட்டர்';

  @override
  String get drvOdoEnd => 'முடிவு ஓடோமீட்டர்';

  @override
  String get mktTitle => 'Nagarva வேலைகள்';

  @override
  String get mktSub => 'Nagarva-வில் வாடிக்கையாளர்கள் பதிவு செய்த இடமாற்றங்கள்';

  @override
  String get mktTier => 'உங்கள் நிலை';

  @override
  String get mktWallet => 'வாலெட்';

  @override
  String mktMinL(String m) {
    return 'வேலை பெற குறைந்தது $m';
  }

  @override
  String get mktLowS => 'குறைந்தபட்சத்துக்குக் கீழ்';

  @override
  String get mktTJobs => 'வேலைகள்';

  @override
  String get mktTWallet => 'வாலெட்';

  @override
  String get mktTTier => 'நிலை';

  @override
  String get mktAv => 'வேலைக்குத் தயார்';

  @override
  String mktAvOn(String c) {
    return '$c வேலை அறிவிப்புகள் வருகின்றன';
  }

  @override
  String get mktAvOff =>
      'அணைக்கப்பட்டது. புதிய வேலை அறிவிப்பு இல்லை. மதிப்பெண் பாதிக்காது.';

  @override
  String get mktCities => 'பிக்அப் நகரங்கள்';

  @override
  String get mktCitiesN =>
      'இந்த நகரங்களில் தொடங்கும் முன்பதிவுகளுக்கு அறிவிப்பு வரும். சொந்த நகரத்தை நீக்க முடியாது.';

  @override
  String get mktEdit => 'மாற்று';

  @override
  String get mktDone2 => 'முடிந்தது';

  @override
  String get mktCancel => 'ரத்து';

  @override
  String get mktHome => 'சொந்தம்';

  @override
  String get mktRtAsk => 'வண்டி வேறு நகரத்திலா?';

  @override
  String get mktRtAdd => 'சேர்';

  @override
  String get mktRtEnd => 'முடி';

  @override
  String get mktRtFrom => 'வண்டி இப்போது இருக்கும் இடம்';

  @override
  String get mktRtDate => 'புறப்படும் நாள்';

  @override
  String mktRtOn(String f, String t) {
    return 'திரும்பும் பயணம் · $f → $t';
  }

  @override
  String get mktRtEnded => 'திரும்பும் பயணம் முடிந்தது';

  @override
  String get mktFNew => 'புதியவை';

  @override
  String get mktFAcc => 'ஏற்றவை';

  @override
  String get mktFDone => 'முடிந்தவை';

  @override
  String get mktENew => 'இப்போது புதிய வேலை இல்லை. வந்ததும் அறிவிப்பு வரும்.';

  @override
  String get mktEAcc => 'ஏற்ற வேலைகள் இல்லை.';

  @override
  String get mktEDone => 'இன்னும் முடிந்த வேலைகள் இல்லை.';

  @override
  String get mktEOff =>
      'நீங்கள் தயாராக இல்லை. புதிய முன்பதிவுகளைப் பார்க்க இயக்கவும்.';

  @override
  String mktLow(String a, String m) {
    return 'வாலெட் $m-க்குக் கீழ் உள்ளது. புதிய வேலைகளைப் பார்க்க $a டாப்-அப் செய்யவும்.';
  }

  @override
  String get mktVal => 'வேலை மதிப்பு (GST உட்பட)';

  @override
  String mktCom(String p) {
    return 'Nagarva கமிஷன் $p%';
  }

  @override
  String get mktEarn => 'உங்கள் வருமானம்';

  @override
  String get mktAdv => 'Nagarva-க்கு செலுத்திய முன்பணம்';

  @override
  String get mktBal => 'டெலிவரி OTP-க்குப் பின் வசூலிக்கவும்';

  @override
  String get mktMasked => 'ஏற்ற பிறகு வாடிக்கையாளர் பெயர், போன் தெரியும்';

  @override
  String get mktPass => 'தவிர்';

  @override
  String get mktAccept => 'வேலையை ஏற்கவும்';

  @override
  String mktAccepted(String id) {
    return '$id உங்களுடையது. வாடிக்கையாளர் விவரம் திறந்தது.';
  }

  @override
  String get mktPassed => 'வேலை தவிர்க்கப்பட்டது';

  @override
  String get mktTaken => 'வேறு விற்பனையாளர் எடுத்தார்';

  @override
  String get mktGoldOnly => 'கோல்ட் மட்டும்';

  @override
  String get mktRl => 'திரும்பும் லோடு';

  @override
  String get mktS0 => 'ஏற்றது';

  @override
  String get mktS1 => 'வழியில்';

  @override
  String get mktS2 => 'வந்தடைந்தது';

  @override
  String get mktS3 => 'ஏற்றுதல்';

  @override
  String get mktS4 => 'பயணத்தில்';

  @override
  String get mktS5 => 'டெலிவரி';

  @override
  String mktNext(String s) {
    return '$s எனக் குறி';
  }

  @override
  String mktPhotos(int n) {
    return 'ஏற்றுதல் புகைப்படங்கள் $n/3';
  }

  @override
  String get mktNeedPh => 'முதலில் 3 ஏற்றுதல் புகைப்படங்கள் சேர்';

  @override
  String get mktAddPh => 'புகைப்படம் சேர்';

  @override
  String get mktFinish => 'OTP சரிபார்த்து முடி';

  @override
  String get mktOtpBad => 'தவறான OTP. வாடிக்கையாளரிடம் சரிபார்க்கவும்.';

  @override
  String mktDone(String a, String c) {
    return 'முடிந்தது. $c கமிஷன் பிடிக்கப்பட்டது, $a முன்பணம் வரவு.';
  }

  @override
  String mktRate(String r) {
    return 'வாடிக்கையாளர் மதிப்பீடு $r';
  }

  @override
  String get mktNoRate => 'வாடிக்கையாளர் மதிப்பீடு வரவில்லை';

  @override
  String get mktTopup => 'டாப்-அப்';

  @override
  String get mktWBal => 'வாலெட் இருப்பு';

  @override
  String get mktWOk => 'செயலில் · புதிய வேலைகள் கிடைக்கும்';

  @override
  String get mktWWithdraw => 'எடு';

  @override
  String mktWNote(String p) {
    return 'வாடிக்கையாளர்கள் முன்பணத்தை Nagarva-க்குச் செலுத்துவார்கள். வேலை முடிந்ததும் முன்பணம் இங்கே வரவாகும், $p% கமிஷன் பிடிக்கப்படும். வேலை பெற குறைந்தபட்ச இருப்பை வைத்திருங்கள்.';
  }

  @override
  String mktWtAdv(String id) {
    return 'முன்பணம் · $id';
  }

  @override
  String mktWtCom(String id) {
    return 'கமிஷன் · $id';
  }

  @override
  String get mktWtTop => 'UPI டாப்-அப்';

  @override
  String get mktWtWd => 'வங்கிக்கு எடுப்பு';

  @override
  String get mktTierF => 'உங்கள் மதிப்பெண் எப்படி';

  @override
  String get mktTierBands => 'கோல்ட் 80+ · சில்வர் 60–79 · பிரான்ஸ் <60';

  @override
  String get mktTierGold => 'கோல்ட்';

  @override
  String get mktTierSilver => 'சில்வர்';

  @override
  String get mktTierBronze => 'பிரான்ஸ்';

  @override
  String mktTierScore(String s) {
    return 'மதிப்பெண் $s / 100';
  }

  @override
  String get mktOtpAsk =>
      'வாடிக்கையாளரிடம் 4 இலக்க டெலிவரி குறியீட்டைக் கேளுங்கள்.';

  @override
  String get mktReqSent =>
      'கோரிக்கை அனுப்பப்பட்டது. Nagarva பணத்தை உறுதி செய்த பின் கணக்கில் வரும்.';

  @override
  String get mktPending => 'நிலுவையில்';

  @override
  String get mktHomeCity => 'சொந்த நகரம்';

  @override
  String get mktExtraCities => 'மற்ற நகரங்கள், காற்புள்ளியால் பிரிக்கவும்';

  @override
  String get mktNotJoined =>
      'Nagarva வேலைகளைப் பெற உங்கள் சொந்த நகரத்தை அமைக்கவும்.';

  @override
  String get mktFactorNote =>
      'Nagarva உங்கள் மதிப்பெண்ணை இவற்றிலிருந்து, இந்த எடைகளுடன் கணக்கிடுகிறது.';

  @override
  String get mktFRating => 'வாடிக்கையாளர் மதிப்பீடு';

  @override
  String get mktFOnTime => 'நேரத்துக்கு வருகை';

  @override
  String get mktFDamage => 'சேத கோரிக்கைகள்';

  @override
  String get mktFAccept => 'ஏற்பு விகிதம்';

  @override
  String get mktFPhotos => 'புகைப்பட இணக்கம்';

  @override
  String get mktFCancel => 'வெண்டர் ரத்துகள்';

  @override
  String get mktFJobs => 'முடித்த வேலைகள்';

  @override
  String get mktAvOnT => 'வேலை அறிவிப்புகள் மீண்டும் வரும்';

  @override
  String get mktAvOffT => 'வேலை அறிவிப்புகள் நிறுத்தப்பட்டன';
}
