// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Kannada (`kn`).
class AppLocalizationsKn extends AppLocalizations {
  AppLocalizationsKn([String locale = 'kn']) : super(locale);

  @override
  String get arunPackersAndCouriers => 'Arun Packers And Couriers';

  @override
  String get movingYouTowardsYourFuture =>
      'ನಿಮ್ಮನ್ನು ನಿಮ್ಮ ಭವಿಷ್ಯದತ್ತ ಸಾಗಿಸುತ್ತಿದ್ದೇವೆ';

  @override
  String get nameOrPhone => 'ಹೆಸರು ಅಥವಾ ಫೋನ್';

  @override
  String get enterYourNameOrPhone => 'ನಿಮ್ಮ ಹೆಸರು ಅಥವಾ ಫೋನ್ ನಮೂದಿಸಿ';

  @override
  String get pin => 'PIN';

  @override
  String get n4DigitPin => '4 ಅಂಕಿಯ PIN';

  @override
  String get login => 'ಲಾಗಿನ್';

  @override
  String get securedEncrypted => 'ಸುರಕ್ಷಿತ ಮತ್ತು ಎನ್‌ಕ್ರಿಪ್ಟ್ ಮಾಡಲಾಗಿದೆ';

  @override
  String get dashboard => 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್';

  @override
  String get thisMonth => 'ಈ ತಿಂಗಳು';

  @override
  String get revenue => 'ಆದಾಯ';

  @override
  String get labour => 'ಕಾರ್ಮಿಕರು';

  @override
  String get expenses => 'ಖರ್ಚುಗಳು';

  @override
  String get porter => 'ಪೋರ್ಟರ್';

  @override
  String get netProfit => 'ನಿವ್ವಳ ಲಾಭ';

  @override
  String get activeLeads => 'ಸಕ್ರಿಯ ಲೀಡ್‌ಗಳು';

  @override
  String get ordersMonth => 'ಆರ್ಡರ್‌ಗಳು/ತಿಂಗಳು';

  @override
  String get outstanding => 'ಬಾಕಿ';

  @override
  String get reminders => 'ಜ್ಞಾಪನೆಗಳು';

  @override
  String get monthlyTarget => 'ಮಾಸಿಕ ಗುರಿ';

  @override
  String get edit => 'ಬದಲಿಸಿ';

  @override
  String get targetThisMonth => 'ಈ ತಿಂಗಳ ಗುರಿ';

  @override
  String get eG200000 => 'e.g. 200000';

  @override
  String get save => 'ಉಳಿಸಿ';

  @override
  String get upcomingOrders => 'ಮುಂಬರುವ ಆರ್ಡರ್‌ಗಳು';

  @override
  String get calendar => 'ಕ್ಯಾಲೆಂಡರ್ ->';

  @override
  String get hotLeads => 'ಹಾಟ್ ಲೀಡ್‌ಗಳು';

  @override
  String get viewAll => 'ಎಲ್ಲಾ ನೋಡಿ ->';

  @override
  String get branchPerformance => 'ಶಾಖೆ ಕಾರ್ಯಕ್ಷಮತೆ';

  @override
  String get orders => 'ಆರ್ಡರ್‌ಗಳು';

  @override
  String get leads => 'ಲೀಡ್‌ಗಳು';

  @override
  String get operations => 'ಕಾರ್ಯಾಚರಣೆಗಳು';

  @override
  String get payments => 'ಪಾವತಿಗಳು';

  @override
  String get homePageExpenses => 'ಖರ್ಚುಗಳು';

  @override
  String get salary => 'ಸಂಬಳ';

  @override
  String get settings => 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು';

  @override
  String get logout => 'ಲಾಗ್ ಔಟ್';

  @override
  String get all => 'ಎಲ್ಲಾ';

  @override
  String get pending => 'ಬಾಕಿ';

  @override
  String get completed => 'ಪೂರ್ಣ';

  @override
  String get cancelled => 'ರದ್ದು';

  @override
  String get confirmed => 'ಖಚಿತ';

  @override
  String get transit => 'ಸಾಗಣೆ';

  @override
  String get done => 'ಮುಗಿದಿದೆ';

  @override
  String get ord001 => 'ORD-001';

  @override
  String get rajeshKumar => 'Rajesh Kumar';

  @override
  String get chennaiBangalore => 'Chennai → Bangalore';

  @override
  String get n12500 => '₹12,500';

  @override
  String get ord002 => 'ORD-002';

  @override
  String get priyaSharma => 'Priya Sharma';

  @override
  String get mumbaiPune => 'Mumbai → Pune';

  @override
  String get n8000 => '₹8,000';

  @override
  String get ord003 => 'ORD-003';

  @override
  String get inTransit => 'ಪ್ರಯಾಣದಲ್ಲಿ';

  @override
  String get anandVerma => 'Anand Verma';

  @override
  String get delhiNoida => 'Delhi → Noida';

  @override
  String get n5500 => '₹5,500';

  @override
  String get ord004 => 'ORD-004';

  @override
  String get sunitaDevi => 'Sunita Devi';

  @override
  String get hyderabadChennai => 'Hyderabad → Chennai';

  @override
  String get n9200 => '₹9,200';

  @override
  String get leadsCrm => 'ಲೀಡ್‌ಗಳು / CRM';

  @override
  String get n8 => '8';

  @override
  String get statusNew => 'ಹೊಸ';

  @override
  String get n5 => '5';

  @override
  String get contacted => 'ಸಂಪರ್ಕಿಸಲಾಗಿದೆ';

  @override
  String get n3 => '3';

  @override
  String get qualified => 'ಅರ್ಹ';

  @override
  String get n2 => '2';

  @override
  String get won => 'ಗೆದ್ದವು';

  @override
  String get lost => 'ಕಳೆದವು';

  @override
  String get raviMenon => 'Ravi Menon';

  @override
  String get n919840012345 => '+91 98400 12345';

  @override
  String get chennaiTn => 'Chennai, TN';

  @override
  String get newLead => 'ಹೊಸ ಲೀಡ್';

  @override
  String get deepaNair => 'Deepa Nair';

  @override
  String get n919447067890 => '+91 94470 67890';

  @override
  String get coimbatoreTn => 'Coimbatore, TN';

  @override
  String get karthikS => 'Karthik S.';

  @override
  String get n919940054321 => '+91 99400 54321';

  @override
  String get maduraiTn => 'Madurai, TN';

  @override
  String get meenaRaj => 'Meena Raj';

  @override
  String get n919380011223 => '+91 93800 11223';

  @override
  String get trichyTn => 'Trichy, TN';

  @override
  String get todaySJobs => 'ಇಂದಿನ ಕೆಲಸಗಳು';

  @override
  String get n3Active => '3 ಸಕ್ರಿಯ';

  @override
  String get tn01Ab1234 => 'TN-01-AB-1234';

  @override
  String get loading => 'ಲೋಡಿಂಗ್';

  @override
  String get sureshDriver => 'Suresh (Driver)';

  @override
  String get chennaiVellore => 'Chennai → Vellore';

  @override
  String get tn02Cd5678 => 'TN-02-CD-5678';

  @override
  String get muruganDriver => 'Murugan (Driver)';

  @override
  String get salemErode => 'Salem → Erode';

  @override
  String get tn03Ef9012 => 'TN-03-EF-9012';

  @override
  String get unloading => 'ಅನ್‌ಲೋಡಿಂಗ್';

  @override
  String get baluDriver => 'Balu (Driver)';

  @override
  String get coimbatoreOoty => 'Coimbatore → Ooty';

  @override
  String get upcoming => 'ಮುಂಬರುವ';

  @override
  String get tn04Gh3456 => 'TN-04-GH-3456';

  @override
  String get scheduled => 'ನಿಗದಿಯಾಗಿದೆ';

  @override
  String get senthilDriver => 'Senthil (Driver)';

  @override
  String get maduraiTirunelveli => 'Madurai → Tirunelveli';

  @override
  String get vehicleTripLog => 'ವಾಹನ ಪ್ರವಾಸ ದಾಖಲೆ';

  @override
  String get logNewTrip => 'ಹೊಸ ಪ್ರವಾಸ ದಾಖಲಿಸಿ';

  @override
  String get paymentsPageOutstanding => 'ಬಾಕಿ';

  @override
  String get n42800 => '₹42,800';

  @override
  String get receivedMonth => 'ಸ್ವೀಕರಿಸಿದ್ದು (ತಿಂಗಳು)';

  @override
  String get n124000 => '₹1,24,000';

  @override
  String get pendingPaymentsLive => 'ಬಾಕಿ ಪಾವತಿಗಳು (ಲೈವ್)';

  @override
  String get pendingInvoices => 'ಬಾಕಿ ಇನ್‌ವಾಯ್ಸ್‌ಗಳು';

  @override
  String get inv045 => 'INV-045';

  @override
  String get due15May => 'ಬಾಕಿ ದಿನ: ಮೇ 15';

  @override
  String get inv046 => 'INV-046';

  @override
  String get due18May => 'ಬಾಕಿ ದಿನ: ಮೇ 18';

  @override
  String get inv047 => 'INV-047';

  @override
  String get overdue => 'ಅವಧಿ ಮೀರಿದೆ';

  @override
  String get inv048 => 'INV-048';

  @override
  String get due22May => 'ಬಾಕಿ ದಿನ: ಮೇ 22';

  @override
  String get n16800 => '₹16,800';

  @override
  String get may2025Total => 'ಮೇ 2025 ಒಟ್ಟು';

  @override
  String get n68450 => '₹68,450';

  @override
  String get n12VsLastMonth => '↑ ಕಳೆದ ತಿಂಗಳಿಗಿಂತ 12%';

  @override
  String get liveExpenses => 'ಲೈವ್ ಖರ್ಚುಗಳು';

  @override
  String get byCategory => 'ವರ್ಗದ ಪ್ರಕಾರ';

  @override
  String get fuel => 'ಇಂಧನ';

  @override
  String get n41 => '41%';

  @override
  String get n28000 => '₹28,000';

  @override
  String get tollsPermits => 'ಟೋಲ್ ಮತ್ತು ಪರವಾನಗಿಗಳು';

  @override
  String get n18 => '18%';

  @override
  String get maintenance => 'ದುರಸ್ತಿಯಲ್ಲಿ';

  @override
  String get n26 => '26%';

  @override
  String get n18000 => '₹18,000';

  @override
  String get expensePageLabour => 'ಕಾರ್ಮಿಕರು';

  @override
  String get n15 => '15%';

  @override
  String get n9950 => '₹9,950';

  @override
  String get addExpense => 'ಖರ್ಚು ಸೇರಿಸಿ';

  @override
  String get may2025 => 'ಮೇ 2025';

  @override
  String get totalPayroll => 'ಒಟ್ಟು ವೇತನ';

  @override
  String get n182000 => '₹1,82,000';

  @override
  String get liveStaffData => 'ಲೈವ್ ಸಿಬ್ಬಂದಿ ಡೇಟಾ';

  @override
  String get todaySAttendance => 'ಇಂದಿನ ಹಾಜರಾತಿ';

  @override
  String get label => '·';

  @override
  String get pendingAdvances => 'ಬಾಕಿ ಮುಂಗಡಗಳು';

  @override
  String get bal => 'ಬಾಕಿ:';

  @override
  String get staff => 'ಸಿಬ್ಬಂದಿ';

  @override
  String get sureshKumar => 'Suresh Kumar';

  @override
  String get driver => 'ಚಾಲಕ';

  @override
  String get n22000 => '₹22,000';

  @override
  String get paid => 'ಪಾವತಿಸಿದೆ';

  @override
  String get muruganP => 'Murugan P.';

  @override
  String get n20000 => '₹20,000';

  @override
  String get baluS => 'Balu S.';

  @override
  String get helper => 'ಸಹಾಯಕ';

  @override
  String get n14000 => '₹14,000';

  @override
  String get senthilR => 'Senthil R.';

  @override
  String get n21000 => '₹21,000';

  @override
  String get kalaM => 'Kala M.';

  @override
  String get officeStaff => 'ಕಚೇರಿ ಸಿಬ್ಬಂದಿ';

  @override
  String get fleet => 'ವಾಹನಗಳು';

  @override
  String get n4 => '4';

  @override
  String get active => 'ಸಕ್ರಿಯ';

  @override
  String get idle => 'ಖಾಲಿ';

  @override
  String get n1 => '1';

  @override
  String get service => 'ಸೇವೆ';

  @override
  String get liveFleet => 'ಲೈವ್ ವಾಹನಗಳು';

  @override
  String get miniTruck407 => 'ಮಿನಿ ಟ್ರಕ್ (407)';

  @override
  String get suresh => 'Suresh';

  @override
  String get n124560Km => '1,24,560 km';

  @override
  String get largeTruckTata => 'ದೊಡ್ಡ ಟ್ರಕ್ (ಟಾಟಾ)';

  @override
  String get murugan => 'Murugan';

  @override
  String get n98340Km => '98,340 km';

  @override
  String get inService => 'ಸರ್ವೀಸ್‌ನಲ್ಲಿ';

  @override
  String get balu => 'Balu';

  @override
  String get n212000Km => '2,12,000 km';

  @override
  String get largeTruckEicher => 'ದೊಡ್ಡ ಟ್ರಕ್ (ಐಷರ್)';

  @override
  String get senthil => 'Senthil';

  @override
  String get n67890Km => '67,890 km';

  @override
  String get newQuotation => 'ಹೊಸ ಕೊಟೇಶನ್';

  @override
  String get customerDetails => 'ಗ್ರಾಹಕರ ವಿವರಗಳು';

  @override
  String get customerName => 'ಗ್ರಾಹಕರ ಹೆಸರು';

  @override
  String get enterFullName => 'ಪೂರ್ಣ ಹೆಸರು ನಮೂದಿಸಿ';

  @override
  String get phoneNumber => 'ಫೋನ್ ಸಂಖ್ಯೆ';

  @override
  String get n91XxxxxXxxxx => '+91 XXXXX XXXXX';

  @override
  String get moveDetails => 'ಸ್ಥಳಾಂತರ ವಿವರಗಳು';

  @override
  String get fromAddress => 'ಎಲ್ಲಿಂದ (ವಿಳಾಸ)';

  @override
  String get pickupLocation => 'ಪಿಕಪ್ ಸ್ಥಳ';

  @override
  String get toAddress => 'ಎಲ್ಲಿಗೆ (ವಿಳಾಸ)';

  @override
  String get dropLocation => 'ಡ್ರಾಪ್ ಸ್ಥಳ';

  @override
  String get moveDate => 'ಸ್ಥಳಾಂತರ ದಿನಾಂಕ';

  @override
  String get ddMmYyyy => 'DD/MM/YYYY';

  @override
  String get floorAccess => 'ಮಹಡಿ / ಪ್ರವೇಶ';

  @override
  String get eG2ndFloorLiftAvailable => 'ಉದಾ., 2ನೇ ಮಹಡಿ, ಲಿಫ್ಟ್ ಇದೆ';

  @override
  String get estimate => 'ಅಂದಾಜು';

  @override
  String get quotedAmount => 'ಉಲ್ಲೇಖಿಸಿದ ಮೊತ್ತ (₹)';

  @override
  String get n000 => '0.00';

  @override
  String get notes => 'ಟಿಪ್ಪಣಿಗಳು';

  @override
  String get additionalDetails => 'ಹೆಚ್ಚುವರಿ ವಿವರಗಳು';

  @override
  String get generateQuotation => 'ಕೊಟೇಶನ್ ರಚಿಸಿ';

  @override
  String get accounts => 'ಖಾತೆಗಳು';

  @override
  String get sbiCurrentAC => 'SBI — ಚಾಲ್ತಿ ಖಾತೆ';

  @override
  String get xxxx4521 => 'XXXX 4521';

  @override
  String get n284500 => '₹2,84,500';

  @override
  String get hdfcSavingsAC => 'HDFC — ಉಳಿತಾಯ ಖಾತೆ';

  @override
  String get xxxx7832 => 'XXXX 7832';

  @override
  String get n112300 => '₹1,12,300';

  @override
  String get cashOnHand => 'ಕೈಯಲ್ಲಿರುವ ನಗದು';

  @override
  String get totalBalance => 'ಒಟ್ಟು ಬಾಕಿ';

  @override
  String get n414800 => '₹4,14,800';

  @override
  String get recentTransactions => 'ಇತ್ತೀಚಿನ ವಹಿವಾಟುಗಳು';

  @override
  String get receivedOrd001 => 'ಸ್ವೀಕರಿಸಲಾಗಿದೆ — ORD-001';

  @override
  String get accountsPageN12500 => '+₹12,500';

  @override
  String get may5 => 'ಮೇ 5';

  @override
  String get fuelTn01Ab1234 => 'ಇಂಧನ — TN-01-AB-1234';

  @override
  String get petrolBunk => 'ಪೆಟ್ರೋಲ್ ಬಂಕ್';

  @override
  String get n3200 => '-₹3,200';

  @override
  String get receivedOrd002 => 'ಸ್ವೀಕರಿಸಲಾಗಿದೆ — ORD-002';

  @override
  String get accountsPageN8000 => '+₹8,000';

  @override
  String get may4 => 'ಮೇ 4';

  @override
  String get tollChennaiNh => 'ಟೋಲ್ — ಚೆನ್ನೈ NH';

  @override
  String get nhai => 'NHAI';

  @override
  String get n480 => '-₹480';

  @override
  String get pLReport => 'ಪ್ಲಾನ್ & ಬಿಲ್ಲಿಂಗ್';

  @override
  String get periodMay2025 => 'ಅವಧಿ: ಮೇ 2025';

  @override
  String get n192000 => '₹1,92,000';

  @override
  String get pLReportPageRevenue => 'ಆದಾಯ';

  @override
  String get n123550 => '₹1,23,550';

  @override
  String get pLReportPageNetProfit => 'ನಿವ್ವಳ ಲಾಭ';

  @override
  String get n643 => '64.3%';

  @override
  String get margin => 'ಲಾಭ';

  @override
  String get topExpenses => 'ಪ್ರಮುಖ ಖರ್ಚುಗಳು';

  @override
  String get arunPackersStaff => 'Arun Packers Staff';

  @override
  String get adminArunpackersIn => 'admin@arunpackers.in';

  @override
  String get company => 'ಕಂಪನಿ';

  @override
  String get businessName => 'ವ್ಯಾಪಾರದ ಹೆಸರು';

  @override
  String get settingsPageArunPackersAndCouriers => 'Arun Packers and Couriers';

  @override
  String get phone => 'ಫೋನ್';

  @override
  String get n9144XxxxXxxx => '+91 44 XXXX XXXX';

  @override
  String get gstNumber => 'GST ಸಂಖ್ಯೆ';

  @override
  String get xxxxxxxxxxxx => 'XXXXXXXXXXXX';

  @override
  String get app => 'ಆಪ್';

  @override
  String get notifications => 'ಅಧಿಸೂಚನೆಗಳು';

  @override
  String get enabled => 'ಚಾಲನೆಯಲ್ಲಿದೆ';

  @override
  String get darkMode => 'ಡಾರ್ಕ್ ಮೋಡ್';

  @override
  String get on => 'ಆನ್';

  @override
  String get language => 'ಭಾಷೆ';

  @override
  String get english => 'ಇಂಗ್ಲಿಷ್';

  @override
  String get data => 'ಡೇಟಾ';

  @override
  String get exportData => 'ಡೇಟಾ ರಫ್ತು ಮಾಡಿ';

  @override
  String get csvPdf => 'CSV / PDF';

  @override
  String get backup => 'ಬ್ಯಾಕಪ್';

  @override
  String get autoDaily => 'ಸ್ವಯಂ (ಪ್ರತಿದಿನ)';

  @override
  String get appTheme => 'ಆ್ಯಪ್ ಥೀಮ್';

  @override
  String get chooseYourPreferredColourScheme =>
      'ನಿಮಗೆ ಇಷ್ಟವಾದ ಬಣ್ಣದ ಯೋಜನೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ.';

  @override
  String get dark => 'ಡಾರ್ಕ್';

  @override
  String get midnight => 'ಮಿಡ್‌ನೈಟ್';

  @override
  String get light => 'ಲೈಟ್';

  @override
  String get calendarPageCalendar => 'ಕ್ಯಾಲೆಂಡರ್';

  @override
  String get mon => 'ಸೋಮ';

  @override
  String get tue => 'ಮಂಗಳ';

  @override
  String get wed => 'ಬುಧ';

  @override
  String get thu => 'ಗುರು';

  @override
  String get fri => 'ಶುಕ್ರ';

  @override
  String get sat => 'ಶನಿ';

  @override
  String get sun => 'ಭಾನು';

  @override
  String get n6 => '6';

  @override
  String get n7 => '7';

  @override
  String get n9 => '9';

  @override
  String get n10 => '10';

  @override
  String get n11 => '11';

  @override
  String get n12 => '12';

  @override
  String get n13 => '13';

  @override
  String get n14 => '14';

  @override
  String get calendarPageN15 => '15';

  @override
  String get n17 => '17';

  @override
  String get calendarPageN18 => '18';

  @override
  String get n20 => '20';

  @override
  String get n21 => '21';

  @override
  String get n22 => '22';

  @override
  String get n23 => '23';

  @override
  String get n24 => '24';

  @override
  String get n25 => '25';

  @override
  String get calendarPageN26 => '26';

  @override
  String get n27 => '27';

  @override
  String get n28 => '28';

  @override
  String get n29 => '29';

  @override
  String get n30 => '30';

  @override
  String get n31 => '31';

  @override
  String get remindersFollowUps => 'ಜ್ಞಾಪನೆಗಳು ಮತ್ತು ಫಾಲೋ-ಅಪ್';

  @override
  String get followUpRaviMenon => 'ಫಾಲೋ-ಅಪ್: Ravi Menon';

  @override
  String get callRegardingBangaloreMoveQuote =>
      'ಬೆಂಗಳೂರು ಸ್ಥಳಾಂತರ ಕೊಟೇಶನ್ ಬಗ್ಗೆ ಕರೆ';

  @override
  String get may7 => 'ಮೇ 7';

  @override
  String get collectionOrd047 => 'ವಸೂಲಿ: ORD-047';

  @override
  String get overduePaymentFromAnandVerma =>
      'Anand Verma ಅವರಿಂದ ಅವಧಿ ಮೀರಿದ ಪಾವತಿ';

  @override
  String get may8 => 'ಮೇ 8';

  @override
  String get jobTn01Ab1234 => 'ಕೆಲಸ: TN-01-AB-1234';

  @override
  String get chennaiVelloreScheduledDelivery =>
      'ಚೆನ್ನೈ → ವೆಲ್ಲೂರು ನಿಗದಿತ ಡೆಲಿವರಿ';

  @override
  String get may9 => 'ಮೇ 9';

  @override
  String get reviewMayExpenses => 'ಪರಿಶೀಲನೆ: ಮೇ ಖರ್ಚುಗಳು';

  @override
  String get monthlyExpenseReviewWithTeam => 'ತಂಡದೊಂದಿಗೆ ಮಾಸಿಕ ಖರ್ಚು ಪರಿಶೀಲನೆ';

  @override
  String get may12 => 'ಮೇ 12';

  @override
  String get activeRemindersLive => 'ಸಕ್ರಿಯ ಜ್ಞಾಪನೆಗಳು (ಲೈವ್)';

  @override
  String get addReminder => 'ಜ್ಞಾಪನೆ ಸೇರಿಸಿ';

  @override
  String get materials => 'ಸಾಮಗ್ರಿಗಳು';

  @override
  String get totalSkus => 'ಒಟ್ಟು SKUಗಳು';

  @override
  String get lowStock => 'ಕಡಿಮೆ ಸ್ಟಾಕ್';

  @override
  String get inventory => 'ದಾಸ್ತಾನು';

  @override
  String get cardboardBoxSmall => 'ಕಾರ್ಡ್‌ಬೋರ್ಡ್ ಬಾಕ್ಸ್ — ಚಿಕ್ಕದು';

  @override
  String get reorder20 => '20ಕ್ಕಿಂತ ಕಡಿಮೆಯಾದರೆ ಮರು ಆರ್ಡರ್';

  @override
  String get n42Pcs => '42 pcs';

  @override
  String get cardboardBoxMedium => 'ಕಾರ್ಡ್‌ಬೋರ್ಡ್ ಬಾಕ್ಸ್ — ಮಧ್ಯಮ';

  @override
  String get n28Pcs => '28 pcs';

  @override
  String get cardboardBoxLarge => 'ಕಾರ್ಡ್‌ಬೋರ್ಡ್ ಬಾಕ್ಸ್ — ದೊಡ್ಡದು';

  @override
  String get reorder15 => '15ಕ್ಕಿಂತ ಕಡಿಮೆಯಾದರೆ ಮರು ಆರ್ಡರ್';

  @override
  String get n11Pcs => '11 pcs';

  @override
  String get bubbleWrapRoll50m => 'ಬಬಲ್ ರ‍್ಯಾಪ್ ರೋಲ್ (50ಮೀ)';

  @override
  String get reorder5 => '5ಕ್ಕಿಂತ ಕಡಿಮೆಯಾದರೆ ಮರು ಆರ್ಡರ್';

  @override
  String get n4Rolls => '4 rolls';

  @override
  String get stretchWrapRoll => 'ಸ್ಟ್ರೆಚ್ ರ‍್ಯಾಪ್ ರೋಲ್';

  @override
  String get ok => 'ಸರಿ';

  @override
  String get n18Rolls => '18 rolls';

  @override
  String get packingTapeBrown => 'ಪ್ಯಾಕಿಂಗ್ ಟೇಪ್ (ಕಂದು)';

  @override
  String get reorder10 => '10ಕ್ಕಿಂತ ಕಡಿಮೆಯಾದರೆ ಮರು ಆರ್ಡರ್';

  @override
  String get n7Pcs => '7 pcs';

  @override
  String get furnitureCoverLarge => 'ಪೀಠೋಪಕರಣ ಕವರ್ (ದೊಡ್ಡದು)';

  @override
  String get n24Pcs => '24 pcs';

  @override
  String get rope50m => 'ಹಗ್ಗ (50ಮೀ)';

  @override
  String get n8Rolls => '8 rolls';

  @override
  String get cornerGuards => 'ಮೂಲೆ ರಕ್ಷಕಗಳು';

  @override
  String get n60Pcs => '60 pcs';

  @override
  String get addRestockItem => 'ವಸ್ತು ಸೇರಿಸಿ / ಸ್ಟಾಕ್ ತುಂಬಿಸಿ';

  @override
  String get reports => 'ವರದಿಗಳು';

  @override
  String get generateReports => 'ವರದಿಗಳನ್ನು ರಚಿಸಿ';

  @override
  String get monthlySummary => 'ಮಾಸಿಕ ಸಾರಾಂಶ';

  @override
  String get revenueExpensesProfitOverview => 'ಆದಾಯ, ಖರ್ಚು ಮತ್ತು ಲಾಭದ ಸಾರಾಂಶ';

  @override
  String get customerReport => 'ಗ್ರಾಹಕ ವರದಿ';

  @override
  String get topCustomersByRevenue => 'ಆದಾಯದ ಪ್ರಕಾರ ಪ್ರಮುಖ ಗ್ರಾಹಕರು';

  @override
  String get driverPerformance => 'ಚಾಲಕರ ಕಾರ್ಯಕ್ಷಮತೆ';

  @override
  String get jobsCompletedPerDriver => 'ಪ್ರತಿ ಚಾಲಕ ಮುಗಿಸಿದ ಕೆಲಸಗಳು';

  @override
  String get expenseBreakdown => 'ಖರ್ಚಿನ ವಿಂಗಡಣೆ';

  @override
  String get categoryWiseExpenseAnalysis => 'ವರ್ಗವಾರು ಖರ್ಚು ವಿಶ್ಲೇಷಣೆ';

  @override
  String get revenueTrend => 'ಆದಾಯದ ಪ್ರವೃತ್ತಿ';

  @override
  String get monthOnMonthRevenueChart => 'ತಿಂಗಳಿನಿಂದ ತಿಂಗಳ ಆದಾಯ ಚಾರ್ಟ್';

  @override
  String get outstandingReport => 'ಬಾಕಿ ವರದಿ';

  @override
  String get pendingPaymentsAgeing => 'ಬಾಕಿ ಪಾವತಿಗಳು ಮತ್ತು ಅವಧಿ';

  @override
  String get vehicleUtilisation => 'ವಾಹನ ಬಳಕೆ';

  @override
  String get fleetUsageAndIdleTimeAnalysis =>
      'ವಾಹನ ಬಳಕೆ ಮತ್ತು ಖಾಲಿ ಸಮಯದ ವಿಶ್ಲೇಷಣೆ';

  @override
  String get exportOptions => 'ರಫ್ತು ಆಯ್ಕೆಗಳು';

  @override
  String get exportPdf => 'PDF ರಫ್ತು';

  @override
  String get exportCsv => 'CSV ರಫ್ತು';

  @override
  String get users => 'ಬಳಕೆದಾರರು';

  @override
  String get addNewUser => 'ಹೊಸ ಬಳಕೆದಾರ ಸೇರಿಸಿ';

  @override
  String get admin => 'ನಿರ್ವಾಹಕ';

  @override
  String get activeUsers => 'ಸಕ್ರಿಯ ಬಳಕೆದಾರರು';

  @override
  String get arunKumar => 'Arun Kumar';

  @override
  String get n919840000001 => '+91 98400 00001';

  @override
  String get today => 'ಇಂದು';

  @override
  String get sureshM => 'Suresh M.';

  @override
  String get n919840000002 => '+91 98400 00002';

  @override
  String get n919840000003 => '+91 98400 00003';

  @override
  String get yesterday => 'ನಿನ್ನೆ';

  @override
  String get kalaR => 'Kala R.';

  @override
  String get n919840000004 => '+91 98400 00004';

  @override
  String get n919840000005 => '+91 98400 00005';

  @override
  String get n2DaysAgo => '2 ದಿನಗಳ ಹಿಂದೆ';

  @override
  String get inactiveUsers => 'ನಿಷ್ಕ್ರಿಯ ಬಳಕೆದಾರರು';

  @override
  String get n919840000006 => '+91 98400 00006';

  @override
  String get inactive => 'ನಿಷ್ಕ್ರಿಯ';

  @override
  String get n5DaysAgo => '5 ದಿನಗಳ ಹಿಂದೆ';

  @override
  String get recordPayment => 'ಪಾವತಿ ದಾಖಲಿಸಿ';

  @override
  String get selectOrder => 'ಆರ್ಡರ್ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get loadingPendingOrders => 'ಬಾಕಿ ಆರ್ಡರ್‌ಗಳನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುತ್ತಿದೆ...';

  @override
  String get select => 'ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get paymentEntry => 'ಪಾವತಿ ದಾಖಲೆ';

  @override
  String get customer => 'ಗ್ರಾಹಕ:';

  @override
  String get totalAmount => 'ಒಟ್ಟು ಮೊತ್ತ:';

  @override
  String get alreadyPaid => 'ಈಗಾಗಲೇ ಪಾವತಿಸಿದ್ದು:';

  @override
  String get amountReceived => 'ಸ್ವೀಕರಿಸಿದ ಮೊತ್ತ (₹)';

  @override
  String get selectStatus => 'ಸ್ಥಿತಿ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get paymentStatus => 'ಪಾವತಿ ಸ್ಥಿತಿ';

  @override
  String get partial => 'ಭಾಗಶಃ';

  @override
  String get recordPaymentPagePaid => 'ಪಾವತಿಸಿದೆ';

  @override
  String get savePayment => 'ಉಳಿಸಿ';

  @override
  String get quickExpense => 'ತ್ವರಿತ ಖರ್ಚು';

  @override
  String get expenseDetails => 'ಖರ್ಚಿನ ವಿವರಗಳು';

  @override
  String get amount => 'ಮೊತ್ತ (₹)';

  @override
  String get selectCategory => 'ವರ್ಗ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get category => 'ವರ್ಗ';

  @override
  String get vehicleMaintenance => 'ವಾಹನ ದುರಸ್ತಿ';

  @override
  String get office => 'ಕಚೇರಿ';

  @override
  String get material => 'ಸಾಮಗ್ರಿ';

  @override
  String get other => 'ಇತರೆ';

  @override
  String get date => 'ದಿನಾಂಕ';

  @override
  String get yyyyMmDd => 'YYYY-MM-DD';

  @override
  String get linkedOrderIdOptional => 'ಸಂಪರ್ಕಿತ ಆರ್ಡರ್ ID (ಐಚ್ಛಿಕ)';

  @override
  String get leaveBlankIfNotLinked => 'ಸಂಪರ್ಕವಿಲ್ಲದಿದ್ದರೆ ಖಾಲಿ ಬಿಡಿ';

  @override
  String get description => 'ವಿವರ';

  @override
  String get briefDescription => 'ಸಂಕ್ಷಿಪ್ತ ವಿವರಣೆ';

  @override
  String get saveExpense => 'ಖರ್ಚು ಉಳಿಸಿ';

  @override
  String get newOrder => 'ಹೊಸ ಆರ್ಡರ್';

  @override
  String get newOrderPageCustomer => 'ಗ್ರಾಹಕ';

  @override
  String get newOrderPageCustomerName => 'ಗ್ರಾಹಕರ ಹೆಸರು *';

  @override
  String get fullName => 'ಪೂರ್ಣ ಹೆಸರು';

  @override
  String get newOrderPagePhone => 'ಫೋನ್ *';

  @override
  String get fromCity => 'ಎಲ್ಲಿಂದ (ನಗರ) *';

  @override
  String get originCity => 'ಆರಂಭದ ನಗರ';

  @override
  String get toCity => 'ಎಲ್ಲಿಗೆ (ನಗರ) *';

  @override
  String get destinationCity => 'ತಲುಪುವ ನಗರ';

  @override
  String get pickupAddress => 'ಪಿಕಪ್ ವಿಳಾಸ';

  @override
  String get dropAddress => 'ಡ್ರಾಪ್ ವಿಳಾಸ';

  @override
  String get fromFloor => 'ಎಲ್ಲಿಂದ (ಮಹಡಿ)';

  @override
  String get eG2ndFloor => 'ಉದಾ., 2ನೇ ಮಹಡಿ';

  @override
  String get toFloor => 'ಎಲ್ಲಿಗೆ (ಮಹಡಿ)';

  @override
  String get eGGroundFloor => 'ಉದಾ., ನೆಲಮಹಡಿ';

  @override
  String get newOrderPageMoveDate => 'ಸ್ಥಳಾಂತರ ದಿನಾಂಕ *';

  @override
  String get tapToPickDate => 'ದಿನಾಂಕ ಆಯ್ಕೆಗೆ ಟ್ಯಾಪ್ ಮಾಡಿ';

  @override
  String get pickDate => 'ದಿನಾಂಕ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get pricingClassification => 'ಬೆಲೆ ಮತ್ತು ವರ್ಗೀಕರಣ';

  @override
  String get newOrderPageAmount => 'ಮೊತ್ತ (₹) *';

  @override
  String get selectService => 'ಸೇವೆ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get newOrderPageService => 'ಸೇವೆ *';

  @override
  String get houseShifting => 'ಮನೆ ಸ್ಥಳಾಂತರ';

  @override
  String get officeShifting => 'ಕಚೇರಿ ಸ್ಥಳಾಂತರ';

  @override
  String get vehicleTransport => 'ವಾಹನ ಸಾಗಣೆ';

  @override
  String get storage => 'ಸಂಗ್ರಹ';

  @override
  String get packingOnly => 'ಪ್ಯಾಕಿಂಗ್ ಮಾತ್ರ';

  @override
  String get longDistance => 'ದೂರದ ಪ್ರಯಾಣ';

  @override
  String get selectBranch => 'ಶಾಖೆ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get branch => 'ಶಾಖೆ *';

  @override
  String get chennai => 'Chennai';

  @override
  String get bengaluru => 'Bengaluru';

  @override
  String get coimbatore => 'Coimbatore';

  @override
  String get selectType => 'ಪ್ರಕಾರ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get orderType => 'ಆರ್ಡರ್ ಪ್ರಕಾರ *';

  @override
  String get direct => 'ನೇರ';

  @override
  String get newOrderPagePorter => 'ಪೋರ್ಟರ್';

  @override
  String get porterCommission => 'ಪೋರ್ಟರ್ ಕಮಿಷನ್ %';

  @override
  String get saveOrder => 'ಆರ್ಡರ್ ಉಳಿಸಿ';

  @override
  String get orderDetails => 'ಆರ್ಡರ್ ವಿವರಗಳು';

  @override
  String get orderDetailPageBranch => 'ಶಾಖೆ';

  @override
  String get type => 'ಪ್ರಕಾರ';

  @override
  String get from => 'ಇಂದ';

  @override
  String get to => 'ವರೆಗೆ';

  @override
  String get addressFrom => 'ವಿಳಾಸ (ಎಲ್ಲಿಂದ)';

  @override
  String get addressTo => 'ವಿಳಾಸ (ಎಲ್ಲಿಗೆ)';

  @override
  String get floorFrom => 'ಮಹಡಿ (ಎಲ್ಲಿಂದ)';

  @override
  String get floorTo => 'ಮಹಡಿ (ಎಲ್ಲಿಗೆ)';

  @override
  String get payment => 'ಪಾವತಿ';

  @override
  String get orderDetailPageAmount => 'ಮೊತ್ತ';

  @override
  String get advancePaid => 'ಪಾವತಿಸಿದ ಮುಂಗಡ';

  @override
  String get trackingStatus => 'ಟ್ರ್ಯಾಕಿಂಗ್ ಸ್ಥಿತಿ';

  @override
  String get editOrder => 'ಆರ್ಡರ್ ತಿದ್ದಿ';

  @override
  String get contact => 'ಸಂಪರ್ಕ';

  @override
  String get email => 'ಇಮೇಲ್';

  @override
  String get emailExampleCom => 'email@example.com';

  @override
  String get newLeadPageFromCity => 'ಎಲ್ಲಿಂದ (ನಗರ)';

  @override
  String get newLeadPageToCity => 'ಎಲ್ಲಿಗೆ (ನಗರ)';

  @override
  String get approxDate => 'ಅಂದಾಜು ದಿನಾಂಕ *';

  @override
  String get classification => 'ವರ್ಗೀಕರಣ';

  @override
  String get status => 'ಸ್ಥಿತಿ *';

  @override
  String get newLeadPageNew => 'ಹೊಸ';

  @override
  String get newLeadPageContacted => 'ಸಂಪರ್ಕಿಸಲಾಗಿದೆ';

  @override
  String get surveyDone => 'ಸರ್ವೆ ಮುಗಿದಿದೆ';

  @override
  String get quoted => 'ಕೊಟೇಶನ್ ಕಳುಹಿಸಲಾಗಿದೆ';

  @override
  String get converted => 'ಬುಕ್ ಆದವು';

  @override
  String get newLeadPageLost => 'ಕಳೆದವು';

  @override
  String get howDidTheyHearAboutUs => 'ಅವರು ನಮ್ಮ ಬಗ್ಗೆ ಹೇಗೆ ತಿಳಿದರು?';

  @override
  String get source => 'ಮೂಲ *';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get phoneCall => 'ಫೋನ್ ಕರೆ';

  @override
  String get website => 'ವೆಬ್‌ಸೈಟ್';

  @override
  String get referral => 'ಶಿಫಾರಸು';

  @override
  String get walkIn => 'ವಾಕ್-ಇನ್';

  @override
  String get google => 'Google';

  @override
  String get justdial => 'JustDial';

  @override
  String get anyRelevantNotes => 'ಸಂಬಂಧಿತ ಟಿಪ್ಪಣಿಗಳು';

  @override
  String get saveLead => 'ಲೀಡ್ ಉಳಿಸಿ';

  @override
  String get leadDetails => 'ಲೀಡ್ ವಿವರಗಳು';

  @override
  String get leadDetailPageSource => 'ಮೂಲ';

  @override
  String get leadDetailPageApproxDate => 'ಅಂದಾಜು ದಿನಾಂಕ';

  @override
  String get convertToOrder => 'ಆರ್ಡರ್ ಆಗಿ ಪರಿವರ್ತಿಸಿ';

  @override
  String get editLead => 'ಲೀಡ್ ತಿದ್ದಿ';

  @override
  String get quickEntry => 'ತ್ವರಿತ ನಮೂದು';

  @override
  String get whatWouldYouLikeToDo => 'ನೀವು ಏನು ಮಾಡಲು ಬಯಸುತ್ತೀರಿ?';

  @override
  String get newInquiry => 'ಹೊಸ ವಿಚಾರಣೆ';

  @override
  String get confirmBooking => 'ಬುಕಿಂಗ್ ದೃಢೀಕರಿಸಿ';

  @override
  String get cashCollectedByPorter => 'ಪೋರ್ಟರ್ ಸಂಗ್ರಹಿಸಿದ ನಗದು (₹)';

  @override
  String get leaveBlankIfNoneCollectedYet => 'ಇನ್ನೂ ಸಂಗ್ರಹಿಸದಿದ್ದರೆ ಖಾಲಿ ಬಿಡಿ';

  @override
  String get jrTitle => 'ಆರ್ಡರ್ ಪಯಣ';

  @override
  String get jrStageLead => 'ಲೀಡ್';

  @override
  String get jrStageFollowUp => 'ಫಾಲೋ-ಅಪ್';

  @override
  String get jrStageSurvey => 'ಸರ್ವೆ';

  @override
  String get jrStageQuote => 'ಕೊಟೇಶನ್ ಮತ್ತು ದೃಢೀಕರಣ';

  @override
  String get jrStageSupervisor => 'ಸೂಪರ್‌ವೈಸರ್';

  @override
  String get jrStageMoveDay => 'ಸ್ಥಳಾಂತರ ದಿನ';

  @override
  String get jrStageInvoice => 'ಇನ್‌ವಾಯ್ಸ್';

  @override
  String get jrStagePayment => 'ಪಾವತಿ & ಸಮಸ್ಯೆಗಳು';

  @override
  String get jrStageClosed => 'ಮುಗಿದಿದೆ';

  @override
  String get jrStateDone => 'ಮುಗಿದಿದೆ';

  @override
  String get jrStateSkipped => 'ಬಿಡಲಾಗಿದೆ';

  @override
  String get jrStateCurrent => 'ಈಗ';

  @override
  String get jrStatePending => 'ನಂತರ';

  @override
  String get jrDirectOrder => 'ಬಿಡಲಾಗಿದೆ · ನೇರ ಆರ್ಡರ್';

  @override
  String get jrMoveDate => 'ಸ್ಥಳಾಂತರ ದಿನಾಂಕ';

  @override
  String get jrRoute => 'ಮಾರ್ಗ';

  @override
  String get jrOrderValue => 'ಆರ್ಡರ್ ಮೌಲ್ಯ';

  @override
  String get jrNotSet => 'ನಿಗದಿಯಾಗಿಲ್ಲ';

  @override
  String get jrDocuments => 'ದಾಖಲೆಗಳು';

  @override
  String get jrDocQuote => 'ಕೊಟೇಶನ್';

  @override
  String get jrDocInvoice => 'ತೆರಿಗೆ ಇನ್‌ವಾಯ್ಸ್';

  @override
  String get jrDocReceipts => 'ಹಣದ ರಸೀದಿಗಳು';

  @override
  String get jrDocLr => 'ಲಾರಿ ರಸೀದಿ';

  @override
  String get jrDocReady => 'ಸಿದ್ಧ · ನೋಡಲು ಒತ್ತಿ';

  @override
  String jrDocAfter(String stage) {
    return '$stage ನಂತರ';
  }

  @override
  String jrCreated(String date) {
    return 'ರಚಿಸಲಾಗಿದೆ $date';
  }

  @override
  String jrSource(String source) {
    return 'ಮೂಲ: $source';
  }

  @override
  String jrService(String service) {
    return 'ಸೇವೆ: $service';
  }

  @override
  String get jrNoCalls => 'ಇನ್ನೂ ಯಾವುದೇ ಕರೆ ದಾಖಲಾಗಿಲ್ಲ';

  @override
  String jrCallsLogged(String count) {
    return '$count ಕರೆಗಳು ದಾಖಲಾಗಿವೆ';
  }

  @override
  String get jrOutcomeQ => 'ಕರೆ ಹೇಗಿತ್ತು?';

  @override
  String get jrOutNoAnswer => 'ಸಂಪರ್ಕ ಸಿಗಲಿಲ್ಲ';

  @override
  String get jrOutCallback => 'ಮತ್ತೆ ಕರೆ';

  @override
  String get jrOutInterested => 'ಆಸಕ್ತಿ ಇದೆ';

  @override
  String get jrOutNotInterested => 'ಆಸಕ್ತಿ ಇಲ್ಲ';

  @override
  String get jrCallNotes => 'ಕರೆಯ ಟಿಪ್ಪಣಿಗಳು';

  @override
  String get jrNextFollowUp => 'ಮುಂದಿನ ಫಾಲೋ-ಅಪ್';

  @override
  String get jrToday => 'ಇಂದು';

  @override
  String get jrTomorrow => 'ನಾಳೆ';

  @override
  String get jrIn2Days => '2 ದಿನದಲ್ಲಿ';

  @override
  String get jrNextWeek => 'ಮುಂದಿನ ವಾರ';

  @override
  String get jrPickDate => 'ದಿನಾಂಕ ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get jrNoNext => 'ಇಲ್ಲ';

  @override
  String get jrLogCall => 'ಕರೆ ದಾಖಲಿಸಿ';

  @override
  String get jrCallLogged => 'ಕರೆ ದಾಖಲಾಯಿತು';

  @override
  String get jrPickOutcome => 'ಕರೆ ಹೇಗಿತ್ತು ಎಂದು ಆಯ್ಕೆಮಾಡಿ';

  @override
  String get jrSurveyWaiting =>
      'ಸರ್ವೆ ಲಿಂಕ್ ಕಳುಹಿಸಲಾಗಿದೆ · ಗ್ರಾಹಕರಿಗಾಗಿ ಕಾಯುತ್ತಿದೆ';

  @override
  String get jrSurveyDone => 'ಗ್ರಾಹಕರು ಸರ್ವೆ ಸಲ್ಲಿಸಿದ್ದಾರೆ';

  @override
  String get jrNoSurvey => 'ಇನ್ನೂ ಸರ್ವೆ ಇಲ್ಲ';

  @override
  String get jrOpenSurveyQuote => 'ಸರ್ವೆ ಮತ್ತು ಕೊಟೇಶನ್ ತೆರೆಯಿರಿ';

  @override
  String get jrNoQuote => 'ಇನ್ನೂ ಕೊಟೇಶನ್ ಇಲ್ಲ';

  @override
  String jrQuoteLine(String amount) {
    return 'ಕೊಟೇಶನ್ $amount';
  }

  @override
  String jrOrderConfirmed(String id) {
    return 'ಆರ್ಡರ್ $id ದೃಢವಾಗಿದೆ';
  }

  @override
  String get jrLeadLost => 'ಲೀಡ್ ಕಳೆದುಹೋಗಿದೆ ಎಂದು ಗುರುತಿಸಲಾಗಿದೆ';

  @override
  String get jrNoSupervisor => 'ಇನ್ನೂ ಮೇಲ್ವಿಚಾರಕರಿಲ್ಲ';

  @override
  String jrSupervisorIs(String name) {
    return 'ಮೇಲ್ವಿಚಾರಕ: $name';
  }

  @override
  String jrCrew(String count) {
    return 'ಕೆಲಸದಲ್ಲಿರುವ ತಂಡ: $count';
  }

  @override
  String get jrAssignInOrder => 'ಸೂಪರ್‌ವೈಸರ್ ನೇಮಿಸಿ';

  @override
  String get jrNotStarted => 'ಆರಂಭವಾಗಿಲ್ಲ';

  @override
  String jrMoveStarted(String time) {
    return 'ಆರಂಭ $time';
  }

  @override
  String jrMoveFinished(String time) {
    return 'ಮುಕ್ತಾಯ $time';
  }

  @override
  String get jrOpenFieldJob => 'ಫೀಲ್ಡ್ ಕೆಲಸ ತೆರೆಯಿರಿ';

  @override
  String get jrNoInvoice => 'ಇನ್‌ವಾಯ್ಸ್ ರಚಿಸಲಾಗಿಲ್ಲ';

  @override
  String jrInvoiceNo(String no) {
    return 'ಇನ್‌ವಾಯ್ಸ್ $no';
  }

  @override
  String get jrSigned => 'ಗ್ರಾಹಕರು ಸಹಿ ಮಾಡಿದ್ದಾರೆ';

  @override
  String get jrNotSigned => 'ಗ್ರಾಹಕರ ಸಹಿ ಇಲ್ಲ';

  @override
  String get jrOpenOrder => 'ಆರ್ಡರ್ ತೆರೆಯಿರಿ';

  @override
  String get jrTotal => 'ಒಟ್ಟು';

  @override
  String get jrPaid => 'ಪಾವತಿಸಿದೆ';

  @override
  String get jrBalance => 'ಬಾಕಿ';

  @override
  String get jrRecordPayment => 'ಪಾವತಿ ದಾಖಲಿಸಿ';

  @override
  String get jrTickets => 'ಟಿಕೆಟ್‌ಗಳು';

  @override
  String get jrNoTickets => 'ಯಾವುದೇ ಟಿಕೆಟ್ ಇಲ್ಲ';

  @override
  String get jrTicketHint => 'ಉದಾ., AC ಅಳವಡಿಕೆ ಬಾಕಿ';

  @override
  String get jrRaiseTicket => 'ಟಿಕೆಟ್ ಮಾಡಿ';

  @override
  String get jrResolve => 'ಪರಿಹರಿಸಿ';

  @override
  String get jrTicketRaised => 'ಟಿಕೆಟ್ ದಾಖಲಾಯಿತು';

  @override
  String get jrTicketResolved => 'ಟಿಕೆಟ್ ಪರಿಹರಿಸಲಾಗಿದೆ';

  @override
  String get jrBlockTicket => 'ಒಂದು ಟಿಕೆಟ್ ಇನ್ನೂ ತೆರೆದಿದೆ';

  @override
  String jrBlockBalance(String amount) {
    return '$amount ಬಾಕಿ ಮೊತ್ತ ಪಾವತಿಸಬೇಕಿದೆ';
  }

  @override
  String get jrCloseOrder => 'ಆರ್ಡರ್ ಮುಚ್ಚಿ';

  @override
  String jrClosedOn(String date) {
    return 'ಮುಚ್ಚಲಾಗಿದೆ $date';
  }

  @override
  String get jrNotClosed => 'ತೆರೆದ';

  @override
  String jrPaymentLine(String amount, String mode) {
    return '$amount · $mode';
  }

  @override
  String get jrCouldNotLoad => 'ಈ ಪಯಣವನ್ನು ಲೋಡ್ ಮಾಡಲಾಗಲಿಲ್ಲ';

  @override
  String get jrRetry => 'ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ';

  @override
  String jrCouldNotSave(String error) {
    return 'ಉಳಿಸಲಾಗಲಿಲ್ಲ: $error';
  }

  @override
  String get ngNavHome => 'ಮುಖಪುಟ';

  @override
  String get ngNavLeads => 'ಲೀಡ್‌ಗಳು';

  @override
  String get ngNavOrders => 'ಆರ್ಡರ್‌ಗಳು';

  @override
  String get ngNavOps => 'ಕಾರ್ಯ';

  @override
  String get ngNavPay => 'ಪಾವತಿ';

  @override
  String get ngNavMore => 'ಇನ್ನಷ್ಟು';

  @override
  String get ngMenuDashboard => 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್';

  @override
  String get ngMenuLeads => 'ಲೀಡ್‌ಗಳು / CRM';

  @override
  String get ngMenuInbox => 'ಇನ್‌ಬಾಕ್ಸ್';

  @override
  String get ngMenuSurveyQuote => 'ಸರ್ವೆ ಮತ್ತು ಕೊಟೇಶನ್';

  @override
  String get ngMenuCalendar => 'ಕ್ಯಾಲೆಂಡರ್';

  @override
  String get ngMenuOrders => 'ಆರ್ಡರ್‌ಗಳು';

  @override
  String get ngMenuOperations => 'ಕಾರ್ಯಾಚರಣೆಗಳು';

  @override
  String get ngMenuReviews => 'ವಿಮರ್ಶೆಗಳು';

  @override
  String get ngMenuPayments => 'ಪಾವತಿಗಳು';

  @override
  String get ngMenuExpenses => 'ಖರ್ಚುಗಳು';

  @override
  String get ngMenuStaff => 'ಸಿಬ್ಬಂದಿ';

  @override
  String get ngMenuTeamAttendance => 'ತಂಡದ ಹಾಜರಾತಿ';

  @override
  String get ngMenuFleet => 'ವಾಹನಗಳು';

  @override
  String get ngMenuMaterials => 'ಸಾಮಗ್ರಿಗಳು';

  @override
  String get ngMenuWarehouses => 'ಗೋದಾಮುಗಳು';

  @override
  String get ngMenuRateCards => 'ದರ ಕಾರ್ಡ್‌ಗಳು';

  @override
  String get ngMenuLrRegister => 'LR ರಿಜಿಸ್ಟರ್';

  @override
  String get ngMenuOpsLog => 'ಕಾರ್ಯ ದಾಖಲೆ';

  @override
  String get ngMenuVendors => 'ಮಾರಾಟಗಾರರು';

  @override
  String get ngMenuCustomers => 'ಗ್ರಾಹಕರು';

  @override
  String get ngMenuInsurance => 'ವಿಮೆ';

  @override
  String get ngMenuTrips => 'ಪ್ರವಾಸಗಳು';

  @override
  String get ngMenuTasks => 'ಕಾರ್ಯಗಳು';

  @override
  String get ngMenuAccounts => 'ಖಾತೆಗಳು';

  @override
  String get ngMenuPnl => 'ಲಾಭ-ನಷ್ಟ';

  @override
  String get ngMenuReports => 'ವರದಿಗಳು';

  @override
  String get ngMenuSalary => 'ವೇತನ';

  @override
  String get ngMenuSettings => 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು';

  @override
  String get ngMenuPlatformAdmin => 'ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ನಿರ್ವಾಹಕ';

  @override
  String get ngMenuMyJobs => 'ನನ್ನ ಕೆಲಸಗಳು';

  @override
  String get ngMenuMyTeam => 'ನನ್ನ ತಂಡ';

  @override
  String get ngMenuMyEarnings => 'ನನ್ನ ಗಳಿಕೆ';

  @override
  String get ngMenuMyAttendance => 'ನನ್ನ ಹಾಜರಾತಿ';

  @override
  String get ngGroupSales => 'ಮಾರಾಟ';

  @override
  String get ngGroupOperations => 'ಕಾರ್ಯಾಚರಣೆಗಳು';

  @override
  String get ngGroupMoney => 'ಹಣ';

  @override
  String get ngGroupPeople => 'ಜನರು';

  @override
  String get ngGroupAssets => 'ಆಸ್ತಿಗಳು';

  @override
  String get ngGroupPartners => 'ಪಾಲುದಾರರು';

  @override
  String get ngGroupSetup => 'ಸೆಟಪ್';

  @override
  String get ngGroupField => 'ಕ್ಷೇತ್ರ';

  @override
  String get ngGroupOther => 'ಇತರೆ';

  @override
  String get ngQuickEntry => 'ತ್ವರಿತ ನಮೂದು';

  @override
  String get ngSearchModules => 'ಮಾಡ್ಯೂಲ್ ಹುಡುಕಿ';

  @override
  String get ngNoModuleMatches => 'ಯಾವುದೇ ಮಾಡ್ಯೂಲ್ ಹೊಂದಿಕೆಯಾಗಿಲ್ಲ';

  @override
  String get ngHelp => 'ಸಹಾಯ';

  @override
  String ngOrgsSwitch(String count) {
    return '$count ಸಂಸ್ಥೆಗಳು · ಬದಲಿಸಲು ಟ್ಯಾಪ್ ಮಾಡಿ';
  }

  @override
  String get ngRoleOwner => 'ಮಾಲೀಕ';

  @override
  String get ngRoleStaff => 'ಸಿಬ್ಬಂದಿ';

  @override
  String get ngTodayMoves => 'ಸ್ಥಳಾಂತರಗಳು';

  @override
  String get ngTodayFollowUps => 'ಫಾಲೋ-ಅಪ್‌ಗಳು';

  @override
  String get ngToCollect => 'ವಸೂಲಿ ಮಾಡಬೇಕಾದ್ದು';

  @override
  String get ngOpenLeads => 'ತೆರೆದ ಲೀಡ್‌ಗಳು';

  @override
  String get ngNoMovesYet => 'ಇನ್ನೂ ಯಾವುದೇ ಸ್ಥಳಾಂತರ ನಿಗದಿಯಾಗಿಲ್ಲ';

  @override
  String get ngCreateFirstOrder => 'ನಿಮ್ಮ ಮೊದಲ ಆರ್ಡರ್ ರಚಿಸಿ';

  @override
  String get ngNoLeadsYet => 'ಇನ್ನೂ ಲೀಡ್‌ಗಳಿಲ್ಲ';

  @override
  String get ngAddLead => 'ಲೀಡ್ ಸೇರಿಸಿ';

  @override
  String get ngAllLeads => 'ಎಲ್ಲಾ ಲೀಡ್‌ಗಳು';

  @override
  String get ngConversion => 'ಪರಿವರ್ತನೆ';

  @override
  String get ngOpen => 'ತೆರೆದವು';

  @override
  String get ngOther => 'ಇತರೆ';

  @override
  String get ngSurveyResponse => 'ಸರ್ವೆ ಪ್ರತಿಕ್ರಿಯೆ ಬಂದಿದೆ';

  @override
  String get ngFollowUpOverdue => 'ಫಾಲೋ-ಅಪ್ ತಡವಾಗಿದೆ';

  @override
  String get ngCall => 'ಕರೆ';

  @override
  String get ngWhatsApp => 'WhatsApp';

  @override
  String get ngSurvey => 'ಸರ್ವೆ';

  @override
  String get ngNewLead => 'ಹೊಸ ಲೀಡ್';

  @override
  String get ngNameOrPhone => 'ಹೆಸರು ಅಥವಾ ಫೋನ್';

  @override
  String get ngNoLeadsMatch => 'ಹೊಂದಿಕೆಯಾಗುವ ಲೀಡ್‌ಗಳಿಲ್ಲ';

  @override
  String get ngLeadsEmptyHint =>
      'ಹೊಸ ಲೀಡ್ ಮೂಲಕ ವಿಚಾರಣೆ ಸೇರಿಸಿ, ಅದು ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ.';

  @override
  String get ngSurveyLinkCreated => 'ಸರ್ವೆ ಲಿಂಕ್ ರಚಿಸಲಾಗಿದೆ';

  @override
  String get ngCopyClose => 'ನಕಲಿಸಿ ಮತ್ತು ಮುಚ್ಚಿ';

  @override
  String get ngClose => 'ಮುಚ್ಚಿ';

  @override
  String get ngTabAll => 'ಎಲ್ಲಾ';

  @override
  String get ngTabPending => 'ಬಾಕಿ';

  @override
  String get ngTabCompleted => 'ಪೂರ್ಣಗೊಂಡವು';

  @override
  String get ngTabCancelled => 'ರದ್ದಾದವು';

  @override
  String get ngToday => 'ಇಂದು';

  @override
  String get ngTomorrow => 'ನಾಳೆ';

  @override
  String get ngYesterday => 'ನಿನ್ನೆ';

  @override
  String get ngNoMoveDate => 'ಸ್ಥಳಾಂತರ ದಿನಾಂಕವಿಲ್ಲ';

  @override
  String get ngPaid => 'ಪಾವತಿಸಲಾಗಿದೆ';

  @override
  String get ngPartPaid => 'ಭಾಗಶಃ ಪಾವತಿ';

  @override
  String get ngDue => 'ಬಾಕಿ';

  @override
  String get ngUnpaid => 'ಪಾವತಿಸಿಲ್ಲ';

  @override
  String get ngNewOrder => 'ಹೊಸ ಆರ್ಡರ್';

  @override
  String get ngNoOrdersHere => 'ಇಲ್ಲಿ ಯಾವುದೇ ಆರ್ಡರ್ ಇಲ್ಲ';

  @override
  String get ngRemind => 'ನೆನಪಿಸಿ';

  @override
  String get ngRecord => 'ದಾಖಲಿಸಿ';

  @override
  String get ngOverdue => 'ತಡವಾದವು';

  @override
  String get ngUpcoming => 'ಮುಂಬರುವ';

  @override
  String get ngNothingToCollect => 'ವಸೂಲಿ ಮಾಡಲು ಏನೂ ಇಲ್ಲ';

  @override
  String get ngLinkedDevice => 'ಸಂಪರ್ಕಿತ ಸಾಧನ';

  @override
  String get ngEnterPin => 'ನಿಮ್ಮ 4 ಅಂಕಿಯ PIN ನಮೂದಿಸಿ';

  @override
  String get ngVerifying => 'ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ…';

  @override
  String get ngUseEmail => 'ಬದಲಿಗೆ ಇಮೇಲ್ ಲಾಗಿನ್ ಬಳಸಿ';

  @override
  String get ngSwitchDevice => 'ನಿಮ್ಮ ಸಂಸ್ಥೆ ಅಲ್ಲವೇ? ಸಾಧನ ಬದಲಿಸಿ';

  @override
  String get ngSecuredBy => 'Nagarva ಮೂಲಕ ಸುರಕ್ಷಿತ';

  @override
  String get suCreate => 'ನಿಮ್ಮ ಬಿಸಿನೆಸ್ ಖಾತೆ ರಚಿಸಿ';

  @override
  String suStep(String n) {
    return 'ಹಂತ $n / 4';
  }

  @override
  String get suS1 => 'ಮೊಬೈಲ್';

  @override
  String get suS2 => 'ಬಿಸಿನೆಸ್';

  @override
  String get suS3 => 'ದಾಖಲೆಗಳು';

  @override
  String get suS4 => 'ಪರಿಶೀಲನೆ';

  @override
  String get suPhS => 'ಮಾಲೀಕರ ನಂಬರ್ ಬಳಸಿ. ಇದರಿಂದಲೇ ನೀವು ಲಾಗಿನ್ ಆಗುತ್ತೀರಿ.';

  @override
  String get suPh => 'ಮೊಬೈಲ್ ಸಂಖ್ಯೆ';

  @override
  String get suSend => 'OTP ಕಳುಹಿಸಿ';

  @override
  String get suPhBad => '10 ಅಂಕಿಯ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ';

  @override
  String get suOtpT => 'OTP ನಮೂದಿಸಿ';

  @override
  String suOtpS(String p) {
    return '+91 $p ಗೆ ಕಳುಹಿಸಲಾಗಿದೆ';
  }

  @override
  String get suEnter => '6 ಅಂಕಿಯ ಕೋಡ್ ಟೈಪ್ ಮಾಡಿ';

  @override
  String get suVerify => 'ದೃಢೀಕರಿಸಿ';

  @override
  String get suOtpBad => '6 ಅಂಕಿಯ OTP ನಮೂದಿಸಿ';

  @override
  String get suResend => 'OTP ಮತ್ತೆ ಕಳುಹಿಸಿ';

  @override
  String get suResent => 'OTP ಮತ್ತೆ ಕಳುಹಿಸಲಾಗಿದೆ';

  @override
  String get suChange => 'ಸಂಖ್ಯೆ ಬದಲಿಸಿ';

  @override
  String get suBzT => 'ನಿಮ್ಮ ಬಿಸಿನೆಸ್ ಬಗ್ಗೆ';

  @override
  String get suBzS =>
      'ಇದು ನಿಮ್ಮ ಕೊಟೇಶನ್ ಮತ್ತು ಬಿಲ್‌ಗಳಲ್ಲಿ ಕಾಣುತ್ತದೆ. ನಂತರ ಬದಲಿಸಬಹುದು.';

  @override
  String get suName => 'ಬಿಸಿನೆಸ್ ಹೆಸರು';

  @override
  String get suNameP => 'ಉದಾ. ಅರುಣ್ ಪ್ಯಾಕರ್ಸ್ & ಮೂವರ್ಸ್';

  @override
  String get suOwner => 'ಮಾಲೀಕರ ಹೆಸರು';

  @override
  String get suEmail => 'ಇಮೇಲ್ (ಐಚ್ಛಿಕ)';

  @override
  String get suEmailP => 'ಬಿಲ್ ಮತ್ತು ಪಾಸ್‌ವರ್ಡ್ ರೀಸೆಟ್‌ಗಾಗಿ';

  @override
  String get suCity => 'ನಗರ';

  @override
  String get suType => 'ನೀವು ಏನು ಮಾಡುತ್ತೀರಿ?';

  @override
  String get suTPm => 'ಪ್ಯಾಕರ್ಸ್ & ಮೂವರ್ಸ್';

  @override
  String get suTPmS => 'ಮನೆ ಮತ್ತು ಕಚೇರಿ ಶಿಫ್ಟಿಂಗ್';

  @override
  String get suTTr => 'ಸಾರಿಗೆ';

  @override
  String get suTTrS => 'ಟ್ರಕ್‌ಗಳು, ಟ್ರಿಪ್‌ಗಳು, LR';

  @override
  String get suTBo => 'ಎರಡೂ';

  @override
  String get suTBoS => 'ಶಿಫ್ಟಿಂಗ್ ಮತ್ತು ಸಾರಿಗೆ';

  @override
  String get suGst => 'GSTIN (ಐಚ್ಛಿಕ)';

  @override
  String get suGstP => '15 ಅಕ್ಷರದ GST ಸಂಖ್ಯೆ';

  @override
  String get suRef => 'ರೆಫರಲ್ ಕೋಡ್ (ಐಚ್ಛಿಕ)';

  @override
  String get suNeedBz => 'ಬಿಸಿನೆಸ್ ಹೆಸರು, ಮಾಲೀಕರ ಹೆಸರು ಮತ್ತು ನಗರ ತುಂಬಿಸಿ';

  @override
  String get suGstBad => 'GSTIN 15 ಅಕ್ಷರಗಳಿರಬೇಕು';

  @override
  String get suEmailBad => 'ಇಮೇಲ್ ವಿಳಾಸ ಪರಿಶೀಲಿಸಿ';

  @override
  String get suDcT => 'ನಿಮ್ಮ ಬಿಸಿನೆಸ್ ಪರಿಶೀಲಿಸಿ';

  @override
  String get suDcS =>
      'ಫೋಟೋ ಅಥವಾ PDF. ಖಾತೆ ಆರಂಭವಾಗುವ ಮೊದಲು ನಮ್ಮ ತಂಡ ಇವುಗಳನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ.';

  @override
  String get suPan => 'PAN ಕಾರ್ಡ್';

  @override
  String get suPanS => 'ಮಾಲೀಕರ ಅಥವಾ ಬಿಸಿನೆಸ್ PAN';

  @override
  String get suGstC => 'GST ಪ್ರಮಾಣಪತ್ರ';

  @override
  String get suGstCS => 'ನೀವು GSTIN ಸೇರಿಸಿದ್ದರಿಂದ ಅಗತ್ಯ';

  @override
  String get suShop => 'ಕಚೇರಿ ಅಥವಾ ಗೋದಾಮಿನ ಫೋಟೋ';

  @override
  String get suShopS => 'ಬೇಗ ಪರಿಶೀಲಿಸಲು ಸಹಾಯ';

  @override
  String get suUpload => 'ಅಪ್‌ಲೋಡ್';

  @override
  String get suReq => 'ಅಗತ್ಯ';

  @override
  String get suOpt => 'ಐಚ್ಛಿಕ';

  @override
  String get suNeedPan => 'ನಿಮ್ಮ PAN ಕಾರ್ಡ್ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ';

  @override
  String get suNeedGstC => 'GST ಪ್ರಮಾಣಪತ್ರ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ಅಥವಾ GSTIN ತೆಗೆಯಿರಿ';

  @override
  String get suPriv =>
      'ದಾಖಲೆಗಳು ಬಿಸಿನೆಸ್ ಪರಿಶೀಲನೆಗೆ ಮಾತ್ರ. ನಿಮ್ಮ ಸಿಬ್ಬಂದಿ ಅಥವಾ ಗ್ರಾಹಕರಿಗೆ ಕಾಣುವುದಿಲ್ಲ.';

  @override
  String get suRvT => 'ಪರಿಶೀಲಿಸಿ ಕಳುಹಿಸಿ';

  @override
  String get suEdit => 'ಬದಲಿಸಿ';

  @override
  String get suNext => 'ಮುಂದೇನು';

  @override
  String get suN1 =>
      'ನಮ್ಮ ತಂಡ ನಿಮ್ಮ ವಿವರ ಪರಿಶೀಲಿಸುತ್ತದೆ, ಸಾಮಾನ್ಯವಾಗಿ 1 ಕೆಲಸದ ದಿನದಲ್ಲಿ.';

  @override
  String get suN3 =>
      'ನೀವು ಉಚಿತ ಪ್ಲಾನ್‌ನಿಂದ ಆರಂಭಿಸುತ್ತೀರಿ. ಯಾವಾಗ ಬೇಕಾದರೂ ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡಿ.';

  @override
  String get suNeedAgree => 'ಮುಂದುವರಿಯಲು ನಿಯಮಗಳನ್ನು ಒಪ್ಪಿ';

  @override
  String get suSubmit => 'ಅನುಮೋದನೆಗೆ ಕಳುಹಿಸಿ';

  @override
  String get suContinue => 'ಮುಂದುವರಿಸಿ';

  @override
  String get suMob => 'ಮೊಬೈಲ್';

  @override
  String get suBt => 'ಬಿಸಿನೆಸ್ ಪ್ರಕಾರ';

  @override
  String get suNone => 'ಸೇರಿಸಿಲ್ಲ';

  @override
  String get suPendT => 'ಅರ್ಜಿ ಪರಿಶೀಲನೆಯಲ್ಲಿದೆ';

  @override
  String suAppId(String id) {
    return 'ಅರ್ಜಿ $id';
  }

  @override
  String get suTl1 => 'ಕಳುಹಿಸಲಾಗಿದೆ';

  @override
  String get suTl2 => 'ದಾಖಲೆ ಪರಿಶೀಲನೆ';

  @override
  String get suTl3 => 'ಖಾತೆ ಸಿದ್ಧ';

  @override
  String get suOkT => 'ನಿಮ್ಮ ಖಾತೆ ಸಿದ್ಧ';

  @override
  String suOkS(String b) {
    return '$b ಅನುಮೋದನೆಯಾಗಿದೆ. ನೀವು ಉಚಿತ ಪ್ಲಾನ್‌ನಲ್ಲಿದ್ದೀರಿ.';
  }

  @override
  String get suStart => 'Nagarva ಆರಂಭಿಸಿ';

  @override
  String get suNoT => 'ಬದಲಾವಣೆ ಅಗತ್ಯ';

  @override
  String get suNoS =>
      'ನಮ್ಮ ತಂಡಕ್ಕೆ ಇನ್ನೂ ಅನುಮೋದಿಸಲು ಆಗಿಲ್ಲ. ಕೆಳಗಿನದನ್ನು ಸರಿಪಡಿಸಿ ಮತ್ತೆ ಕಳುಹಿಸಿ.';

  @override
  String get suFix => 'ಸರಿಪಡಿಸಿ ಮತ್ತೆ ಕಳುಹಿಸಿ';

  @override
  String get suWa => 'WhatsApp ನಲ್ಲಿ ಮಾತನಾಡಿ';

  @override
  String get suToLogin => 'ಲಾಗಿನ್‌ಗೆ ಹಿಂತಿರುಗಿ';

  @override
  String get suHave => 'ಈಗಾಗಲೇ ಖಾತೆ ಇದೆಯೇ?';

  @override
  String get suLogin => 'ಲಾಗಿನ್';

  @override
  String get suBnP => 'ಅರ್ಜಿ ಪರಿಶೀಲನೆಯಲ್ಲಿದೆ';

  @override
  String get suBnOk => 'ಖಾತೆ ಅನುಮೋದನೆಯಾಗಿದೆ';

  @override
  String get suBnNo => 'ಅರ್ಜಿಯಲ್ಲಿ ಬದಲಾವಣೆ ಅಗತ್ಯ';

  @override
  String get suView => 'ನೋಡಿ';

  @override
  String get suSent => 'ಅರ್ಜಿ ಕಳುಹಿಸಲಾಗಿದೆ';

  @override
  String get lgTerms => 'ಬಳಕೆಯ ನಿಯಮಗಳು';

  @override
  String get lgPriv => 'ಗೌಪ್ಯತಾ ನೀತಿ';

  @override
  String suTrT(String n) {
    return '$n ದಿನ Pro ಉಚಿತವಾಗಿ ಬಳಸಿ ನೋಡಿ';
  }

  @override
  String suTrUsers(String n) {
    return '$n ಬಳಕೆದಾರರವರೆಗೆ';
  }

  @override
  String get suTrOrdersAll => 'ಪ್ರತಿ ತಿಂಗಳು ಅನಿಯಮಿತ ಆರ್ಡರ್‌ಗಳು';

  @override
  String suTrOrders(String n) {
    return 'ತಿಂಗಳಿಗೆ $n ಆರ್ಡರ್‌ಗಳು';
  }

  @override
  String get suTrReports => 'ವರದಿಗಳು ಮತ್ತು ಲಾಭ-ನಷ್ಟ';

  @override
  String get suTrBranches => 'ಹಲವು ಶಾಖೆಗಳು';

  @override
  String suTrNote(String n) {
    return 'ಕಾರ್ಡ್ ಬೇಕಿಲ್ಲ. $n ದಿನಗಳ ನಂತರ ನೀವು ತಾನಾಗಿ ಉಚಿತ ಯೋಜನೆಗೆ ಬರುತ್ತೀರಿ. ನಿಮ್ಮ ಡೇಟಾ ಉಳಿಯುತ್ತದೆ.';
  }

  @override
  String suTrBtn(String n) {
    return '$n ದಿನದ Pro ಪ್ರಯೋಗ ಆರಂಭಿಸಿ';
  }

  @override
  String get suStayFree => 'ಉಚಿತದಲ್ಲೇ ಇರಿ';

  @override
  String suTrOn(String n) {
    return 'Pro ಪ್ರಯೋಗ ಆರಂಭವಾಗಿದೆ · $n ದಿನ';
  }

  @override
  String get suFreeOn => 'ನೀವು ಉಚಿತ ಯೋಜನೆಯಲ್ಲಿದ್ದೀರಿ';

  @override
  String plTrBan(String n) {
    return 'Pro ಪ್ರಯೋಗ $n ದಿನಗಳಲ್ಲಿ ಮುಗಿಯುತ್ತದೆ. ನಂತರ ನೀವು ಉಚಿತ ಯೋಜನೆಗೆ ಬರುತ್ತೀರಿ. ನಿಮ್ಮ ಡೇಟಾ ಉಳಿಯುತ್ತದೆ.';
  }

  @override
  String get plTrEnded =>
      'ನಿಮ್ಮ Pro ಪ್ರಯೋಗ ಮುಗಿದಿದೆ. ನೀವು ಉಚಿತ ಯೋಜನೆಯಲ್ಲಿದ್ದೀರಿ ಮತ್ತು ನಿಮ್ಮ ಎಲ್ಲಾ ಡೇಟಾ ಸುರಕ್ಷಿತವಾಗಿದೆ.';

  @override
  String plTrEnds(String d, String n) {
    return 'Pro ಪ್ರಯೋಗ $d ರಂದು ಮುಗಿಯುತ್ತದೆ · $n ದಿನ ಉಳಿದಿದೆ';
  }

  @override
  String get suN2b =>
      'ನಿಮ್ಮ ಸ್ಥಿತಿ ನೋಡಲು ಯಾವಾಗ ಬೇಕಾದರೂ ಇದೇ ಮೊಬೈಲ್ ನಂಬರ್‌ನಿಂದ ಲಾಗಿನ್ ಆಗಿ.';

  @override
  String suPendS2(String p) {
    return 'ಸಾಮಾನ್ಯವಾಗಿ 1 ಕೆಲಸದ ದಿನದೊಳಗೆ ಉತ್ತರಿಸುತ್ತೇವೆ. ಫಲಿತಾಂಶ ನೋಡಲು +91 $p ನಿಂದ ಲಾಗಿನ್ ಆಗಿ.';
  }

  @override
  String get suOtpUnavailable =>
      'ಮೊಬೈಲ್ ಸೈನ್-ಅಪ್ ಇನ್ನೂ ಆನ್ ಆಗಿಲ್ಲ. ದಯವಿಟ್ಟು Nagarva ಸಹಾಯವನ್ನು ಸಂಪರ್ಕಿಸಿ.';

  @override
  String get suSendFailed =>
      'OTP ಕಳುಹಿಸಲಾಗಲಿಲ್ಲ. ನಂಬರ್ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get suOtpFailed => 'ಆ ಕೋಡ್ ಕೆಲಸ ಮಾಡಲಿಲ್ಲ. ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get suUploadFailed => 'ಅಪ್‌ಲೋಡ್ ವಿಫಲವಾಯಿತು. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get suMobileLogin => 'ಮೊಬೈಲ್ ನಂಬರ್‌ನಿಂದ ಲಾಗಿನ್ ಆಗಿ';

  @override
  String get suRefresh => 'ಸ್ಥಿತಿ ನೋಡಿ';

  @override
  String suResendIn(String n) {
    return '$n ಸೆಕೆಂಡ್‌ನಲ್ಲಿ ಮತ್ತೆ ಕಳುಹಿಸಿ';
  }

  @override
  String get suAgreeLead => 'ಇವುಗಳಿಗೆ ಒಪ್ಪುತ್ತೇನೆ:';

  @override
  String get ngGreetMorning => 'ಶುಭೋದಯ';

  @override
  String get ngGreetAfternoon => 'ಶುಭ ಮಧ್ಯಾಹ್ನ';

  @override
  String get ngGreetEvening => 'ಶುಭ ಸಂಜೆ';

  @override
  String ngPlanName(String plan) {
    return '$plan ಯೋಜನೆ';
  }

  @override
  String get ngPlanActive => 'ಸಕ್ರಿಯ';

  @override
  String get ngPlanTrial => 'ಟ್ರಯಲ್';

  @override
  String get ngPlanEndingSoon => 'ಶೀಘ್ರ ಮುಗಿಯುತ್ತದೆ';

  @override
  String get ngPlanEnded => 'ಮುಗಿದಿದೆ';

  @override
  String ngPlanTrialEnds(String date, int days) {
    return 'ಟ್ರಯಲ್ $date ರಂದು ಮುಗಿಯುತ್ತದೆ · $days ದಿನ ಉಳಿದಿದೆ';
  }

  @override
  String ngPlanReadOnlyIn(int days) {
    return 'ಟ್ರಯಲ್ ಮುಗಿದಿದೆ · $days ದಿನಗಳಲ್ಲಿ ನೋಡಲು ಮಾತ್ರ';
  }

  @override
  String get ngPlanReadOnly => 'ಟ್ರಯಲ್ ಮುಗಿದಿದೆ · ನೋಡಲು ಮಾತ್ರ';

  @override
  String get ngPlanNoExpiry => 'ಮುಕ್ತಾಯ ದಿನಾಂಕ ಇಲ್ಲ';

  @override
  String get ngPlanSee => 'ಯೋಜನೆಗಳು';

  @override
  String get ngPaymentsDue => 'ಬಾಕಿ ಪಾವತಿಗಳು';

  @override
  String ngPaymentsDueSub(int n) {
    return '$n ಆರ್ಡರ್‌ಗಳು ಪೂರ್ಣ ಪಾವತಿಯಾಗಿಲ್ಲ';
  }

  @override
  String get ngOverdueFollowUps => 'ಮೀರಿದ ಫಾಲೋ-ಅಪ್‌ಗಳು';

  @override
  String get ngOverdueFollowUpsSub => 'ಮೊದಲು ಇವರಿಗೆ ಕರೆ ಮಾಡಿ';

  @override
  String get ngTodaysPlan => 'ಇಂದಿನ ಯೋಜನೆ';

  @override
  String get ngNothingToday => 'ಇಂದು ಏನೂ ಯೋಜಿಸಿಲ್ಲ';

  @override
  String get ngComingUp => 'ಮುಂಬರುವ';

  @override
  String ngAgendaMove(String name) {
    return 'ಸ್ಥಳಾಂತರ · $name';
  }

  @override
  String get ngAllDay => 'ಇಡೀ ದಿನ';

  @override
  String get ngPeriodThisMonth => 'ಈ ತಿಂಗಳು';

  @override
  String get ngPeriodLastMonth => 'ಕಳೆದ ತಿಂಗಳು';

  @override
  String get ngPeriod3m => 'ಕಳೆದ 3 ತಿಂಗಳು';

  @override
  String get ngPeriodFy => 'ಈ ಹಣಕಾಸು ವರ್ಷ';

  @override
  String get ngPeriodAll => 'ಎಲ್ಲಾ ಸಮಯ';

  @override
  String get ngPickPeriod => 'ಈ ಅವಧಿಯ ಅಂಕಿಗಳು';

  @override
  String get ngProfitTarget => 'ಲಾಭದ ಗುರಿ';

  @override
  String get ngSetTarget => 'ತಿಂಗಳ ಲಾಭದ ಗುರಿ ಹೊಂದಿಸಿ';

  @override
  String get ngSetTargetSub => 'ತಲುಪಬೇಕಾದ ಮೊತ್ತ ಹೊಂದಿಸಲು ಟ್ಯಾಪ್ ಮಾಡಿ';

  @override
  String get ngProfit => 'ಲಾಭ';

  @override
  String ngProfitAfter(String labour, String expenses) {
    return 'ಕೂಲಿ $labour ಮತ್ತು ಖರ್ಚು $expenses ನಂತರ';
  }

  @override
  String get ngAddExpense => 'ಖರ್ಚು ಸೇರಿಸಿ';

  @override
  String get ngSeeAll => 'ಎಲ್ಲಾ ನೋಡಿ';

  @override
  String get ngHotLeads => 'ಹಾಟ್ ಲೀಡ್‌ಗಳು';

  @override
  String get ngBranches => 'ಶಾಖೆಗಳು';

  @override
  String ngOrdersN(int n) {
    return '$n ಆರ್ಡರ್‌ಗಳು';
  }

  @override
  String get ngTargetDone => 'ಗುರಿ ತಲುಪಿದೆ';

  @override
  String get ngNoProfitYet => 'ಈ ಅವಧಿಯಲ್ಲಿ ಇನ್ನೂ ಲಾಭವಿಲ್ಲ';

  @override
  String get ngEditTarget => 'ತಿಂಗಳ ಲಾಭದ ಗುರಿ';

  @override
  String get ngQuote => 'ಕೊಟೇಶನ್';

  @override
  String get ngTabDone => 'ಮುಗಿದವು';

  @override
  String get ngReceived => 'ಸ್ವೀಕರಿಸಿದವು';

  @override
  String ngDaysLate(int n) {
    String _temp0 = intl.Intl.pluralLogic(
      n,
      locale: localeName,
      other: '$n ದಿನ ತಡ',
      one: '1 ದಿನ ತಡ',
    );
    return '$_temp0';
  }

  @override
  String get ngNoPaymentsYet => 'ಇನ್ನೂ ಯಾವುದೇ ಪಾವತಿ ದಾಖಲಾಗಿಲ್ಲ';

  @override
  String get ngOpsTitle => 'ಕಾರ್ಯಾಚರಣೆ';

  @override
  String get ngOpsNewTrip => 'ಹೊಸ ಟ್ರಿಪ್';

  @override
  String get ngOpsCrewsOut => 'ಕೆಲಸದಲ್ಲಿರುವ ತಂಡ';

  @override
  String get ngOpsVehiclesFree => 'ಖಾಲಿ ವಾಹನಗಳು';

  @override
  String get ngOpsAttention => 'ಗಮನ ಬೇಕು';

  @override
  String ngOpsNoCrew(String name) {
    return 'ತಂಡವಿಲ್ಲ · $name';
  }

  @override
  String get ngOpsAssign => 'ನಿಯೋಜಿಸಿ';

  @override
  String get ngOpsAssignCrew => 'ತಂಡ ನಿಯೋಜಿಸಿ';

  @override
  String ngOpsInsuranceExpires(int n) {
    return 'ವಿಮೆ $n ದಿನಗಳಲ್ಲಿ ಮುಗಿಯುತ್ತದೆ';
  }

  @override
  String get ngOpsInsuranceExpired => 'ವಿಮೆ ಮುಗಿದಿದೆ';

  @override
  String ngOpsLowStock(String name) {
    return '$name ಕಡಿಮೆಯಾಗಿದೆ';
  }

  @override
  String ngOpsStockLeft(String qty) {
    return '$qty ಉಳಿದಿದೆ';
  }

  @override
  String get ngOpsReorder => 'ಮರು ಆರ್ಡರ್';

  @override
  String get ngOpsView => 'ನೋಡಿ';

  @override
  String get ngOpsAwaiting => 'ಅನುಮೋದನೆಗೆ ಕಾಯುತ್ತಿದೆ';

  @override
  String get ngOpsJobs => 'ಕೆಲಸಗಳು';

  @override
  String get ngOpsNoJobs => 'ಈ ದಿನ ಯಾವುದೇ ಸ್ಥಳಾಂತರವಿಲ್ಲ';

  @override
  String get ngOpsFleet => 'ವಾಹನಗಳು';

  @override
  String ngOpsFleetSummary(int free, int total) {
    return '$total ರಲ್ಲಿ $free ಖಾಲಿ';
  }

  @override
  String get ngOpsInService => 'ಸರ್ವಿಸ್‌ನಲ್ಲಿ';

  @override
  String get ngOpsOnJob => 'ಕೆಲಸದಲ್ಲಿ';

  @override
  String get ngOpsFree => 'ಖಾಲಿ';

  @override
  String ngExpCount(int n) {
    return '$n ಖರ್ಚುಗಳು';
  }

  @override
  String ngExpVsLast(int pct) {
    return 'ಕಳೆದ ತಿಂಗಳಿಗೆ ಹೋಲಿಸಿ $pct%';
  }

  @override
  String get ngExpThisWeek => 'ಈ ವಾರ';

  @override
  String get ngExpOrderOnly => 'ಆರ್ಡರ್ ಸಂಬಂಧಿತ ಮಾತ್ರ';

  @override
  String get ngExpNone => 'ಈ ಅವಧಿಯಲ್ಲಿ ಖರ್ಚುಗಳಿಲ್ಲ';

  @override
  String get ngExpUncategorised => 'ವರ್ಗವಿಲ್ಲದ್ದು';

  @override
  String get ngExpDelete => 'ಖರ್ಚು ಅಳಿಸಿ';

  @override
  String get ngExpByCategory => 'ವರ್ಗದ ಪ್ರಕಾರ';

  @override
  String get ngExpNoCat => 'ಇನ್ನೂ ವಿಂಗಡಿಸಲು ಏನೂ ಇಲ್ಲ';

  @override
  String get ngExpNoCatSub => 'ಖರ್ಚು ದಾಖಲಿಸಿದ ನಂತರ ವರ್ಗಗಳು ಇಲ್ಲಿ ಕಾಣುತ್ತವೆ.';

  @override
  String get ngFleetNew => 'ಹೊಸ ವಾಹನ';

  @override
  String get ngFleetActive => 'ಸಕ್ರಿಯ';

  @override
  String get ngFleetMaintenance => 'ನಿರ್ವಹಣೆ';

  @override
  String get ngFleetInactive => 'ನಿಷ್ಕ್ರಿಯ';

  @override
  String get ngFleetNone =>
      'ಇನ್ನೂ ವಾಹನಗಳಿಲ್ಲ. ದಾಖಲೆ ಮತ್ತು ಟ್ರಿಪ್ ಗಮನಿಸಲು ಒಂದನ್ನು ಸೇರಿಸಿ.';

  @override
  String get ngFleetDelete => 'ವಾಹನ ಅಳಿಸಿ';

  @override
  String get ngFleetInsurance => 'ವಿಮೆ';

  @override
  String get ngFleetPermit => 'ಪರ್ಮಿಟ್';

  @override
  String ngFleetExpires(String doc, int n) {
    return '$doc $n ದಿನಗಳಲ್ಲಿ ಮುಗಿಯುತ್ತದೆ';
  }

  @override
  String ngFleetExpired(String doc, int n) {
    return '$doc $n ದಿನಗಳ ಹಿಂದೆ ಮುಗಿದಿದೆ';
  }

  @override
  String get ngMatNew => 'ಹೊಸ ಸಾಮಗ್ರಿ';

  @override
  String get ngMatSearch => 'ಸಾಮಗ್ರಿ ಹುಡುಕಿ';

  @override
  String get ngMatReorderSoon => 'ಶೀಘ್ರ ಮರು ಆರ್ಡರ್';

  @override
  String get ngMatReturnable => 'ಹಿಂತಿರುಗಿಸಬಹುದಾದ';

  @override
  String ngMatMin(String n) {
    return 'ಕನಿಷ್ಠ $n';
  }

  @override
  String get ngMatDelete => 'ಸಾಮಗ್ರಿ ಅಳಿಸಿ';

  @override
  String get ngMatNone => 'ಇನ್ನೂ ಸಾಮಗ್ರಿಗಳಿಲ್ಲ';

  @override
  String get ngTripPlanned => 'ಯೋಜಿತ';

  @override
  String get ngTripOngoing => 'ನಡೆಯುತ್ತಿದೆ';

  @override
  String get ngTripNone => 'ಇನ್ನೂ ಟ್ರಿಪ್‌ಗಳಿಲ್ಲ';

  @override
  String get ngTripNoNumber => '(ಟ್ರಿಪ್ ಸಂಖ್ಯೆ ಇಲ್ಲ)';

  @override
  String get ngTripHired => 'ಬಾಡಿಗೆ';

  @override
  String get ngTripOwn => 'ಸ್ವಂತ';

  @override
  String get ngTripDelete => 'ಟ್ರಿಪ್ ಅಳಿಸಿ';

  @override
  String ngCustCount(int n) {
    return '$n ಗ್ರಾಹಕರು';
  }

  @override
  String get ngCustNew => 'ಹೊಸ';

  @override
  String get ngCustSearch => 'ಹೆಸರು, ಫೋನ್ ಅಥವಾ ಕಂಪನಿ ಹುಡುಕಿ';

  @override
  String get ngCustNone => 'ಗ್ರಾಹಕರು ಸಿಗಲಿಲ್ಲ';

  @override
  String ngCustDue(String amount) {
    return '$amount ಬಾಕಿ';
  }

  @override
  String get ngStaffTitle => 'ಸಿಬ್ಬಂದಿ';

  @override
  String ngStaffSummary(int n, int monthly, int other) {
    return '$n ಜನ · $monthly ಮಾಸಿಕ · $other ದಿನಗೂಲಿ / ತಾತ್ಕಾಲಿಕ';
  }

  @override
  String get ngStaffAdd => 'ಸಿಬ್ಬಂದಿ ಸೇರಿಸಿ';

  @override
  String get ngStaffMonthly => 'ಸ್ಥಿರ ಮಾಸಿಕ';

  @override
  String get ngStaffDaily => 'ದಿನಗೂಲಿ';

  @override
  String get ngStaffTemporary => 'ತಾತ್ಕಾಲಿಕ';

  @override
  String ngStaffJoined(String date) {
    return 'ಸೇರಿದ್ದು $date';
  }

  @override
  String get ngStaffAllRoles => 'ಎಲ್ಲಾ ಪಾತ್ರಗಳು';

  @override
  String get ngStaffNone => 'ಇನ್ನೂ ಸಿಬ್ಬಂದಿ ಇಲ್ಲ';

  @override
  String get ngStaffInactive => 'ನಿಷ್ಕ್ರಿಯ';

  @override
  String get ngSalTitle => 'ಸಂಬಳ';

  @override
  String get ngSalToPay => 'ಕೊಡಬೇಕಾದದ್ದು';

  @override
  String get ngSalAdvances => 'ಮುಂಗಡ';

  @override
  String get ngSalPaid => 'ಪಾವತಿಸಿದ ಸಂಬಳ';

  @override
  String get ngSalBalance => 'ಬಾಕಿ';

  @override
  String ngSalJobs(int n) {
    return '$n ಕೆಲಸ';
  }

  @override
  String ngSalAdvance(String amount) {
    return 'ಮುಂಗಡ $amount';
  }

  @override
  String get ngSalNote =>
      'ಈ ತಿಂಗಳು ಪ್ರತಿ ಕೆಲಸದಲ್ಲಿ ನಮೂದಿಸಿದ ತಂಡದಿಂದ ಗಳಿಕೆ ಬರುತ್ತದೆ. ಪಾವತಿ ಅಥವಾ ಮುಂಗಡಕ್ಕಾಗಿ ವ್ಯಕ್ತಿಯನ್ನು ತೆರೆಯಿರಿ.';

  @override
  String get ngSetApp => 'ಆ್ಯಪ್';

  @override
  String get ngSetLanguage => 'ಭಾಷೆ';

  @override
  String get ngSetTheme => 'ಥೀಮ್';

  @override
  String get ngSetThemeLight => 'ಬೆಳಕು';

  @override
  String get ngSetThemeDark => 'ಡಾರ್ಕ್';

  @override
  String get ngSetThemeMidnight => 'ಮಧ್ಯರಾತ್ರಿ';

  @override
  String get ngSetNotifications => 'ಅಧಿಸೂಚನೆಗಳು';

  @override
  String get ngSetNotificationsSub => 'ಆ್ಯಪ್ ತೆರೆದಿರುವಾಗ ಎಚ್ಚರಿಕೆ ತೋರಿಸಿ';

  @override
  String get ngSetBusiness => 'ವ್ಯವಹಾರ';

  @override
  String get ngSetBizDetails => 'ವ್ಯವಹಾರ ವಿವರ';

  @override
  String get ngSetBizDetailsSub =>
      'ಹೆಸರು, ಟ್ಯಾಗ್‌ಲೈನ್, GST, ವಿಳಾಸ, ಲೋಗೋ, ಸಹಿ, ನಿಯಮಗಳು, ಸಂಖ್ಯೆ';

  @override
  String get ngSetCft => 'CFT ಮತ್ತು ಪ್ಯಾಕೇಜ್‌ಗಳು';

  @override
  String get ngSetCftSub => 'ವಸ್ತು ಗಾತ್ರ, ಮನೆ ಗಾತ್ರ, ಸಂಗ್ರಹಣೆ ದರ';

  @override
  String get ngSetSecurity => 'ಭದ್ರತೆ';

  @override
  String get ngSetLogin => 'ಲಾಗಿನ್ ಮತ್ತು ಭದ್ರತೆ';

  @override
  String get ngSetLoginSub => 'ನಿಮ್ಮ ಆ್ಯಪ್ PIN';

  @override
  String get ngSetAccount => 'ಖಾತೆ ಮತ್ತು ಬೆಂಬಲ';

  @override
  String get ngSetPlan => 'ಯೋಜನೆ ಮತ್ತು ಬಿಲ್ಲಿಂಗ್';

  @override
  String get ngSetPlanSub => 'ನಿಮ್ಮ ಯೋಜನೆ ಮತ್ತು ಮಿತಿಗಳು';

  @override
  String get ngSetRecycle => 'ಅಳಿಸಿದ ಐಟಂಗಳು';

  @override
  String get ngSetRecycleSub => 'ತಪ್ಪಾಗಿ ಅಳಿಸಿದ್ದನ್ನು ಮರಳಿ ತನ್ನಿ';

  @override
  String get ngSetHelp => 'ಸಹಾಯ ಮತ್ತು ಬೆಂಬಲ';

  @override
  String get ngSetHelpSub => 'ಬೆಂಬಲ ಸಂಪರ್ಕ, ಗೌಪ್ಯತಾ ನೀತಿ, ನಿಯಮಗಳು';

  @override
  String get ngSetPorter => 'Porter ಸಂಯೋಜನೆ';

  @override
  String get ngSetPorterSub =>
      'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ Porter ಕಮಿಷನ್ ತೋರಿಸಿ. ನಿಮ್ಮ ವ್ಯವಹಾರ Porter ಬಳಸಿದರೆ ಮಾತ್ರ ಆನ್ ಮಾಡಿ.';

  @override
  String odStageOf(int n, int total, String name) {
    return 'ಹಂತ $n / $total · $name';
  }

  @override
  String get odJourneyDone => 'ಎಲ್ಲಾ ಹಂತಗಳು ಮುಗಿದಿವೆ';

  @override
  String get odMaps => 'ನಕ್ಷೆ';

  @override
  String get odProgress => 'ಪ್ರಗತಿ';

  @override
  String get odInProgress => 'ಪ್ರಗತಿಯಲ್ಲಿದೆ';

  @override
  String odMarkAs(String stage) {
    return '$stage ಎಂದು ಗುರುತಿಸಿ';
  }

  @override
  String get odDeliveredHint =>
      'ಗ್ರಾಹಕರ ಕೋಡ್‌ನೊಂದಿಗೆ ತಂಡ ಕೆಲಸ ಮುಗಿಸಿದಾಗ ವಿತರಣೆ ದಾಖಲಾಗುತ್ತದೆ.';

  @override
  String get odOpenFieldJob => 'ಫೀಲ್ಡ್ ಕೆಲಸ ತೆರೆಯಿರಿ';

  @override
  String get odCrewVehicle => 'ತಂಡ & ವಾಹನ';

  @override
  String get odNoCrew => 'ಇನ್ನೂ ತಂಡ ನಿಯೋಜಿಸಿಲ್ಲ';

  @override
  String get odNoVehicle => 'ವಾಹನ ನಿಯೋಜಿಸಿಲ್ಲ';

  @override
  String odSupervisorCrew(String name, int count) {
    return 'ಮೇಲ್ವಿಚಾರಕ · $name · $count ಜನ';
  }

  @override
  String odCrewCount(int count) {
    return '$count ಜನ';
  }

  @override
  String get odPayment => 'ಪಾವತಿ';

  @override
  String get odTotal => 'ಒಟ್ಟು';

  @override
  String get odPaid => 'ಪಾವತಿಸಲಾಗಿದೆ';

  @override
  String get odBalance => 'ಬಾಕಿ';

  @override
  String get odPartPaid => 'ಭಾಗಶಃ ಪಾವತಿ';

  @override
  String get odFullyPaid => 'ಪಾವತಿಯಾಗಿದೆ';

  @override
  String get odUnpaid => 'ಪಾವತಿಸಿಲ್ಲ';

  @override
  String get odRemind => 'ನೆನಪಿಸಿ';

  @override
  String get odRecordPayment => 'ಪಾವತಿ ದಾಖಲಿಸಿ';

  @override
  String get odActivity => 'ಚಟುವಟಿಕೆ';

  @override
  String odAllN(int count) {
    return 'ಎಲ್ಲಾ $count';
  }

  @override
  String get odStageChanged => 'ಹಂತ ಬದಲಾಗಿದೆ';

  @override
  String odPaymentReceived(String amount) {
    return 'ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ · $amount';
  }

  @override
  String get odNoActivity => 'ಈ ಆರ್ಡರ್‌ನಲ್ಲಿ ಇನ್ನೂ ಏನೂ ದಾಖಲಾಗಿಲ್ಲ.';

  @override
  String get odMoveDetails => 'ಸ್ಥಳಾಂತರ ವಿವರ';

  @override
  String get odCancelled => 'ರದ್ದುಗೊಂಡಿದೆ';

  @override
  String get odMore => 'ಇನ್ನಷ್ಟು ಕ್ರಿಯೆಗಳು';

  @override
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor) {
    return 'Hi $customer, a balance of $amount is due for your move ($orderId). Thank you, $vendor';
  }

  @override
  String get odStConfirmed => 'ದೃಢೀಕೃತ';

  @override
  String get odStPacking => 'ಪ್ಯಾಕಿಂಗ್';

  @override
  String get odStInTransit => 'ಸಾಗಣೆಯಲ್ಲಿ';

  @override
  String get odStArrived => 'ತಲುಪಿದೆ';

  @override
  String get odStDelivered => 'ತಲುಪಿಸಲಾಗಿದೆ';

  @override
  String get odStCompleted => 'ಪೂರ್ಣಗೊಂಡಿದೆ';

  @override
  String get nlPhone => 'ಫೋನ್';

  @override
  String get nlName => 'ಹೆಸರು';

  @override
  String get nlRoute => 'ಮಾರ್ಗ';

  @override
  String get nlMovingFrom => 'ಎಲ್ಲಿಂದ';

  @override
  String get nlMovingTo => 'ಎಲ್ಲಿಗೆ';

  @override
  String get nlService => 'ಸೇವೆ';

  @override
  String get nlWhen => 'ಯಾವಾಗ';

  @override
  String get nlToday => 'ಇಂದು';

  @override
  String get nlTomorrow => 'ನಾಳೆ';

  @override
  String get nlPickDate => 'ದಿನಾಂಕ ಆರಿಸಿ';

  @override
  String get nlSource => 'ಮೂಲ';

  @override
  String get nlBranch => 'ಶಾಖೆ';

  @override
  String get nlNextStep => 'ಮುಂದಿನ ಹೆಜ್ಜೆ';

  @override
  String get nlStepFollow => 'ಫಾಲೋ-ಅಪ್';

  @override
  String get nlStepFollowSub => 'ನಂತರ ಮತ್ತೆ ಕರೆ';

  @override
  String get nlStepSurvey => 'ಸಮೀಕ್ಷೆ';

  @override
  String get nlStepSurveySub => 'ಭೇಟಿ, ಲಿಂಕ್ ಅಥವಾ ಕರೆಯಲ್ಲಿ';

  @override
  String get nlStepQuote => 'ಸಮೀಕ್ಷೆ ಬಿಡಿ · ಕೋಟ್';

  @override
  String get nlStepQuoteSub => 'ಈ ಕರೆಯಲ್ಲೇ ಬೆಲೆ';

  @override
  String get nlStepConfirm => 'ಆರ್ಡರ್ ದೃಢೀಕರಿಸಿ';

  @override
  String get nlStepConfirmSub => 'ಗ್ರಾಹಕರು ಒಪ್ಪಿದ್ದಾರೆ';

  @override
  String get nlMore => 'ಇನ್ನಷ್ಟು ವಿವರ';

  @override
  String get nlEmail => 'ಇಮೇಲ್ (ಐಚ್ಛಿಕ)';

  @override
  String get nlNotes => 'ಟಿಪ್ಪಣಿಗಳು';

  @override
  String get nlNameRequired => 'ಗ್ರಾಹಕರ ಹೆಸರು ನಮೂದಿಸಿ.';

  @override
  String get nlNoBranches => 'ಲೀಡ್ ಉಳಿಸುವ ಮೊದಲು ಸೆಟ್ಟಿಂಗ್‌ಗಳಲ್ಲಿ ಶಾಖೆ ಸೇರಿಸಿ.';

  @override
  String get nlUpdateLead => 'ಲೀಡ್ ನವೀಕರಿಸಿ';

  @override
  String get noPickup => 'ಪಿಕಪ್';

  @override
  String get noDrop => 'ಡ್ರಾಪ್';

  @override
  String get noPricing => 'ಬೆಲೆ & ಮೂಲ';

  @override
  String get ngSetFy => 'ಆರ್ಥಿಕ ವರ್ಷ & ಸಂಖ್ಯೆ';

  @override
  String get ngSetFySub => 'ಮುಂದಿನ ವರ್ಷದ ಬಿಲ್ ಸಂಖ್ಯೆ ಆರಂಭಿಸಿ';

  @override
  String get ngSetWa => 'WhatsApp';

  @override
  String get ngSetWaSub => 'ನಿಮ್ಮದೇ ಸಂಖ್ಯೆಯಿಂದ ಸಂದೇಶ ಕಳುಹಿಸಿ';

  @override
  String get ngSetAutoWa => 'ಸ್ವಯಂ WhatsApp';

  @override
  String get ngSetAutoWaSub => 'ಪ್ರತಿ ಹಂತದಲ್ಲಿ ಗ್ರಾಹಕರಿಗೆ ಕಳುಹಿಸುವ ಸಂದೇಶಗಳು';

  @override
  String get mdTitle => 'ಮಾಡ್ಯೂಲ್‌ಗಳು';

  @override
  String get mdSettingsSub => 'ಪ್ಯಾಕರ್ಸ್ & ಮೂವರ್ಸ್, ಸಾರಿಗೆ ಅಥವಾ ಎರಡೂ';

  @override
  String get mdType => 'ನಿಮ್ಮ ವ್ಯವಹಾರ';

  @override
  String get mdAdv => 'ಸುಧಾರಿತ';

  @override
  String mdCount(int count, int total) {
    return '$total ರಲ್ಲಿ $count ಮಾಡ್ಯೂಲ್‌ಗಳು ಆನ್';
  }

  @override
  String mdGroupOn(int count, int total) {
    return '$total ರಲ್ಲಿ $count ಆನ್';
  }

  @override
  String get mdNote =>
      'ಆಫ್ ಮಾಡಿದ ಮಾಡ್ಯೂಲ್‌ಗಳು ಮೆನುವಿನಿಂದ ಮರೆಯಾಗುತ್ತವೆ. ನಿಮ್ಮ ಡೇಟಾ ಉಳಿದಿರುತ್ತದೆ, ಮತ್ತೆ ಆನ್ ಮಾಡಿದಾಗ ಹಿಂದಿರುಗುತ್ತದೆ.';

  @override
  String get mdReset => 'ಈ ವ್ಯವಹಾರಕ್ಕೆ ಶಿಫಾರಸು ಮಾಡಿದ್ದಕ್ಕೆ ಮರುಹೊಂದಿಸಿ';

  @override
  String mdResetDone(String type) {
    return '$type ಗೆ ಮಾಡ್ಯೂಲ್‌ಗಳನ್ನು ಮರುಹೊಂದಿಸಲಾಗಿದೆ';
  }

  @override
  String mdTypeSet(String type) {
    return '$type ಆಯ್ಕೆ · ಮೆನು ನವೀಕರಿಸಲಾಗಿದೆ';
  }

  @override
  String get mdOwnerOnly => 'ಮಾಲೀಕರು ಮಾತ್ರ ಮಾಡ್ಯೂಲ್‌ಗಳನ್ನು ಬದಲಿಸಬಹುದು';

  @override
  String get mdSaveFailed => 'ಉಳಿಸಲಾಗಲಿಲ್ಲ. ಸಂಪರ್ಕ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get btPm => 'ಪ್ಯಾಕರ್ಸ್ & ಮೂವರ್ಸ್';

  @override
  String get btPmS => 'ಮನೆ, ಕಚೇರಿ ಮತ್ತು ವಾಹನ ಸ್ಥಳಾಂತರ';

  @override
  String get btTr => 'ಸಾರಿಗೆ / ಲಾಜಿಸ್ಟಿಕ್ಸ್';

  @override
  String get btTrS => 'ಲಾರಿ, ಟ್ರಿಪ್, ಸರಕು ಮತ್ತು ಚಾಲಕರು';

  @override
  String get btBoth => 'ಎರಡೂ';

  @override
  String get btBothS => 'ಸ್ಥಳಾಂತರ ಮತ್ತು ಸಾರಿಗೆ, ಎಲ್ಲವೂ ಆನ್';

  @override
  String get btTitle => 'ನಿಮ್ಮ ವ್ಯವಹಾರ ಏನು ಮಾಡುತ್ತದೆ?';

  @override
  String get btSub =>
      'ಬೇಕಾದ ಮಾಡ್ಯೂಲ್‌ಗಳನ್ನು ಮಾತ್ರ ತೋರಿಸುತ್ತೇವೆ. ಸೆಟ್ಟಿಂಗ್ಸ್ › ಮಾಡ್ಯೂಲ್‌ಗಳಲ್ಲಿ ಯಾವಾಗ ಬೇಕಾದರೂ ಬದಲಿಸಿ.';

  @override
  String get btLater => 'ನಂತರ ಸೆಟ್ಟಿಂಗ್ಸ್ › ಮಾಡ್ಯೂಲ್‌ಗಳಲ್ಲಿ ಬದಲಿಸಬಹುದು';

  @override
  String get dwTitle => 'ವಿಜೆಟ್‌ಗಳು';

  @override
  String get dwSub => 'ಮಾಲೀಕರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ಏನು ತೋರಿಸಬೇಕು';

  @override
  String get dwNote =>
      'ಮಾಲೀಕರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ಈ ಕ್ರಮದಲ್ಲಿ ತೋರಿಸುತ್ತವೆ. ಬಾಣದಿಂದ ಮೇಲೆ, ಸ್ವಿಚ್‌ನಿಂದ ಮರೆಮಾಡಿ.';

  @override
  String dwShown(int n) {
    return 'ತೋರಿಸುತ್ತಿದೆ · ಸ್ಥಾನ $n';
  }

  @override
  String get dwHidden => 'ಮರೆಮಾಡಲಾಗಿದೆ';

  @override
  String get dwUp => 'ಮೇಲೆ';

  @override
  String get dwToday => 'ಇಂದಿನ ಅಂಕಿಅಂಶಗಳು';

  @override
  String get dwFleet => 'ವಾಹನ ಸ್ಥಿತಿ';

  @override
  String dwFleetSub(int a, int s) {
    return '$a ಸಕ್ರಿಯ · $s ಸರ್ವಿಸ್‌ನಲ್ಲಿ';
  }

  @override
  String get dwAttendance => 'ಸಿಬ್ಬಂದಿ ಹಾಜರಾತಿ';

  @override
  String get dwAttendanceSub => 'ಇಂದು ಚೆಕ್-ಇನ್';

  @override
  String get dwSaveFailed => 'ಉಳಿಸಲಾಗಲಿಲ್ಲ. ಸಂಪರ್ಕ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';

  @override
  String get jrShareInvoice => 'ಬಿಲ್ ಕಳುಹಿಸಿ';

  @override
  String get jrSendForSignature => 'ಸಹಿಗಾಗಿ ಕಳುಹಿಸಿ';

  @override
  String get lsTitle => 'ಲಾಗಿನ್ & ಭದ್ರತೆ';

  @override
  String get lsMy => 'ನಿಮ್ಮ ಲಾಗಿನ್';

  @override
  String get lsMyEmail => 'ಲಾಗಿನ್ ಇಮೇಲ್';

  @override
  String get lsChangePw => 'ಪಾಸ್‌ವರ್ಡ್ ಬದಲಿಸಿ';

  @override
  String get lsCurPw => 'ಪ್ರಸ್ತುತ ಪಾಸ್‌ವರ್ಡ್';

  @override
  String get lsNewPw => 'ಹೊಸ ಪಾಸ್‌ವರ್ಡ್';

  @override
  String get lsConfPw => 'ಹೊಸ ಪಾಸ್‌ವರ್ಡ್ ದೃಢೀಕರಿಸಿ';

  @override
  String get lsPwSub => 'ಕನಿಷ್ಠ 8 ಅಕ್ಷರಗಳು';

  @override
  String get lsPwShort => 'ಪಾಸ್‌ವರ್ಡ್ ಕನಿಷ್ಠ 8 ಅಕ್ಷರಗಳಿರಬೇಕು';

  @override
  String get lsPwMismatch => 'ಪಾಸ್‌ವರ್ಡ್‌ಗಳು ಹೊಂದುತ್ತಿಲ್ಲ';

  @override
  String get lsPwCurReq => 'ಪ್ರಸ್ತುತ ಪಾಸ್‌ವರ್ಡ್ ನೀಡಿ';

  @override
  String get lsPwDone => 'ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಗಿದೆ';

  @override
  String get lsUpdatePw => 'ಪಾಸ್‌ವರ್ಡ್ ಅಪ್‌ಡೇಟ್';

  @override
  String get lsForgot =>
      'ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ? ಲಾಗಿನ್ ಪರದೆಯಲ್ಲಿ \"ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ?\" ಒತ್ತಿ. ರೀಸೆಟ್ ಲಿಂಕ್ ಇಮೇಲ್ ಮಾಡುತ್ತೇವೆ.';

  @override
  String get lsStaffPins => 'ಸಿಬ್ಬಂದಿ PIN ಗಳು';

  @override
  String get lsStaffPinsSub =>
      'ಸಿಬ್ಬಂದಿ ಮತ್ತು ಸೂಪರ್‌ವೈಸರ್‌ಗಳು PIN ಮೂಲಕ ಲಾಗಿನ್ ಆಗುತ್ತಾರೆ. ಮರೆತರೆ ಹೊಸ PIN ಹೊಂದಿಸಿ. ಪದೇ ಪದೇ ತಪ್ಪು PIN ಹಾಕಿದರೆ, ನೀವು ರೀಸೆಟ್ ಮಾಡುವವರೆಗೆ PIN ಲಾಕ್ ಆಗುತ್ತದೆ.';

  @override
  String get lsResetPin => 'PIN ರೀಸೆಟ್';

  @override
  String get lsPinSet => 'PIN ಹೊಂದಿಸಿದ್ದು';

  @override
  String lsLocked(int n) {
    return 'ಲಾಕ್ · $n ತಪ್ಪು';
  }

  @override
  String get lsNewPin => 'ಹೊಸ PIN';

  @override
  String get lsConfPin => 'PIN ದೃಢೀಕರಿಸಿ';

  @override
  String get lsPinBad => 'PIN 4 ಅಂಕಿ ಇರಬೇಕು';

  @override
  String get lsPinMismatch => 'PIN ಗಳು ಹೊಂದುತ್ತಿಲ್ಲ';

  @override
  String lsPinSetFor(String name) {
    return 'ಹೊಸ PIN ಹೊಂದಿಸಲಾಗಿದೆ: $name';
  }

  @override
  String get lsTellStaff =>
      'ಹೊಸ PIN ಅನ್ನು ನೇರವಾಗಿ ಅಥವಾ ಫೋನ್‌ನಲ್ಲಿ ತಿಳಿಸಿ. ಇದು ಮತ್ತೆ ತೋರಿಸಲಾಗದು.';

  @override
  String get lsSetPin => 'ಹೊಸ PIN ಹೊಂದಿಸಿ';

  @override
  String get lsSignOutAll => 'ಇತರ ಎಲ್ಲಾ ಸಾಧನಗಳಿಂದ ಸೈನ್ ಔಟ್';

  @override
  String get lsAllOut => 'ಇತರ ಎಲ್ಲಾ ಸಾಧನಗಳು ಸೈನ್ ಔಟ್ ಆಗಿವೆ';

  @override
  String get lsNoPin => 'ಇನ್ನೂ PIN ಇಲ್ಲ';

  @override
  String get lsOwnerOnly => 'ಸಿಬ್ಬಂದಿ PIN ಅನ್ನು ಮಾಲೀಕರು ಮಾತ್ರ ಮರುಹೊಂದಿಸಬಹುದು.';

  @override
  String get qdTitle => 'ಕೋಟ್ ವಿನ್ಯಾಸ';

  @override
  String get qdSub => 'ನಿಮ್ಮ ಕೋಟೇಶನ್ PDF ಗ್ರಾಹಕರಿಗೆ ಹೇಗೆ ಕಾಣುತ್ತದೆ.';

  @override
  String get qdTheme => 'ಥೀಮ್';

  @override
  String get qdColor => 'ಬ್ರಾಂಡ್ ಬಣ್ಣ';

  @override
  String get qdLogo => 'ಲೋಗೋ';

  @override
  String get qdLogoAdd => 'ಲೋಗೋ ಅಪ್‌ಲೋಡ್';

  @override
  String get qdLogoHint => 'PNG ಅಥವಾ JPG, ಚೌಕ ಉತ್ತಮ';

  @override
  String get qdSave => 'ವಿನ್ಯಾಸ ಉಳಿಸಿ';

  @override
  String get qdPreview => 'ಮಾದರಿ PDF ನೋಡಿ';

  @override
  String get qdSaved => 'ಕೋಟ್ ವಿನ್ಯಾಸ ಉಳಿಸಲಾಗಿದೆ';

  @override
  String get qdTheme1A => 'ಕ್ಲಾಸಿಕ್';

  @override
  String get qdTheme1B => 'ಬೋಲ್ಡ್ ಬ್ಯಾಂಡ್';

  @override
  String get qdTheme1C => 'ಸೈಡ್‌ಬಾರ್';

  @override
  String get qdTheme1D => 'ಮಿನಿಮಲ್';

  @override
  String get qdTheme1E => 'ಕಾರ್ಪೊರೇಟ್';

  @override
  String get qdTheme1F => 'ಲೆಟರ್‌ಹೆಡ್';

  @override
  String get qdThemeDesc1A => 'ಸೆರಿಫ್, ಗೆರೆಗಳು';

  @override
  String get qdThemeDesc1B => 'ಬಣ್ಣದ ಹೆಡರ್, ದುಂಡಗಿನ ಪ್ಯಾನೆಲ್';

  @override
  String get qdThemeDesc1C => 'ಎಡಭಾಗದಲ್ಲಿ ವಿವರ ಕಾಲಂ';

  @override
  String get qdThemeDesc1D => 'ಕಪ್ಪು ಬಿಳುಪು, ಎಲ್ಲೂ ಪ್ರಿಂಟ್';

  @override
  String get qdThemeDesc1E => 'ಬಾಕ್ಸ್ ಫಾರ್ಮ್, ಆಫೀಸ್ ಶಿಫ್ಟಿಂಗ್‌ಗೆ';

  @override
  String get qdThemeDesc1F => 'ಮಧ್ಯದಲ್ಲಿ, ಎರಡು ಗೆರೆ';

  @override
  String get drvTitle => 'ಚಾಲಕ ಆ್ಯಪ್';

  @override
  String get drvNone => 'ಇಂದು ಟ್ರಿಪ್ ಇಲ್ಲ';

  @override
  String get drvPlanned => 'ಯೋಜಿತ';

  @override
  String get drvOngoing => 'ಟ್ರಿಪ್‌ನಲ್ಲಿ';

  @override
  String get drvStart => 'ಟ್ರಿಪ್ ಆರಂಭ';

  @override
  String get drvEnd => 'ಟ್ರಿಪ್ ಮುಗಿಸಿ';

  @override
  String get drvDone => 'ಟ್ರಿಪ್ ಮುಗಿದಿದೆ';

  @override
  String get drvFuel => 'ಇಂಧನ';

  @override
  String get drvFuelT => 'ಇಂಧನ ಸೇರಿಸಿ';

  @override
  String get drvToll => 'ಟೋಲ್';

  @override
  String get drvTollT => 'ಟೋಲ್ ಸೇರಿಸಿ';

  @override
  String get drvLitres => 'ಲೀಟರ್';

  @override
  String get drvPlaza => 'ಪ್ಲಾಜಾ';

  @override
  String get drvAdd => 'ನಮೂದು ಸೇರಿಸಿ';

  @override
  String get drvNeedStart => 'ಆರಂಭ ಓಡೋಮೀಟರ್ ನೀಡಿ';

  @override
  String get drvNeedEnd => 'ಅಂತ್ಯ ಓಡೋಮೀಟರ್ ಆರಂಭಕ್ಕಿಂತ ಹೆಚ್ಚು ಇರಬೇಕು';

  @override
  String get drvNeedAmount => 'ಮೊತ್ತ ನೀಡಿ';

  @override
  String get drvTripKm => 'ಟ್ರಿಪ್ ಕಿಮೀ';

  @override
  String get drvTripSpend => 'ಟ್ರಿಪ್ ಖರ್ಚು';

  @override
  String get drvToday => 'ಇಂದಿನ ನಮೂದುಗಳು';

  @override
  String get drvOdoStart => 'ಆರಂಭ ಓಡೋಮೀಟರ್';

  @override
  String get drvOdoEnd => 'ಅಂತ್ಯ ಓಡೋಮೀಟರ್';

  @override
  String get mktTitle => 'Nagarva ಕೆಲಸಗಳು';

  @override
  String get mktSub => 'Nagarva ನಲ್ಲಿ ಗ್ರಾಹಕರು ಬುಕ್ ಮಾಡಿದ ಸ್ಥಳಾಂತರಗಳು';

  @override
  String get mktTier => 'ನಿಮ್ಮ ಶ್ರೇಣಿ';

  @override
  String get mktWallet => 'ವಾಲೆಟ್';

  @override
  String mktMinL(String m) {
    return 'ಕೆಲಸ ಪಡೆಯಲು ಕನಿಷ್ಠ $m';
  }

  @override
  String get mktLowS => 'ಕನಿಷ್ಠಕ್ಕಿಂತ ಕಡಿಮೆ';

  @override
  String get mktTJobs => 'ಕೆಲಸಗಳು';

  @override
  String get mktTWallet => 'ವಾಲೆಟ್';

  @override
  String get mktTTier => 'ಶ್ರೇಣಿ';

  @override
  String get mktAv => 'ಕೆಲಸಕ್ಕೆ ಲಭ್ಯ';

  @override
  String mktAvOn(String c) {
    return '$c ಜಾಬ್ ಅಲರ್ಟ್ ಬರುತ್ತಿವೆ';
  }

  @override
  String get mktAvOff => 'ಆಫ್. ಹೊಸ ಜಾಬ್ ಅಲರ್ಟ್ ಇಲ್ಲ. ಸ್ಕೋರ್‌ಗೆ ಪರಿಣಾಮವಿಲ್ಲ.';

  @override
  String get mktCities => 'ಪಿಕಪ್ ನಗರಗಳು';

  @override
  String get mktCitiesN =>
      'ಈ ನಗರಗಳಿಂದ ಆರಂಭವಾಗುವ ಬುಕಿಂಗ್‌ಗೆ ಅಲರ್ಟ್ ಬರುತ್ತದೆ. ಸ್ವಂತ ನಗರ ತೆಗೆಯಲಾಗದು.';

  @override
  String get mktEdit => 'ಬದಲಿಸಿ';

  @override
  String get mktDone2 => 'ಮುಗಿದಿದೆ';

  @override
  String get mktCancel => 'ರದ್ದು';

  @override
  String get mktHome => 'ಸ್ವಂತ';

  @override
  String get mktRtAsk => 'ವಾಹನ ಬೇರೆ ನಗರದಲ್ಲಿದೆಯೇ?';

  @override
  String get mktRtAdd => 'ಸೇರಿಸಿ';

  @override
  String get mktRtEnd => 'ಮುಗಿಸಿ';

  @override
  String get mktRtFrom => 'ವಾಹನ ಈಗ ಇರುವುದು';

  @override
  String get mktRtDate => 'ಹೊರಡುವ ದಿನ';

  @override
  String mktRtOn(String f, String t) {
    return 'ರಿಟರ್ನ್ ಟ್ರಿಪ್ · $f → $t';
  }

  @override
  String get mktRtEnded => 'ರಿಟರ್ನ್ ಟ್ರಿಪ್ ಮುಗಿದಿದೆ';

  @override
  String get mktFNew => 'ಹೊಸದು';

  @override
  String get mktFAcc => 'ಒಪ್ಪಿದವು';

  @override
  String get mktFDone => 'ಮುಗಿದವು';

  @override
  String get mktENew => 'ಈಗ ಹೊಸ ಕೆಲಸ ಇಲ್ಲ. ಬಂದಾಗ ಸೂಚನೆ ಬರುತ್ತದೆ.';

  @override
  String get mktEAcc => 'ಒಪ್ಪಿದ ಕೆಲಸ ಇಲ್ಲ.';

  @override
  String get mktEDone => 'ಇನ್ನೂ ಮುಗಿದ ಕೆಲಸ ಇಲ್ಲ.';

  @override
  String get mktEOff => 'ನೀವು ಲಭ್ಯವಿಲ್ಲ. ಹೊಸ ಬುಕಿಂಗ್ ನೋಡಲು ಆನ್ ಮಾಡಿ.';

  @override
  String mktLow(String a, String m) {
    return 'ವಾಲೆಟ್ $m ಕ್ಕಿಂತ ಕಡಿಮೆ. ಹೊಸ ಕೆಲಸ ನೋಡಲು $a ಟಾಪ್-ಅಪ್ ಮಾಡಿ.';
  }

  @override
  String get mktVal => 'ಕೆಲಸದ ಮೌಲ್ಯ (GST ಸಹಿತ)';

  @override
  String mktCom(String p) {
    return 'Nagarva ಕಮಿಷನ್ $p%';
  }

  @override
  String get mktEarn => 'ನಿಮ್ಮ ಗಳಿಕೆ';

  @override
  String get mktAdv => 'Nagarva ಗೆ ಪಾವತಿಸಿದ ಮುಂಗಡ';

  @override
  String get mktBal => 'ಡೆಲಿವರಿ OTP ನಂತರ ಸಂಗ್ರಹಿಸಿ';

  @override
  String get mktMasked => 'ಒಪ್ಪಿದ ನಂತರ ಗ್ರಾಹಕರ ಹೆಸರು, ಫೋನ್ ಕಾಣುತ್ತದೆ';

  @override
  String get mktPass => 'ಬಿಡಿ';

  @override
  String get mktAccept => 'ಕೆಲಸ ಒಪ್ಪಿಕೊಳ್ಳಿ';

  @override
  String mktAccepted(String id) {
    return '$id ನಿಮ್ಮದು. ಗ್ರಾಹಕರ ವಿವರ ತೆರೆಯಿತು.';
  }

  @override
  String get mktPassed => 'ಕೆಲಸ ಬಿಡಲಾಗಿದೆ';

  @override
  String get mktTaken => 'ಬೇರೆ ವೆಂಡರ್ ತೆಗೆದುಕೊಂಡರು';

  @override
  String get mktGoldOnly => 'ಗೋಲ್ಡ್ ಮಾತ್ರ';

  @override
  String get mktRl => 'ರಿಟರ್ನ್ ಲೋಡ್';

  @override
  String get mktS0 => 'ಒಪ್ಪಿಗೆ';

  @override
  String get mktS1 => 'ದಾರಿಯಲ್ಲಿ';

  @override
  String get mktS2 => 'ತಲುಪಿದೆ';

  @override
  String get mktS3 => 'ಲೋಡಿಂಗ್';

  @override
  String get mktS4 => 'ಪ್ರಯಾಣದಲ್ಲಿ';

  @override
  String get mktS5 => 'ಡೆಲಿವರಿ';

  @override
  String mktNext(String s) {
    return '$s ಎಂದು ಗುರುತಿಸಿ';
  }

  @override
  String mktPhotos(int n) {
    return 'ಲೋಡಿಂಗ್ ಫೋಟೋ $n/3';
  }

  @override
  String get mktNeedPh => 'ಮೊದಲು 3 ಲೋಡಿಂಗ್ ಫೋಟೋ ಸೇರಿಸಿ';

  @override
  String get mktAddPh => 'ಫೋಟೋ ಸೇರಿಸಿ';

  @override
  String get mktFinish => 'OTP ಪರಿಶೀಲಿಸಿ ಮುಗಿಸಿ';

  @override
  String get mktOtpBad => 'ತಪ್ಪು OTP. ಗ್ರಾಹಕರೊಂದಿಗೆ ಪರಿಶೀಲಿಸಿ.';

  @override
  String mktDone(String a, String c) {
    return 'ಮುಗಿದಿದೆ. $c ಕಮಿಷನ್ ಕಡಿತ, $a ಮುಂಗಡ ಜಮೆ.';
  }

  @override
  String mktRate(String r) {
    return 'ಗ್ರಾಹಕ ರೇಟಿಂಗ್ $r';
  }

  @override
  String get mktNoRate => 'ಗ್ರಾಹಕ ರೇಟಿಂಗ್ ಬರಬೇಕಿದೆ';

  @override
  String get mktTopup => 'ಟಾಪ್-ಅಪ್';

  @override
  String get mktWBal => 'ವಾಲೆಟ್ ಬ್ಯಾಲೆನ್ಸ್';

  @override
  String get mktWOk => 'ಸಕ್ರಿಯ · ಹೊಸ ಕೆಲಸ ಸಿಗುತ್ತದೆ';

  @override
  String get mktWWithdraw => 'ಹಿಂಪಡೆಯಿರಿ';

  @override
  String mktWNote(String p) {
    return 'ಗ್ರಾಹಕರು ಮುಂಗಡವನ್ನು Nagarva ಗೆ ಪಾವತಿಸುತ್ತಾರೆ. ಕೆಲಸ ಮುಗಿದಾಗ ಮುಂಗಡ ಇಲ್ಲಿ ಜಮೆಯಾಗಿ $p% ಕಮಿಷನ್ ಕಡಿತವಾಗುತ್ತದೆ. ಕೆಲಸ ಪಡೆಯಲು ಕನಿಷ್ಠ ಬ್ಯಾಲೆನ್ಸ್ ಇಡಿ.';
  }

  @override
  String mktWtAdv(String id) {
    return 'ಮುಂಗಡ · $id';
  }

  @override
  String mktWtCom(String id) {
    return 'ಕಮಿಷನ್ · $id';
  }

  @override
  String get mktWtTop => 'UPI ಟಾಪ್-ಅಪ್';

  @override
  String get mktWtWd => 'ಬ್ಯಾಂಕ್‌ಗೆ ಹಿಂಪಡೆತ';

  @override
  String get mktTierF => 'ನಿಮ್ಮ ಸ್ಕೋರ್ ಹೇಗೆ';

  @override
  String get mktTierBands => 'ಗೋಲ್ಡ್ 80+ · ಸಿಲ್ವರ್ 60–79 · ಬ್ರಾಂಜ್ <60';

  @override
  String get mktTierGold => 'ಗೋಲ್ಡ್';

  @override
  String get mktTierSilver => 'ಸಿಲ್ವರ್';

  @override
  String get mktTierBronze => 'ಬ್ರಾಂಜ್';

  @override
  String mktTierScore(String s) {
    return 'ಸ್ಕೋರ್ $s / 100';
  }

  @override
  String get mktOtpAsk => 'ಗ್ರಾಹಕರಿಂದ 4 ಅಂಕಿಯ ಡೆಲಿವರಿ ಕೋಡ್ ಕೇಳಿ.';

  @override
  String get mktReqSent =>
      'ವಿನಂತಿ ಕಳುಹಿಸಲಾಗಿದೆ. Nagarva ಪಾವತಿ ದೃಢಪಡಿಸಿದ ನಂತರ ಎಣಿಕೆಯಾಗುತ್ತದೆ.';

  @override
  String get mktPending => 'ಬಾಕಿ';

  @override
  String get mktHomeCity => 'ಮನೆ ನಗರ';

  @override
  String get mktExtraCities => 'ಇತರ ನಗರಗಳು, ಅಲ್ಪವಿರಾಮದಿಂದ ಬೇರ್ಪಡಿಸಿ';

  @override
  String get mktNotJoined => 'Nagarva ಕೆಲಸಗಳನ್ನು ಪಡೆಯಲು ನಿಮ್ಮ ಮನೆ ನಗರ ಹೊಂದಿಸಿ.';

  @override
  String get mktFactorNote =>
      'Nagarva ನಿಮ್ಮ ಸ್ಕೋರ್ ಅನ್ನು ಇವುಗಳಿಂದ, ಈ ತೂಕಗಳೊಂದಿಗೆ ಲೆಕ್ಕಹಾಕುತ್ತದೆ.';

  @override
  String get mktFRating => 'ಗ್ರಾಹಕ ರೇಟಿಂಗ್';

  @override
  String get mktFOnTime => 'ಸಮಯಕ್ಕೆ ಆಗಮನ';

  @override
  String get mktFDamage => 'ಹಾನಿ ಕ್ಲೈಮ್‌ಗಳು';

  @override
  String get mktFAccept => 'ಸ್ವೀಕಾರ ದರ';

  @override
  String get mktFPhotos => 'ಫೋಟೋ ಅನುಸರಣೆ';

  @override
  String get mktFCancel => 'ವೆಂಡರ್ ರದ್ದತಿಗಳು';

  @override
  String get mktFJobs => 'ಪೂರ್ಣಗೊಂಡ ಕೆಲಸಗಳು';

  @override
  String get mktAvOnT => 'ಜಾಬ್ ಅಲರ್ಟ್ ಮತ್ತೆ ಬರುತ್ತವೆ';

  @override
  String get mktAvOffT => 'ಜಾಬ್ ಅಲರ್ಟ್ ನಿಲ್ಲಿಸಲಾಗಿದೆ';
}
