import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '/main.dart';
import '/app_session.dart';
import '/backend/device_org_binding.dart';
import '/backend/pending_password_reset.dart';
import '/components/coming_soon_page.dart';
import '/nav_items.dart';
import '/permissions.dart';
import '/flutter_flow/flutter_flow_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  bool showSplashImage = true;

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

// Routes reachable without an AppSession — everything else bounces to
// /login. Found missing during item 1's retest: navigating straight to
// e.g. /calendar after Logout rendered the page with empty data instead
// of redirecting, since nothing but each page's own queries enforced
// auth. main() fully awaits Supabase session restore before runApp() (see
// main.dart), so this can't race a still-restoring session on cold start.
// WHERE CUSTOMER LINKS ACTUALLY RESOLVE (29 Jul 2026). kPublicBaseUrl now
// points at link.nagarva.in — a plain static site, NOT this Flutter build.
// So a customer opening a shared link never reaches the routes below:
//
//   /survey  -> STATIC SITE. Live and verified end-to-end.
//   /sign    -> STATIC SITE. Live.
//   /quote   -> NOTHING SERVES IT. Still 404s for the customer.
//   /track   -> NOTHING SERVES IT. Still 404s for the customer.
//
// /track is the one the handoff brief missed: "Share Tracking Link" on
// Order Details builds its URL from the same kPublicBaseUrl, so it broke
// the moment that constant moved off nagarva.in, in exactly the way
// /quote did.
//
// UPDATED 15 Sept 2026 — the warning that used to end this block ("if
// the originals are ever dropped, these pages break silently") came
// true, deliberately, and is resolved rather than left standing. All four
// original RPCs were dropped:
// supabase/20260915_drop_ungated_public_rpcs.sql. They were SECURITY
// DEFINER with anon holding DIRECT EXECUTE and no wrapper, and their
// bodies — not merely their missing gate — returned customer phone
// numbers, skipped every expiry check and let any token holder overwrite
// a customer's identity fields.
//
// SurveyPage and QuotePage were DELETED with them, routes and exports
// included. Neither could work without those RPCs, and a page that cannot
// load while still sitting in the tree reads as alive — the same shape as
// a share button handing a customer a dead link. Git holds both layouts
// if the /quote rebuild wants them:
// `git show 3199ea1:lib/quote_page/quote_page_widget.dart` (3199ea1 is
// the last commit before this change, so both files are intact there).
//
//   /survey — served by public_site/, which calls the public_* pair.
//   /quote  — never served by anything, ever. kQuoteLinkHosted is false.
//             When it is built it goes through the WRAPPER PATTERN
//             (public_get_quotation / public_accept_quotation, each
//             calling an _impl locked to postgres/service_role), never by
//             restoring the dropped pair.
//   /sign   — unaffected; both go through Edge Functions
//   /track    (sign-document, track-order), not the dropped RPCs, and
//             their Flutter pages remain the only implementations.
const _kPublicRoutePrefixes = [
  '/login',
  '/signup',
  '/survey',
  '/quote',
  '/sign',
  '/track',
  '/pin-login',
  '/bind-org',
  '/admin-login',
];

bool _isPublicRoute(String path) =>
    path == '/' || _kPublicRoutePrefixes.any((p) => path.startsWith(p));

/// Route guard (Users Kickoff Step 2.4 / permission-model decision 4).
///
/// `StaffPermissions.activeStaffPages` only ever filtered which tabs the
/// sidebar/bottom-nav/drawer render — presentation, not enforcement. A
/// deep link, a stale nav stack, or (on web) a typed URL reached the
/// target page directly regardless. This closes that: deliberately
/// scoped to top-level nav destinations only (the three lists in
/// nav_items.dart) — detail/action pages (OrderDetailPage,
/// NewOrderPage, a staff sheet, ...) are not nav destinations at all and
/// are intentionally NOT covered here, since none of the three role nav
/// sets name them; those stay gated by the existing per-button
/// `StaffPermissions.canActive` checks, which is the correct layer for
/// them, not a blanket route-level block that would also stop
/// legitimate in-app navigation (tap an order -> OrderDetailPage) for
/// every session type.
bool _isTopLevelNavRoute(String routeName) =>
    kOwnerManagerNavItems.any((i) => i.name == routeName) ||
    kSupervisorNavItems.any((i) => i.name == routeName) ||
    kFieldStaffNavItems.any((i) => i.name == routeName);

bool _routeAllowedForCurrentSession(String routeName) {
  if (AppSession.instance.currentStaffId == null)
    return true; // owner/vendor: never filtered
  if (isOwnerOrManagerSession) {
    // Manager: same permission-driven set main.dart's _navItems computes.
    // Null (not loaded yet) fails open rather than bouncing a fresh
    // session before StaffPermissions.loadForStaff() has even resolved.
    final allowed = StaffPermissions.activeStaffPages;
    return allowed == null || allowed.contains(routeName);
  }
  // Supervisor/field-staff: fixed by role, not permission-matrix-driven.
  final fixedSet = AppSession.instance.currentStaffRole == 'supervisor'
      ? kSupervisorNavItems
      : kFieldStaffNavItems;
  return fixedSet.any((i) => i.name == routeName);
}

/// Refresh-after-write fix (parity brief Part 1, 27 Jul 2026).
///
/// Root cause: NavBarPage swaps its single `body` slot between tab widgets
/// (Home/Orders/Leads/... — see main.dart's `_tabs`/`_currentPage`), so a
/// tab's State is created once and reused for as long as that tab stays
/// selected. Every list/dashboard page fetched its data once in `initState`
/// with no way to know a route pushed on top of it (RecordPaymentPage,
/// NewOrderPage, a staff-advance sheet, ...) had written new data — popping
/// back just revealed the same State object with its stale in-memory list.
/// Switching tabs "fixed" it only because that path *does* dispose/recreate
/// the State, which is what made this look like a per-screen quirk instead
/// of one systemic gap.
///
/// Fix: a single RouteObserver on the root Navigator, subscribed to by every
/// affected page via the RefreshOnPopMixin below. `didPopNext()` fires
/// exactly when a route pushed on top of a subscribed page is popped, so
/// each page can re-run its existing load method without needing every push
/// call site to be awaited/chained individually.
///
/// Typed on [ModalRoute] rather than [PageRoute]: several of the write
/// surfaces this needs to catch (StaffLedgerSheet's Pay/Advance/Settle,
/// staff_form_sheet, plan_edit_sheet, ...) are `showModalBottomSheet`/
/// `showDialog` routes, which are [PopupRoute]s, not [PageRoute]s — both
/// extend [ModalRoute], which is the common type that covers full pushed
/// pages, dialogs, and bottom sheets alike. `RouteObserver.didPop` only
/// fires when both the popped route and the route below it match the
/// observer's generic type, so `PageRoute` would silently miss every
/// sheet/dialog dismissal.
final RouteObserver<ModalRoute<dynamic>> nagarvaRouteObserver =
    RouteObserver<ModalRoute<dynamic>>();

/// Mix into a page's State to re-fetch data whenever a route pushed on top
/// of it is popped. Implement [onPageRefresh] to call the page's existing
/// load method (e.g. `_loadData()`); everything else is handled here.
mixin RefreshOnPopMixin<T extends StatefulWidget> on State<T>
    implements RouteAware {
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route != null) {
      nagarvaRouteObserver.subscribe(this, route);
    }
  }

  @override
  void dispose() {
    nagarvaRouteObserver.unsubscribe(this);
    super.dispose();
  }

  @override
  void didPush() {}

  @override
  void didPop() {}

  @override
  void didPushNext() {}

  @override
  void didPopNext() => onPageRefresh();

  /// Called when this page becomes visible again after a route pushed on
  /// top of it was popped — re-run the page's data load here.
  void onPageRefresh();
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      observers: [nagarvaRouteObserver],
      errorBuilder: (context, state) => const LoginPageWidget(),
      redirect: (context, state) {
        final path = state.uri.path;
        if (_isPublicRoute(path)) return null;
        // Nagarva Admin: a platform admin need not belong to any vendor
        // org, so the panel is gated on the admin sign-in instead of the
        // org session, and an unauthenticated visit goes to the admin
        // login, not the vendor one. The page itself re-checks
        // platform_admins, and RLS enforces it on every query.
        if (path.startsWith(SuperAdminPageWidget.routePath)) {
          final s = AppSession.instance;
          return s.authUserId != null && s.isPlatformAdmin
              ? null
              : AdminLoginPage.routePath;
        }
        if (!AppSession.instance.isAuthenticated) {
          return LoginPageWidget.routePath;
        }
        final routeName = state.name;
        if (routeName != null &&
            _isTopLevelNavRoute(routeName) &&
            !_routeAllowedForCurrentSession(routeName)) {
          final home = homeNavNameForCurrentSession();
          try {
            return GoRouter.of(context).namedLocation(home);
          } catch (_) {
            // Should not happen (home is always one of the three fixed
            // nav sets, all registered above) - fail toward a known-safe
            // route rather than propagate a router exception.
            return LoginPageWidget.routePath;
          }
        }
        return null;
      },
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          // NG-BRIEF-vendor-auth-flow.md §4 (12 Aug 2026), superseding
          // Part 7's original shape: a bound device still goes straight to
          // the PIN screen, but an UNBOUND device now lands on
          // LoginPageWidget (vendor email/password + its own "Create an
          // account" link to SignupPageWidget) instead of
          // OrgBindingPageWidget — asking a brand-new vendor for an
          // organization code they cannot possibly have was the actual
          // signup-funnel bug this brief exists to close. Staff normally
          // arrive via an invite link and never hit this route at all;
          // OrgBindingPageWidget is still reachable, unchanged, via
          // LoginPageWidget's new "Joining a team? Use an org or invite
          // code" link, for the fallback case of a staff member who
          // installed the app manually.
          // 17 Aug 2026: a type=recovery deep link processed before
          // runApp() (main()'s AuthDeepLinkHandler.handleInitialLink(),
          // cold start — there is no live GoRouter yet at that point for
          // an explicit router.go()) sets PendingPasswordReset.active as
          // a side effect. Checked first, ahead of the ordinary bound/
          // unbound branch, so that flag is the one thing that can
          // override where a cold start lands.
          builder: (context, _) => PendingPasswordReset.active
              ? const SetNewPasswordPageWidget()
              : (DeviceOrgBinding.isBound
                  ? const PinLoginPageWidget()
                  : const LoginPageWidget()),
        ),
        FFRoute(
          name: LoginPageWidget.routeName,
          path: LoginPageWidget.routePath,
          builder: (context, params) => const LoginPageWidget(),
        ),
        FFRoute(
          name: PinLoginPageWidget.routeName,
          path: PinLoginPageWidget.routePath,
          builder: (context, params) => const PinLoginPageWidget(),
        ),
        FFRoute(
          name: SetNewPasswordPageWidget.routeName,
          path: SetNewPasswordPageWidget.routePath,
          builder: (context, params) => const SetNewPasswordPageWidget(),
        ),
        // NOT a public route (28 Aug 2026): reached only after a real
        // email login, so it stays behind the `redirect:` auth guard —
        // it writes a credential and must never be reachable by URL to
        // an unauthenticated caller.
        FFRoute(
          name: SetOwnerPinPageWidget.routeName,
          path: SetOwnerPinPageWidget.routePath,
          builder: (context, params) => const SetOwnerPinPageWidget(),
        ),
        FFRoute(
          name: OrgBindingPageWidget.routeName,
          path: OrgBindingPageWidget.routePath,
          builder: (context, params) => const OrgBindingPageWidget(),
        ),
        FFRoute(
          name: HomePageWidget.routeName,
          path: HomePageWidget.routePath,
          // pin_login_page_widget.dart sends EVERY successful login here
          // (`context.go(HomePageWidget.routePath)`), owner and staff
          // alike — this was unconditionally forcing `initialPage:
          // 'HomePage'`, a tab name that doesn't exist in a supervisor's
          // or field-staff's own `_tabs` map (main.dart). NavBarPage
          // rendered `tabs['HomePage'] ?? const SizedBox.shrink()` — i.e.
          // nothing at all, not even the AppBar — until the person
          // manually tapped a bottom-nav item, which set a real page name
          // via _selectTab. Passing null for a non-owner/manager session
          // lets NavBarPage's own `homeNavNameForCurrentSession()` (which
          // already returns the correct role-specific landing page) run
          // instead of being pre-empted by this route's hardcoded value.
          builder: (context, params) => params.isEmpty
              ? NavBarPage(
                  initialPage: isOwnerOrManagerSession ? 'HomePage' : null)
              : const HomePageWidget(),
        ),
        FFRoute(
          name: OrdersPageWidget.routeName,
          path: OrdersPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'OrdersPage')
              : const OrdersPageWidget(),
        ),
        FFRoute(
          name: LeadsPageWidget.routeName,
          path: LeadsPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'LeadsPage')
              : const LeadsPageWidget(),
        ),
        FFRoute(
          name: OperationsPageWidget.routeName,
          path: OperationsPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'OperationsPage')
              : const OperationsPageWidget(),
        ),
        FFRoute(
          name: PaymentsPageWidget.routeName,
          path: PaymentsPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'PaymentsPage')
              : const PaymentsPageWidget(),
        ),
        FFRoute(
          name: ExpensePageWidget.routeName,
          path: ExpensePageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'ExpensePage')
              : const ExpensePageWidget(),
        ),
        FFRoute(
          name: SalaryPageWidget.routeName,
          path: SalaryPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'SalaryPage')
              : const SalaryPageWidget(),
        ),
        FFRoute(
          name: FleetPageWidget.routeName,
          path: FleetPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'FleetPage')
              : const FleetPageWidget(),
        ),
        FFRoute(
          name: SurveyQuotePageWidget.routeName,
          path: SurveyQuotePageWidget.routePath,
          builder: (context, params) => SurveyQuotePageWidget(
            // Prefills the builder from a submitted customer survey.
            surveyId: params.getParam('surveyId', ParamType.String),
            // EDIT MODE. When set, the builder loads that quotation and
            // saves through revise_quote() instead of inserting a new
            // row — see the widget's own doc comment.
            quotationId: params.getParam('quotationId', ParamType.String),
            leadId: params.getParam('leadId', ParamType.String),
            leadCustomer: params.getParam('leadCustomer', ParamType.String),
            leadPhone: params.getParam('leadPhone', ParamType.String),
            leadFromCity: params.getParam('leadFromCity', ParamType.String),
            leadToCity: params.getParam('leadToCity', ParamType.String),
          ),
        ),
        FFRoute(
          name: AccountsPageWidget.routeName,
          path: AccountsPageWidget.routePath,
          builder: (context, params) => const AccountsPageWidget(),
        ),
        FFRoute(
          name: PLReportPageWidget.routeName,
          path: PLReportPageWidget.routePath,
          builder: (context, params) => const PLReportPageWidget(),
        ),
        FFRoute(
          name: SettingsPageWidget.routeName,
          path: SettingsPageWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'SettingsPage')
              : const SettingsPageWidget(),
        ),
        FFRoute(
          name: CalendarPageWidget.routeName,
          path: CalendarPageWidget.routePath,
          builder: (context, params) => const CalendarPageWidget(),
        ),
        FFRoute(
          name: AdminLoginPage.routeName,
          path: AdminLoginPage.routePath,
          builder: (context, params) => const AdminLoginPage(),
        ),
        FFRoute(
          name: SuperAdminPageWidget.routeName,
          path: SuperAdminPageWidget.routePath,
          builder: (context, params) => const SuperAdminPageWidget(),
        ),
        FFRoute(
          name: MaterialsPageWidget.routeName,
          path: MaterialsPageWidget.routePath,
          builder: (context, params) => const MaterialsPageWidget(),
        ),
        FFRoute(
          name: LostReportPage.routeName,
          path: LostReportPage.routePath,
          builder: (context, params) => const LostReportPage(),
        ),
        FFRoute(
          name: ReferralsPage.routeName,
          path: ReferralsPage.routePath,
          builder: (context, params) => const ReferralsPage(),
        ),
        FFRoute(
          name: DailySummaryPage.routeName,
          path: DailySummaryPage.routePath,
          builder: (context, params) => const DailySummaryPage(),
        ),
        FFRoute(
          name: ApprovalsPage.routeName,
          path: ApprovalsPage.routePath,
          builder: (context, params) => const ApprovalsPage(),
        ),
        FFRoute(
          name: GstPage.routeName,
          path: GstPage.routePath,
          builder: (context, params) => const GstPage(),
        ),
        FFRoute(
          name: CreditNotesPage.routeName,
          path: CreditNotesPage.routePath,
          builder: (context, params) => const CreditNotesPage(),
        ),
        FFRoute(
          name: BankMatchPage.routeName,
          path: BankMatchPage.routePath,
          builder: (context, params) => const BankMatchPage(),
        ),
        FFRoute(
          name: CashBookPage.routeName,
          path: CashBookPage.routePath,
          builder: (context, params) => const CashBookPage(),
        ),
        FFRoute(
          name: PayslipsPage.routeName,
          path: PayslipsPage.routePath,
          builder: (context, params) => const PayslipsPage(),
        ),
        FFRoute(
          name: StorageBillingPage.routeName,
          path: StorageBillingPage.routePath,
          builder: (context, params) => const StorageBillingPage(),
        ),
        FFRoute(
          name: MarketplaceJobsPage.routeName,
          path: MarketplaceJobsPage.routePath,
          builder: (context, params) => const MarketplaceJobsPage(),
        ),
        FFRoute(
          name: DriverAppPage.routeName,
          path: DriverAppPage.routePath,
          builder: (context, params) => const DriverAppPage(),
        ),
        FFRoute(
          name: FieldAttendancePageWidget.routeName,
          path: FieldAttendancePageWidget.routePath,
          builder: (context, params) => const FieldAttendancePageWidget(),
        ),
        FFRoute(
          name: FuelPage.routeName,
          path: FuelPage.routePath,
          builder: (context, params) => const FuelPage(),
        ),
        FFRoute(
          name: VehicleDocsPage.routeName,
          path: VehicleDocsPage.routePath,
          builder: (context, params) => const VehicleDocsPage(),
        ),
        FFRoute(
          name: EwayBillsPage.routeName,
          path: EwayBillsPage.routePath,
          builder: (context, params) => const EwayBillsPage(),
        ),
        FFRoute(
          name: LeadSourcesPage.routeName,
          path: LeadSourcesPage.routePath,
          builder: (context, params) => const LeadSourcesPage(),
        ),
        FFRoute(
          name: ActivityLogPage.routeName,
          path: ActivityLogPage.routePath,
          builder: (context, params) => const ActivityLogPage(),
        ),
        FFRoute(
          name: BusinessAccountsPage.routeName,
          path: BusinessAccountsPage.routePath,
          builder: (context, params) => const BusinessAccountsPage(),
        ),
        FFRoute(
          name: PartLoadPage.routeName,
          path: PartLoadPage.routePath,
          builder: (context, params) => const PartLoadPage(),
        ),
        FFRoute(
          name: StaffDocumentsPage.routeName,
          path: StaffDocumentsPage.routePath,
          builder: (context, params) => const StaffDocumentsPage(),
        ),
        FFRoute(
          name: LabourContractorsPage.routeName,
          path: LabourContractorsPage.routePath,
          builder: (context, params) => const LabourContractorsPage(),
        ),
        FFRoute(
          name: DieselAdvancePage.routeName,
          path: DieselAdvancePage.routePath,
          builder: (context, params) => const DieselAdvancePage(),
        ),
        FFRoute(
          name: HiredTrucksPage.routeName,
          path: HiredTrucksPage.routePath,
          builder: (context, params) => const HiredTrucksPage(),
        ),
        FFRoute(
          name: ModulesPage.routeName,
          path: ModulesPage.routePath,
          builder: (context, params) => const ModulesPage(),
        ),
        FFRoute(
          name: DashboardWidgetsPage.routeName,
          path: DashboardWidgetsPage.routePath,
          builder: (context, params) => const DashboardWidgetsPage(),
        ),
        FFRoute(
          name: QuoteDesignPage.routeName,
          path: QuoteDesignPage.routePath,
          builder: (context, params) => const QuoteDesignPage(),
        ),
        FFRoute(
          name: WhatsAppPage.routeName,
          path: WhatsAppPage.routePath,
          builder: (context, params) => const WhatsAppPage(),
        ),
        FFRoute(
          name: AutoWhatsAppPage.routeName,
          path: AutoWhatsAppPage.routePath,
          builder: (context, params) => const AutoWhatsAppPage(),
        ),
        FFRoute(
          name: BackupPage.routeName,
          path: BackupPage.routePath,
          builder: (context, params) => const BackupPage(),
        ),
        FFRoute(
          name: LeavePage.routeName,
          path: LeavePage.routePath,
          builder: (context, params) => const LeavePage(),
        ),
        FFRoute(
          name: IncentivesPage.routeName,
          path: IncentivesPage.routePath,
          builder: (context, params) => const IncentivesPage(),
        ),
        FFRoute(
          name: WarehousesPageWidget.routeName,
          path: WarehousesPageWidget.routePath,
          builder: (context, params) => const WarehousesPageWidget(),
        ),
        FFRoute(
          name: ReportsPageWidget.routeName,
          path: ReportsPageWidget.routePath,
          builder: (context, params) => const ReportsPageWidget(),
        ),
        FFRoute(
          name: UsersPageWidget.routeName,
          path: UsersPageWidget.routePath,
          builder: (context, params) => const UsersPageWidget(),
        ),
        FFRoute(
          name: RecordPaymentPageWidget.routeName,
          path: RecordPaymentPageWidget.routePath,
          builder: (context, params) => RecordPaymentPageWidget(
            orderId: params.getParam('orderId', ParamType.String),
          ),
        ),
        // Redesign (20 Oct 2026): the order journey — a read model over the
        // lead and order, opened from Lead/Order Details. Either id is
        // enough; see JourneyLoader.
        FFRoute(
          name: OrderJourneyPageWidget.routeName,
          path: OrderJourneyPageWidget.routePath,
          builder: (context, params) => OrderJourneyPageWidget(
            leadId: params.getParam('leadId', ParamType.String),
            orderId: params.getParam('orderId', ParamType.String),
          ),
        ),
        FFRoute(
          name: QuickExpensePageWidget.routeName,
          path: QuickExpensePageWidget.routePath,
          builder: (context, params) => const QuickExpensePageWidget(),
        ),
        FFRoute(
          name: NewOrderPageWidget.routeName,
          path: NewOrderPageWidget.routePath,
          builder: (context, params) => NewOrderPageWidget(
            orderId: params.getParam('orderId', ParamType.String),
          ),
        ),
        FFRoute(
          name: OrderDetailPageWidget.routeName,
          path: OrderDetailPageWidget.routePath,
          builder: (context, params) => OrderDetailPageWidget(
            orderId: params.getParam(
              'orderId',
              ParamType.String,
            ),
            orderCustomer: params.getParam(
              'orderCustomer',
              ParamType.String,
            ),
            orderPhone: params.getParam(
              'orderPhone',
              ParamType.String,
            ),
            orderFromCity: params.getParam(
              'orderFromCity',
              ParamType.String,
            ),
            orderToCity: params.getParam(
              'orderToCity',
              ParamType.String,
            ),
            orderFromAddress: params.getParam(
              'orderFromAddress',
              ParamType.String,
            ),
            orderToAddress: params.getParam(
              'orderToAddress',
              ParamType.String,
            ),
            orderFromFloor: params.getParam(
              'orderFromFloor',
              ParamType.String,
            ),
            orderToFloor: params.getParam(
              'orderToFloor',
              ParamType.String,
            ),
            orderMoveDate: params.getParam(
              'orderMoveDate',
              ParamType.String,
            ),
            orderAmount: params.getParam(
              'orderAmount',
              ParamType.String,
            ),
            orderStatus: params.getParam(
              'orderStatus',
              ParamType.String,
            ),
            orderPaymentStatus: params.getParam(
              'orderPaymentStatus',
              ParamType.String,
            ),
            orderTrackingStatus: params.getParam(
              'orderTrackingStatus',
              ParamType.String,
            ),
            orderService: params.getParam(
              'orderService',
              ParamType.String,
            ),
            orderBranch: params.getParam(
              'orderBranch',
              ParamType.String,
            ),
            orderType: params.getParam(
              'orderType',
              ParamType.String,
            ),
            orderNotes: params.getParam(
              'orderNotes',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: NewLeadPageWidget.routeName,
          path: NewLeadPageWidget.routePath,
          builder: (context, params) => NewLeadPageWidget(
            leadId: params.getParam('leadId', ParamType.String),
          ),
        ),
        FFRoute(
          name: LeadDetailPageWidget.routeName,
          path: LeadDetailPageWidget.routePath,
          builder: (context, params) => LeadDetailPageWidget(
            leadId: params.getParam(
              'leadId',
              ParamType.String,
            ),
            leadCustomer: params.getParam(
              'leadCustomer',
              ParamType.String,
            ),
            leadPhone: params.getParam(
              'leadPhone',
              ParamType.String,
            ),
            leadEmail: params.getParam(
              'leadEmail',
              ParamType.String,
            ),
            leadFromCity: params.getParam(
              'leadFromCity',
              ParamType.String,
            ),
            leadToCity: params.getParam(
              'leadToCity',
              ParamType.String,
            ),
            leadApproxDate: params.getParam(
              'leadApproxDate',
              ParamType.String,
            ),
            leadService: params.getParam(
              'leadService',
              ParamType.String,
            ),
            leadSource: params.getParam(
              'leadSource',
              ParamType.String,
            ),
            leadStatus: params.getParam(
              'leadStatus',
              ParamType.String,
            ),
            leadBranch: params.getParam(
              'leadBranch',
              ParamType.String,
            ),
            leadNotes: params.getParam(
              'leadNotes',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: QuickEntryPageWidget.routeName,
          path: QuickEntryPageWidget.routePath,
          builder: (context, params) => const QuickEntryPageWidget(),
        ),
        FFRoute(
          name: SignupPageWidget.routeName,
          path: SignupPageWidget.routePath,
          builder: (context, params) => const SignupPageWidget(),
        ),
        FFRoute(
          name: VendorSignupPageWidget.routeName,
          path: VendorSignupPageWidget.routePath,
          builder: (context, params) => const VendorSignupPageWidget(),
        ),
        FFRoute(
          name: OrgSetupPageWidget.routeName,
          path: OrgSetupPageWidget.routePath,
          builder: (context, params) => const OrgSetupPageWidget(),
        ),
        FFRoute(
          name: PlanPageWidget.routeName,
          path: PlanPageWidget.routePath,
          builder: (context, params) => const PlanPageWidget(),
        ),
        // Item 11.6: owner-only recycle bin, reached from Settings.
        FFRoute(
          name: RecycleBinPage.routeName,
          path: RecycleBinPage.routePath,
          builder: (context, params) => const RecycleBinPage(),
        ),
        // Item 12: slabs + CFT catalogue editors, reached from Settings.
        FFRoute(
          name: SurveyPricingPage.routeName,
          path: SurveyPricingPage.routePath,
          builder: (context, params) => const SurveyPricingPage(),
        ),
        // Branch management (27 Aug 2026). Reached from Settings, and
        // deep-linked from New Order / New Lead's "set up a branch first"
        // empty state — which is the state a brand-new org starts in,
        // since nothing could create a branch before this screen existed.
        FFRoute(
          name: BranchesPage.routeName,
          path: BranchesPage.routePath,
          builder: (context, params) => const BranchesPage(),
        ),
        // Help & About — carries the in-app privacy policy link Play
        // Store review requires and the support contact Meta's WhatsApp
        // Business review asks for. Not owner-gated: every staff session
        // needs to reach support and the legal links too.
        FFRoute(
          name: HelpAboutPage.routeName,
          path: HelpAboutPage.routePath,
          builder: (context, params) => const HelpAboutPage(),
        ),
        FFRoute(
          name: SupervisorJobPageWidget.routeName,
          path: SupervisorJobPageWidget.routePath,
          builder: (context, params) => SupervisorJobPageWidget(
            orderId: params.getParam('orderId', ParamType.String),
          ),
        ),
        // Day-close crew sheet (staff-pay brief §4) — per-job crew,
        // wages, driver tag and A/C. Not public: it falls under the
        // GoRouter auth guard like every other non-prefixed route.
        FFRoute(
          name: CrewSheetPageWidget.routeName,
          path: CrewSheetPageWidget.routePath,
          builder: (context, params) => CrewSheetPageWidget(
            orderId: params.getParam('orderId', ParamType.String),
          ),
        ),
        // The /survey and /quote routes were REMOVED 15 Sept 2026 along
        // with SurveyPageWidget and QuotePageWidget — see the block at the
        // top of this file. Their four RPCs were dropped
        // (supabase/20260915_drop_ungated_public_rpcs.sql). /sign and
        // /track below are unaffected: they go through Edge Functions.
        // Fix brief #2 items 3 and 6 — same public-link pattern as the two
        // above, but these read/write via the sign-document / track-order
        // Edge Functions rather than anon-granted RPCs.
        FFRoute(
          name: SignPageWidget.routeName,
          path: SignPageWidget.routePath,
          builder: (context, params) => SignPageWidget(
            token: params.getParam('token', ParamType.String),
          ),
        ),
        FFRoute(
          name: TrackPageWidget.routeName,
          path: TrackPageWidget.routePath,
          builder: (context, params) => TrackPageWidget(
            token: params.getParam('token', ParamType.String),
          ),
        ),
        // Users Kickoff Step 2: real routes for every nav destination that
        // only has a Coming Soon placeholder today (see nav_items.dart).
        // Registered as actual routes, not just _tabs map keys inside
        // NavBarPage, for two reasons: HomePage's drawer navigates via
        // context.pushNamed(item.name), which needs a real route to find;
        // and the route guard below needs a real path to intercept a
        // direct deep link to one of these the same way it does for every
        // other destination.
        for (final entry in <(String name, String path, String title)>[
          // 'StaffTeamAttendance' removed (device-test follow-up):
          // dropped from kSupervisorNavItems as redundant with My Team,
          // which already does everything it would have — see
          // nav_items.dart.
          ('MySalComingSoon', '/my-sal', 'My Earnings'),
        ])
          FFRoute(
            name: entry.$1,
            path: entry.$2,
            builder: (context, params) => ComingSoonPage(title: entry.$3),
          ),
        // Session 4, Part B2: real screen — see nav_items.dart/main.dart's
        // matching updates (same "route + _tabs map must both change"
        // lesson Session 2's supervisor-screens bug already taught this
        // codebase).
        FFRoute(
          name: ReviewsPageWidget.routeName,
          path: ReviewsPageWidget.routePath,
          builder: (context, params) => const ReviewsPageWidget(),
        ),
        // Session 4, Part B3.
        FFRoute(
          name: WaInboxPageWidget.routeName,
          path: WaInboxPageWidget.routePath,
          builder: (context, params) => const WaInboxPageWidget(),
        ),
        // Session 4, Part B4. Accepts navLead for deep-linking from the
        // lead screen, per the brief's own wording.
        FFRoute(
          name: SurveyQuoteHubPageWidget.routeName,
          path: SurveyQuoteHubPageWidget.routePath,
          builder: (context, params) => SurveyQuoteHubPageWidget(
            navLead: params.getParam('navLead', ParamType.String),
          ),
        ),
        // TOMBSTONE — CustomerSurveysPage was DELETED 15 Sept 2026,
        // along with CustomerSurveysTable, its detail sheet,
        // customer_survey_parse.dart and SurveyQueue. Dormant since
        // 3 Sept; deleted because the class had stopped being merely
        // unused and become WRONG: `tableName` still resolved to
        // `customer_surveys`, but that name now belongs to the RENAMED
        // `surveys` table (20260909_consolidate_survey_tables.sql), so
        // every getter for a column of the dropped schema read null and
        // the sheet's four update paths wrote `reviewed_by`/`reviewed_at`
        // and a status vocabulary the live table does not have.
        // Unreachable, so never a live bug — a landmine, not a fire.
        // Read survey rows through SurveysTable. `git show 9febea4` has
        // the deleted files.
        // Session 4, Part C-2.
        FFRoute(
          name: RateCardsPageWidget.routeName,
          path: RateCardsPageWidget.routePath,
          builder: (context, params) => const RateCardsPageWidget(),
        ),
        FFRoute(
          name: RateCardDetailPageWidget.routeName,
          path: RateCardDetailPageWidget.routePath,
          builder: (context, params) => RateCardDetailPageWidget(
            cardId: params.getParam('cardId', ParamType.String),
          ),
        ),
        // Session 4, Part C-3.
        FFRoute(
          name: LrRegisterPageWidget.routeName,
          path: LrRegisterPageWidget.routePath,
          builder: (context, params) => const LrRegisterPageWidget(),
        ),
        // Session 4, Part C-4.
        FFRoute(
          name: OperationsStandalonePageWidget.routeName,
          path: OperationsStandalonePageWidget.routePath,
          builder: (context, params) => const OperationsStandalonePageWidget(),
        ),
        // Session 4, Part C-6.
        FFRoute(
          name: VendorsPageWidget.routeName,
          path: VendorsPageWidget.routePath,
          builder: (context, params) => const VendorsPageWidget(),
        ),
        FFRoute(
          name: VendorDetailPageWidget.routeName,
          path: VendorDetailPageWidget.routePath,
          builder: (context, params) => VendorDetailPageWidget(
            vendorId: params.getParam('vendorId', ParamType.String),
          ),
        ),
        // Session 4, Part C-7.
        FFRoute(
          name: CustomersPageWidget.routeName,
          path: CustomersPageWidget.routePath,
          builder: (context, params) => const CustomersPageWidget(),
        ),
        FFRoute(
          name: CustomerDetailPageWidget.routeName,
          path: CustomerDetailPageWidget.routePath,
          builder: (context, params) => CustomerDetailPageWidget(
            customerId: params.getParam('customerId', ParamType.String),
          ),
        ),
        // Session 4, Part C-8.
        FFRoute(
          name: InsuranceClaimsPageWidget.routeName,
          path: InsuranceClaimsPageWidget.routePath,
          builder: (context, params) => const InsuranceClaimsPageWidget(),
        ),
        // Session 4, Part C-9.
        FFRoute(
          name: TripsPageWidget.routeName,
          path: TripsPageWidget.routePath,
          builder: (context, params) => const TripsPageWidget(),
        ),
        FFRoute(
          name: TripDetailPageWidget.routeName,
          path: TripDetailPageWidget.routePath,
          builder: (context, params) => TripDetailPageWidget(
            tripId: params.getParam('tripId', ParamType.String),
          ),
        ),
        // Session 4, Part C-12.
        FFRoute(
          name: TasksPageWidget.routeName,
          path: TasksPageWidget.routePath,
          builder: (context, params) => const TasksPageWidget(),
        ),
        // Session 2, Part B1 + Part C: the 4 remaining supervisor
        // ComingSoon stubs (sup-jobs/sup-team/sup-sal/sup-att) are now
        // real screens, under new route names — kSupervisorNavItems in
        // nav_items.dart is updated to match (context.pushNamed(item.name)
        // needs the two to agree exactly). 'Job Entry' (sup-entry) was
        // built too but dropped from the nav (device-test follow-up:
        // supervisors work assigned jobs, they don't book new ones) — its
        // route stays registered (parked, not deleted) so the built page
        // isn't lost, just unreachable from nav.
        FFRoute(
          name: SupervisorJobsListPageWidget.routeName,
          path: SupervisorJobsListPageWidget.routePath,
          builder: (context, params) => const SupervisorJobsListPageWidget(),
        ),
        FFRoute(
          name: SupervisorEntryPageWidget.routeName,
          path: SupervisorEntryPageWidget.routePath,
          builder: (context, params) => const SupervisorEntryPageWidget(),
        ),
        FFRoute(
          name: SupervisorTeamPageWidget.routeName,
          path: SupervisorTeamPageWidget.routePath,
          builder: (context, params) => const SupervisorTeamPageWidget(),
        ),
        FFRoute(
          name: SupervisorEarningsPageWidget.routeName,
          path: SupervisorEarningsPageWidget.routePath,
          builder: (context, params) => const SupervisorEarningsPageWidget(),
        ),
        FFRoute(
          name: SupervisorAttendancePageWidget.routeName,
          path: SupervisorAttendancePageWidget.routePath,
          builder: (context, params) => const SupervisorAttendancePageWidget(),
        ),
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  name: state.name,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(
                  key: state.pageKey, name: state.name, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() =>
      const TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
