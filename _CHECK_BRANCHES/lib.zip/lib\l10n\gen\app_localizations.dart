import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_kn.dart';
import 'app_localizations_ml.dart';
import 'app_localizations_ta.dart';
import 'app_localizations_te.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'gen/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
      : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('hi'),
    Locale('kn'),
    Locale('ml'),
    Locale('ta'),
    Locale('te')
  ];

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'Arun Packers And Couriers'**
  String get arunPackersAndCouriers;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'Moving you towards your future'**
  String get movingYouTowardsYourFuture;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'Name or Phone'**
  String get nameOrPhone;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'Enter your name or phone'**
  String get enterYourNameOrPhone;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'PIN'**
  String get pin;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'4-digit PIN'**
  String get n4DigitPin;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'LOGIN'**
  String get login;

  /// LoginPage
  ///
  /// In en, this message translates to:
  /// **'Secured & Encrypted'**
  String get securedEncrypted;

  /// HomePage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Dashboard'**
  String get dashboard;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'THIS MONTH'**
  String get thisMonth;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'REVENUE'**
  String get revenue;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'LABOUR'**
  String get labour;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'EXPENSES'**
  String get expenses;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'PORTER'**
  String get porter;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'NET PROFIT'**
  String get netProfit;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'ACTIVE LEADS'**
  String get activeLeads;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'ORDERS/MONTH'**
  String get ordersMonth;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'OUTSTANDING'**
  String get outstanding;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'REMINDERS'**
  String get reminders;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'MONTHLY TARGET'**
  String get monthlyTarget;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get edit;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'target this month'**
  String get targetThisMonth;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'e.g. 200000'**
  String get eG200000;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'Upcoming Orders'**
  String get upcomingOrders;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'Calendar ->'**
  String get calendar;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'Hot Leads'**
  String get hotLeads;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'View All ->'**
  String get viewAll;

  /// HomePage
  ///
  /// In en, this message translates to:
  /// **'BRANCH PERFORMANCE'**
  String get branchPerformance;

  /// HomePage; OrdersPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Orders'**
  String get orders;

  /// HomePage; LeadsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Leads'**
  String get leads;

  /// HomePage; OperationsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Operations'**
  String get operations;

  /// HomePage; PaymentsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Payments'**
  String get payments;

  /// ExpensePage; HomePage; PLReportPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Expenses'**
  String get homePageExpenses;

  /// HomePage; QuickExpensePage; SalaryPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Salary'**
  String get salary;

  /// HomePage; SettingsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// HomePage; SettingsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// LeadsPage; OrdersPage; UsersPage (used 11x)
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get all;

  /// OrdersPage; SalaryPage (used 13x)
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get pending;

  /// OrdersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get completed;

  /// OrdersPage (used 9x)
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get cancelled;

  /// OrdersPage (used 8x)
  ///
  /// In en, this message translates to:
  /// **'Confirmed'**
  String get confirmed;

  /// OrdersPage (used 8x)
  ///
  /// In en, this message translates to:
  /// **'Transit'**
  String get transit;

  /// OrdersPage (used 8x)
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get done;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'ORD-001'**
  String get ord001;

  /// AccountsPage; OrdersPage; PaymentsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Rajesh Kumar'**
  String get rajeshKumar;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'Chennai → Bangalore'**
  String get chennaiBangalore;

  /// ExpensePage; OrdersPage; PLReportPage; PaymentsPage (used 4x)
  ///
  /// In en, this message translates to:
  /// **'₹12,500'**
  String get n12500;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'ORD-002'**
  String get ord002;

  /// AccountsPage; OrdersPage; PaymentsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Priya Sharma'**
  String get priyaSharma;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'Mumbai → Pune'**
  String get mumbaiPune;

  /// OrdersPage; PaymentsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'₹8,000'**
  String get n8000;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'ORD-003'**
  String get ord003;

  /// OperationsPage; OrdersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'In Transit'**
  String get inTransit;

  /// OrdersPage; PaymentsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Anand Verma'**
  String get anandVerma;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'Delhi → Noida'**
  String get delhiNoida;

  /// OrdersPage; PaymentsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'₹5,500'**
  String get n5500;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'ORD-004'**
  String get ord004;

  /// OrdersPage; PaymentsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Sunita Devi'**
  String get sunitaDevi;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'Hyderabad → Chennai'**
  String get hyderabadChennai;

  /// OrdersPage
  ///
  /// In en, this message translates to:
  /// **'₹9,200'**
  String get n9200;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Leads / CRM'**
  String get leadsCrm;

  /// CalendarPage; LeadsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'8'**
  String get n8;

  /// LeadsPage (used 2x). Key is NOT 'new': an ARB key that is a Dart reserved word breaks the whole l10n build, because gen_l10n maps keys straight to getters.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get statusNew;

  /// CalendarPage; LeadsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'5'**
  String get n5;

  /// LeadsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Contacted'**
  String get contacted;

  /// CalendarPage; LeadsPage; MaterialsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'3'**
  String get n3;

  /// LeadsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Qualified'**
  String get qualified;

  /// CalendarPage; FleetPage; LeadsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'2'**
  String get n2;

  /// LeadsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Won'**
  String get won;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Lost'**
  String get lost;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Ravi Menon'**
  String get raviMenon;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 12345'**
  String get n919840012345;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Chennai, TN'**
  String get chennaiTn;

  /// LeadsPage; NewLeadPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'New Lead'**
  String get newLead;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Deepa Nair'**
  String get deepaNair;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'+91 94470 67890'**
  String get n919447067890;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Coimbatore, TN'**
  String get coimbatoreTn;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Karthik S.'**
  String get karthikS;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'+91 99400 54321'**
  String get n919940054321;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Madurai, TN'**
  String get maduraiTn;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Meena Raj'**
  String get meenaRaj;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'+91 93800 11223'**
  String get n919380011223;

  /// LeadsPage
  ///
  /// In en, this message translates to:
  /// **'Trichy, TN'**
  String get trichyTn;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Today\'s Jobs'**
  String get todaySJobs;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'3 Active'**
  String get n3Active;

  /// FleetPage; OperationsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'TN-01-AB-1234'**
  String get tn01Ab1234;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Loading'**
  String get loading;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Suresh (Driver)'**
  String get sureshDriver;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Chennai → Vellore'**
  String get chennaiVellore;

  /// FleetPage; OperationsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'TN-02-CD-5678'**
  String get tn02Cd5678;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Murugan (Driver)'**
  String get muruganDriver;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Salem → Erode'**
  String get salemErode;

  /// FleetPage; OperationsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'TN-03-EF-9012'**
  String get tn03Ef9012;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Unloading'**
  String get unloading;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Balu (Driver)'**
  String get baluDriver;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Coimbatore → Ooty'**
  String get coimbatoreOoty;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Upcoming'**
  String get upcoming;

  /// FleetPage; OperationsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'TN-04-GH-3456'**
  String get tn04Gh3456;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Scheduled'**
  String get scheduled;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Senthil (Driver)'**
  String get senthilDriver;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Madurai → Tirunelveli'**
  String get maduraiTirunelveli;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Vehicle Trip Log'**
  String get vehicleTripLog;

  /// OperationsPage
  ///
  /// In en, this message translates to:
  /// **'Log New Trip'**
  String get logNewTrip;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Outstanding'**
  String get paymentsPageOutstanding;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'₹42,800'**
  String get n42800;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Received (Month)'**
  String get receivedMonth;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'₹1,24,000'**
  String get n124000;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Pending Payments (Live)'**
  String get pendingPaymentsLive;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Pending Invoices'**
  String get pendingInvoices;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'INV-045'**
  String get inv045;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Due: 15 May'**
  String get due15May;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'INV-046'**
  String get inv046;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Due: 18 May'**
  String get due18May;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'INV-047'**
  String get inv047;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Overdue'**
  String get overdue;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'INV-048'**
  String get inv048;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'Due: 22 May'**
  String get due22May;

  /// PaymentsPage
  ///
  /// In en, this message translates to:
  /// **'₹16,800'**
  String get n16800;

  /// ExpensePage
  ///
  /// In en, this message translates to:
  /// **'May 2025 Total'**
  String get may2025Total;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'₹68,450'**
  String get n68450;

  /// ExpensePage
  ///
  /// In en, this message translates to:
  /// **'↑ 12% vs last month'**
  String get n12VsLastMonth;

  /// ExpensePage
  ///
  /// In en, this message translates to:
  /// **'Live Expenses'**
  String get liveExpenses;

  /// ExpensePage
  ///
  /// In en, this message translates to:
  /// **'By Category'**
  String get byCategory;

  /// ExpensePage; PLReportPage; QuickExpensePage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Fuel'**
  String get fuel;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'41%'**
  String get n41;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'₹28,000'**
  String get n28000;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Tolls & Permits'**
  String get tollsPermits;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'18%'**
  String get n18;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Maintenance'**
  String get maintenance;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'26%'**
  String get n26;

  /// AccountsPage; ExpensePage; PLReportPage; SalaryPage (used 4x)
  ///
  /// In en, this message translates to:
  /// **'₹18,000'**
  String get n18000;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Labour'**
  String get expensePageLabour;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'15%'**
  String get n15;

  /// ExpensePage; PLReportPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'₹9,950'**
  String get n9950;

  /// ExpensePage
  ///
  /// In en, this message translates to:
  /// **'Add Expense'**
  String get addExpense;

  /// CalendarPage; SalaryPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'May 2025'**
  String get may2025;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Total Payroll'**
  String get totalPayroll;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'₹1,82,000'**
  String get n182000;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Live Staff Data'**
  String get liveStaffData;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Today\'s Attendance'**
  String get todaySAttendance;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'·'**
  String get label;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Pending Advances'**
  String get pendingAdvances;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Bal:'**
  String get bal;

  /// SalaryPage; UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Staff'**
  String get staff;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Suresh Kumar'**
  String get sureshKumar;

  /// SalaryPage; UsersPage (used 7x)
  ///
  /// In en, this message translates to:
  /// **'Driver'**
  String get driver;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'₹22,000'**
  String get n22000;

  /// SalaryPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get paid;

  /// SalaryPage; UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Murugan P.'**
  String get muruganP;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'₹20,000'**
  String get n20000;

  /// SalaryPage; UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Balu S.'**
  String get baluS;

  /// SalaryPage; UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Helper'**
  String get helper;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'₹14,000'**
  String get n14000;

  /// SalaryPage; UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Senthil R.'**
  String get senthilR;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'₹21,000'**
  String get n21000;

  /// SalaryPage
  ///
  /// In en, this message translates to:
  /// **'Kala M.'**
  String get kalaM;

  /// SalaryPage; UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Office Staff'**
  String get officeStaff;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Fleet'**
  String get fleet;

  /// CalendarPage; FleetPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'4'**
  String get n4;

  /// FleetPage; UsersPage (used 8x)
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get active;

  /// FleetPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Idle'**
  String get idle;

  /// CalendarPage; FleetPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'1'**
  String get n1;

  /// FleetPage; LeadDetailPage; OrderDetailPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Service'**
  String get service;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Live Fleet'**
  String get liveFleet;

  /// FleetPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Mini Truck (407)'**
  String get miniTruck407;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Suresh'**
  String get suresh;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'1,24,560 km'**
  String get n124560Km;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Large Truck (Tata)'**
  String get largeTruckTata;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Murugan'**
  String get murugan;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'98,340 km'**
  String get n98340Km;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'In Service'**
  String get inService;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Balu'**
  String get balu;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'2,12,000 km'**
  String get n212000Km;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Large Truck (Eicher)'**
  String get largeTruckEicher;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'Senthil'**
  String get senthil;

  /// FleetPage
  ///
  /// In en, this message translates to:
  /// **'67,890 km'**
  String get n67890Km;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'New Quotation'**
  String get newQuotation;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Customer Details'**
  String get customerDetails;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Customer Name'**
  String get customerName;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Enter full name'**
  String get enterFullName;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Phone Number'**
  String get phoneNumber;

  /// NewLeadPage; NewOrderPage; QuotationPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'+91 XXXXX XXXXX'**
  String get n91XxxxxXxxxx;

  /// LeadDetailPage; NewLeadPage; NewOrderPage; OrderDetailPage; QuotationPage (used 5x)
  ///
  /// In en, this message translates to:
  /// **'Move Details'**
  String get moveDetails;

  /// NewOrderPage; QuotationPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'From Address'**
  String get fromAddress;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Pickup location'**
  String get pickupLocation;

  /// NewOrderPage; QuotationPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'To Address'**
  String get toAddress;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Drop location'**
  String get dropLocation;

  /// OrderDetailPage; QuotationPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Move Date'**
  String get moveDate;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'DD/MM/YYYY'**
  String get ddMmYyyy;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Floor / Access'**
  String get floorAccess;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'e.g. 2nd floor, lift available'**
  String get eG2ndFloorLiftAvailable;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Estimate'**
  String get estimate;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Quoted Amount (₹)'**
  String get quotedAmount;

  /// NewOrderPage; QuickExpensePage; QuotationPage; RecordPaymentPage (used 4x)
  ///
  /// In en, this message translates to:
  /// **'0.00'**
  String get n000;

  /// LeadDetailPage; NewLeadPage; NewOrderPage; OrderDetailPage; QuotationPage (used 7x)
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get notes;

  /// NewOrderPage; QuotationPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Additional details'**
  String get additionalDetails;

  /// QuotationPage
  ///
  /// In en, this message translates to:
  /// **'Generate Quotation'**
  String get generateQuotation;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Accounts'**
  String get accounts;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'SBI — Current A/C'**
  String get sbiCurrentAC;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'XXXX 4521'**
  String get xxxx4521;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'₹2,84,500'**
  String get n284500;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'HDFC — Savings A/C'**
  String get hdfcSavingsAC;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'XXXX 7832'**
  String get xxxx7832;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'₹1,12,300'**
  String get n112300;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Cash on Hand'**
  String get cashOnHand;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Total Balance'**
  String get totalBalance;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'₹4,14,800'**
  String get n414800;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Recent Transactions'**
  String get recentTransactions;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Received — ORD-001'**
  String get receivedOrd001;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'+₹12,500'**
  String get accountsPageN12500;

  /// AccountsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'May 5'**
  String get may5;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Fuel — TN-01-AB-1234'**
  String get fuelTn01Ab1234;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Petrol Bunk'**
  String get petrolBunk;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'-₹3,200'**
  String get n3200;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Received — ORD-002'**
  String get receivedOrd002;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'+₹8,000'**
  String get accountsPageN8000;

  /// AccountsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'May 4'**
  String get may4;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'Toll — Chennai NH'**
  String get tollChennaiNh;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'NHAI'**
  String get nhai;

  /// AccountsPage
  ///
  /// In en, this message translates to:
  /// **'-₹480'**
  String get n480;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'P&L Report'**
  String get pLReport;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'Period: May 2025'**
  String get periodMay2025;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'₹1,92,000'**
  String get n192000;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'Revenue'**
  String get pLReportPageRevenue;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'₹1,23,550'**
  String get n123550;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'Net Profit'**
  String get pLReportPageNetProfit;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'64.3%'**
  String get n643;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'Margin'**
  String get margin;

  /// PLReportPage
  ///
  /// In en, this message translates to:
  /// **'Top Expenses'**
  String get topExpenses;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Arun Packers Staff'**
  String get arunPackersStaff;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'admin@arunpackers.in'**
  String get adminArunpackersIn;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Company'**
  String get company;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Business Name'**
  String get businessName;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Arun Packers and Couriers'**
  String get settingsPageArunPackersAndCouriers;

  /// LeadDetailPage; OrderDetailPage; SettingsPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get phone;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'+91 44 XXXX XXXX'**
  String get n9144XxxxXxxx;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'GST Number'**
  String get gstNumber;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'XXXXXXXXXXXX'**
  String get xxxxxxxxxxxx;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'App'**
  String get app;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Enabled'**
  String get enabled;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Dark Mode'**
  String get darkMode;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'On'**
  String get on;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get english;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Data'**
  String get data;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Export Data'**
  String get exportData;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'CSV / PDF'**
  String get csvPdf;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Backup'**
  String get backup;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Auto (Daily)'**
  String get autoDaily;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'App Theme'**
  String get appTheme;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Choose your preferred colour scheme.'**
  String get chooseYourPreferredColourScheme;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Dark'**
  String get dark;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Midnight'**
  String get midnight;

  /// SettingsPage
  ///
  /// In en, this message translates to:
  /// **'Light'**
  String get light;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Calendar'**
  String get calendarPageCalendar;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Mon'**
  String get mon;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Tue'**
  String get tue;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Wed'**
  String get wed;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Thu'**
  String get thu;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Fri'**
  String get fri;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Sat'**
  String get sat;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Sun'**
  String get sun;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'6'**
  String get n6;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'7'**
  String get n7;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'9'**
  String get n9;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'10'**
  String get n10;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'11'**
  String get n11;

  /// CalendarPage; MaterialsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'12'**
  String get n12;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'13'**
  String get n13;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'14'**
  String get n14;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'15'**
  String get calendarPageN15;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'17'**
  String get n17;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'18'**
  String get calendarPageN18;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'20'**
  String get n20;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'21'**
  String get n21;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'22'**
  String get n22;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'23'**
  String get n23;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'24'**
  String get n24;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'25'**
  String get n25;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'26'**
  String get calendarPageN26;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'27'**
  String get n27;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'28'**
  String get n28;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'29'**
  String get n29;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'30'**
  String get n30;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'31'**
  String get n31;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Reminders & Follow-ups'**
  String get remindersFollowUps;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Follow-up: Ravi Menon'**
  String get followUpRaviMenon;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Call regarding Bangalore move quote'**
  String get callRegardingBangaloreMoveQuote;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'May 7'**
  String get may7;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Collection: ORD-047'**
  String get collectionOrd047;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Overdue payment from Anand Verma'**
  String get overduePaymentFromAnandVerma;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'May 8'**
  String get may8;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Job: TN-01-AB-1234'**
  String get jobTn01Ab1234;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Chennai → Vellore scheduled delivery'**
  String get chennaiVelloreScheduledDelivery;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'May 9'**
  String get may9;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Review: May Expenses'**
  String get reviewMayExpenses;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Monthly expense review with team'**
  String get monthlyExpenseReviewWithTeam;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'May 12'**
  String get may12;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Active Reminders (Live)'**
  String get activeRemindersLive;

  /// CalendarPage
  ///
  /// In en, this message translates to:
  /// **'Add Reminder'**
  String get addReminder;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Materials'**
  String get materials;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Total SKUs'**
  String get totalSkus;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Low Stock'**
  String get lowStock;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Inventory'**
  String get inventory;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Cardboard Box — Small'**
  String get cardboardBoxSmall;

  /// MaterialsPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Reorder < 20'**
  String get reorder20;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'42 pcs'**
  String get n42Pcs;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Cardboard Box — Medium'**
  String get cardboardBoxMedium;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'28 pcs'**
  String get n28Pcs;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Cardboard Box — Large'**
  String get cardboardBoxLarge;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Reorder < 15'**
  String get reorder15;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'11 pcs'**
  String get n11Pcs;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Bubble Wrap Roll (50m)'**
  String get bubbleWrapRoll50m;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Reorder < 5'**
  String get reorder5;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'4 rolls'**
  String get n4Rolls;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Stretch Wrap Roll'**
  String get stretchWrapRoll;

  /// MaterialsPage (used 4x)
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get ok;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'18 rolls'**
  String get n18Rolls;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Packing Tape (Brown)'**
  String get packingTapeBrown;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Reorder < 10'**
  String get reorder10;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'7 pcs'**
  String get n7Pcs;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Furniture Cover (Large)'**
  String get furnitureCoverLarge;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'24 pcs'**
  String get n24Pcs;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Rope (50m)'**
  String get rope50m;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'8 rolls'**
  String get n8Rolls;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Corner Guards'**
  String get cornerGuards;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'60 pcs'**
  String get n60Pcs;

  /// MaterialsPage
  ///
  /// In en, this message translates to:
  /// **'Add / Restock Item'**
  String get addRestockItem;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get reports;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Generate Reports'**
  String get generateReports;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Monthly Summary'**
  String get monthlySummary;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Revenue, expenses & profit overview'**
  String get revenueExpensesProfitOverview;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Customer Report'**
  String get customerReport;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Top customers by revenue'**
  String get topCustomersByRevenue;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Driver Performance'**
  String get driverPerformance;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Jobs completed per driver'**
  String get jobsCompletedPerDriver;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Expense Breakdown'**
  String get expenseBreakdown;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Category-wise expense analysis'**
  String get categoryWiseExpenseAnalysis;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Revenue Trend'**
  String get revenueTrend;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Month-on-month revenue chart'**
  String get monthOnMonthRevenueChart;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Outstanding Report'**
  String get outstandingReport;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Pending payments & ageing'**
  String get pendingPaymentsAgeing;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Vehicle Utilisation'**
  String get vehicleUtilisation;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Fleet usage and idle time analysis'**
  String get fleetUsageAndIdleTimeAnalysis;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Export Options'**
  String get exportOptions;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Export PDF'**
  String get exportPdf;

  /// ReportsPage
  ///
  /// In en, this message translates to:
  /// **'Export CSV'**
  String get exportCsv;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Users'**
  String get users;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Add New User'**
  String get addNewUser;

  /// UsersPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Admin'**
  String get admin;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Active Users'**
  String get activeUsers;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Arun Kumar'**
  String get arunKumar;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 00001'**
  String get n919840000001;

  /// UsersPage (used 3x)
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get today;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Suresh M.'**
  String get sureshM;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 00002'**
  String get n919840000002;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 00003'**
  String get n919840000003;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Yesterday'**
  String get yesterday;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Kala R.'**
  String get kalaR;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 00004'**
  String get n919840000004;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 00005'**
  String get n919840000005;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'2 days ago'**
  String get n2DaysAgo;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Inactive Users'**
  String get inactiveUsers;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'+91 98400 00006'**
  String get n919840000006;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get inactive;

  /// UsersPage
  ///
  /// In en, this message translates to:
  /// **'5 days ago'**
  String get n5DaysAgo;

  /// QuickEntryPage; RecordPaymentPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Record Payment'**
  String get recordPayment;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Select Order'**
  String get selectOrder;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Loading pending orders...'**
  String get loadingPendingOrders;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Select'**
  String get select;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Payment Entry'**
  String get paymentEntry;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Customer:'**
  String get customer;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Total Amount:'**
  String get totalAmount;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Already Paid:'**
  String get alreadyPaid;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Amount Received (₹)'**
  String get amountReceived;

  /// NewLeadPage; RecordPaymentPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Select status'**
  String get selectStatus;

  /// OrderDetailPage; RecordPaymentPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Payment Status'**
  String get paymentStatus;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'partial'**
  String get partial;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'paid'**
  String get recordPaymentPagePaid;

  /// RecordPaymentPage
  ///
  /// In en, this message translates to:
  /// **'Save Payment'**
  String get savePayment;

  /// QuickEntryPage; QuickExpensePage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Quick Expense'**
  String get quickExpense;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Expense Details'**
  String get expenseDetails;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Amount (₹)'**
  String get amount;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Select category'**
  String get selectCategory;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get category;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Vehicle Maintenance'**
  String get vehicleMaintenance;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Office'**
  String get office;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Material'**
  String get material;

  /// NewLeadPage; QuickExpensePage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get other;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get date;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'YYYY-MM-DD'**
  String get yyyyMmDd;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Linked Order ID (optional)'**
  String get linkedOrderIdOptional;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Leave blank if not linked'**
  String get leaveBlankIfNotLinked;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get description;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Brief description'**
  String get briefDescription;

  /// QuickExpensePage
  ///
  /// In en, this message translates to:
  /// **'Save Expense'**
  String get saveExpense;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'New Order'**
  String get newOrder;

  /// NewOrderPage; OrderDetailPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Customer'**
  String get newOrderPageCustomer;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Customer Name *'**
  String get newOrderPageCustomerName;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Full name'**
  String get fullName;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Phone *'**
  String get newOrderPagePhone;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'From City *'**
  String get fromCity;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Origin city'**
  String get originCity;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'To City *'**
  String get toCity;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Destination city'**
  String get destinationCity;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Pickup address'**
  String get pickupAddress;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Drop address'**
  String get dropAddress;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'From Floor'**
  String get fromFloor;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'e.g. 2nd floor'**
  String get eG2ndFloor;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'To Floor'**
  String get toFloor;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'e.g. Ground floor'**
  String get eGGroundFloor;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Move Date *'**
  String get newOrderPageMoveDate;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Tap to pick date'**
  String get tapToPickDate;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Pick Date'**
  String get pickDate;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Pricing & Classification'**
  String get pricingClassification;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Amount (₹) *'**
  String get newOrderPageAmount;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Select service'**
  String get selectService;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Service *'**
  String get newOrderPageService;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'House Shifting'**
  String get houseShifting;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Office Shifting'**
  String get officeShifting;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Vehicle Transport'**
  String get vehicleTransport;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Storage'**
  String get storage;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Packing Only'**
  String get packingOnly;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Long Distance'**
  String get longDistance;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Select branch'**
  String get selectBranch;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Branch *'**
  String get branch;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Chennai'**
  String get chennai;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Bengaluru'**
  String get bengaluru;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Coimbatore'**
  String get coimbatore;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Select type'**
  String get selectType;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Order Type *'**
  String get orderType;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Direct'**
  String get direct;

  /// NewLeadPage; NewOrderPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Porter'**
  String get newOrderPagePorter;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Porter Commission %'**
  String get porterCommission;

  /// NewOrderPage
  ///
  /// In en, this message translates to:
  /// **'Save Order'**
  String get saveOrder;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Order Details'**
  String get orderDetails;

  /// LeadDetailPage; OrderDetailPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Branch'**
  String get orderDetailPageBranch;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get type;

  /// LeadDetailPage; OrderDetailPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'From'**
  String get from;

  /// LeadDetailPage; OrderDetailPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'To'**
  String get to;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Address (From)'**
  String get addressFrom;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Address (To)'**
  String get addressTo;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Floor (From)'**
  String get floorFrom;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Floor (To)'**
  String get floorTo;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Payment'**
  String get payment;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Amount'**
  String get orderDetailPageAmount;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Advance Paid'**
  String get advancePaid;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Tracking Status'**
  String get trackingStatus;

  /// OrderDetailPage
  ///
  /// In en, this message translates to:
  /// **'Edit Order'**
  String get editOrder;

  /// LeadDetailPage; NewLeadPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get contact;

  /// LeadDetailPage; NewLeadPage (used 2x)
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'email@example.com'**
  String get emailExampleCom;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'From City'**
  String get newLeadPageFromCity;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'To City'**
  String get newLeadPageToCity;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Approx Date *'**
  String get approxDate;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Classification'**
  String get classification;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Status *'**
  String get status;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'new'**
  String get newLeadPageNew;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'contacted'**
  String get newLeadPageContacted;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'survey_done'**
  String get surveyDone;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'quoted'**
  String get quoted;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'converted'**
  String get converted;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'lost'**
  String get newLeadPageLost;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'How did they hear about us?'**
  String get howDidTheyHearAboutUs;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Source *'**
  String get source;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'WhatsApp'**
  String get whatsapp;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Phone Call'**
  String get phoneCall;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Website'**
  String get website;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Referral'**
  String get referral;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Walk-in'**
  String get walkIn;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Google'**
  String get google;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'JustDial'**
  String get justdial;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Any relevant notes'**
  String get anyRelevantNotes;

  /// NewLeadPage
  ///
  /// In en, this message translates to:
  /// **'Save Lead'**
  String get saveLead;

  /// LeadDetailPage
  ///
  /// In en, this message translates to:
  /// **'Lead Details'**
  String get leadDetails;

  /// LeadDetailPage
  ///
  /// In en, this message translates to:
  /// **'Source'**
  String get leadDetailPageSource;

  /// LeadDetailPage
  ///
  /// In en, this message translates to:
  /// **'Approx. Date'**
  String get leadDetailPageApproxDate;

  /// LeadDetailPage
  ///
  /// In en, this message translates to:
  /// **'Convert to Order'**
  String get convertToOrder;

  /// LeadDetailPage
  ///
  /// In en, this message translates to:
  /// **'Edit Lead'**
  String get editLead;

  /// QuickEntryPage
  ///
  /// In en, this message translates to:
  /// **'Quick Entry'**
  String get quickEntry;

  /// QuickEntryPage
  ///
  /// In en, this message translates to:
  /// **'What would you like to do?'**
  String get whatWouldYouLikeToDo;

  /// QuickEntryPage
  ///
  /// In en, this message translates to:
  /// **'New Inquiry'**
  String get newInquiry;

  /// QuickEntryPage
  ///
  /// In en, this message translates to:
  /// **'Confirm Booking'**
  String get confirmBooking;

  /// NewOrderPage — porter section. RECOVERED 27 Aug 2026: the old FF key 'porcashcol1' was never present in kTranslationsMap, so this label rendered blank.
  ///
  /// In en, this message translates to:
  /// **'Cash Collected by Porter (₹)'**
  String get cashCollectedByPorter;

  /// NewOrderPage — porter section hint. Same recovery as cashCollectedByPorter (old key: porcashcol2).
  ///
  /// In en, this message translates to:
  /// **'Leave blank if none collected yet'**
  String get leaveBlankIfNoneCollectedYet;

  /// OrderJourneyPage — screen title, and the button that opens it from Lead/Order details
  ///
  /// In en, this message translates to:
  /// **'Order journey'**
  String get jrTitle;

  /// OrderJourneyPage — stage 1
  ///
  /// In en, this message translates to:
  /// **'Lead'**
  String get jrStageLead;

  /// OrderJourneyPage — stage 2
  ///
  /// In en, this message translates to:
  /// **'Follow-up'**
  String get jrStageFollowUp;

  /// OrderJourneyPage — stage 3
  ///
  /// In en, this message translates to:
  /// **'Survey'**
  String get jrStageSurvey;

  /// OrderJourneyPage — stage 4
  ///
  /// In en, this message translates to:
  /// **'Quote & confirm'**
  String get jrStageQuote;

  /// OrderJourneyPage — stage 5
  ///
  /// In en, this message translates to:
  /// **'Supervisor'**
  String get jrStageSupervisor;

  /// OrderJourneyPage — stage 6
  ///
  /// In en, this message translates to:
  /// **'Move day'**
  String get jrStageMoveDay;

  /// OrderJourneyPage — stage 7
  ///
  /// In en, this message translates to:
  /// **'Invoice'**
  String get jrStageInvoice;

  /// OrderJourneyPage — stage 8
  ///
  /// In en, this message translates to:
  /// **'Payment & issues'**
  String get jrStagePayment;

  /// OrderJourneyPage — stage 9
  ///
  /// In en, this message translates to:
  /// **'Closed'**
  String get jrStageClosed;

  /// OrderJourneyPage — stage state pill
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get jrStateDone;

  /// OrderJourneyPage — stage state pill
  ///
  /// In en, this message translates to:
  /// **'Skipped'**
  String get jrStateSkipped;

  /// OrderJourneyPage — stage state pill for the current stage
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get jrStateCurrent;

  /// OrderJourneyPage — stage state pill for a stage not reached yet
  ///
  /// In en, this message translates to:
  /// **'Later'**
  String get jrStatePending;

  /// OrderJourneyPage — follow-up/survey summary on an order booked without a lead
  ///
  /// In en, this message translates to:
  /// **'Skipped · direct order'**
  String get jrDirectOrder;

  /// OrderJourneyPage — header tile
  ///
  /// In en, this message translates to:
  /// **'Move date'**
  String get jrMoveDate;

  /// OrderJourneyPage — header tile
  ///
  /// In en, this message translates to:
  /// **'Route'**
  String get jrRoute;

  /// OrderJourneyPage — header tile
  ///
  /// In en, this message translates to:
  /// **'Order value'**
  String get jrOrderValue;

  /// OrderJourneyPage — header tile with no value
  ///
  /// In en, this message translates to:
  /// **'Not set'**
  String get jrNotSet;

  /// OrderJourneyPage — documents panel title
  ///
  /// In en, this message translates to:
  /// **'Documents'**
  String get jrDocuments;

  /// OrderJourneyPage — document card
  ///
  /// In en, this message translates to:
  /// **'Quotation'**
  String get jrDocQuote;

  /// OrderJourneyPage — document card
  ///
  /// In en, this message translates to:
  /// **'Tax invoice'**
  String get jrDocInvoice;

  /// OrderJourneyPage — document card
  ///
  /// In en, this message translates to:
  /// **'Money receipts'**
  String get jrDocReceipts;

  /// OrderJourneyPage — document card
  ///
  /// In en, this message translates to:
  /// **'Lorry receipt'**
  String get jrDocLr;

  /// OrderJourneyPage — document card state
  ///
  /// In en, this message translates to:
  /// **'Ready · tap to view'**
  String get jrDocReady;

  /// OrderJourneyPage — document card state; {stage} is a stage name
  ///
  /// In en, this message translates to:
  /// **'After {stage}'**
  String jrDocAfter(String stage);

  /// OrderJourneyPage — lead stage line
  ///
  /// In en, this message translates to:
  /// **'Created {date}'**
  String jrCreated(String date);

  /// OrderJourneyPage — lead stage line
  ///
  /// In en, this message translates to:
  /// **'Source: {source}'**
  String jrSource(String source);

  /// OrderJourneyPage — lead stage line
  ///
  /// In en, this message translates to:
  /// **'Service: {service}'**
  String jrService(String service);

  /// OrderJourneyPage — follow-up summary
  ///
  /// In en, this message translates to:
  /// **'No calls logged yet'**
  String get jrNoCalls;

  /// OrderJourneyPage — follow-up summary
  ///
  /// In en, this message translates to:
  /// **'{count} calls logged'**
  String jrCallsLogged(String count);

  /// OrderJourneyPage — follow-up form label
  ///
  /// In en, this message translates to:
  /// **'How did the call go?'**
  String get jrOutcomeQ;

  /// OrderJourneyPage — call outcome chip
  ///
  /// In en, this message translates to:
  /// **'Not reachable'**
  String get jrOutNoAnswer;

  /// OrderJourneyPage — call outcome chip
  ///
  /// In en, this message translates to:
  /// **'Call back'**
  String get jrOutCallback;

  /// OrderJourneyPage — call outcome chip
  ///
  /// In en, this message translates to:
  /// **'Interested'**
  String get jrOutInterested;

  /// OrderJourneyPage — call outcome chip
  ///
  /// In en, this message translates to:
  /// **'Not interested'**
  String get jrOutNotInterested;

  /// OrderJourneyPage — follow-up notes hint
  ///
  /// In en, this message translates to:
  /// **'Notes from the call'**
  String get jrCallNotes;

  /// OrderJourneyPage — follow-up date label
  ///
  /// In en, this message translates to:
  /// **'Next follow-up'**
  String get jrNextFollowUp;

  /// OrderJourneyPage — quick date chip
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get jrToday;

  /// OrderJourneyPage — quick date chip
  ///
  /// In en, this message translates to:
  /// **'Tomorrow'**
  String get jrTomorrow;

  /// OrderJourneyPage — quick date chip
  ///
  /// In en, this message translates to:
  /// **'In 2 days'**
  String get jrIn2Days;

  /// OrderJourneyPage — quick date chip
  ///
  /// In en, this message translates to:
  /// **'Next week'**
  String get jrNextWeek;

  /// OrderJourneyPage — quick date chip
  ///
  /// In en, this message translates to:
  /// **'Pick date'**
  String get jrPickDate;

  /// OrderJourneyPage — no next follow-up
  ///
  /// In en, this message translates to:
  /// **'None'**
  String get jrNoNext;

  /// OrderJourneyPage — button
  ///
  /// In en, this message translates to:
  /// **'Log call'**
  String get jrLogCall;

  /// OrderJourneyPage — snackbar
  ///
  /// In en, this message translates to:
  /// **'Call logged'**
  String get jrCallLogged;

  /// OrderJourneyPage — validation
  ///
  /// In en, this message translates to:
  /// **'Pick how the call went'**
  String get jrPickOutcome;

  /// OrderJourneyPage — survey summary
  ///
  /// In en, this message translates to:
  /// **'Survey link sent · waiting for the customer'**
  String get jrSurveyWaiting;

  /// OrderJourneyPage — survey summary
  ///
  /// In en, this message translates to:
  /// **'Customer submitted the survey'**
  String get jrSurveyDone;

  /// OrderJourneyPage — survey summary
  ///
  /// In en, this message translates to:
  /// **'No survey yet'**
  String get jrNoSurvey;

  /// OrderJourneyPage — button opening Lead details
  ///
  /// In en, this message translates to:
  /// **'Open survey & quote'**
  String get jrOpenSurveyQuote;

  /// OrderJourneyPage — quote summary
  ///
  /// In en, this message translates to:
  /// **'No quote yet'**
  String get jrNoQuote;

  /// OrderJourneyPage — quote version line; {amount} is formatted money
  ///
  /// In en, this message translates to:
  /// **'Quote {amount}'**
  String jrQuoteLine(String amount);

  /// OrderJourneyPage — quote stage summary
  ///
  /// In en, this message translates to:
  /// **'Order {id} confirmed'**
  String jrOrderConfirmed(String id);

  /// OrderJourneyPage — shown instead of a current stage
  ///
  /// In en, this message translates to:
  /// **'Lead marked lost'**
  String get jrLeadLost;

  /// OrderJourneyPage — supervisor summary
  ///
  /// In en, this message translates to:
  /// **'No supervisor yet'**
  String get jrNoSupervisor;

  /// OrderJourneyPage — supervisor summary
  ///
  /// In en, this message translates to:
  /// **'Supervisor: {name}'**
  String jrSupervisorIs(String name);

  /// OrderJourneyPage — supervisor/move line
  ///
  /// In en, this message translates to:
  /// **'Crew on the job: {count}'**
  String jrCrew(String count);

  /// OrderJourneyPage — button opening Order details crew section
  ///
  /// In en, this message translates to:
  /// **'Assign supervisor'**
  String get jrAssignInOrder;

  /// OrderJourneyPage — move day summary
  ///
  /// In en, this message translates to:
  /// **'Not started'**
  String get jrNotStarted;

  /// OrderJourneyPage — move day summary
  ///
  /// In en, this message translates to:
  /// **'Started {time}'**
  String jrMoveStarted(String time);

  /// OrderJourneyPage — move day summary
  ///
  /// In en, this message translates to:
  /// **'Finished {time}'**
  String jrMoveFinished(String time);

  /// OrderJourneyPage — button opening the supervisor job screen
  ///
  /// In en, this message translates to:
  /// **'Open field job'**
  String get jrOpenFieldJob;

  /// OrderJourneyPage — invoice summary and close blocker
  ///
  /// In en, this message translates to:
  /// **'Invoice not generated'**
  String get jrNoInvoice;

  /// OrderJourneyPage — invoice summary
  ///
  /// In en, this message translates to:
  /// **'Invoice {no}'**
  String jrInvoiceNo(String no);

  /// OrderJourneyPage — invoice line
  ///
  /// In en, this message translates to:
  /// **'Customer signed'**
  String get jrSigned;

  /// OrderJourneyPage — invoice line and close blocker
  ///
  /// In en, this message translates to:
  /// **'Customer signature missing'**
  String get jrNotSigned;

  /// OrderJourneyPage — button opening Order details
  ///
  /// In en, this message translates to:
  /// **'Open order'**
  String get jrOpenOrder;

  /// OrderJourneyPage — payment tile
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get jrTotal;

  /// OrderJourneyPage — payment tile
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get jrPaid;

  /// OrderJourneyPage — payment tile
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get jrBalance;

  /// OrderJourneyPage — button
  ///
  /// In en, this message translates to:
  /// **'Record payment'**
  String get jrRecordPayment;

  /// OrderJourneyPage — section label
  ///
  /// In en, this message translates to:
  /// **'Tickets'**
  String get jrTickets;

  /// OrderJourneyPage — tickets empty
  ///
  /// In en, this message translates to:
  /// **'No tickets'**
  String get jrNoTickets;

  /// OrderJourneyPage — new ticket hint
  ///
  /// In en, this message translates to:
  /// **'e.g. AC fitting pending'**
  String get jrTicketHint;

  /// OrderJourneyPage — button
  ///
  /// In en, this message translates to:
  /// **'Raise ticket'**
  String get jrRaiseTicket;

  /// OrderJourneyPage — button
  ///
  /// In en, this message translates to:
  /// **'Resolve'**
  String get jrResolve;

  /// OrderJourneyPage — snackbar
  ///
  /// In en, this message translates to:
  /// **'Ticket raised'**
  String get jrTicketRaised;

  /// OrderJourneyPage — snackbar
  ///
  /// In en, this message translates to:
  /// **'Ticket resolved'**
  String get jrTicketResolved;

  /// OrderJourneyPage — close blocker
  ///
  /// In en, this message translates to:
  /// **'A ticket is still open'**
  String get jrBlockTicket;

  /// OrderJourneyPage — close blocker
  ///
  /// In en, this message translates to:
  /// **'Balance of {amount} is due'**
  String jrBlockBalance(String amount);

  /// OrderJourneyPage — button opening the audited close on Order details
  ///
  /// In en, this message translates to:
  /// **'Close order'**
  String get jrCloseOrder;

  /// OrderJourneyPage — closed summary
  ///
  /// In en, this message translates to:
  /// **'Closed {date}'**
  String jrClosedOn(String date);

  /// OrderJourneyPage — closed stage summary while open
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get jrNotClosed;

  /// OrderJourneyPage — payment history line
  ///
  /// In en, this message translates to:
  /// **'{amount} · {mode}'**
  String jrPaymentLine(String amount, String mode);

  /// OrderJourneyPage — error
  ///
  /// In en, this message translates to:
  /// **'Could not load this journey'**
  String get jrCouldNotLoad;

  /// OrderJourneyPage — error action
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get jrRetry;

  /// OrderJourneyPage — error snackbar
  ///
  /// In en, this message translates to:
  /// **'Could not save: {error}'**
  String jrCouldNotSave(String error);

  /// Bottom bar
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get ngNavHome;

  /// Bottom bar
  ///
  /// In en, this message translates to:
  /// **'Leads'**
  String get ngNavLeads;

  /// Bottom bar
  ///
  /// In en, this message translates to:
  /// **'Orders'**
  String get ngNavOrders;

  /// Bottom bar — short for Operations
  ///
  /// In en, this message translates to:
  /// **'Ops'**
  String get ngNavOps;

  /// Bottom bar — short for Payments
  ///
  /// In en, this message translates to:
  /// **'Pay'**
  String get ngNavPay;

  /// Bottom bar — opens the module sheet
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get ngNavMore;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Dashboard'**
  String get ngMenuDashboard;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Leads / CRM'**
  String get ngMenuLeads;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Inbox'**
  String get ngMenuInbox;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Survey & Quote'**
  String get ngMenuSurveyQuote;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Calendar'**
  String get ngMenuCalendar;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Orders'**
  String get ngMenuOrders;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Operations'**
  String get ngMenuOperations;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Reviews'**
  String get ngMenuReviews;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Payments'**
  String get ngMenuPayments;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Expenses'**
  String get ngMenuExpenses;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Staff'**
  String get ngMenuStaff;

  /// More sheet / menu item (Staff label without salary rights)
  ///
  /// In en, this message translates to:
  /// **'Team Attendance'**
  String get ngMenuTeamAttendance;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Fleet'**
  String get ngMenuFleet;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Materials'**
  String get ngMenuMaterials;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Warehouses'**
  String get ngMenuWarehouses;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Rate Cards'**
  String get ngMenuRateCards;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'LR Register'**
  String get ngMenuLrRegister;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Ops Log'**
  String get ngMenuOpsLog;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Vendors'**
  String get ngMenuVendors;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Customers'**
  String get ngMenuCustomers;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Insurance'**
  String get ngMenuInsurance;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Trips'**
  String get ngMenuTrips;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Tasks'**
  String get ngMenuTasks;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Accounts'**
  String get ngMenuAccounts;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'P & L'**
  String get ngMenuPnl;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get ngMenuReports;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Salary'**
  String get ngMenuSalary;

  /// More sheet / menu item and footer button
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get ngMenuSettings;

  /// More sheet / menu item
  ///
  /// In en, this message translates to:
  /// **'Platform Admin'**
  String get ngMenuPlatformAdmin;

  /// Supervisor bottom bar
  ///
  /// In en, this message translates to:
  /// **'My Jobs'**
  String get ngMenuMyJobs;

  /// Supervisor bottom bar
  ///
  /// In en, this message translates to:
  /// **'My Team'**
  String get ngMenuMyTeam;

  /// Supervisor / field bottom bar
  ///
  /// In en, this message translates to:
  /// **'My Earnings'**
  String get ngMenuMyEarnings;

  /// Supervisor / field bottom bar
  ///
  /// In en, this message translates to:
  /// **'My Attendance'**
  String get ngMenuMyAttendance;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Sales'**
  String get ngGroupSales;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Operations'**
  String get ngGroupOperations;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Money'**
  String get ngGroupMoney;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'People'**
  String get ngGroupPeople;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Assets'**
  String get ngGroupAssets;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Partners'**
  String get ngGroupPartners;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Setup'**
  String get ngGroupSetup;

  /// More sheet group (supervisor/field staff)
  ///
  /// In en, this message translates to:
  /// **'Field'**
  String get ngGroupField;

  /// More sheet group
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get ngGroupOther;

  /// More sheet tile
  ///
  /// In en, this message translates to:
  /// **'Quick entry'**
  String get ngQuickEntry;

  /// More sheet search hint
  ///
  /// In en, this message translates to:
  /// **'Search modules'**
  String get ngSearchModules;

  /// More sheet empty search
  ///
  /// In en, this message translates to:
  /// **'No module matches'**
  String get ngNoModuleMatches;

  /// More sheet footer
  ///
  /// In en, this message translates to:
  /// **'Help'**
  String get ngHelp;

  /// More sheet header, several organisations
  ///
  /// In en, this message translates to:
  /// **'{count} orgs · tap to switch'**
  String ngOrgsSwitch(String count);

  /// Top bar role line
  ///
  /// In en, this message translates to:
  /// **'Owner'**
  String get ngRoleOwner;

  /// Top bar role line fallback
  ///
  /// In en, this message translates to:
  /// **'Staff'**
  String get ngRoleStaff;

  /// Dashboard today tile
  ///
  /// In en, this message translates to:
  /// **'Moves'**
  String get ngTodayMoves;

  /// Dashboard today tile
  ///
  /// In en, this message translates to:
  /// **'Follow-ups'**
  String get ngTodayFollowUps;

  /// Dashboard tile / Payments legend
  ///
  /// In en, this message translates to:
  /// **'To collect'**
  String get ngToCollect;

  /// Dashboard tile when money is hidden
  ///
  /// In en, this message translates to:
  /// **'Open leads'**
  String get ngOpenLeads;

  /// Dashboard agenda empty
  ///
  /// In en, this message translates to:
  /// **'No moves scheduled yet'**
  String get ngNoMovesYet;

  /// Dashboard agenda empty action
  ///
  /// In en, this message translates to:
  /// **'Create your first order'**
  String get ngCreateFirstOrder;

  /// Dashboard/Leads empty
  ///
  /// In en, this message translates to:
  /// **'No leads yet'**
  String get ngNoLeadsYet;

  /// Dashboard hot leads empty action
  ///
  /// In en, this message translates to:
  /// **'Add a lead'**
  String get ngAddLead;

  /// Leads statistics card heading
  ///
  /// In en, this message translates to:
  /// **'All leads'**
  String get ngAllLeads;

  /// Leads statistics
  ///
  /// In en, this message translates to:
  /// **'Conversion'**
  String get ngConversion;

  /// Leads statistics — open leads
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get ngOpen;

  /// Lead source fallback in the statistics bar
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get ngOther;

  /// Lead card badge tooltip
  ///
  /// In en, this message translates to:
  /// **'Survey response received'**
  String get ngSurveyResponse;

  /// Lead card badge
  ///
  /// In en, this message translates to:
  /// **'Follow-up overdue'**
  String get ngFollowUpOverdue;

  /// Lead card action
  ///
  /// In en, this message translates to:
  /// **'Call'**
  String get ngCall;

  /// Lead card action
  ///
  /// In en, this message translates to:
  /// **'WhatsApp'**
  String get ngWhatsApp;

  /// Lead card action — creates a survey link
  ///
  /// In en, this message translates to:
  /// **'Survey'**
  String get ngSurvey;

  /// Leads header button
  ///
  /// In en, this message translates to:
  /// **'New lead'**
  String get ngNewLead;

  /// Leads search hint
  ///
  /// In en, this message translates to:
  /// **'Name or phone'**
  String get ngNameOrPhone;

  /// Leads search empty
  ///
  /// In en, this message translates to:
  /// **'No leads match'**
  String get ngNoLeadsMatch;

  /// Leads empty hint
  ///
  /// In en, this message translates to:
  /// **'Add an enquiry with New lead and it will show up here.'**
  String get ngLeadsEmptyHint;

  /// Leads survey link dialog title
  ///
  /// In en, this message translates to:
  /// **'Survey link created'**
  String get ngSurveyLinkCreated;

  /// Dialog action
  ///
  /// In en, this message translates to:
  /// **'Copy & close'**
  String get ngCopyClose;

  /// Dialog action
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get ngClose;

  /// Orders chip
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get ngTabAll;

  /// Orders chip
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get ngTabPending;

  /// Orders chip
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get ngTabCompleted;

  /// Orders chip and card stage
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get ngTabCancelled;

  /// Orders day group
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get ngToday;

  /// Orders day group
  ///
  /// In en, this message translates to:
  /// **'Tomorrow'**
  String get ngTomorrow;

  /// Orders day group
  ///
  /// In en, this message translates to:
  /// **'Yesterday'**
  String get ngYesterday;

  /// Orders group with no date
  ///
  /// In en, this message translates to:
  /// **'No move date'**
  String get ngNoMoveDate;

  /// Payment state
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get ngPaid;

  /// Payment state
  ///
  /// In en, this message translates to:
  /// **'Part paid'**
  String get ngPartPaid;

  /// Payment state
  ///
  /// In en, this message translates to:
  /// **'Due'**
  String get ngDue;

  /// Payment state
  ///
  /// In en, this message translates to:
  /// **'Unpaid'**
  String get ngUnpaid;

  /// Orders header button
  ///
  /// In en, this message translates to:
  /// **'New order'**
  String get ngNewOrder;

  /// Orders empty
  ///
  /// In en, this message translates to:
  /// **'No orders here'**
  String get ngNoOrdersHere;

  /// Payments action
  ///
  /// In en, this message translates to:
  /// **'Remind'**
  String get ngRemind;

  /// Payments action
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get ngRecord;

  /// Payments group
  ///
  /// In en, this message translates to:
  /// **'Overdue'**
  String get ngOverdue;

  /// Payments group
  ///
  /// In en, this message translates to:
  /// **'Upcoming'**
  String get ngUpcoming;

  /// Payments empty
  ///
  /// In en, this message translates to:
  /// **'Nothing to collect'**
  String get ngNothingToCollect;

  /// PIN login header
  ///
  /// In en, this message translates to:
  /// **'Linked device'**
  String get ngLinkedDevice;

  /// PIN login
  ///
  /// In en, this message translates to:
  /// **'Enter your 4-digit PIN'**
  String get ngEnterPin;

  /// PIN login busy
  ///
  /// In en, this message translates to:
  /// **'Verifying…'**
  String get ngVerifying;

  /// PIN login link
  ///
  /// In en, this message translates to:
  /// **'Use email login instead'**
  String get ngUseEmail;

  /// PIN login link
  ///
  /// In en, this message translates to:
  /// **'Not your organization? Switch device'**
  String get ngSwitchDevice;

  /// PIN login footer
  ///
  /// In en, this message translates to:
  /// **'Secured by Nagarva'**
  String get ngSecuredBy;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Create your business account'**
  String get suCreate;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Step {n} of 4'**
  String suStep(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Mobile'**
  String get suS1;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Business'**
  String get suS2;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Documents'**
  String get suS3;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Review'**
  String get suS4;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Use the owner\'s number. You will log in with it.'**
  String get suPhS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Mobile number'**
  String get suPh;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Send OTP'**
  String get suSend;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Enter a 10-digit mobile number'**
  String get suPhBad;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Enter the OTP'**
  String get suOtpT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Sent to +91 {p}'**
  String suOtpS(String p);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Type the 6-digit code'**
  String get suEnter;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Verify'**
  String get suVerify;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Enter the 6-digit OTP'**
  String get suOtpBad;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Resend OTP'**
  String get suResend;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'OTP sent again'**
  String get suResent;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Change number'**
  String get suChange;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'About your business'**
  String get suBzT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'This appears on your quotes and invoices. You can change it later.'**
  String get suBzS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Business name'**
  String get suName;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'e.g. Arun Packers & Movers'**
  String get suNameP;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Owner name'**
  String get suOwner;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Email (optional)'**
  String get suEmail;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'For invoices and password reset'**
  String get suEmailP;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get suCity;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'What do you do?'**
  String get suType;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Packers & movers'**
  String get suTPm;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'House and office shifting'**
  String get suTPmS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Transport'**
  String get suTTr;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Trucks, trips and LR'**
  String get suTTrS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Both'**
  String get suTBo;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Shifting and transport'**
  String get suTBoS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'GSTIN (optional)'**
  String get suGst;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'15-character GST number'**
  String get suGstP;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Referral code (optional)'**
  String get suRef;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Fill business name, owner name and city'**
  String get suNeedBz;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'GSTIN should be 15 characters'**
  String get suGstBad;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Check the email address'**
  String get suEmailBad;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Verify your business'**
  String get suDcT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Photos or PDFs. Our team checks these before your account goes live.'**
  String get suDcS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'PAN card'**
  String get suPan;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Owner or business PAN'**
  String get suPanS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'GST certificate'**
  String get suGstC;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Needed because you added a GSTIN'**
  String get suGstCS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Office or godown photo'**
  String get suShop;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Helps us verify faster'**
  String get suShopS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Upload'**
  String get suUpload;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Required'**
  String get suReq;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Optional'**
  String get suOpt;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Upload your PAN card'**
  String get suNeedPan;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Upload the GST certificate or remove the GSTIN'**
  String get suNeedGstC;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Documents are used only to verify your business. They are not shown to your staff or customers.'**
  String get suPriv;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Check and submit'**
  String get suRvT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get suEdit;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'What happens next'**
  String get suNext;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Our team checks your details, usually within 1 working day.'**
  String get suN1;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'You start on the Free plan. Upgrade any time.'**
  String get suN3;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Accept the terms to continue'**
  String get suNeedAgree;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Submit for approval'**
  String get suSubmit;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get suContinue;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Mobile'**
  String get suMob;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Business type'**
  String get suBt;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Not added'**
  String get suNone;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Application under review'**
  String get suPendT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Application {id}'**
  String suAppId(String id);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Submitted'**
  String get suTl1;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Documents check'**
  String get suTl2;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Account ready'**
  String get suTl3;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Your account is ready'**
  String get suOkT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'{b} is approved. Choose how you want to start.'**
  String suOkS(String b);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Start using Nagarva'**
  String get suStart;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Changes needed'**
  String get suNoT;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Our team could not approve the application yet. Fix the item below and submit again.'**
  String get suNoS;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Fix and resubmit'**
  String get suFix;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Chat with us on WhatsApp'**
  String get suWa;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Back to login'**
  String get suToLogin;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Already have an account?'**
  String get suHave;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Log in'**
  String get suLogin;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Application under review'**
  String get suBnP;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Account approved'**
  String get suBnOk;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Changes needed on your application'**
  String get suBnNo;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get suView;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Application submitted'**
  String get suSent;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Terms of use'**
  String get lgTerms;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Privacy policy'**
  String get lgPriv;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Try Pro free for {n} days'**
  String suTrT(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Up to {n} users'**
  String suTrUsers(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Unlimited orders every month'**
  String get suTrOrdersAll;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'{n} orders a month'**
  String suTrOrders(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Reports and P&L'**
  String get suTrReports;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Multiple branches'**
  String get suTrBranches;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'No card needed. After {n} days you move to the Free plan automatically. Your data stays.'**
  String suTrNote(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Start {n}-day Pro trial'**
  String suTrBtn(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Stay on Free'**
  String get suStayFree;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Pro trial started · {n} days'**
  String suTrOn(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'You are on the Free plan'**
  String get suFreeOn;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Pro trial ends in {n} days. Then you move to the Free plan. Your data stays.'**
  String plTrBan(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Your Pro trial has ended. You are on the Free plan and all your data is safe.'**
  String get plTrEnded;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Pro trial ends on {d} · {n} days left'**
  String plTrEnds(String d, String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Log in with this mobile number any time to check your status.'**
  String get suN2b;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'We usually reply within 1 working day. Log in with +91 {p} to see the result.'**
  String suPendS2(String p);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Mobile sign-up is not switched on yet. Please contact Nagarva support.'**
  String get suOtpUnavailable;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Could not send the OTP. Check the number and try again.'**
  String get suSendFailed;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'That code did not work. Check it and try again.'**
  String get suOtpFailed;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Upload failed. Try again.'**
  String get suUploadFailed;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Log in with mobile number'**
  String get suMobileLogin;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Check status'**
  String get suRefresh;

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'Resend in {n}s'**
  String suResendIn(String n);

  /// VendorSignupPage / trial (handoff 21 Oct 2026)
  ///
  /// In en, this message translates to:
  /// **'I agree to the'**
  String get suAgreeLead;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Good morning'**
  String get ngGreetMorning;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Good afternoon'**
  String get ngGreetAfternoon;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Good evening'**
  String get ngGreetEvening;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{plan} plan'**
  String ngPlanName(String plan);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get ngPlanActive;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Trial'**
  String get ngPlanTrial;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Ending soon'**
  String get ngPlanEndingSoon;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Ended'**
  String get ngPlanEnded;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Trial ends {date} · {days} days left'**
  String ngPlanTrialEnds(String date, int days);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Trial ended · view only in {days} days'**
  String ngPlanReadOnlyIn(int days);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Trial ended · view only'**
  String get ngPlanReadOnly;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No expiry date'**
  String get ngPlanNoExpiry;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Plans'**
  String get ngPlanSee;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Payments due'**
  String get ngPaymentsDue;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{n} orders not fully paid'**
  String ngPaymentsDueSub(int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Overdue follow-ups'**
  String get ngOverdueFollowUps;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Call these first'**
  String get ngOverdueFollowUpsSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Today\'s plan'**
  String get ngTodaysPlan;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Nothing planned for today'**
  String get ngNothingToday;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Coming up'**
  String get ngComingUp;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Move · {name}'**
  String ngAgendaMove(String name);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'All day'**
  String get ngAllDay;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'This month'**
  String get ngPeriodThisMonth;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Last month'**
  String get ngPeriodLastMonth;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Last 3 months'**
  String get ngPeriod3m;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'This financial year'**
  String get ngPeriodFy;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'All time'**
  String get ngPeriodAll;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Show figures for'**
  String get ngPickPeriod;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Profit target'**
  String get ngProfitTarget;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Set a monthly profit target'**
  String get ngSetTarget;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Tap to set the number you want to reach'**
  String get ngSetTargetSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Profit'**
  String get ngProfit;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'After labour {labour} and expenses {expenses}'**
  String ngProfitAfter(String labour, String expenses);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Add expense'**
  String get ngAddExpense;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get ngSeeAll;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Hot leads'**
  String get ngHotLeads;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Branches'**
  String get ngBranches;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{n} orders'**
  String ngOrdersN(int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Target met'**
  String get ngTargetDone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No profit yet this period'**
  String get ngNoProfitYet;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Monthly profit target'**
  String get ngEditTarget;

  /// Lead card action
  ///
  /// In en, this message translates to:
  /// **'Quote'**
  String get ngQuote;

  /// Orders tab
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get ngTabDone;

  /// Payments tab
  ///
  /// In en, this message translates to:
  /// **'Received'**
  String get ngReceived;

  /// Payments due card
  ///
  /// In en, this message translates to:
  /// **'{n, plural, =1{1 day late} other{{n} days late}}'**
  String ngDaysLate(int n);

  /// Payments received empty
  ///
  /// In en, this message translates to:
  /// **'No payments recorded yet'**
  String get ngNoPaymentsYet;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Operations'**
  String get ngOpsTitle;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'New trip'**
  String get ngOpsNewTrip;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Crews out'**
  String get ngOpsCrewsOut;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Vehicles free'**
  String get ngOpsVehiclesFree;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Needs attention'**
  String get ngOpsAttention;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No crew · {name}'**
  String ngOpsNoCrew(String name);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Assign'**
  String get ngOpsAssign;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Assign crew'**
  String get ngOpsAssignCrew;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Insurance expires in {n} days'**
  String ngOpsInsuranceExpires(int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Insurance expired'**
  String get ngOpsInsuranceExpired;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{name} running low'**
  String ngOpsLowStock(String name);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{qty} left'**
  String ngOpsStockLeft(String qty);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Reorder'**
  String get ngOpsReorder;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get ngOpsView;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Awaiting approval'**
  String get ngOpsAwaiting;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Jobs'**
  String get ngOpsJobs;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No moves on this day'**
  String get ngOpsNoJobs;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Fleet'**
  String get ngOpsFleet;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{free} of {total} free'**
  String ngOpsFleetSummary(int free, int total);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'In service'**
  String get ngOpsInService;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'On a job'**
  String get ngOpsOnJob;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Free'**
  String get ngOpsFree;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{n, plural, =1{1 expense} other{{n} expenses}}'**
  String ngExpCount(int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{pct}% vs last month'**
  String ngExpVsLast(int pct);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'This week'**
  String get ngExpThisWeek;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Order-linked only'**
  String get ngExpOrderOnly;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No expenses in this period'**
  String get ngExpNone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Uncategorised'**
  String get ngExpUncategorised;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Delete expense'**
  String get ngExpDelete;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'By category'**
  String get ngExpByCategory;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Nothing to break down yet'**
  String get ngExpNoCat;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Categories appear here once you record an expense.'**
  String get ngExpNoCatSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'New vehicle'**
  String get ngFleetNew;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get ngFleetActive;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Maintenance'**
  String get ngFleetMaintenance;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get ngFleetInactive;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No vehicles yet. Add one to track documents and trips.'**
  String get ngFleetNone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Delete vehicle'**
  String get ngFleetDelete;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Insurance'**
  String get ngFleetInsurance;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Permit'**
  String get ngFleetPermit;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{doc} expires in {n} days'**
  String ngFleetExpires(String doc, int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{doc} expired {n} days ago'**
  String ngFleetExpired(String doc, int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'New material'**
  String get ngMatNew;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Search materials'**
  String get ngMatSearch;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Reorder soon'**
  String get ngMatReorderSoon;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Returnable'**
  String get ngMatReturnable;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'min {n}'**
  String ngMatMin(String n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Delete material'**
  String get ngMatDelete;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No materials here yet'**
  String get ngMatNone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Planned'**
  String get ngTripPlanned;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Ongoing'**
  String get ngTripOngoing;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No trips yet'**
  String get ngTripNone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'(no trip no.)'**
  String get ngTripNoNumber;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Hired'**
  String get ngTripHired;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Own'**
  String get ngTripOwn;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Delete trip'**
  String get ngTripDelete;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{n, plural, =1{1 customer} other{{n} customers}}'**
  String ngCustCount(int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get ngCustNew;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Search name, phone or company'**
  String get ngCustSearch;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No customers found'**
  String get ngCustNone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{amount} due'**
  String ngCustDue(String amount);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Staff'**
  String get ngStaffTitle;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{n} people · {monthly} monthly · {other} daily / temporary'**
  String ngStaffSummary(int n, int monthly, int other);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Add staff'**
  String get ngStaffAdd;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Fixed monthly'**
  String get ngStaffMonthly;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Daily'**
  String get ngStaffDaily;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Temporary'**
  String get ngStaffTemporary;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Joined {date}'**
  String ngStaffJoined(String date);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'All roles'**
  String get ngStaffAllRoles;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No staff here yet'**
  String get ngStaffNone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get ngStaffInactive;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Salary'**
  String get ngSalTitle;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'To pay'**
  String get ngSalToPay;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Advances'**
  String get ngSalAdvances;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Salary paid'**
  String get ngSalPaid;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get ngSalBalance;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{n, plural, =1{1 job} other{{n} jobs}}'**
  String ngSalJobs(int n);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Advance {amount}'**
  String ngSalAdvance(String amount);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Earnings come from the crew entered on each job this month. Open a person to pay or give an advance.'**
  String get ngSalNote;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'App'**
  String get ngSetApp;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get ngSetLanguage;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Theme'**
  String get ngSetTheme;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Light'**
  String get ngSetThemeLight;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Dark'**
  String get ngSetThemeDark;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Midnight'**
  String get ngSetThemeMidnight;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get ngSetNotifications;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Show alerts while the app is open'**
  String get ngSetNotificationsSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Business'**
  String get ngSetBusiness;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Business details'**
  String get ngSetBizDetails;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Name, tagline, GST, address, logo, signature, terms, numbering'**
  String get ngSetBizDetailsSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'CFT & packages'**
  String get ngSetCft;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Item volumes, house sizes and storage rates'**
  String get ngSetCftSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Security'**
  String get ngSetSecurity;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Login & security'**
  String get ngSetLogin;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Your app PIN'**
  String get ngSetLoginSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Account & support'**
  String get ngSetAccount;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Plan & billing'**
  String get ngSetPlan;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Your plan and its limits'**
  String get ngSetPlanSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Deleted items'**
  String get ngSetRecycle;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Restore anything deleted by mistake'**
  String get ngSetRecycleSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Help & support'**
  String get ngSetHelp;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Support contact, privacy policy and terms'**
  String get ngSetHelpSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Porter integration'**
  String get ngSetPorter;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Show Porter commission on the dashboard. Turn on only if your business uses Porter.'**
  String get ngSetPorterSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Stage {n} of {total} · {name}'**
  String odStageOf(int n, int total, String name);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'All stages done'**
  String get odJourneyDone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Maps'**
  String get odMaps;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Progress'**
  String get odProgress;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'In progress'**
  String get odInProgress;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Mark as {stage}'**
  String odMarkAs(String stage);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Delivered is recorded when the crew finishes the job with the customer\'s code.'**
  String get odDeliveredHint;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Open field job'**
  String get odOpenFieldJob;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Crew & vehicle'**
  String get odCrewVehicle;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No crew assigned yet'**
  String get odNoCrew;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'No vehicle assigned'**
  String get odNoVehicle;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Supervisor · {name} · {count} crew'**
  String odSupervisorCrew(String name, int count);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'{count} crew'**
  String odCrewCount(int count);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Payment'**
  String get odPayment;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get odTotal;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get odPaid;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get odBalance;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Part paid'**
  String get odPartPaid;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get odFullyPaid;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Unpaid'**
  String get odUnpaid;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Remind'**
  String get odRemind;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Record payment'**
  String get odRecordPayment;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get odActivity;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'All {count}'**
  String odAllN(int count);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Stage changed'**
  String get odStageChanged;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Payment received · {amount}'**
  String odPaymentReceived(String amount);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Nothing recorded on this order yet.'**
  String get odNoActivity;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Move details'**
  String get odMoveDetails;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get odCancelled;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'More actions'**
  String get odMore;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Hi {customer}, a balance of {amount} is due for your move ({orderId}). Thank you, {vendor}'**
  String odRemindMsg(
      String customer, String amount, String orderId, String vendor);

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Confirmed'**
  String get odStConfirmed;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Packing'**
  String get odStPacking;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'In transit'**
  String get odStInTransit;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Arrived'**
  String get odStArrived;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Delivered'**
  String get odStDelivered;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get odStCompleted;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get nlPhone;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get nlName;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Route'**
  String get nlRoute;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Moving from'**
  String get nlMovingFrom;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Moving to'**
  String get nlMovingTo;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Service'**
  String get nlService;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'When'**
  String get nlWhen;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get nlToday;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Tomorrow'**
  String get nlTomorrow;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Pick date'**
  String get nlPickDate;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Source'**
  String get nlSource;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Branch'**
  String get nlBranch;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Next step'**
  String get nlNextStep;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Follow-up'**
  String get nlStepFollow;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Call again later'**
  String get nlStepFollowSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Survey'**
  String get nlStepSurvey;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Visit, link or on call'**
  String get nlStepSurveySub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Skip survey · Quote'**
  String get nlStepQuote;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Price on this call'**
  String get nlStepQuoteSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Confirm order'**
  String get nlStepConfirm;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Customer agreed now'**
  String get nlStepConfirmSub;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'More details'**
  String get nlMore;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Email (optional)'**
  String get nlEmail;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get nlNotes;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Enter the customer\'s name.'**
  String get nlNameRequired;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Add a branch in Settings before saving leads.'**
  String get nlNoBranches;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Update lead'**
  String get nlUpdateLead;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Pickup'**
  String get noPickup;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Drop'**
  String get noDrop;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Price & source'**
  String get noPricing;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Financial year & numbering'**
  String get ngSetFy;

  /// Dashboard redesign
  ///
  /// In en, this message translates to:
  /// **'Start next year\'s invoice and receipt numbers'**
  String get ngSetFySub;

  /// Settings row: WhatsApp connection
  ///
  /// In en, this message translates to:
  /// **'WhatsApp'**
  String get ngSetWa;

  /// Settings row subtitle
  ///
  /// In en, this message translates to:
  /// **'Send messages from your own number'**
  String get ngSetWaSub;

  /// Settings row: automatic messages
  ///
  /// In en, this message translates to:
  /// **'Auto WhatsApp'**
  String get ngSetAutoWa;

  /// Settings row subtitle (design pf_s_wa)
  ///
  /// In en, this message translates to:
  /// **'Messages sent to the customer at each stage'**
  String get ngSetAutoWaSub;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Modules'**
  String get mdTitle;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Packers & movers, transport or both'**
  String get mdSettingsSub;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Your business'**
  String get mdType;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Advanced'**
  String get mdAdv;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'{count} of {total} modules on'**
  String mdCount(int count, int total);

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'{count} of {total} on'**
  String mdGroupOn(int count, int total);

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Turned-off modules disappear from the menu. Your data stays saved and comes back when you turn the module on again.'**
  String get mdNote;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Reset to recommended for this business type'**
  String get mdReset;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Modules reset for {type}'**
  String mdResetDone(String type);

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'{type} selected · menu updated'**
  String mdTypeSet(String type);

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Only the owner can change modules'**
  String get mdOwnerOnly;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Could not save. Check your connection and try again.'**
  String get mdSaveFailed;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Packers & Movers'**
  String get btPm;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'House, office and vehicle shifting'**
  String get btPmS;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Transport / Logistics'**
  String get btTr;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Trucks, trips, freight and drivers'**
  String get btTrS;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Both'**
  String get btBoth;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'Shifting and transport, everything on'**
  String get btBothS;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'What does your business do?'**
  String get btTitle;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'We will show only the modules you need. You can change this any time in Settings › Modules.'**
  String get btSub;

  /// Business type / Settings › Modules (design bt_/md_)
  ///
  /// In en, this message translates to:
  /// **'You can change this later in Settings › Modules'**
  String get btLater;

  /// Setup › Dashboard widgets (design pf_dw)
  ///
  /// In en, this message translates to:
  /// **'Widgets'**
  String get dwTitle;

  /// design pf_s_dw
  ///
  /// In en, this message translates to:
  /// **'Choose what the owner dashboard shows'**
  String get dwSub;

  /// design dw_note
  ///
  /// In en, this message translates to:
  /// **'Owner dashboard shows these in this order. Use the arrow to move one up, the switch to hide it.'**
  String get dwNote;

  /// design dw_shown
  ///
  /// In en, this message translates to:
  /// **'Shown · position {n}'**
  String dwShown(int n);

  /// design dw_hidden
  ///
  /// In en, this message translates to:
  /// **'Hidden'**
  String get dwHidden;

  /// design dw_up
  ///
  /// In en, this message translates to:
  /// **'Up'**
  String get dwUp;

  /// Dashboard widget name (design WID0)
  ///
  /// In en, this message translates to:
  /// **'Today\'s numbers'**
  String get dwToday;

  /// design wx_fleet
  ///
  /// In en, this message translates to:
  /// **'Fleet status'**
  String get dwFleet;

  /// design wx_fleetS
  ///
  /// In en, this message translates to:
  /// **'{a} active · {s} in service'**
  String dwFleetSub(int a, int s);

  /// design wx_att
  ///
  /// In en, this message translates to:
  /// **'Staff attendance'**
  String get dwAttendance;

  /// design wx_attS
  ///
  /// In en, this message translates to:
  /// **'checked in today'**
  String get dwAttendanceSub;

  /// Dashboard widgets save error
  ///
  /// In en, this message translates to:
  /// **'Could not save. Check your connection and try again.'**
  String get dwSaveFailed;

  /// Journey Invoice stage (design jr_shareInv): generate/open and share the tax invoice
  ///
  /// In en, this message translates to:
  /// **'Share invoice'**
  String get jrShareInvoice;

  /// Journey Invoice stage: send the customer the signing link
  ///
  /// In en, this message translates to:
  /// **'Send for signature'**
  String get jrSendForSignature;

  /// Login & security (design sc_title)
  ///
  /// In en, this message translates to:
  /// **'Login & security'**
  String get lsTitle;

  /// Login & security (design sc_my)
  ///
  /// In en, this message translates to:
  /// **'Your login'**
  String get lsMy;

  /// Login & security (design sc_myEmail)
  ///
  /// In en, this message translates to:
  /// **'Login email'**
  String get lsMyEmail;

  /// Login & security (design sc_chPw)
  ///
  /// In en, this message translates to:
  /// **'Change password'**
  String get lsChangePw;

  /// Login & security (design sc_cur)
  ///
  /// In en, this message translates to:
  /// **'Current password'**
  String get lsCurPw;

  /// Login & security (design sc_new)
  ///
  /// In en, this message translates to:
  /// **'New password'**
  String get lsNewPw;

  /// Login & security (design sc_conf)
  ///
  /// In en, this message translates to:
  /// **'Confirm new password'**
  String get lsConfPw;

  /// Login & security (design sc_pwSub)
  ///
  /// In en, this message translates to:
  /// **'Use at least 8 characters'**
  String get lsPwSub;

  /// Login & security (design sc_pwShort)
  ///
  /// In en, this message translates to:
  /// **'Password must be at least 8 characters'**
  String get lsPwShort;

  /// Login & security (design sc_pwMis)
  ///
  /// In en, this message translates to:
  /// **'Passwords do not match'**
  String get lsPwMismatch;

  /// Login & security (design sc_pwCur)
  ///
  /// In en, this message translates to:
  /// **'Enter your current password'**
  String get lsPwCurReq;

  /// Login & security (design sc_pwDone)
  ///
  /// In en, this message translates to:
  /// **'Password updated'**
  String get lsPwDone;

  /// Login & security (design sc_upd)
  ///
  /// In en, this message translates to:
  /// **'Update password'**
  String get lsUpdatePw;

  /// Login & security (design sc_forgot)
  ///
  /// In en, this message translates to:
  /// **'Forgot your password? Use \"Forgot password?\" on the login screen. We email you a reset link.'**
  String get lsForgot;

  /// Login & security (design sc_staff)
  ///
  /// In en, this message translates to:
  /// **'Staff PINs'**
  String get lsStaffPins;

  /// Login & security (design sc_staffSub)
  ///
  /// In en, this message translates to:
  /// **'Staff and supervisors log in with a PIN. Set a new one if they forget it. Repeated wrong tries lock the PIN until you reset it.'**
  String get lsStaffPinsSub;

  /// Login & security (design sc_reset)
  ///
  /// In en, this message translates to:
  /// **'Reset PIN'**
  String get lsResetPin;

  /// Login & security (design sc_lastSet)
  ///
  /// In en, this message translates to:
  /// **'PIN set'**
  String get lsPinSet;

  /// Login & security (design sc_locked)
  ///
  /// In en, this message translates to:
  /// **'Locked · {n} wrong tries'**
  String lsLocked(int n);

  /// Login & security (design sc_newPin)
  ///
  /// In en, this message translates to:
  /// **'New PIN'**
  String get lsNewPin;

  /// Login & security (design sc_confPin)
  ///
  /// In en, this message translates to:
  /// **'Confirm PIN'**
  String get lsConfPin;

  /// Login & security (design sc_pinBad)
  ///
  /// In en, this message translates to:
  /// **'PIN must be 4 digits'**
  String get lsPinBad;

  /// Login & security (design sc_pinMis)
  ///
  /// In en, this message translates to:
  /// **'PINs do not match'**
  String get lsPinMismatch;

  /// Login & security (design sc_pinSet)
  ///
  /// In en, this message translates to:
  /// **'New PIN set for {name}'**
  String lsPinSetFor(String name);

  /// Login & security (design sc_tellStaff)
  ///
  /// In en, this message translates to:
  /// **'Tell the staff member their new PIN in person or by phone. It is never shown again.'**
  String get lsTellStaff;

  /// Login & security (design sc_setPin)
  ///
  /// In en, this message translates to:
  /// **'Set new PIN'**
  String get lsSetPin;

  /// Login & security (design sc_signOutAll)
  ///
  /// In en, this message translates to:
  /// **'Sign out all other devices'**
  String get lsSignOutAll;

  /// Login & security (design sc_allOut)
  ///
  /// In en, this message translates to:
  /// **'All other devices signed out'**
  String get lsAllOut;

  /// Login & security: staff member has no PIN yet
  ///
  /// In en, this message translates to:
  /// **'No PIN yet'**
  String get lsNoPin;

  /// Login & security: staff PIN reset is owner-only
  ///
  /// In en, this message translates to:
  /// **'Only the owner can reset staff PINs.'**
  String get lsOwnerOnly;

  /// Settings › Quote design (design qt_title)
  ///
  /// In en, this message translates to:
  /// **'Quote design'**
  String get qdTitle;

  /// Settings › Quote design (design qt_sub)
  ///
  /// In en, this message translates to:
  /// **'How your quotation PDF looks to customers.'**
  String get qdSub;

  /// Settings › Quote design (design qt_theme)
  ///
  /// In en, this message translates to:
  /// **'Theme'**
  String get qdTheme;

  /// Settings › Quote design (design qt_color)
  ///
  /// In en, this message translates to:
  /// **'Brand colour'**
  String get qdColor;

  /// Settings › Quote design (design qt_logo)
  ///
  /// In en, this message translates to:
  /// **'Logo'**
  String get qdLogo;

  /// Settings › Quote design (design qt_logoAdd)
  ///
  /// In en, this message translates to:
  /// **'Upload logo'**
  String get qdLogoAdd;

  /// Settings › Quote design (design qt_logoHint)
  ///
  /// In en, this message translates to:
  /// **'PNG or JPG, square works best'**
  String get qdLogoHint;

  /// Settings › Quote design (design qt_save)
  ///
  /// In en, this message translates to:
  /// **'Save design'**
  String get qdSave;

  /// Settings › Quote design (design qt_preview)
  ///
  /// In en, this message translates to:
  /// **'Preview sample PDF'**
  String get qdPreview;

  /// Settings › Quote design (design qt_saved)
  ///
  /// In en, this message translates to:
  /// **'Quote design saved'**
  String get qdSaved;

  /// Settings › Quote design (design qt_t1a)
  ///
  /// In en, this message translates to:
  /// **'Classic'**
  String get qdTheme1A;

  /// Settings › Quote design (design qt_t1b)
  ///
  /// In en, this message translates to:
  /// **'Bold band'**
  String get qdTheme1B;

  /// Settings › Quote design (design qt_t1c)
  ///
  /// In en, this message translates to:
  /// **'Sidebar'**
  String get qdTheme1C;

  /// Settings › Quote design (design qt_t1d)
  ///
  /// In en, this message translates to:
  /// **'Minimal'**
  String get qdTheme1D;

  /// Settings › Quote design (design qt_t1e)
  ///
  /// In en, this message translates to:
  /// **'Corporate'**
  String get qdTheme1E;

  /// Settings › Quote design (design qt_t1f)
  ///
  /// In en, this message translates to:
  /// **'Letterhead'**
  String get qdTheme1F;

  /// Settings › Quote design (design qt_d1a)
  ///
  /// In en, this message translates to:
  /// **'Serif, ruled lines'**
  String get qdThemeDesc1A;

  /// Settings › Quote design (design qt_d1b)
  ///
  /// In en, this message translates to:
  /// **'Colour header, rounded panels'**
  String get qdThemeDesc1B;

  /// Settings › Quote design (design qt_d1c)
  ///
  /// In en, this message translates to:
  /// **'Details column on the left'**
  String get qdThemeDesc1C;

  /// Settings › Quote design (design qt_d1d)
  ///
  /// In en, this message translates to:
  /// **'Black and white, prints anywhere'**
  String get qdThemeDesc1D;

  /// Settings › Quote design (design qt_d1e)
  ///
  /// In en, this message translates to:
  /// **'Boxed form, for office moves'**
  String get qdThemeDesc1E;

  /// Settings › Quote design (design qt_d1f)
  ///
  /// In en, this message translates to:
  /// **'Centred, double rule'**
  String get qdThemeDesc1F;

  /// Driver app (design dv_title)
  ///
  /// In en, this message translates to:
  /// **'Driver app'**
  String get drvTitle;

  /// Driver app (design dv_none)
  ///
  /// In en, this message translates to:
  /// **'No trip assigned today'**
  String get drvNone;

  /// Driver app (design dv_planned)
  ///
  /// In en, this message translates to:
  /// **'Planned'**
  String get drvPlanned;

  /// Driver app (design dv_ongoing)
  ///
  /// In en, this message translates to:
  /// **'On trip'**
  String get drvOngoing;

  /// Driver app (design dv_start)
  ///
  /// In en, this message translates to:
  /// **'Start trip'**
  String get drvStart;

  /// Driver app (design dv_end)
  ///
  /// In en, this message translates to:
  /// **'End trip'**
  String get drvEnd;

  /// Driver app (design dv_done)
  ///
  /// In en, this message translates to:
  /// **'Trip completed'**
  String get drvDone;

  /// Driver app (design dv_fuel)
  ///
  /// In en, this message translates to:
  /// **'Fuel'**
  String get drvFuel;

  /// Driver app (design dv_fuelT)
  ///
  /// In en, this message translates to:
  /// **'Add fuel'**
  String get drvFuelT;

  /// Driver app (design dv_toll)
  ///
  /// In en, this message translates to:
  /// **'Toll'**
  String get drvToll;

  /// Driver app (design dv_tollT)
  ///
  /// In en, this message translates to:
  /// **'Add toll'**
  String get drvTollT;

  /// Driver app (design dv_litres)
  ///
  /// In en, this message translates to:
  /// **'Litres'**
  String get drvLitres;

  /// Driver app (design dv_plaza)
  ///
  /// In en, this message translates to:
  /// **'Plaza'**
  String get drvPlaza;

  /// Driver app (design dv_add)
  ///
  /// In en, this message translates to:
  /// **'Add entry'**
  String get drvAdd;

  /// Driver app (design dv_need0)
  ///
  /// In en, this message translates to:
  /// **'Enter start odometer'**
  String get drvNeedStart;

  /// Driver app (design dv_need1)
  ///
  /// In en, this message translates to:
  /// **'End odometer must be more than start'**
  String get drvNeedEnd;

  /// Driver app (design dv_needA)
  ///
  /// In en, this message translates to:
  /// **'Enter the amount'**
  String get drvNeedAmount;

  /// Driver app (design dv_tKm)
  ///
  /// In en, this message translates to:
  /// **'Trip km'**
  String get drvTripKm;

  /// Driver app (design dv_tExp)
  ///
  /// In en, this message translates to:
  /// **'Trip spend'**
  String get drvTripSpend;

  /// Driver app (design dv_today)
  ///
  /// In en, this message translates to:
  /// **'Today’s entries'**
  String get drvToday;

  /// Driver app (design jr_odo0)
  ///
  /// In en, this message translates to:
  /// **'Start odometer'**
  String get drvOdoStart;

  /// Driver app (design jr_odo1)
  ///
  /// In en, this message translates to:
  /// **'End odometer'**
  String get drvOdoEnd;

  /// Nagarva jobs (design mk_title)
  ///
  /// In en, this message translates to:
  /// **'Nagarva jobs'**
  String get mktTitle;

  /// Nagarva jobs (design mk_sub)
  ///
  /// In en, this message translates to:
  /// **'Moves booked by customers on Nagarva'**
  String get mktSub;

  /// Nagarva jobs (design mk_tier)
  ///
  /// In en, this message translates to:
  /// **'Your tier'**
  String get mktTier;

  /// Nagarva jobs (design mk_wallet)
  ///
  /// In en, this message translates to:
  /// **'Wallet'**
  String get mktWallet;

  /// Nagarva jobs (design mk_minL)
  ///
  /// In en, this message translates to:
  /// **'Min {m} to get jobs'**
  String mktMinL(String m);

  /// Nagarva jobs (design mk_lowS)
  ///
  /// In en, this message translates to:
  /// **'Below minimum'**
  String get mktLowS;

  /// Nagarva jobs (design mk_tJobs)
  ///
  /// In en, this message translates to:
  /// **'Jobs'**
  String get mktTJobs;

  /// Nagarva jobs (design mk_tWallet)
  ///
  /// In en, this message translates to:
  /// **'Wallet'**
  String get mktTWallet;

  /// Nagarva jobs (design mk_tTier)
  ///
  /// In en, this message translates to:
  /// **'Tier'**
  String get mktTTier;

  /// Nagarva jobs (design mk_av)
  ///
  /// In en, this message translates to:
  /// **'Available for jobs'**
  String get mktAv;

  /// Nagarva jobs (design mk_avOn)
  ///
  /// In en, this message translates to:
  /// **'Getting job alerts for {c}'**
  String mktAvOn(String c);

  /// Nagarva jobs (design mk_avOff)
  ///
  /// In en, this message translates to:
  /// **'Off. No new job alerts. Your score is not affected.'**
  String get mktAvOff;

  /// Nagarva jobs (design mk_cities)
  ///
  /// In en, this message translates to:
  /// **'Pickup cities'**
  String get mktCities;

  /// Nagarva jobs (design mk_citiesN)
  ///
  /// In en, this message translates to:
  /// **'You get alerts for bookings that start in these cities. Home city cannot be removed.'**
  String get mktCitiesN;

  /// Nagarva jobs (design mk_edit)
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get mktEdit;

  /// Nagarva jobs (design mk_done2)
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get mktDone2;

  /// Nagarva jobs (design mk_cancel)
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get mktCancel;

  /// Nagarva jobs (design mk_home)
  ///
  /// In en, this message translates to:
  /// **'home'**
  String get mktHome;

  /// Nagarva jobs (design mk_rtAsk)
  ///
  /// In en, this message translates to:
  /// **'Truck in another city?'**
  String get mktRtAsk;

  /// Nagarva jobs (design mk_rtAdd)
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get mktRtAdd;

  /// Nagarva jobs (design mk_rtEnd)
  ///
  /// In en, this message translates to:
  /// **'End'**
  String get mktRtEnd;

  /// Nagarva jobs (design mk_rtFrom)
  ///
  /// In en, this message translates to:
  /// **'Truck is now in'**
  String get mktRtFrom;

  /// Nagarva jobs (design mk_rtDate)
  ///
  /// In en, this message translates to:
  /// **'Leaving on'**
  String get mktRtDate;

  /// Nagarva jobs (design mk_rtOn)
  ///
  /// In en, this message translates to:
  /// **'Return trip · {f} → {t}'**
  String mktRtOn(String f, String t);

  /// Nagarva jobs (design mk_rtEnded)
  ///
  /// In en, this message translates to:
  /// **'Return trip ended'**
  String get mktRtEnded;

  /// Nagarva jobs (design mk_fNew)
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get mktFNew;

  /// Nagarva jobs (design mk_fAcc)
  ///
  /// In en, this message translates to:
  /// **'Accepted'**
  String get mktFAcc;

  /// Nagarva jobs (design mk_fDone)
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get mktFDone;

  /// Nagarva jobs (design mk_eNew)
  ///
  /// In en, this message translates to:
  /// **'No new jobs right now. You will get a notification when one comes in.'**
  String get mktENew;

  /// Nagarva jobs (design mk_eAcc)
  ///
  /// In en, this message translates to:
  /// **'No accepted jobs.'**
  String get mktEAcc;

  /// Nagarva jobs (design mk_eDone)
  ///
  /// In en, this message translates to:
  /// **'No completed jobs yet.'**
  String get mktEDone;

  /// Nagarva jobs (design mk_eOff)
  ///
  /// In en, this message translates to:
  /// **'You are not available. Turn on Available for jobs to see new bookings.'**
  String get mktEOff;

  /// Nagarva jobs (design mk_low)
  ///
  /// In en, this message translates to:
  /// **'Wallet is below {m}. Top up {a} to see new jobs.'**
  String mktLow(String a, String m);

  /// Nagarva jobs (design mk_val)
  ///
  /// In en, this message translates to:
  /// **'Job value (incl. GST)'**
  String get mktVal;

  /// Nagarva jobs (design mk_com)
  ///
  /// In en, this message translates to:
  /// **'Nagarva commission {p}%'**
  String mktCom(String p);

  /// Nagarva jobs (design mk_earn)
  ///
  /// In en, this message translates to:
  /// **'You earn'**
  String get mktEarn;

  /// Nagarva jobs (design mk_adv)
  ///
  /// In en, this message translates to:
  /// **'Advance paid to Nagarva'**
  String get mktAdv;

  /// Nagarva jobs (design mk_bal)
  ///
  /// In en, this message translates to:
  /// **'Collect after delivery OTP'**
  String get mktBal;

  /// Nagarva jobs (design mk_masked)
  ///
  /// In en, this message translates to:
  /// **'Customer name and phone unlock after you accept'**
  String get mktMasked;

  /// Nagarva jobs (design mk_pass)
  ///
  /// In en, this message translates to:
  /// **'Pass'**
  String get mktPass;

  /// Nagarva jobs (design mk_accept)
  ///
  /// In en, this message translates to:
  /// **'Accept job'**
  String get mktAccept;

  /// Nagarva jobs (design mk_accepted)
  ///
  /// In en, this message translates to:
  /// **'{id} is yours. Customer details unlocked.'**
  String mktAccepted(String id);

  /// Nagarva jobs (design mk_passed)
  ///
  /// In en, this message translates to:
  /// **'Job passed'**
  String get mktPassed;

  /// Nagarva jobs (design mk_taken)
  ///
  /// In en, this message translates to:
  /// **'Taken by another vendor'**
  String get mktTaken;

  /// Nagarva jobs (design mk_goldOnly)
  ///
  /// In en, this message translates to:
  /// **'Gold only'**
  String get mktGoldOnly;

  /// Nagarva jobs (design mk_rl)
  ///
  /// In en, this message translates to:
  /// **'Return load'**
  String get mktRl;

  /// Nagarva jobs (design mk_s0)
  ///
  /// In en, this message translates to:
  /// **'Accepted'**
  String get mktS0;

  /// Nagarva jobs (design mk_s1)
  ///
  /// In en, this message translates to:
  /// **'On the way'**
  String get mktS1;

  /// Nagarva jobs (design mk_s2)
  ///
  /// In en, this message translates to:
  /// **'Arrived'**
  String get mktS2;

  /// Nagarva jobs (design mk_s3)
  ///
  /// In en, this message translates to:
  /// **'Loading'**
  String get mktS3;

  /// Nagarva jobs (design mk_s4)
  ///
  /// In en, this message translates to:
  /// **'In transit'**
  String get mktS4;

  /// Nagarva jobs (design mk_s5)
  ///
  /// In en, this message translates to:
  /// **'Delivered'**
  String get mktS5;

  /// Nagarva jobs (design mk_next)
  ///
  /// In en, this message translates to:
  /// **'Mark {s}'**
  String mktNext(String s);

  /// Nagarva jobs (design mk_photos)
  ///
  /// In en, this message translates to:
  /// **'Loading photos {n}/3'**
  String mktPhotos(int n);

  /// Nagarva jobs (design mk_needPh)
  ///
  /// In en, this message translates to:
  /// **'Add 3 loading photos first'**
  String get mktNeedPh;

  /// Nagarva jobs (design mk_addPh)
  ///
  /// In en, this message translates to:
  /// **'Add photo'**
  String get mktAddPh;

  /// Nagarva jobs (design mk_finish)
  ///
  /// In en, this message translates to:
  /// **'Verify OTP & complete'**
  String get mktFinish;

  /// Nagarva jobs (design mk_otpBad)
  ///
  /// In en, this message translates to:
  /// **'Wrong OTP. Check with the customer.'**
  String get mktOtpBad;

  /// Nagarva jobs (design mk_done)
  ///
  /// In en, this message translates to:
  /// **'Completed. {c} commission deducted, {a} advance credited.'**
  String mktDone(String a, String c);

  /// Nagarva jobs (design mk_rate)
  ///
  /// In en, this message translates to:
  /// **'Customer rating {r}'**
  String mktRate(String r);

  /// Nagarva jobs (design mk_noRate)
  ///
  /// In en, this message translates to:
  /// **'Awaiting customer rating'**
  String get mktNoRate;

  /// Nagarva jobs (design mk_topup)
  ///
  /// In en, this message translates to:
  /// **'Top up'**
  String get mktTopup;

  /// Nagarva jobs (design w_bal)
  ///
  /// In en, this message translates to:
  /// **'Wallet balance'**
  String get mktWBal;

  /// Nagarva jobs (design w_ok)
  ///
  /// In en, this message translates to:
  /// **'Active · you get new jobs'**
  String get mktWOk;

  /// Nagarva jobs (design w_withdraw)
  ///
  /// In en, this message translates to:
  /// **'Withdraw'**
  String get mktWWithdraw;

  /// Nagarva jobs (design w_note)
  ///
  /// In en, this message translates to:
  /// **'Customers pay the advance to Nagarva. When you complete a job, the advance is credited here and the {p}% commission is deducted. Keep the minimum balance to receive jobs.'**
  String mktWNote(String p);

  /// Nagarva jobs (design wt_adv)
  ///
  /// In en, this message translates to:
  /// **'Advance · {id}'**
  String mktWtAdv(String id);

  /// Nagarva jobs (design wt_com)
  ///
  /// In en, this message translates to:
  /// **'Commission · {id}'**
  String mktWtCom(String id);

  /// Nagarva jobs (design wt_top)
  ///
  /// In en, this message translates to:
  /// **'UPI top-up'**
  String get mktWtTop;

  /// Nagarva jobs (design wt_wd)
  ///
  /// In en, this message translates to:
  /// **'Withdrawal to bank'**
  String get mktWtWd;

  /// Nagarva jobs (design tr_f)
  ///
  /// In en, this message translates to:
  /// **'How your score is made'**
  String get mktTierF;

  /// Nagarva jobs (design tr_bands)
  ///
  /// In en, this message translates to:
  /// **'Gold 80+ · Silver 60–79 · Bronze <60'**
  String get mktTierBands;

  /// Nagarva jobs (design tr_gold)
  ///
  /// In en, this message translates to:
  /// **'Gold'**
  String get mktTierGold;

  /// Nagarva jobs (design tr_silver)
  ///
  /// In en, this message translates to:
  /// **'Silver'**
  String get mktTierSilver;

  /// Nagarva jobs (design tr_bronze)
  ///
  /// In en, this message translates to:
  /// **'Bronze'**
  String get mktTierBronze;

  /// Nagarva jobs (design tr_score)
  ///
  /// In en, this message translates to:
  /// **'Score {s} / 100'**
  String mktTierScore(String s);

  /// Nagarva jobs: delivery code prompt
  ///
  /// In en, this message translates to:
  /// **'Ask the customer for the 4-digit delivery code.'**
  String get mktOtpAsk;

  /// Nagarva jobs: wallet request sent
  ///
  /// In en, this message translates to:
  /// **'Request sent. It counts once Nagarva confirms the payment.'**
  String get mktReqSent;

  /// Nagarva jobs: pending wallet row
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get mktPending;

  /// Nagarva jobs: home city field
  ///
  /// In en, this message translates to:
  /// **'Home city'**
  String get mktHomeCity;

  /// Nagarva jobs: extra cities field
  ///
  /// In en, this message translates to:
  /// **'Other cities, separated by commas'**
  String get mktExtraCities;

  /// Nagarva jobs: vendor has no profile yet
  ///
  /// In en, this message translates to:
  /// **'Set your home city to start getting Nagarva jobs.'**
  String get mktNotJoined;

  /// Nagarva jobs: tier tab note
  ///
  /// In en, this message translates to:
  /// **'Nagarva works out your score from these, with these weights.'**
  String get mktFactorNote;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'Customer rating'**
  String get mktFRating;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'On-time arrival'**
  String get mktFOnTime;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'Damage claims'**
  String get mktFDamage;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'Acceptance rate'**
  String get mktFAccept;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'Photo compliance'**
  String get mktFPhotos;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'Vendor cancellations'**
  String get mktFCancel;

  /// Tier factor
  ///
  /// In en, this message translates to:
  /// **'Jobs completed'**
  String get mktFJobs;

  /// Nagarva jobs (design mk_avOnT)
  ///
  /// In en, this message translates to:
  /// **'You will get job alerts again'**
  String get mktAvOnT;

  /// Nagarva jobs (design mk_avOffT)
  ///
  /// In en, this message translates to:
  /// **'Job alerts paused'**
  String get mktAvOffT;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>[
        'en',
        'hi',
        'kn',
        'ml',
        'ta',
        'te'
      ].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'hi':
      return AppLocalizationsHi();
    case 'kn':
      return AppLocalizationsKn();
    case 'ml':
      return AppLocalizationsMl();
    case 'ta':
      return AppLocalizationsTa();
    case 'te':
      return AppLocalizationsTe();
  }

  throw FlutterError(
      'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
      'an issue with the localizations generation tool. Please file an issue '
      'on GitHub with a reproducible sample app and the gen-l10n configuration '
      'that was used.');
}
