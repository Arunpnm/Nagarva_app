import 'package:flutter/material.dart';

import '/l10n/gen/app_localizations.dart';

import '/app_session.dart';
import '/backend/device_org_binding.dart';
import '/backend/edge_function_errors.dart';
import '/backend/org_resolution.dart';
import '/backend/supabase/supabase.dart';
import '/backend/supabase/org_session_loader.dart';
import '/backend/vendor_org_resolver.dart';
import '/flutter_flow/ng_tokens.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/components/language_quick_button.dart';
import '/components/ng_top_bar.dart';
import '/components/theme_quick_button.dart';
import '/index.dart';
import '/permissions.dart';

/// Unified PIN login (parity brief Part 7). Ported from reference/APC Web
/// App JSX/App.jsx's LoginScreen (~line 1341): four single-digit boxes,
/// auto-advance, backspace-back, auto-submit on the 4th digit, an
/// on-screen numpad, and a shake-on-wrong-PIN animation. No email, no
/// password, no phone entry — owner and staff share this one screen, each
/// typing their own PIN. The org comes from the device (see
/// DeviceOrgBinding), never typed here.
///
/// The old two-tab email/password + phone/PIN LoginPageWidget is kept,
/// unreachable from normal navigation but not deleted — this flow could
/// not be live-tested this session (network outage), and it's also the
/// only path that can set an owner's PIN for the very first time (see
/// "Use email login instead" below).
class PinLoginPageWidget extends StatefulWidget {
  const PinLoginPageWidget({super.key});

  static String routeName = 'PinLoginPage';
  static String routePath = '/pin-login';

  @override
  State<PinLoginPageWidget> createState() => _PinLoginPageWidgetState();
}

class _PinLoginPageWidgetState extends State<PinLoginPageWidget>
    with SingleTickerProviderStateMixin {
  final _digits = <String>['', '', '', ''];
  int _focusedBox = 0;
  bool _busy = false;
  String? _error;
  late final AnimationController _shakeCtrl;

  @override
  void initState() {
    super.initState();
    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    super.dispose();
  }

  void _tapDigit(String d) {
    if (_busy) return;
    final i = _digits.indexOf('');
    if (i == -1) return;
    setState(() {
      _digits[i] = d;
      _focusedBox = i == 3 ? 3 : i + 1;
    });
    if (i == 3) _submit();
  }

  void _tapBackspace() {
    if (_busy) return;
    var i = _digits.lastIndexWhere((d) => d.isNotEmpty);
    if (i == -1) return;
    setState(() {
      _digits[i] = '';
      _focusedBox = i;
    });
  }

  Future<void> _submit() async {
    final pin = _digits.join();
    if (pin.length != 4) return;
    final orgId = DeviceOrgBinding.boundOrgId;
    if (orgId == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      // Auth plan REVISED item 4. A device bound to a specific PERSON
      // goes to `staff-login` with {staff_id, pin} — it never searches the
      // org-wide pool and so cannot reach the owner's credentials at all.
      // That is the structural fix for the privilege escalation; the
      // collision guard in verify_org_pin is the stopgap for devices still
      // on the old org-only binding.
      //
      // `pin-login` is now effectively owner-only: reached only by a
      // device bound by org slug with no staff_id.
      final staffId = DeviceOrgBinding.boundStaffId;
      final res = staffId != null
          ? await SupaFlow.client.functions.invoke(
              'staff-login',
              body: {'staff_id': staffId, 'pin': pin},
            )
          : await SupaFlow.client.functions.invoke(
              'pin-login',
              body: {'org_id': orgId, 'pin': pin},
            );
      final data = res.data;
      if (data is! Map || data['access_token'] == null) {
        throw Exception('Wrong PIN. Try again.');
      }
      // staff-login returns no `kind` — it only ever authenticates staff,
      // which is the point. Treat its response as the staff branch.
      final kind = staffId != null ? 'staff' : data['kind'] as String?;
      final refreshToken = data['refresh_token'] as String;

      final swap = await SupaFlow.client.auth.setSession(refreshToken);
      if (swap.session == null) throw Exception('Could not start session.');

      if (kind == 'staff') {
        final staff = Map<String, dynamic>.from(data['staff'] as Map);
        final staffOrgId = staff['org_id'] as String;
        // Part 7 drops the old requirement of an existing vendor session
        // on this device (see login_page_widget.dart's "device not set up
        // for staff login yet" guard) — a fresh device now needs its own
        // org display info, hence loading it here via setOrgOnly rather
        // than relying on a vendor session that was set up earlier.
        final sessionData = await loadOrgSessionData(staffOrgId);
        AppSession.instance.setOrgOnly(
          orgId: sessionData.orgId,
          orgName: sessionData.orgName,
          orgSlug: sessionData.orgSlug,
          logoUrl: sessionData.logoUrl,
          limits: sessionData.limits,
          features: sessionData.features,
          planName: sessionData.planName,
          planStatus: sessionData.planStatus,
          trialEndsAt: sessionData.trialEndsAt,
          graceDays: sessionData.graceDays,
          orgActive: sessionData.orgActive,
          trialFallsBackToFree: sessionData.trialFallsBackToFree,
          trialEndedToFree: sessionData.trialEndedToFree,
        );
        AppSession.instance.setStaff(
          staffId: staff['id'] as String,
          staffName: (staff['name'] as String?) ?? 'Staff',
          role: staff['role'] as String?,
        );
        // Was missing — the only one of the three setStaff() call sites
        // that didn't also load the permission matrix (main.dart's
        // session-restore and the legacy login_page_widget.dart both
        // already do this). Without it, StaffPermissions.activeStaffPages
        // stays null for the rest of the session, and main.dart's nav
        // filter used to silently substitute a hardcoded 3-item guess
        // instead of the real permission-driven set.
        await StaffPermissions.loadForStaff(staff['id'] as String);
      } else {
        // Owner: resolve org/plan through the same create-org recovery
        // path login_page_widget.dart's _handleVendorLogin and the
        // email-confirmation deep-link handler both use — this branch
        // used to just throw "not linked to any organization" on an
        // empty org_members, the same dead end §2a's recovery exists to
        // close everywhere else. No promptForOrgName here: a PIN-login
        // device implies the org already exists (that's what the PIN was
        // verified against), so org_name metadata being missing on this
        // path would mean something is genuinely wrong, not a legitimate
        // "ask the user" case.
        final user = SupaFlow.client.auth.currentUser!;
        final availableOrgs = await resolveVendorOrgs(user);
        // CORRECTNESS FIX, 27 Aug 2026. This used to be
        // `availableOrgs.first.orgId` — so the PIN was verified against
        // `orgId` (DeviceOrgBinding.boundOrgId, above) and the session
        // was then established for an UNRELATED row. With several orgs
        // live, an owner could authenticate against one legal entity and
        // land in another's books; it had not bitten only because row
        // order happened to favour the right one, and that order is not
        // even deterministic.
        //
        // The bound org is now the SOLE input on this path — not
        // consulted-then-preferred, which would leave it readable as a
        // preference. resolveActiveOrg throws if it is not a real
        // membership rather than falling through to another org.
        final resolved = await resolveActiveOrg(
          availableOrgs: availableOrgs,
          boundOrgId: orgId,
        );
        if (resolved == null) {
          throw Exception('Your account is not linked to any organization.');
        }
        await establishVendorSession(user, resolved.orgId, availableOrgs);
      }

      if (!mounted) return;
      context.go(HomePageWidget.routePath);
    } catch (e) {
      // `invoke` throws FunctionException on any non-2xx response (17 Aug
      // 2026 finding — see edge_function_errors.dart) — a wrong PIN (401)
      // or a rate-limit lockout (429) both land here, not in the
      // `data['access_token'] == null` check above, which is why this
      // screen used to show a raw "FunctionException(status: ...)" string
      // instead of "Wrong PIN. Try again." / the lockout message.
      _shakeCtrl.forward(from: 0);
      setState(() {
        _digits.setAll(0, ['', '', '', '']);
        _focusedBox = 0;
        _error = extractFunctionErrorMessage(e,
            fallback: e.toString().replaceFirst('Exception: ', ''));
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Redesign ("LOGIN B: PIN-first, device bound"): a 16px dot per digit
  /// instead of a box — filled accent once entered, the next position
  /// ringed in accent, the rest a w25 ring.
  Widget _pinDot(int i) {
    final c = NgPalette.of(context);
    final filled = _digits[i].isNotEmpty;
    final next = !filled && _focusedBox == i;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: filled ? c.accBtn : Colors.transparent,
        border: Border.all(
          color: filled || next ? c.accBtn : c.hairline(0.25),
          width: 1.5,
        ),
      ),
    );
  }

  Widget _numKey(String label,
      {VoidCallback? onTap, Widget? icon, double width = 72}) {
    final c = NgPalette.of(context);
    return SizedBox(
      width: width,
      height: 66,
      child: Material(
        color: c.s1,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Center(
            child: icon ??
                Text(label,
                    style: NgFonts.geist(
                        fontSize: 28,
                        fontWeight: FontWeight.w500,
                        color: c.text)),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = NgPalette.of(context);
    // The org this device is bound to — never the platform. A person
    // signing in should see who they are signing in to.
    final orgName = (DeviceOrgBinding.boundOrgName ?? '').trim();
    return Scaffold(
      backgroundColor: c.bg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 26),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Redesign top row: the device-binding state on the left
                // (this screen only ever shows on a bound device), theme
                // and language on the right — both reachable before
                // signing in, as in the handoff.
                Row(
                  children: [
                    Icon(Icons.verified_user_rounded,
                        size: 16, color: c.green),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(AppLocalizations.of(context).ngLinkedDevice,
                          style: NgFonts.geist(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w500,
                              color: c.green)),
                    ),
                    NgHeaderButton(
                        child: ThemeQuickButton(iconColor: c.soft)),
                    const SizedBox(width: 8),
                    NgHeaderButton(
                        child: LanguageQuickButton(iconColor: c.soft)),
                  ],
                ),
                const SizedBox(height: 44),
                Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: c.w04, width: 6,
                        strokeAlign: BorderSide.strokeAlignOutside),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset('assets/images/nagarva_logo.png',
                      fit: BoxFit.cover),
                ),
                const SizedBox(height: 14),
                Text(orgName,
                    textAlign: TextAlign.center,
                    style: NgFonts.geist(
                        fontSize: 21,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.21,
                        color: c.text)),
                const SizedBox(height: 6),
                Text(AppLocalizations.of(context).ngEnterPin,
                    style: NgFonts.geist(fontSize: 14, color: c.mute)),
                const SizedBox(height: 24),
                AnimatedBuilder(
                  animation: _shakeCtrl,
                  builder: (context, child) {
                    final t = _shakeCtrl.value;
                    final dx = (t == 0 || t == 1)
                        ? 0.0
                        : 10 *
                            (t < 0.5 ? 1 : -1) *
                            (1 - (t - 0.5).abs() * 2);
                    return Transform.translate(
                        offset: Offset(dx, 0), child: child);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (var i = 0; i < 4; i++) ...[
                        _pinDot(i),
                        if (i < 3) const SizedBox(width: 18),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 20,
                  // Was a bare default-colour CircularProgressIndicator —
                  // read as generic rather than branded. Same gold as the
                  // truck icon/active PIN boxes, plus a label, so a wait
                  // longer than a beat still reads as "verifying your
                  // PIN" rather than an unexplained spinner.
                  child: _busy
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: c.acc,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(AppLocalizations.of(context).ngVerifying,
                                style: TextStyle(
                                    color: c.mute,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500)),
                          ],
                        )
                      : (_error != null
                          ? Text(_error!,
                              style: TextStyle(
                                  color: c.red,
                                  fontWeight: FontWeight.w600))
                          : null),
                ),
                const SizedBox(height: 20),
                // Fixed 3-wide grid (phone dialpad / ATM / calculator
                // convention), not a width-dependent Wrap — the previous
                // Wrap happened to fit 4 keys per row on some screen
                // widths (1 2 3 4 / 5 6 7 8 / 9 _ 0 <-), which fights
                // muscle memory for staff dialling a PIN many times a day.
                // 0 centred in the bottom row, backspace bottom-right.
                //
                // Key width is computed from available space (72px cap,
                // 48px floor — Material's minimum touch target) rather
                // than hardcoded, so 3 columns stays provably true on any
                // screen instead of relying on 72px happening to fit the
                // narrowest phone we'd expect. The old Wrap's bug was a
                // device-dependent layout; a hardcoded key width in its
                // replacement would just be the same class of assumption
                // with a different number.
                LayoutBuilder(
                  builder: (context, constraints) {
                    // Redesign: keys fill the width (3 equal columns,
                    // 12px gaps), 66 tall, radius 20.
                    const gap = 12.0;
                    final keyWidth = ((constraints.maxWidth - 2 * gap) / 3)
                        .clamp(48.0, 120.0);
                    return Column(
                      children: [
                        for (final row in [
                          ['1', '2', '3'],
                          ['4', '5', '6'],
                          ['7', '8', '9'],
                        ]) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              for (final d in row) ...[
                                _numKey(d,
                                    width: keyWidth, onTap: () => _tapDigit(d)),
                                if (d != row.last) const SizedBox(width: gap),
                              ],
                            ],
                          ),
                          const SizedBox(height: gap),
                        ],
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width: keyWidth, height: 66),
                            const SizedBox(width: gap),
                            _numKey('0',
                                width: keyWidth, onTap: () => _tapDigit('0')),
                            const SizedBox(width: gap),
                            _numKey('',
                                width: keyWidth,
                                icon: Icon(Icons.backspace_outlined,
                                    size: 24, color: c.text),
                                onTap: _tapBackspace),
                          ],
                        ),
                      ],
                    );
                  },
                ),
                const SizedBox(height: 24),
                TextButton(
                  onPressed: () => context.pushNamed(LoginPageWidget.routeName),
                  child: Text(AppLocalizations.of(context).ngUseEmail,
                      textAlign: TextAlign.center,
                      style: NgFonts.geist(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: c.acc)),
                ),
                TextButton(
                  onPressed: () async {
                    await DeviceOrgBinding.unbind();
                    if (mounted) {
                      context.pushNamed(OrgBindingPageWidget.routeName);
                    }
                  },
                  child: Text(AppLocalizations.of(context).ngSwitchDevice,
                      textAlign: TextAlign.center,
                      style: NgFonts.geist(fontSize: 13, color: c.mute)),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.lock_rounded, size: 14, color: c.faint),
                    const SizedBox(width: 5),
                    Text(AppLocalizations.of(context).ngSecuredBy,
                        style: NgFonts.geist(fontSize: 12, color: c.faint)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
