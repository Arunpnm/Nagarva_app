/// App-wide configuration constants.
///
/// Created 28 Jul 2026 for live-test fix brief #2, Item 1 (blocker).
library;

/// Public web origin used to build customer-facing links (survey, quote,
/// signature, order tracking) that are shared over WhatsApp/SMS.
///
/// **Never derive this from `Uri.base`.** That was the original bug: on
/// Flutter *web* `Uri.base` is the page URL so `Uri.base.origin` works, but
/// inside an installed APK `Uri.base` is `file:///` and `.origin` throws
///
///     Bad state: Origin is only applicable schemes http and https: file:///
///
/// which is exactly what the "Could not create survey link" toast was
/// reporting on device. The link-building code had only ever run on web.
///
/// Overridable at build time without touching source, for staging builds:
///
///     flutter build apk --dart-define=NAGARVA_PUBLIC_BASE_URL=https://staging.nagarva.in
///
/// If per-tenant custom domains are ever added, read the org's configured
/// domain from settings and fall back to this constant.
const String kPublicBaseUrl = String.fromEnvironment(
  'NAGARVA_PUBLIC_BASE_URL',
  defaultValue: 'https://link.nagarva.in',
);

/// Web origin Supabase Auth should redirect to after a confirmation or
/// password-reset email. Pass this explicitly on every client-side auth
/// call that sends an email (`signUp()`'s `emailRedirectTo`,
/// `resetPasswordForEmail()`'s `redirectTo`) rather than relying on the
/// Auth dashboard's Site URL default — see the 16 Aug 2026 redirect-issue
/// report for why that default can't be trusted blindly. Requires this
/// exact URL to be present in Supabase's Redirect URLs allow-list, or
/// GoTrue silently falls back to Site URL instead of rejecting the call.
///
/// 17 Aug 2026: changed from the Flutter web build (nagarva.netlify.app,
/// set 16 Aug 2026 when this session's own read of link.nagarva.in found
/// a 404 at root — that read was of a pre-deploy state) to link.nagarva.in
/// now that its relay page is confirmed live: renders "Email confirmed"
/// and forwards the full URL fragment to `nagarva://auth-callback`
/// (AndroidManifest.xml's intent-filter, handled by
/// backend/auth_deep_link.dart) — the actual trigger for this app's
/// native auto-login path. Not [kPublicBaseUrl] — that constant is for
/// customer-facing shareable links (survey/quote/track), a separate
/// concern that happens to be hosted on the same domain.
///
/// 17 Aug 2026 (later): moved from the domain root to `/auth` — link.
/// nagarva.in turned out to be serving the Flutter *web build* of this
/// repo (the `/survey`, `/sign`, `/track` public routes), and a
/// drag-drop deploy of just this relay page had silently replaced the
/// whole site, taking those three routes down. Restored as: Flutter web
/// build at root, this static relay page moved to `web/auth/index.html`
/// (copied verbatim, unchanged) so it coexists — see `web/_redirects`.
/// The Supabase Auth "Site URL" and Redirect URLs allow-list both need
/// this exact `/auth` path, not the bare domain, or GoTrue either
/// rejects the redirect or silently falls back to Site URL and a
/// confirmation link lands on the Flutter SPA instead of this page.
///
/// Keep supabase/functions/admin-reset-owner-password/index.ts's
/// RESET_REDIRECT_TO in sync — same value by convention, can't share the
/// literal across Dart/Deno.
const String kAuthRedirectUrl = 'https://link.nagarva.in/auth';

/// Builds a customer-facing shareable link.
///
/// [path] is a route path with a leading slash (e.g. `/survey`), matching
/// the public route prefixes registered in `lib/flutter_flow/nav/nav.dart`.
///
/// Use this rather than string-concatenating [kPublicBaseUrl] at each call
/// site, so trailing-slash handling and query encoding stay consistent.
String buildPublicLink(
  String path, {
  Map<String, String> params = const {},
}) {
  final base = kPublicBaseUrl.endsWith('/')
      ? kPublicBaseUrl.substring(0, kPublicBaseUrl.length - 1)
      : kPublicBaseUrl;
  final normalizedPath = path.startsWith('/') ? path : '/$path';
  if (params.isEmpty) return '$base$normalizedPath';
  final query = params.entries
      .map((e) =>
          '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}')
      .join('&');
  return '$base$normalizedPath?$query';
}

/// Convenience wrapper for the token-keyed public links (survey, quote,
/// sign, track) — they all share the `?token=<token>` shape.
String buildTokenLink(String path, String token) =>
    buildPublicLink(path, params: {'token': token});

/// Has `supabase/20260908_quotations_survey_id_fk_repoint.sql` been run?
///
/// `quotations.survey_id`'s foreign key targeted `customer_surveys` — a
/// table with no writer and no rows — while every survey the product
/// creates lands in `surveys`. So the column was structurally impossible
/// to populate: any id worth writing would have violated the constraint,
/// which is why it has never been non-null on any row.
///
/// Ships FALSE, and stays false until that migration is live. **Writing
/// survey_id before the FK is repointed makes every quote-from-survey
/// save fail with a foreign-key violation** — the quote is lost and the
/// surveyor is standing in a customer's flat. Flip it, ship a build, and
/// only then does the link start being recorded.
///
/// Deliberately a compile-time flag rather than a runtime probe: asking
/// Postgres about its own constraints on every quote save costs a round
/// trip to answer a question whose answer changes once, ever.
// RUN 8 Sept 2026. The migration's postflight asserts, inside the same
// transaction, that the constraint's confrelid resolves to `surveys` and
// that the delete action is SET NULL — so a clean commit IS the
// verification, and a failure would have rolled the whole thing back
// rather than leaving a half-applied FK.
const bool kQuotationSurveyIdFkRepointed = true;

/// Has `supabase/20260908_next_order_id_allocator.sql` been run?
///
/// Order ids were allocated by read-modify-write from the device across
/// two round trips with no lock, in four identical copies. The allocator
/// moves that into `next_order_id()`, which uses the same
/// SELECT ... FOR UPDATE shape on `number_series` as every other numbered
/// document in the product.
///
/// While false, `OrderIdAllocator.next()` THROWS rather than falling back
/// to the old path — a fallback would reintroduce the race exactly when
/// the RPC is failing and retries are most likely.
///
/// **Flip this only after the migration is confirmed committed IN THE
/// DATABASE, by querying the database.** "The file is ready", "the
/// migration ran" and "the objects exist" are three different states.
/// A clean postflight proves the migration was correct WHEN IT RAN; it
/// proves nothing about whether it ran.
///
/// That is not theoretical. This was set true once on 8 Sept 2026 on the
/// strength of a message saying the migration had run. It had not — it
/// had aborted in its own preflight on a 42803 — and because there is
/// deliberately no fallback path, order creation broke in every org,
/// including a live business.
///
/// TRUE since 8 Sept 2026, verified by direct query rather than by
/// report: `next_order_id` exists and is SECURITY INVOKER,
/// `number_series_key_uniq` exists and is unique, all three orgs have
/// exactly one order counter with `fy IS NULL` / `branch IS NULL` /
/// `active`, anon has EXECUTE on none of the three allocators while
/// `authenticated` and `service_role` retain theirs, and
/// `next_doc_number` carries the `doc_type='order'` guard.
const bool kServerSideOrderIds = true;

/// `expenses.payment_mode` (supabase/20261021_expenses_payment_mode.sql).
/// FALSE until that migration is confirmed live BY QUERY — not on a
/// report that it ran. While false, Quick Expense does not show or send
/// "Paid by", because writing a column that does not exist fails the
/// whole expense insert (the kServerSideOrderIds lesson, 8 Sept 2026).
/// Cash book reads it either way and says so when it is missing.
// LIVE 21 Oct 2026: column + check constraint confirmed by query.
const bool kExpensePaymentModeLive = true;

/// `staff_leaves` / `staff_incentives`
/// (supabase/20261021_staff_leave_and_incentives.sql). FALSE until both
/// tables are confirmed live by query. While false, Leave and Overtime &
/// incentives say what is missing instead of failing on a 42P01.
// LIVE 21 Oct 2026: both tables, RLS and the four command policies
// confirmed by query; readable as a real member.
const bool kStaffLeaveIncentivesLive = true;

/// WhatsApp through each vendor's own Meta Cloud API number
/// (supabase/20261021_whatsapp_cloud_api.sql + the `whatsapp` and
/// `whatsapp-webhook` Edge Functions). FALSE until the tables are
/// confirmed live by query AND both functions are deployed. While false,
/// the WhatsApp screens say what is missing and every send falls back to
/// opening WhatsApp on the phone, exactly as before.
// LIVE 21 Oct 2026: tables, Vault wrappers (service_role only), RLS and
// column grants confirmed by query; `whatsapp` and `whatsapp-webhook`
// deployed and ACTIVE. Not yet exercised against Meta.
const bool kWhatsAppCloudLive = true;

/// Canonical legal URLs, used by BOTH the signup agreement checkbox and
/// Settings → Help & About.
///
/// Moved here 18 Aug 2026 when Help & About was built — they were
/// top-level consts in `signup_page_widget.dart`, and duplicating them
/// into a second screen would have meant two places to update when a URL
/// changes. `kSignupTermsUrl`/`kSignupPrivacyUrl` still exist there as
/// aliases so the signup screen's own code reads unchanged.
///
/// Confirmed live 12 Aug 2026: bare `nagarva.in/terms` 301s to the `www`
/// host on Netlify. The redirect works, but Arun gave the `www` URLs as
/// canonical, so these point straight at them rather than taking the hop.
///
/// **Play Store requires the privacy policy be reachable IN-APP**, not
/// merely linked from the store listing — that requirement is why Help &
/// About exists at all, alongside Meta's WhatsApp Business review asking
/// for support contact details. Two external approvals depend on this
/// screen; don't remove either link.
const String kTermsUrl = 'https://www.nagarva.in/terms';
const String kPrivacyPolicyUrl = 'https://www.nagarva.in/privacy-policy';

/// App version shown in Help & About.
///
/// Deliberately NOT `package_info_plus` — that would be a new dependency,
/// and this project pins exact versions FlutterFlow-style with a pinned
/// SDK (see CLAUDE.md's environment rules), so adding one is never
/// casual. Instead this follows the same `--dart-define` pattern
/// [kPublicBaseUrl] above already uses:
///
///   flutter build apk --release --dart-define=NAGARVA_APP_VERSION=1.0.1+4
///
/// The default tracks `pubspec.yaml`'s `version:` field and must be
/// bumped with it — a release built without the define shows this
/// string, so a stale default is a wrong version number in front of a
/// vendor, not a crash.
const String kAppVersion = String.fromEnvironment(
  'NAGARVA_APP_VERSION',
  defaultValue: '1.0.0+1',
);

/// One-line positioning used on Help & About and anywhere else the
/// product introduces itself.
const String kNagarvaTagline =
    'Industry ERP for packers & movers — jobs, fleet, staff and GST '
    'billing in one place.';

/// Nagarva's own support line — the PLATFORM's number, not a tenant's.
///
/// **Currently empty on purpose.** Arun is setting up a dedicated
/// WhatsApp Business line (18 Aug 2026), deliberately separate from APC's
/// customer line: Nagarva is pan-India, so lapsed-trial contact arrives
/// at any hour and must not land on the mover's own business phone. Until
/// he hands the number over, every consumer below must degrade to plain
/// text with **no dead button** — a contact affordance that goes nowhere
/// is worse than none, especially for a vendor whose trial just ended.
///
/// Guard every use with [hasNagarvaSupportPhone] rather than testing the
/// string inline, so switching it on is one edit here and nothing else.
///
/// WHERE THIS IS (OR WILL BE) NEEDED — keep this list current, the whole
/// point is that wiring the number is one change, not a hunt:
///   1. `plan_page_widget.dart` — the activation CTA. Live text today,
///      becomes a "Chat with support" WhatsApp button. **Built and
///      waiting; see the comment at that call site.**
///   2. Settings → Help / About — this section does not exist yet
///      (grepped 18 Aug 2026: no About, Help or Support entry anywhere
///      in `settings_page_widget.dart`). It needs building, and the
///      support number is the reason to build it: support contact, app
///      version, and the privacy-policy link Phase 5 requires for the
///      Play Store and the Meta/WhatsApp API review.
///   3. The signup confirmation email — NOT in this repo. It's a Supabase
///      Auth email template, edited in the Dashboard under
///      Authentication → Email Templates, so it needs updating there by
///      hand rather than in code. Noted here because it's the easiest
///      one to forget precisely because it isn't a file.
///   4. The trial banner in `main.dart` (`_withTrialBanner`) currently
///      routes to PlanPage, which is correct — it should keep doing that
///      rather than opening WhatsApp directly, so there's one place a
///      vendor learns what their plan is and how to change it.
const String kNagarvaSupportPhone = '';

/// True once [kNagarvaSupportPhone] is set. Every support-contact
/// affordance in the app is gated on this.
bool get hasNagarvaSupportPhone => kNagarvaSupportPhone.trim().isNotEmpty;

/// Builds a `wa.me` deep link that opens WhatsApp with [message]
/// pre-filled (fix brief #2, items 3 and 6 — "WhatsApp-first" sharing).
///
/// [phone] may be in any local format; non-digits are stripped and a bare
/// 10-digit Indian number gets a 91 country code, since that is what the
/// app's own phone fields hold. Pass null to open the WhatsApp share
/// sheet with no recipient chosen.
///
/// Note this is the plain consumer-app deep link, deliberately NOT the
/// AiSensy Business API — CLAUDE.md's Phase 4 rule is that AiSensy is
/// only ever called from a Supabase Edge Function so the API key never
/// ships in the APK. This just opens the user's own WhatsApp.
String buildWhatsAppLink({String? phone, required String message}) {
  final encoded = Uri.encodeComponent(message);
  final digits = (phone ?? '').replaceAll(RegExp(r'\D'), '');
  if (digits.isEmpty) return 'https://wa.me/?text=$encoded';
  final withCode = digits.length == 10 ? '91$digits' : digits;
  return 'https://wa.me/$withCode?text=$encoded';
}

// ---------------------------------------------------------------------------
// Which public pages are ACTUALLY HOSTED on kPublicBaseUrl
// ---------------------------------------------------------------------------
//
// The app can mint a token link for four customer-facing paths, but
// link.nagarva.in only serves some of them. A button that hands a
// customer a dead link is the same class of trust damage as the invented
// demo data was — the vendor looks incompetent in front of their own
// customer, and they cannot tell it was our fault.
//
// So these flags gate the SHARE AFFORDANCE, not the code behind it. The
// pages and token plumbing are built and correct; they are simply not
// hosted yet. Nobody should delete SurveyPage/QuotePage/SignPage/
// TrackPage on the strength of these being false.
//
// Flip to true the moment the corresponding page is live, and verify by
// opening a real token link in a browser first — not by reading the
// deploy log.
//
// Status, 3 Sept 2026 — VERIFIED BY FETCHING ALL FOUR PATHS, not read
// from the previous note. Every one of them now returns a holding page
// headed "Link unavailable":
//
//   /survey — "Link unavailable"  (was recorded as hosted on 19 Aug)
//   /sign   — "Link unavailable"  (was recorded as hosted on 19 Aug)
//   /quote  — never hosted by anything, at any point
//   /track  — never deployed
//
// So survey and sign were flipped to FALSE. They were marked true, which
// meant the app was handing customers survey and signature links that
// land on a dead page — the precise trust damage the comment above warns
// about, live, today. The holding page is at least honest ("nothing is
// wrong on your side"), which is far better than the "Email confirmed"
// relay that used to answer every path, but it is not a working link.
//
// The signature one has a second consequence worth stating: the remote
// customer-signature path is the only way a customer signs WITHOUT being
// present. With it down, in-app capture on the Documents section is the
// only route to a signed document.
//
// Flip back the moment a real token link opens the real page in a
// browser — verified that way, not from a deploy log.
const bool kSurveyLinkHosted = true;
const bool kSignLinkHosted = true;
const bool kQuoteLinkHosted = false;
/// True since 7 Sept 2026: /track serves the customer document hub
/// (status timeline, issued documents as downloads, rate-the-move and
/// report-a-problem), deployed from `public_site/track/`.
///
/// Verified the way this file's own convention demands - by opening a
/// real token link in a browser and downloading the invoice, not by
/// reading a deploy log.
const bool kTrackLinkHosted = true;
