import 'package:flutter/material.dart';
import '/app_session.dart';
import 'support_tickets_page.dart';

import '/components/ng_top_bar.dart';
import '/components/ng_widgets.dart';
import 'package:url_launcher/url_launcher.dart';

import '/config/app_config.dart';
import '/flutter_flow/ng_tokens.dart';

/// Settings → Help & About (18 Aug 2026).
///
/// **This screen is a launch blocker, not a nicety.** Two external
/// approvals depend on it:
///   - **Play Store** requires the privacy policy to be reachable
///     IN-APP, not merely linked from the store listing.
///   - **Meta's WhatsApp Business API review** asks for support contact
///     details to be discoverable in the product.
/// Neither existed anywhere in the app before this — grepped 18 Aug
/// 2026: no About, Help or Support entry in `settings_page_widget.dart`.
///
/// Built with no new dependencies, per instruction: `url_launcher` was
/// already a dependency (the signup screen opens the same two legal
/// links with it), and the version string comes from a `--dart-define`
/// rather than `package_info_plus` — see [kAppVersion] for why adding a
/// package here is not casual in this pinned-SDK project.
///
/// The support row is gated on [hasNagarvaSupportPhone] and simply does
/// not render until Arun hands over the dedicated WhatsApp Business
/// number. That is deliberate: a contact affordance that goes nowhere is
/// worse than none, which is the same call made on PlanPage's CTA.
class HelpAboutPage extends StatelessWidget {
  const HelpAboutPage({super.key});

  static String routeName = 'HelpAboutPage';
  static String routePath = '/help-about';

  Future<void> _open(BuildContext context, String url) async {
    final ok = await launchUrl(
      Uri.parse(url),
      mode: LaunchMode.externalApplication,
    );
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open $url')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ng = NgPalette.of(context);
    return Scaffold(
      backgroundColor: ng.bg,
      appBar: const NgTopBar(),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
        children: [
          const NgModuleHeader('Help & support'),
          const SizedBox(height: 18),
          // ---- Branding ------------------------------------------------
          Center(
            child: Column(
              children: [
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    color: ng.acc.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(Icons.local_shipping,
                      size: 32, color: ng.acc),
                ),
                const SizedBox(height: 12),
                Text('Nagarva',
                    style: NgFonts.geist(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: ng.text)),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    kNagarvaTagline,
                    textAlign: TextAlign.center,
                    style: NgFonts.geist(
                        fontSize: 12.5,
                        height: 1.45,
                        color: ng.mute),
                  ),
                ),
                const SizedBox(height: 10),
                Text('Version $kAppVersion',
                    style: NgFonts.geist(
                        fontSize: 12, color: ng.mute)),
              ],
            ),
          ),
          const SizedBox(height: 28),

          // ---- Support -------------------------------------------------
          // Hidden entirely until the number exists — see the class doc.
          if (hasNagarvaSupportPhone) ...[
            _sectionLabel(ng, 'Support'),
            _card(ng, [
              _row(
                ng,
                icon: Icons.chat_bubble_outline,
                title: 'Chat with support',
                subtitle: kNagarvaSupportPhone,
                onTap: () => _open(
                  context,
                  buildWhatsAppLink(
                    phone: kNagarvaSupportPhone,
                    message: 'Hi Nagarva support, I need help with my account.',
                  ),
                ),
              ),
              _divider(ng),
              _row(
                ng,
                icon: Icons.call_outlined,
                title: 'Call support',
                subtitle: kNagarvaSupportPhone,
                onTap: () => _open(context, 'tel:$kNagarvaSupportPhone'),
              ),
            ]),
            const SizedBox(height: 22),
          ],

          // ---- Ask Nagarva (support tickets) ---------------------------
          // Works without the support phone: it is a ticket the Nagarva
          // team answers in the admin panel, replies shown in the app.
          if (AppSession.instance.currentOrgId != null) ...[
            _sectionLabel(ng, 'Ask Nagarva'),
            _card(ng, [
              _row(
                ng,
                icon: Icons.support_agent_rounded,
                title: 'Questions & replies',
                subtitle: 'Write to Nagarva support',
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const SupportTicketsPage())),
              ),
            ]),
            const SizedBox(height: 22),
          ],

          // ---- Legal ---------------------------------------------------
          _sectionLabel(ng, 'Legal'),
          _card(ng, [
            _row(
              ng,
              icon: Icons.privacy_tip_outlined,
              title: 'Privacy Policy',
              onTap: () => _open(context, kPrivacyPolicyUrl),
            ),
            _divider(ng),
            _row(
              ng,
              icon: Icons.description_outlined,
              title: 'Terms of Service',
              onTap: () => _open(context, kTermsUrl),
            ),
          ]),

          const SizedBox(height: 26),
          Center(
            child: Text(
              '© ${DateTime.now().year} Nagarva',
              style:
                  NgFonts.geist(fontSize: 11.5, color: ng.mute),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(NgPalette ng, String text) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(
          text.toUpperCase(),
          style: NgFonts.geist(
            fontSize: 11.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.6,
            color: ng.mute,
          ),
        ),
      );

  Widget _card(NgPalette ng, List<Widget> children) => Container(
        decoration: BoxDecoration(
          color: ng.s1,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(children: children),
      );

  Widget _divider(NgPalette ng) => Divider(
        height: 1,
        thickness: 1,
        indent: 52,
        color: ng.bg,
      );

  Widget _row(
    NgPalette ng, {
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) =>
      ListTile(
        leading: Icon(icon, size: 21, color: ng.acc),
        title: Text(title,
            style: NgFonts.geist(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: ng.text)),
        subtitle: subtitle == null
            ? null
            : Text(subtitle,
                style: NgFonts.geist(
                    fontSize: 12, color: ng.mute)),
        trailing: Icon(Icons.open_in_new, size: 16, color: ng.mute),
        onTap: onTap,
      );
}
