import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'new_lead_page_widget.dart' show NewLeadPageWidget;
import 'package:flutter/material.dart';

class NewLeadPageModel extends FlutterFlowModel<NewLeadPageWidget> {
  ///  Local state fields for this page.

  String? ldService = '';

  String? ldStatus = 'new';

  String? ldSource = '';

  // No hardcoded default — was the literal 'Bengaluru', the same
  // APC-shaped-default bug as New Order's old ordBranch (see
  // new_order_page_model.dart). Set in
  // _NewLeadPageWidgetState._loadBranches().
  String? ldBranch;

  /// This org's active branch names, role-restricted for a non-owner
  /// session — see new_order_page_widget.dart's _loadBranches() for the
  /// identical pattern this mirrors.
  List<String> availableBranches = [];
  bool branchesLoaded = false;
  bool orgHasAnyBranches = true;

  /// Set when the branch query itself FAILED, as distinct from the org
  /// genuinely having no branches.
  ///
  /// Added 3 Sept 2026. `_loadBranches()` had no try/catch, so any
  /// failure left `availableBranches` empty and `branchesLoaded` false
  /// with nothing shown anywhere. Branch is MANDATORY, so the vendor got
  /// an unopenable dropdown and, on save, "Select a branch first" -
  /// blaming them for a load that had silently died. Reproduced live in
  /// APC Bengaluru right after an in-app org switch: the org had an
  /// active Head Office the whole time, and a page reload fixed it.
  ///
  /// Same failure shape as the Materials/Users/Fleet hangs fixed on
  /// 7 Aug 2026 - an unguarded primary query that leaves the screen
  /// looking empty rather than broken.
  String? branchLoadError;


  bool? ldSaveSuccess = false;

  DateTime? ldApproxDate;

  bool? ldApproxDatePicked = false;

  ///  State fields for stateful widgets in this page.

  // State field(s) for LdCustomerField widget.
  FocusNode? ldCustomerFieldFocusNode;
  TextEditingController? ldCustomerFieldTextController;
  String? Function(BuildContext, String?)?
      ldCustomerFieldTextControllerValidator;
  // State field(s) for LdPhoneField widget.
  FocusNode? ldPhoneFieldFocusNode;
  TextEditingController? ldPhoneFieldTextController;
  String? Function(BuildContext, String?)? ldPhoneFieldTextControllerValidator;
  // State field(s) for LdEmailField widget.
  FocusNode? ldEmailFieldFocusNode;
  TextEditingController? ldEmailFieldTextController;
  String? Function(BuildContext, String?)? ldEmailFieldTextControllerValidator;
  // State field(s) for LdFromCityField widget.
  FocusNode? ldFromCityFieldFocusNode;
  TextEditingController? ldFromCityFieldTextController;
  String? Function(BuildContext, String?)?
      ldFromCityFieldTextControllerValidator;
  // State field(s) for LdToCityField widget.
  FocusNode? ldToCityFieldFocusNode;
  TextEditingController? ldToCityFieldTextController;
  String? Function(BuildContext, String?)? ldToCityFieldTextControllerValidator;
  DateTime? datePicked;
  // State field(s) for LdServiceDropdown widget.
  String? ldServiceDropdownValue;
  FormFieldController<String>? ldServiceDropdownValueController;
  // State field(s) for LdStatusDropdown widget.
  String? ldStatusDropdownValue;
  FormFieldController<String>? ldStatusDropdownValueController;
  // State field(s) for LdSourceDropdown widget.
  String? ldSourceDropdownValue;
  FormFieldController<String>? ldSourceDropdownValueController;
  // State field(s) for LdBranchDropdown widget.
  String? ldBranchDropdownValue;
  FormFieldController<String>? ldBranchDropdownValueController;
  // State field(s) for LdNotesField widget.
  FocusNode? ldNotesFieldFocusNode;
  TextEditingController? ldNotesFieldTextController;
  String? Function(BuildContext, String?)? ldNotesFieldTextControllerValidator;
  // Stores action output result for [Backend Call - Insert Row] action in SaveLeadBtn widget.
  LeadsRow? createdLead;

  // Edit-mode support: when NewLeadPageWidget.leadId is set, the page loads
  // the existing lead here instead of starting from the field defaults
  // above, and the save button updates that row instead of inserting a
  // new one. Fixes LeadDetailPage's "Edit Lead" button, which previously
  // navigated here with no way to load the lead it was meant to edit —
  // see CLAUDE.md.
  bool isLoadingExisting = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    ldCustomerFieldFocusNode?.dispose();
    ldCustomerFieldTextController?.dispose();

    ldPhoneFieldFocusNode?.dispose();
    ldPhoneFieldTextController?.dispose();

    ldEmailFieldFocusNode?.dispose();
    ldEmailFieldTextController?.dispose();

    ldFromCityFieldFocusNode?.dispose();
    ldFromCityFieldTextController?.dispose();

    ldToCityFieldFocusNode?.dispose();
    ldToCityFieldTextController?.dispose();

    ldNotesFieldFocusNode?.dispose();
    ldNotesFieldTextController?.dispose();
  }
}
